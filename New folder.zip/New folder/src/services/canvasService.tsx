
import { nanoid } from 'nanoid';
import { LibraryComponent } from './componentLibraryService';

export interface CanvasComponent extends LibraryComponent {
  position?: { x: number; y: number };
  rotation?: number;
  zIndex?: number;
  locked?: boolean;
}

export interface CanvasState {
  components: CanvasComponent[];
  selectedComponentId: string | null;
  history: CanvasComponent[][];
  historyIndex: number;
  gridEnabled: boolean;
  snapToGrid: boolean;
  gridSize: number;
  viewportZoom: number;
  viewportOffset: { x: number; y: number };
}

const initialCanvasState: CanvasState = {
  components: [],
  selectedComponentId: null,
  history: [],
  historyIndex: -1,
  gridEnabled: true,
  snapToGrid: true,
  gridSize: 8,
  viewportZoom: 1,
  viewportOffset: { x: 0, y: 0 },
};

// Helper functions for canvas operations
export const addComponentToCanvas = (
  canvasState: CanvasState,
  component: LibraryComponent,
  position?: { x: number; y: number }
): CanvasState => {
  const newComponent: CanvasComponent = {
    ...component,
    id: `${component.id}-${nanoid(6)}`,
    position: position || { x: 100, y: 100 },
    zIndex: canvasState.components.length,
  };

  const newComponents = [...canvasState.components, newComponent];
  const newHistory = [...canvasState.history.slice(0, canvasState.historyIndex + 1), [...newComponents]];

  return {
    ...canvasState,
    components: newComponents,
    selectedComponentId: newComponent.id,
    history: newHistory,
    historyIndex: newHistory.length - 1,
  };
};

export const removeComponentFromCanvas = (
  canvasState: CanvasState,
  componentId: string
): CanvasState => {
  const newComponents = canvasState.components.filter(c => c.id !== componentId);
  const newHistory = [...canvasState.history.slice(0, canvasState.historyIndex + 1), [...newComponents]];

  return {
    ...canvasState,
    components: newComponents,
    selectedComponentId: null,
    history: newHistory,
    historyIndex: newHistory.length - 1,
  };
};

export const updateComponentPosition = (
  canvasState: CanvasState,
  componentId: string,
  position: { x: number; y: number }
): CanvasState => {
  const newComponents = canvasState.components.map(component => {
    if (component.id === componentId) {
      return { ...component, position };
    }
    return component;
  });

  return { ...canvasState, components: newComponents };
};

export const updateComponentProperty = (
  canvasState: CanvasState,
  componentId: string,
  property: string,
  value: any
): CanvasState => {
  const newComponents = canvasState.components.map(component => {
    if (component.id === componentId) {
      if (property.startsWith('props.')) {
        const propKey = property.substring(6);
        return {
          ...component,
          props: { ...component.props, [propKey]: value }
        };
      } else if (property.startsWith('style.')) {
        const styleKey = property.substring(6);
        return {
          ...component,
          style: { ...component.style, [styleKey]: value }
        };
      } else {
        return { ...component, [property]: value };
      }
    }
    return component;
  });

  const newHistory = [...canvasState.history.slice(0, canvasState.historyIndex + 1), [...newComponents]];

  return {
    ...canvasState,
    components: newComponents,
    history: newHistory,
    historyIndex: newHistory.length - 1,
  };
};

export const selectComponent = (
  canvasState: CanvasState,
  componentId: string | null
): CanvasState => {
  return { ...canvasState, selectedComponentId: componentId };
};

export const toggleGrid = (canvasState: CanvasState): CanvasState => {
  return { ...canvasState, gridEnabled: !canvasState.gridEnabled };
};

export const toggleSnapToGrid = (canvasState: CanvasState): CanvasState => {
  return { ...canvasState, snapToGrid: !canvasState.snapToGrid };
};

export const undo = (canvasState: CanvasState): CanvasState => {
  if (canvasState.historyIndex <= 0) return canvasState;
  
  const newIndex = canvasState.historyIndex - 1;
  return {
    ...canvasState,
    components: [...canvasState.history[newIndex]],
    historyIndex: newIndex,
  };
};

export const redo = (canvasState: CanvasState): CanvasState => {
  if (canvasState.historyIndex >= canvasState.history.length - 1) return canvasState;
  
  const newIndex = canvasState.historyIndex + 1;
  return {
    ...canvasState,
    components: [...canvasState.history[newIndex]],
    historyIndex: newIndex,
  };
};

export const saveCanvasState = (canvasState: CanvasState): CanvasState => {
  const newHistory = [...canvasState.history.slice(0, canvasState.historyIndex + 1), [...canvasState.components]];
  
  return {
    ...canvasState,
    history: newHistory,
    historyIndex: newHistory.length - 1,
  };
};

export { initialCanvasState };
