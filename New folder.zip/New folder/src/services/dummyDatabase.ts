import { User } from "@/types/user";

export interface ForumPost {
  id: string;
  title: string;
  content: string;
  author: User;
  timestamp: string;
  tags: string[];
  likes: number;
  replies: number;
  isLiked: boolean;
  isBookmarked: boolean;
}

export interface Resource {
  id: string;
  title: string;
  description: string;
  type: 'template' | 'guide' | 'code' | 'video' | 'dataset';
  tags: string[];
  author: User;
  thumbnailUrl?: string;
  downloadUrl: string;
  downloadCount: number;
  likes: number;
  isLiked: boolean;
  createdAt: string;
}

export interface ContentReviewItem {
  id: string;
  title: string;
  content: string;
  type: 'post' | 'comment' | 'resource' | 'agent' | 'workflow';
  author: User;
  timestamp: string;
  status: 'pending' | 'approved' | 'rejected';
  reportCount?: number;
  reportReasons?: string[];
}

const users: User[] = [
  {
    id: "1",
    name: "Alex Rivera",
    email: "alex@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alex",
  },
  {
    id: "2",
    name: "Emma Wilson",
    email: "emma@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Emma",
  },
  {
    id: "3",
    name: "Michael Chen",
    email: "michael@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Michael",
  },
  {
    id: "4",
    name: "Sarah Johnson",
    email: "sarah@example.com",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah",
  }
];

const dummyPosts: ForumPost[] = [
  {
    id: "post-1",
    title: "Best practices for prompt engineering?",
    content: "I've been working with large language models and I'm wondering what are some of the best practices for prompt engineering that you've found effective?",
    author: {
      ...users[0],
      role: "Official"
    },
    timestamp: "2 hours ago",
    tags: ["prompt-engineering", "llm", "ai"],
    likes: 24,
    replies: 8,
    isLiked: false,
    isBookmarked: true
  },
  {
    id: "post-2",
    title: "Handling API rate limits in production",
    content: "Our team is running into API rate limits with OpenAI. How are you handling this in production environments? Any tips on efficient token usage?",
    author: users[1],
    timestamp: "5 hours ago",
    tags: ["api", "rate-limits", "production"],
    likes: 18,
    replies: 12,
    isLiked: true,
    isBookmarked: false
  },
  {
    id: "post-3",
    title: "Integrating vector databases with LangGraph",
    content: "I'm trying to integrate a vector database with my LangGraph workflow. Has anyone done this successfully? Looking for examples or best practices.",
    author: users[2],
    timestamp: "1 day ago",
    tags: ["vector-db", "langgraph", "integration"],
    likes: 32,
    replies: 15,
    isLiked: false,
    isBookmarked: false
  }
];

const dummyResources: Resource[] = [
  {
    id: "resource-1",
    title: "AI Agent Development Framework",
    description: "A comprehensive framework for building autonomous AI agents with customizable behaviors.",
    type: "template",
    tags: ["agent", "framework", "development"],
    author: users[0],
    thumbnailUrl: "https://placehold.co/600x400/412284/FFFFFF/png?text=Agent+Framework",
    downloadUrl: "#",
    downloadCount: 235,
    likes: 48,
    isLiked: false,
    createdAt: "2024-02-15"
  },
  {
    id: "resource-2",
    title: "LLM Prompt Engineering Guide",
    description: "A detailed guide to crafting effective prompts for large language models with examples and best practices.",
    type: "guide",
    tags: ["llm", "prompt-engineering", "tutorial"],
    author: users[1],
    thumbnailUrl: "https://placehold.co/600x400/224283/FFFFFF/png?text=Prompt+Guide",
    downloadUrl: "#",
    downloadCount: 367,
    likes: 92,
    isLiked: true,
    createdAt: "2024-03-05"
  },
  {
    id: "resource-3",
    title: "Vector Database Integration Code",
    description: "Sample code for integrating vector databases with LangGraph workflows for improved context handling.",
    type: "code",
    tags: ["vector-db", "code", "langgraph"],
    author: users[2],
    downloadUrl: "#",
    downloadCount: 189,
    likes: 37,
    isLiked: false,
    createdAt: "2024-03-22"
  },
  {
    id: "resource-4",
    title: "AI Ethics in Development",
    description: "A video course covering the ethical considerations when developing AI applications and agents.",
    type: "video",
    tags: ["ethics", "course", "ai-development"],
    author: users[3],
    thumbnailUrl: "https://placehold.co/600x400/284122/FFFFFF/png?text=AI+Ethics",
    downloadUrl: "#",
    downloadCount: 415,
    likes: 73,
    isLiked: false,
    createdAt: "2024-01-30"
  }
];

const dummyReviewItems: ContentReviewItem[] = [
  {
    id: "review-1",
    title: "New AI Agent Submission",
    content: "I've created a new AI agent for text summarization that works with multiple languages.",
    type: "agent",
    author: users[2],
    timestamp: "2 hours ago",
    status: "pending",
  },
  {
    id: "review-2",
    title: "Community Post Flagged",
    content: "This post contains potentially misleading information about AI capabilities.",
    type: "post",
    author: users[1],
    timestamp: "5 hours ago",
    status: "pending",
    reportCount: 3,
    reportReasons: ["Misinformation", "Misleading"]
  },
  {
    id: "review-3",
    title: "New Workflow Template",
    content: "A workflow for automated document processing and summarization.",
    type: "workflow",
    author: users[3],
    timestamp: "1 day ago",
    status: "pending",
  }
];

export const dummyDatabase = {
  getPosts: async (): Promise<ForumPost[]> => {
    await new Promise(resolve => setTimeout(resolve, 800));
    return [...dummyPosts];
  },
  
  addPost: async (content: string): Promise<ForumPost> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const newPost: ForumPost = {
      id: `post-${Date.now()}`,
      title: content.split("\n")[0] || "New Discussion",
      content,
      author: users[0],
      timestamp: "Just now",
      tags: ["community"],
      likes: 0,
      replies: 0,
      isLiked: false,
      isBookmarked: false
    };
    
    dummyPosts.unshift(newPost);
    return newPost;
  },
  
  toggleLike: async (postId: string): Promise<void> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const post = dummyPosts.find(p => p.id === postId);
    if (post) {
      post.isLiked = !post.isLiked;
      post.likes += post.isLiked ? 1 : -1;
    }
  },
  
  toggleBookmark: async (postId: string): Promise<void> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const post = dummyPosts.find(p => p.id === postId);
    if (post) {
      post.isBookmarked = !post.isBookmarked;
    }
  },
  
  getResources: async (): Promise<Resource[]> => {
    await new Promise(resolve => setTimeout(resolve, 800));
    return [...dummyResources];
  },
  
  toggleResourceLike: async (resourceId: string): Promise<void> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const resource = dummyResources.find(r => r.id === resourceId);
    if (resource) {
      resource.isLiked = !resource.isLiked;
      resource.likes += resource.isLiked ? 1 : -1;
    }
  },
  
  incrementResourceDownload: async (resourceId: string): Promise<void> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const resource = dummyResources.find(r => r.id === resourceId);
    if (resource) {
      resource.downloadCount += 1;
    }
  },

  getReviewItems: async (): Promise<ContentReviewItem[]> => {
    await new Promise(resolve => setTimeout(resolve, 800));
    return [...dummyReviewItems];
  },

  approveContent: async (id: string): Promise<void> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const item = dummyReviewItems.find(item => item.id === id);
    if (item) {
      item.status = "approved";
    }
  },

  rejectContent: async (id: string): Promise<void> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const item = dummyReviewItems.find(item => item.id === id);
    if (item) {
      item.status = "rejected";
    }
  }
};
