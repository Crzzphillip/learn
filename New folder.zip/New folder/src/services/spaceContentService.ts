// src/services/spaceContentService.ts

// Types
export interface SpaceContent {
  id: string;
  title: string;
  description?: string;
  type: string;
  image: string;
}

// Constants
export const CONTENT_TYPES = [
  "All",
  "Agents",
  "Workflows", 
  "Workspaces",
  "Apps",
  "Tools",
  "Resources",
  "Community"
] as const;

export type ContentType = (typeof CONTENT_TYPES)[number];

// Helper functions
const getDefaultImage = (type: string) => 
  `https://placehold.co/600x400/232323/FFFFFF/png?text=${type}`;

// Service functions
export const spaceContentService = {
  getContentTypes: () => CONTENT_TYPES,

  formatContent: (
    content: any,
    type: Exclude<ContentType, "All">
  ): SpaceContent => ({
    ...content,
    type,
    image: content.image || getDefaultImage(type)
  }),

  getAllContent: (
    filteredAgents: any[],
    filteredWorkflows: any[],
    filteredApps: any[],
    filteredTools: any[],
    filteredResources: any[],
    trendingWorkspaces: any[]
  ): SpaceContent[] => {
    return [
      ...filteredAgents.map(agent => 
        spaceContentService.formatContent(agent, "Agents")),
      ...filteredWorkflows.map(workflow => 
        spaceContentService.formatContent(workflow, "Workflows")),
      ...filteredApps.map(app => 
        spaceContentService.formatContent(app, "Apps")),
      ...filteredTools.map(tool => 
        spaceContentService.formatContent(tool, "Tools")),
      ...filteredResources.map(resource => 
        spaceContentService.formatContent(resource, "Resources")),
      ...trendingWorkspaces.map(workspace => 
        spaceContentService.formatContent(workspace, "Workspaces"))
    ];
  },

  filterContent: (
    content: SpaceContent[],
    searchQuery: string,
    activeType: ContentType
  ): SpaceContent[] => {
    return content.filter(item => {
      const matchesSearch = !searchQuery || 
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.description && 
         item.description.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesType = activeType === "All" || item.type === activeType;
      
      return matchesSearch && matchesType;
    });
  }
};
