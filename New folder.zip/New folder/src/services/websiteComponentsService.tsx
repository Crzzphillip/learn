
// This file is deprecated - import from the new location instead
import {
  WebsiteComponent,
  componentCategories,
  websiteComponents,
  createComponentInstance,
  findComponentById,
  updateComponentInTree,
  deleteComponentFromTree,
  addComponentToParent,
  moveComponent,
  createInitialComponents
} from './websiteComponents';

export {
  WebsiteComponent,
  componentCategories,
  websiteComponents,
  createComponentInstance,
  findComponentById,
  updateComponentInTree,
  deleteComponentFromTree,
  addComponentToParent,
  moveComponent,
  createInitialComponents
};
