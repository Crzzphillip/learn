
import { jsonDatabaseService } from './jsonDatabaseService';
import { toast } from "sonner";

export interface Category {
  id: string;
  title: string;
  description: string;
  icon: string;
  gradient: string;
  image: string;
}

export interface CategorySpace {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: string;
  rating: string;
  listens: string;
  duration: string;
  image: string;
}

export const categoriesService = {
  // Get all categories
  getAllCategories: async (): Promise<Category[]> => {
    try {
      return await jsonDatabaseService.getAll<Category>('categories');
    } catch (error) {
      console.error("Error fetching categories:", error);
      toast.error("Failed to load categories");
      return [];
    }
  },

  // Get a category by ID
  getCategoryById: async (id: string): Promise<Category | null> => {
    try {
      return await jsonDatabaseService.getById<Category>('categories', id);
    } catch (error) {
      console.error(`Error fetching category ${id}:`, error);
      toast.error("Failed to load category details");
      return null;
    }
  },

  // Get spaces by category ID
  getSpacesByCategoryId: async (categoryId: string): Promise<CategorySpace[]> => {
    try {
      return await jsonDatabaseService.query<CategorySpace>(
        'category_spaces',
        (space) => space.category === categoryId
      );
    } catch (error) {
      console.error(`Error fetching spaces for category ${categoryId}:`, error);
      toast.error("Failed to load category spaces");
      return [];
    }
  },

  // Get all category spaces
  getAllCategorySpaces: async (): Promise<CategorySpace[]> => {
    try {
      return await jsonDatabaseService.getAll<CategorySpace>('category_spaces');
    } catch (error) {
      console.error("Error fetching all category spaces:", error);
      toast.error("Failed to load spaces");
      return [];
    }
  }
};
