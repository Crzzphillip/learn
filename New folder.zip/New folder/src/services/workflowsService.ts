
import { jsonDatabaseService } from './jsonDatabaseService';
import { toast } from "sonner";

export interface Workflow {
  id: string;
  title: string;
  imageUrl: string;
  description: string;
  agents?: string[]; // Make agents optional with an array type
}

export const workflowsService = {
  // Get all workflows
  getAllWorkflows: async (): Promise<Workflow[]> => {
    try {
      return await jsonDatabaseService.getAll<Workflow>('workflows');
    } catch (error) {
      console.error("Error fetching workflows:", error);
      toast.error("Failed to load workflows");
      return [];
    }
  },

  // Get a workflow by ID
  getWorkflowById: async (id: string): Promise<Workflow | null> => {
    try {
      return await jsonDatabaseService.getById<Workflow>('workflows', id);
    } catch (error) {
      console.error(`Error fetching workflow ${id}:`, error);
      toast.error("Failed to load workflow details");
      return null;
    }
  },

  // Create a new workflow
  createWorkflow: async (workflow: Omit<Workflow, 'id'>): Promise<Workflow> => {
    try {
      const newWorkflow = await jsonDatabaseService.create<Workflow>('workflows', workflow);
      toast.success("New workflow created successfully");
      return newWorkflow;
    } catch (error) {
      console.error("Error creating workflow:", error);
      toast.error("Failed to create new workflow");
      throw error;
    }
  },

  // Update a workflow
  updateWorkflow: async (id: string, data: Partial<Workflow>): Promise<Workflow | null> => {
    try {
      const updatedWorkflow = await jsonDatabaseService.update<Workflow>('workflows', id, data);
      if (updatedWorkflow) {
        toast.success("Workflow updated successfully");
      }
      return updatedWorkflow;
    } catch (error) {
      console.error(`Error updating workflow ${id}:`, error);
      toast.error("Failed to update workflow");
      throw error;
    }
  },

  // Delete a workflow
  deleteWorkflow: async (id: string): Promise<boolean> => {
    try {
      const result = await jsonDatabaseService.delete('workflows', id);
      if (result) {
        toast.success("Workflow deleted successfully");
      }
      return result;
    } catch (error) {
      console.error(`Error deleting workflow ${id}:`, error);
      toast.error("Failed to delete workflow");
      throw error;
    }
  }
};
