
import React from 'react';
import { createIcon } from './icons';
import { 
  Layout,
  Box,
  Text,
  FormInput,
  BarChart3,
  Image,
  Navigation,
  ShoppingCart,
  Users,
  Sliders
} from 'lucide-react';

export const componentCategories = [
  { id: 'layout', name: 'Layout', icon: createIcon(Layout) },
  { id: 'basic', name: 'Basic', icon: createIcon(Box) },
  { id: 'text', name: 'Typography', icon: createIcon(Text) },
  { id: 'input', name: 'Form Inputs', icon: createIcon(FormInput) },
  { id: 'data', name: 'Data Display', icon: createIcon(BarChart3) },
  { id: 'media', name: 'Media', icon: createIcon(Image) },
  { id: 'navigation', name: 'Navigation', icon: createIcon(Navigation) },
  { id: 'commerce', name: 'Commerce', icon: createIcon(ShoppingCart) },
  { id: 'social', name: 'Social', icon: createIcon(Users) },
  { id: 'form', name: 'Form Controls', icon: createIcon(Sliders) }
];
