
import React from 'react';
import { Box, Heading, Text, Layout, Image, Link } from 'lucide-react';
import type { 
  ComponentCategory,
  ComponentState,
  ComponentAction,
  LibraryComponent 
} from './types';
import { createIcon } from './icons';

// Component Categories
export const componentCategories: ComponentCategory[] = [
  { id: 'layout', name: 'Layout', icon: createIcon(Layout) },
  { id: 'text', name: 'Typography', icon: createIcon(Text) },
  { id: 'basic', name: 'Basic Elements', icon: createIcon(Box) },
  { id: 'media', name: 'Media', icon: createIcon(Image) },
  { id: 'input', name: 'Forms & Input', icon: createIcon(Link) },
];

// Get the component library
export const getComponentLibrary = (): LibraryComponent[] => {
  return [
    {
      id: 'section-container',
      name: 'Section',
      type: 'section',
      category: 'layout',
      icon: createIcon(Layout),
      iconName: 'Layout',
      isSelectable: true,
      isDraggable: true,
      isDroppable: true,
      props: {
        className: 'w-full p-4'
      },
      style: {
        minHeight: '100px',
        backgroundColor: '#f9fafb'
      },
      children: [],
      description: 'A section container for grouping content'
    },
    {
      id: 'div-container',
      name: 'Container',
      type: 'div',
      category: 'layout',
      icon: createIcon(Box),
      iconName: 'Box',
      isSelectable: true,
      isDraggable: true,
      isDroppable: true,
      props: {
        className: 'container mx-auto p-4'
      },
      style: {
        minHeight: '80px',
      },
      children: [],
      description: 'A flexible container for holding content'
    },
    {
      id: 'heading',
      name: 'Heading',
      type: 'h1',
      category: 'text',
      icon: createIcon(Heading),
      iconName: 'Heading',
      isSelectable: true,
      isDraggable: true,
      isDroppable: false,
      props: {},
      style: {
        fontSize: '24px',
        fontWeight: 'bold',
        marginBottom: '16px'
      },
      content: 'Heading Text',
      description: 'A heading element for titles and sections'
    },
    {
      id: 'paragraph',
      name: 'Paragraph',
      type: 'p',
      category: 'text',
      icon: createIcon(Text),
      iconName: 'Text',
      isSelectable: true,
      isDraggable: true,
      isDroppable: false,
      props: {},
      style: {
        fontSize: '16px',
        lineHeight: '1.5',
        marginBottom: '16px'
      },
      content: 'This is a paragraph of text. You can edit this content to add your own text.',
      description: 'A paragraph for displaying text content'
    },
    {
      id: 'image',
      name: 'Image',
      type: 'img',
      category: 'media',
      icon: createIcon(Image),
      iconName: 'Image',
      isSelectable: true,
      isDraggable: true,
      isDroppable: false,
      props: {
        src: 'https://via.placeholder.com/400x200',
        alt: 'Placeholder image'
      },
      style: {
        maxWidth: '100%',
        height: 'auto',
        marginBottom: '16px'
      },
      description: 'An image element for displaying visual content'
    },
    {
      id: 'link',
      name: 'Link',
      type: 'a',
      category: 'basic',
      icon: createIcon(Link),
      iconName: 'Link',
      isSelectable: true,
      isDraggable: true,
      isDroppable: false,
      props: {
        href: '#',
        target: '_blank'
      },
      style: {
        color: '#3b82f6',
        textDecoration: 'underline',
        cursor: 'pointer'
      },
      content: 'Click here',
      description: 'A link for navigating to other pages or resources'
    },
    {
      id: 'button',
      name: 'Button',
      type: 'button',
      category: 'basic',
      icon: createIcon(Link),
      iconName: 'Link',
      isSelectable: true,
      isDraggable: true,
      isDroppable: false,
      props: {
        className: 'px-4 py-2 bg-blue-500 text-white rounded'
      },
      style: {
        cursor: 'pointer',
        border: 'none',
        display: 'inline-block',
        marginBottom: '16px'
      },
      content: 'Button',
      description: 'A button element for triggering actions'
    }
  ];
};

// Get a specific component by ID
export const getComponentById = (id: string): LibraryComponent | undefined => {
  const components = getComponentLibrary();
  return components.find(component => component.id === id);
};

// Get components by category
export const getComponentsByCategory = (categoryId: string): LibraryComponent[] => {
  const components = getComponentLibrary();
  return components.filter(component => component.category === categoryId);
};
