
import React, { ReactNode } from 'react';
import { LucideIcon } from 'lucide-react';

// Helper function to create an icon component from a Lucide icon
export const createIcon = (Icon: LucideIcon): ReactNode => {
  return React.createElement(Icon, { size: 16 });
};
