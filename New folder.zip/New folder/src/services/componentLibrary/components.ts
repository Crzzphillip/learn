import { LibraryComponent, ComponentState, ComponentAction } from './types';
import { createIcon } from './icons';
import {
  Layout,
  Box,
  Heading,
  Text,
  AlignLeft,
  Code,
  Image,
  Video,
  Link,
  Menu,
  List,
  Table,
  ShoppingCart,
  CheckCircle
} from 'lucide-react';

// Helper to create a ComponentState with required properties
const createComponentState = (id: string, name: string, defaultValue: any, type: string, description?: string): ComponentState => {
  return {
    id,
    name,
    type,
    value: defaultValue, // Initialize value with defaultValue
    defaultValue,
    description
  };
};

// Helper to create a ComponentAction with required properties
const createComponentAction = (id: string, name: string, description: string): ComponentAction => {
  return {
    id,
    name,
    type: 'function', // Default action type
    description
  };
};

export const getComponentLibrary = (): LibraryComponent[] => {
  return [
    // Layout components
    {
      id: 'section',
      type: 'section',
      name: 'Section',
      category: 'layout',
      icon: createIcon(Layout),
      iconName: 'Layout',
      description: 'A full-width section container for grouping content',
      props: {
        id: '',
        className: 'p-6 bg-white w-full'
      },
      style: {
        width: '100%',
        minHeight: '200px',
      },
      isSelectable: true,
      isDraggable: true,
      isDroppable: true,
      children: [],
      states: [
        createComponentState('isVisible', 'Visible', true, 'boolean')
      ],
      actions: [
        createComponentAction('scrollTo', 'Scroll To', 'Scroll to this section')
      ]
    },
    {
      id: 'container',
      type: 'div',
      name: 'Container',
      category: 'layout',
      icon: createIcon(Box),
      iconName: 'Box',
      description: 'A centered container with max width',
      props: {
        id: '',
        className: 'container mx-auto px-4'
      },
      style: {
        maxWidth: '1200px',
        margin: '0 auto',
      },
      isSelectable: true,
      isDraggable: true,
      isDroppable: true,
      children: [],
      states: [
        createComponentState('isVisible', 'Visible', true, 'boolean')
      ],
      actions: []
    },
    {
      id: 'flex-row',
      type: 'div',
      name: 'Flex Row',
      category: 'layout',
      icon: createIcon(Layout),
      iconName: 'Layout',
      description: 'Horizontal flex container for arranging items in a row',
      props: {
        id: '',
        className: 'flex flex-row items-center gap-4'
      },
      style: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        gap: '1rem',
      },
      isSelectable: true,
      isDraggable: true,
      isDroppable: true,
      children: [],
      states: [
        createComponentState('isVisible', 'Visible', true, 'boolean')
      ],
      actions: []
    },
    {
      id: 'flex-col',
      type: 'div',
      name: 'Flex Column',
      category: 'layout',
      icon: createIcon(Layout),
      iconName: 'Layout',
      description: 'Vertical flex container for arranging items in a column',
      props: {
        id: '',
        className: 'flex flex-col gap-4'
      },
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: '1rem',
      },
      isSelectable: true,
      isDraggable: true,
      isDroppable: true,
      children: [],
      states: [
        createComponentState('isVisible', 'Visible', true, 'boolean')
      ],
      actions: []
    },
    
    // Typography components
    {
      id: 'heading',
      type: 'h1',
      name: 'Heading',
      category: 'text',
      icon: createIcon(Heading),
      iconName: 'Heading',
      description: 'A headline text element (h1-h6)',
      props: {
        id: '',
        className: 'text-2xl font-bold'
      },
      content: 'Heading',
      style: {
        fontSize: '1.5rem',
        fontWeight: 'bold',
        marginBottom: '0.5rem',
      },
      isSelectable: true,
      isDraggable: true,
      isDroppable: false,
      states: [
        createComponentState('isVisible', 'Visible', true, 'boolean')
      ],
      actions: []
    },
    {
      id: 'paragraph',
      type: 'p',
      name: 'Paragraph',
      category: 'text',
      icon: createIcon(Text),
      iconName: 'Text',
      description: 'A standard paragraph text element',
      props: {
        id: '',
        className: 'text-base'
      },
      content: 'This is a paragraph of text. Edit this to add your own content.',
      style: {
        marginBottom: '1rem',
      },
      isSelectable: true,
      isDraggable: true,
      isDroppable: false,
      states: [
        createComponentState('isVisible', 'Visible', true, 'boolean')
      ],
      actions: []
    },
    
    // Form elements
    {
      id: 'text-input',
      type: 'input',
      name: 'Text Input',
      category: 'input',
      icon: createIcon(AlignLeft),
      iconName: 'AlignLeft',
      description: 'A text input field for collecting user data',
      props: {
        id: '',
        type: 'text',
        placeholder: 'Enter text...',
        className: 'px-3 py-2 border border-gray-300 rounded w-full'
      },
      style: {
        padding: '0.5rem 0.75rem',
        border: '1px solid #d1d5db',
        borderRadius: '0.25rem',
        width: '100%',
      },
      isSelectable: true,
      isDraggable: true,
      isDroppable: false,
      states: [
        createComponentState('value', 'Value', '', 'string'),
        createComponentState('isDisabled', 'Disabled', false, 'boolean'),
        createComponentState('isRequired', 'Required', false, 'boolean')
      ],
      actions: [
        createComponentAction('focus', 'Focus', 'Give focus to this input'),
        createComponentAction('clear', 'Clear', 'Clear the input value')
      ]
    },
    {
      id: 'button',
      type: 'button',
      name: 'Button',
      category: 'form',
      icon: createIcon(Code),
      iconName: 'Code',
      description: 'A clickable button for user interaction',
      props: {
        id: '',
        className: 'px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors'
      },
      content: 'Button',
      style: {
        padding: '0.5rem 1rem',
        backgroundColor: '#3b82f6',
        color: 'white',
        borderRadius: '0.25rem',
        cursor: 'pointer',
      },
      isSelectable: true,
      isDraggable: true,
      isDroppable: false,
      states: [
        createComponentState('isDisabled', 'Disabled', false, 'boolean'),
        createComponentState('isLoading', 'Loading', false, 'boolean')
      ],
      actions: [
        createComponentAction('click', 'Click', 'Simulate a button click')
      ]
    },
    
    // Media components
    {
      id: 'image',
      type: 'img',
      name: 'Image',
      category: 'media',
      icon: createIcon(Image),
      iconName: 'Image',
      description: 'An image element for displaying pictures',
      props: {
        id: '',
        src: 'https://via.placeholder.com/350x150',
        alt: 'Placeholder image',
        className: 'w-full h-auto rounded'
      },
      style: {
        width: '100%',
        height: 'auto',
        borderRadius: '0.25rem',
      },
      isSelectable: true,
      isDraggable: true,
      isDroppable: false,
      states: [
        createComponentState('isLoaded', 'Loaded', false, 'boolean')
      ],
      actions: [
        createComponentAction('reload', 'Reload', 'Reload the image')
      ]
    },
    {
      id: 'video',
      type: 'video',
      name: 'Video',
      category: 'media',
      icon: createIcon(Video),
      iconName: 'Video',
      description: 'A video player element',
      props: {
        id: '',
        src: '',
        controls: true,
        className: 'w-full h-auto rounded'
      },
      style: {
        width: '100%',
        height: 'auto',
        borderRadius: '0.25rem',
      },
      isSelectable: true,
      isDraggable: true,
      isDroppable: false,
      states: [
        createComponentState('isPlaying', 'Playing', false, 'boolean'),
        createComponentState('currentTime', 'Current Time', 0, 'number')
      ],
      actions: [
        createComponentAction('play', 'Play', 'Play the video'),
        createComponentAction('pause', 'Pause', 'Pause the video')
      ]
    },
    
    // Navigation components
    {
      id: 'link',
      type: 'a',
      name: 'Link',
      category: 'navigation',
      icon: createIcon(Link),
      iconName: 'Link',
      description: 'A hyperlink to navigate to other pages',
      props: {
        id: '',
        href: '#',
        className: 'text-blue-500 hover:underline'
      },
      content: 'Link',
      style: {
        color: '#3b82f6',
        textDecoration: 'none',
      },
      isSelectable: true,
      isDraggable: true,
      isDroppable: false,
      states: [
        createComponentState('isDisabled', 'Disabled', false, 'boolean')
      ],
      actions: [
        createComponentAction('navigate', 'Navigate', 'Navigate to the link URL')
      ]
    },
    {
      id: 'navbar',
      type: 'nav',
      name: 'Navigation Bar',
      category: 'navigation',
      icon: createIcon(Menu),
      iconName: 'Menu',
      description: 'A responsive navigation bar',
      props: {
        id: '',
        className: 'flex justify-between items-center py-4 px-6 bg-white shadow'
      },
      style: {
        width: '100%',
      },
      isSelectable: true,
      isDraggable: true,
      isDroppable: true,
      children: [],
      states: [
        createComponentState('isExpanded', 'Expanded (Mobile)', false, 'boolean')
      ],
      actions: [
        createComponentAction('toggle', 'Toggle Menu', 'Toggle mobile menu visibility')
      ]
    },
    
    // Data components
    {
      id: 'list',
      type: 'ul',
      name: 'List',
      category: 'data',
      icon: createIcon(List),
      iconName: 'List',
      description: 'An unordered list for displaying items',
      props: {
        id: '',
        className: 'list-disc pl-5 space-y-2'
      },
      style: {},
      isSelectable: true,
      isDraggable: true,
      isDroppable: true,
      children: [],
      states: [
        createComponentState('isVisible', 'Visible', true, 'boolean')
      ],
      actions: []
    },
    {
      id: 'table',
      type: 'table',
      name: 'Table',
      category: 'data',
      icon: createIcon(Table),
      iconName: 'Table',
      description: 'A data table for structured information',
      props: {
        id: '',
        className: 'min-w-full border-collapse'
      },
      style: {
        width: '100%',
      },
      isSelectable: true,
      isDraggable: true,
      isDroppable: true,
      children: [],
      states: [
        createComponentState('isVisible', 'Visible', true, 'boolean')
      ],
      actions: [
        createComponentAction('sort', 'Sort', 'Sort the table data')
      ]
    },
    
    // UI components
    {
      id: 'card',
      type: 'div',
      name: 'Card',
      category: 'basic',
      icon: createIcon(Box),
      iconName: 'Box',
      description: 'A content card with shadow and rounded corners',
      props: {
        id: '',
        className: 'bg-white rounded-lg shadow p-6'
      },
      style: {},
      isSelectable: true,
      isDraggable: true,
      isDroppable: true,
      children: [],
      states: [
        createComponentState('isVisible', 'Visible', true, 'boolean')
      ],
      actions: []
    },
    {
      id: 'modal',
      type: 'div',
      name: 'Modal',
      category: 'basic',
      icon: createIcon(Layout),
      iconName: 'Layout',
      description: 'A popup modal dialog',
      props: {
        id: '',
        className: 'fixed inset-0 flex items-center justify-center bg-black bg-opacity-50'
      },
      style: {
        zIndex: 50
      },
      isSelectable: true,
      isDraggable: true,
      isDroppable: true,
      children: [],
      states: [
        createComponentState('isOpen', 'Open', false, 'boolean')
      ],
      actions: [
        createComponentAction('open', 'Open', 'Open the modal'),
        createComponentAction('close', 'Close', 'Close the modal'),
        createComponentAction('toggle', 'Toggle', 'Toggle modal visibility')
      ]
    },
    
    // Additional form components
    {
      id: 'textarea',
      type: 'textarea',
      name: 'Text Area',
      category: 'input',
      icon: createIcon(AlignLeft),
      iconName: 'AlignLeft',
      description: 'A multi-line text input',
      props: {
        id: '',
        placeholder: 'Enter text...',
        rows: 4,
        className: 'px-3 py-2 border border-gray-300 rounded w-full'
      },
      style: {},
      isSelectable: true,
      isDraggable: true,
      isDroppable: false,
      states: [
        createComponentState('value', 'Value', '', 'string'),
        createComponentState('isDisabled', 'Disabled', false, 'boolean')
      ],
      actions: [
        createComponentAction('focus', 'Focus', 'Give focus to this textarea'),
        createComponentAction('clear', 'Clear', 'Clear the textarea value')
      ]
    },
    {
      id: 'select',
      type: 'select',
      name: 'Select Dropdown',
      category: 'input',
      icon: createIcon(List),
      iconName: 'List',
      description: 'A dropdown select element',
      props: {
        id: '',
        className: 'px-3 py-2 border border-gray-300 rounded w-full'
      },
      style: {},
      isSelectable: true,
      isDraggable: true,
      isDroppable: true,
      children: [],
      states: [
        createComponentState('value', 'Selected Value', '', 'string'),
        createComponentState('isDisabled', 'Disabled', false, 'boolean')
      ],
      actions: [
        createComponentAction('focus', 'Focus', 'Give focus to this select')
      ]
    },
    
    // Commerce components
    {
      id: 'product-card',
      type: 'div',
      name: 'Product Card',
      category: 'commerce',
      icon: createIcon(ShoppingCart),
      iconName: 'ShoppingCart',
      description: 'A product display card for e-commerce',
      props: {
        id: '',
        className: 'bg-white rounded-lg shadow p-4'
      },
      style: {},
      isSelectable: true,
      isDraggable: true,
      isDroppable: true,
      children: [],
      states: [
        createComponentState('isInCart', 'In Cart', false, 'boolean'),
        createComponentState('quantity', 'Quantity', 1, 'number')
      ],
      actions: [
        createComponentAction('addToCart', 'Add To Cart', 'Add this product to cart')
      ]
    },
    
    // Additional components
    {
      id: 'icon',
      type: 'span',
      name: 'Icon',
      category: 'basic',
      icon: createIcon(CheckCircle),
      iconName: 'CheckCircle',
      description: 'A decorative or functional icon',
      props: {
        id: '',
        className: 'inline-block text-gray-600'
      },
      style: {},
      isSelectable: true,
      isDraggable: true,
      isDroppable: false,
      states: [
        createComponentState('isVisible', 'Visible', true, 'boolean')
      ],
      actions: []
    },
    {
      id: 'divider',
      type: 'hr',
      name: 'Divider',
      category: 'basic',
      icon: createIcon(AlignLeft),
      iconName: 'AlignLeft',
      description: 'A horizontal divider line',
      props: {
        id: '',
        className: 'my-6 border-t border-gray-300'
      },
      style: {},
      isSelectable: true,
      isDraggable: true,
      isDroppable: false,
      states: [
        createComponentState('isVisible', 'Visible', true, 'boolean')
      ],
      actions: []
    }
  ];
};
