
import { ReactNode } from 'react';

// Component category definition
export interface ComponentCategory {
  id: string;
  name: string;
  icon: ReactNode;
}

// Component state definition
export interface ComponentState {
  id: string;
  name: string;
  type: string;
  value?: any;
  defaultValue?: any;
  description?: string;
}

// Component action definition
export interface ComponentAction {
  id: string;
  name: string;
  type: string;
  description?: string;
}

// Component definition
export interface LibraryComponent {
  id: string;
  name: string;
  type: string;
  category: string;
  icon: ReactNode;
  iconName: string;
  isSelectable?: boolean;
  isDraggable?: boolean;
  isDroppable?: boolean;
  props?: Record<string, any>;
  style?: Record<string, any>;
  content?: string;
  children?: LibraryComponent[];
  description?: string;
  states?: ComponentState[];
  actions?: ComponentAction[];
}
