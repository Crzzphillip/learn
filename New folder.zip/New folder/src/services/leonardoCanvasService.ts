
// This service will be used to provide canvas-specific functionality for Leonardo workspace

export interface CanvasImage {
  input: string;
  output: string;
}

export const leonardoCanvasService = {
  // Get canvas image data for specific workspace
  getCanvasImages: (workspaceId: string): CanvasImage => {
    switch (workspaceId) {
      case 'canvas-1': 
        return {
          input: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Background+Remover",
          output: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Result"
        };
      case 'canvas-2':
        return {
          input: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Image+Editor+Pro",
          output: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Edited+Image"
        };
      case 'canvas-3':
        return {
          input: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Style+Transfer+Input",
          output: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Style+Applied"
        };
      case 'canvas-4':
        return {
          input: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Concept+Art+Generator",
          output: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Generated+Concept"
        };
      case 'canvas-5':
        return {
          input: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Upscaling+Input",
          output: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Upscaled+Image" 
        };
      default:
        return {
          input: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Input+Image",
          output: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Output+Image"
        };
    }
  }
};
