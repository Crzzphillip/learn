
import { Workspace } from "./workspaceService";

export interface TeamMember {
  id: string;
  name: string;
  avatar: string;
  role: 'owner' | 'editor' | 'viewer';
}

export interface PendingInvite {
  id: string;
  email: string;
  invited: string;
  role: 'editor' | 'viewer';
}

export interface ActivityItem {
  id: string;
  user: {
    name: string;
    avatar: string;
  };
  action: string;
  target: string;
  timestamp: string;
}

export interface MessageItem {
  id: string;
  user: {
    name: string;
    avatar: string;
  };
  content: string;
  timestamp: string;
}

/**
 * Get team members for a workspace
 */
export const getTeamMembers = (workspace: Workspace): TeamMember[] => {
  // If workspace is null or undefined, return empty array
  if (!workspace) {
    console.warn("Workspace is undefined or null, returning empty team members array");
    return [];
  }
  
  // If workspace has owner info, create default members
  const defaultMembers: TeamMember[] = [];
  
  // Add the owner
  if (workspace.creator) {
    defaultMembers.push({
      id: 'owner-1',
      name: workspace.creator.name,
      avatar: workspace.creator.avatar,
      role: 'owner'
    });
  }
  
  // If workspace has collaborators, add them
  if (workspace.activeCollaborators && workspace.activeCollaborators.length > 0) {
    workspace.activeCollaborators.forEach((collaborator, index) => {
      if (index === 0) return; // Skip the first one as it's usually the owner
      
      defaultMembers.push({
        id: `collaborator-${index}`,
        name: collaborator.name,
        avatar: collaborator.avatar,
        role: index % 2 === 0 ? 'editor' : 'viewer'
      });
    });
  }
  
  return defaultMembers;
};

/**
 * Get pending invites for a workspace
 */
export const getPendingInvites = (): PendingInvite[] => {
  // In a real app, this would be fetched from the backend
  return [
    {
      id: 'invite-1',
      email: 'john.doe@example.com',
      invited: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      role: 'editor'
    },
    {
      id: 'invite-2',
      email: 'jane.smith@example.com',
      invited: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      role: 'viewer'
    }
  ];
};

/**
 * Get activity data for the workspace
 */
export const getActivityData = (): ActivityItem[] => {
  return [
    {
      id: 'activity-1',
      user: {
        name: 'Alex Morgan',
        avatar: 'https://i.pravatar.cc/150?u=alex'
      },
      action: 'added',
      target: 'a new workflow component',
      timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString()
    },
    {
      id: 'activity-2',
      user: {
        name: 'Jamie Rivera',
        avatar: 'https://i.pravatar.cc/150?u=jamie'
      },
      action: 'updated',
      target: 'the API settings',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString()
    },
    {
      id: 'activity-3',
      user: {
        name: 'Taylor Kim',
        avatar: 'https://i.pravatar.cc/150?u=taylor'
      },
      action: 'commented on',
      target: 'the AI agent configuration',
      timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
    }
  ];
};

/**
 * Get message data for the workspace chat
 */
export const getMessagesData = (): MessageItem[] => {
  return [
    {
      id: 'message-1',
      user: {
        name: 'Alex Morgan',
        avatar: 'https://i.pravatar.cc/150?u=alex'
      },
      content: 'Hey team, I just updated the API endpoints for our project. Please test them when you get a chance.',
      timestamp: new Date(Date.now() - 45 * 60 * 1000).toISOString()
    },
    {
      id: 'message-2',
      user: {
        name: 'Jamie Rivera',
        avatar: 'https://i.pravatar.cc/150?u=jamie'
      },
      content: 'Will do! Also, I found a bug in the authentication flow that we need to fix.',
      timestamp: new Date(Date.now() - 42 * 60 * 1000).toISOString()
    },
    {
      id: 'message-3',
      user: {
        name: 'Taylor Kim',
        avatar: 'https://i.pravatar.cc/150?u=taylor'
      },
      content: 'I can take a look at the auth issue this afternoon. Can you add it to our task board?',
      timestamp: new Date(Date.now() - 38 * 60 * 1000).toISOString()
    }
  ];
};

/**
 * Format time ago for displaying timestamps
 */
export const formatTimeAgo = (timestamp: string): string => {
  const now = new Date();
  const past = new Date(timestamp);
  const diffMs = now.getTime() - past.getTime();
  
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);
  
  if (diffSecs < 60) {
    return 'just now';
  } else if (diffMins < 60) {
    return `${diffMins} minute${diffMins !== 1 ? 's' : ''} ago`;
  } else if (diffHours < 24) {
    return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
  } else if (diffDays < 30) {
    return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
  } else {
    return past.toLocaleDateString();
  }
};
