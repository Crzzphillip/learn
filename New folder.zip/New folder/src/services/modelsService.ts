
import { jsonDatabaseService } from './jsonDatabaseService';
import { toast } from "sonner";

export interface AIModel {
  id: string;
  name: string;
  logo: string;
  description: string;
  category: string;
  background?: string;
}

export const modelsService = {
  // Get all AI models
  getAllModels: async (): Promise<AIModel[]> => {
    try {
      return await jsonDatabaseService.getAll<AIModel>('models');
    } catch (error) {
      console.error("Error fetching models:", error);
      toast.error("Failed to load AI models");
      return [];
    }
  },

  // Get a model by ID
  getModelById: async (id: string): Promise<AIModel | null> => {
    try {
      return await jsonDatabaseService.getById<AIModel>('models', id);
    } catch (error) {
      console.error(`Error fetching model ${id}:`, error);
      toast.error("Failed to load AI model details");
      return null;
    }
  },

  // Create a new model
  createModel: async (model: Omit<AIModel, 'id'>): Promise<AIModel> => {
    try {
      const newModel = await jsonDatabaseService.create<AIModel>('models', model);
      toast.success("New AI model created successfully");
      return newModel;
    } catch (error) {
      console.error("Error creating model:", error);
      toast.error("Failed to create new AI model");
      throw error;
    }
  },

  // Update a model
  updateModel: async (id: string, data: Partial<AIModel>): Promise<AIModel | null> => {
    try {
      const updatedModel = await jsonDatabaseService.update<AIModel>('models', id, data);
      if (updatedModel) {
        toast.success("AI model updated successfully");
      }
      return updatedModel;
    } catch (error) {
      console.error(`Error updating model ${id}:`, error);
      toast.error("Failed to update AI model");
      throw error;
    }
  },

  // Delete a model
  deleteModel: async (id: string): Promise<boolean> => {
    try {
      const result = await jsonDatabaseService.delete('models', id);
      if (result) {
        toast.success("AI model deleted successfully");
      }
      return result;
    } catch (error) {
      console.error(`Error deleting model ${id}:`, error);
      toast.error("Failed to delete AI model");
      throw error;
    }
  },

  // Get models by category
  getModelsByCategory: async (category: string): Promise<AIModel[]> => {
    try {
      return await jsonDatabaseService.query<AIModel>(
        'models',
        (model) => model.category === category
      );
    } catch (error) {
      console.error(`Error fetching models for category ${category}:`, error);
      toast.error("Failed to load category models");
      return [];
    }
  }
};
