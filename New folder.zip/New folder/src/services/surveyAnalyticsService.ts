import { toast } from "sonner";

export interface SurveyAnalytics {
  accuracyMetrics: {
    points: number;
    averageAccuracy: number;
    accuracyDistribution: { range: string; count: number }[];
  };
  progressMetrics: {
    totalPoints: number;
    processedPoints: number;
    remainingPoints: number;
    completionPercentage: number;
  };
  dataDistribution: {
    categories: string[];
    values: number[];
  };
}

export interface SurveyChartData {
  labels: string[];
  datasets: {
    label: string;
    data: number[];
    backgroundColor: string[];
    borderColor: string;
    borderWidth: number;
  }[];
}

class SurveyAnalyticsService {
  private static instance: SurveyAnalyticsService;

  private constructor() {}

  static getInstance(): SurveyAnalyticsService {
    if (!SurveyAnalyticsService.instance) {
      SurveyAnalyticsService.instance = new SurveyAnalyticsService();
    }
    return SurveyAnalyticsService.instance;
  }

  async getAnalytics(): Promise<SurveyAnalytics> {
    // Simulate fetching analytics data
    await new Promise(resolve => setTimeout(resolve, 500));

    return {
      accuracyMetrics: {
        points: 156,
        averageAccuracy: 0.95,
        accuracyDistribution: [
          { range: "0.9-1.0", count: 120 },
          { range: "0.8-0.9", count: 25 },
          { range: "0.7-0.8", count: 8 },
          { range: "0.6-0.7", count: 3 }
        ]
      },
      progressMetrics: {
        totalPoints: 200,
        processedPoints: 156,
        remainingPoints: 44,
        completionPercentage: 78
      },
      dataDistribution: {
        categories: ["Boundary Points", "Topographic Points", "Control Points", "Detail Points"],
        values: [45, 30, 15, 10]
      }
    };
  }

  async getAccuracyChartData(): Promise<SurveyChartData> {
    const analytics = await this.getAnalytics();
    
    return {
      labels: analytics.accuracyMetrics.accuracyDistribution.map(d => d.range),
      datasets: [
        {
          label: "Point Distribution",
          data: analytics.accuracyMetrics.accuracyDistribution.map(d => d.count),
          backgroundColor: ["#4ade80", "#22d3ee", "#fbbf24", "#f87171"],
          borderColor: "#ffffff",
          borderWidth: 1
        }
      ]
    };
  }

  async getProgressChartData(): Promise<SurveyChartData> {
    const analytics = await this.getAnalytics();
    
    return {
      labels: ["Processed", "Remaining"],
      datasets: [
        {
          label: "Survey Progress",
          data: [analytics.progressMetrics.processedPoints, analytics.progressMetrics.remainingPoints],
          backgroundColor: ["#4ade80", "#f87171"],
          borderColor: "#ffffff",
          borderWidth: 1
        }
      ]
    };
  }

  async getDistributionChartData(): Promise<SurveyChartData> {
    const analytics = await this.getAnalytics();
    
    return {
      labels: analytics.dataDistribution.categories,
      datasets: [
        {
          label: "Point Types",
          data: analytics.dataDistribution.values,
          backgroundColor: ["#4ade80", "#22d3ee", "#fbbf24", "#f87171"],
          borderColor: "#ffffff",
          borderWidth: 1
        }
      ]
    };
  }
}

export const surveyAnalyticsService = SurveyAnalyticsService.getInstance(); 