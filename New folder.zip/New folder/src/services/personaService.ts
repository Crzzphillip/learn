
import { PersonaData, PersonaReview, PersonaShowcase, PersonaUseCase } from "@/data/personaData";

// Sample persona data
const personaDetailsData: Record<string, PersonaData> = {
  "persona-1": {
    id: "persona-1",
    name: "Creative Writer",
    description: "An AI assistant specialized in creative writing, storytelling, and content creation.",
    category: "Creative",
    rating: 4.8,
    users: 1240,
    creator: "AI Labs",
    createdAt: "2023-12-10",
    icon: "BrainCircuit",
    abilities: [
      "Story creation and development",
      "Poetry and creative verse",
      "Blog post drafting",
      "Content editing and refinement",
      "Character and plot development"
    ],
    limitations: [
      "Cannot guarantee factual accuracy",
      "May struggle with specialized technical content",
      "Cannot research or cite sources"
    ],
    promptExamples: [
      {
        title: "Create a short story",
        prompt: "Write a short story about a lighthouse keeper who discovers something unusual washed up on the shore."
      },
      {
        title: "Generate blog post ideas",
        prompt: "Generate 5 blog post ideas about artificial intelligence for beginners."
      },
      {
        title: "Edit my writing",
        prompt: "Edit this paragraph for clarity and conciseness: [your text here]"
      }
    ],
    capabilities: [
      {
        title: "Creative Writing",
        description: "Generates stories, poems, and creative content across various genres and styles.",
        icon: "BrainCircuit"
      },
      {
        title: "Content Creation",
        description: "Creates blog posts, articles, and marketing copy tailored to your audience.",
        icon: "BookOpen"
      },
      {
        title: "Editing Assistance",
        description: "Provides suggestions to enhance clarity, flow, and engagement in your writing.",
        icon: "Sparkles"
      }
    ]
  },
  "persona-2": {
    id: "persona-2",
    name: "Code Assistant",
    description: "A technical assistant specialized in programming, debugging, and software development.",
    category: "Technical",
    rating: 4.6,
    users: 2380,
    creator: "Dev Tools Inc",
    createdAt: "2023-11-15",
    icon: "Terminal",
    abilities: [
      "Code explanation and review",
      "Debugging assistance",
      "Framework implementation guidance",
      "Best practices recommendations",
      "Code optimization suggestions"
    ],
    limitations: [
      "Cannot run or test code directly",
      "May not be updated with latest framework versions",
      "Cannot access private repositories or databases"
    ],
    promptExamples: [
      {
        title: "Explain code",
        prompt: "Explain what this React code does: [your code here]"
      },
      {
        title: "Debug an issue",
        prompt: "Help me debug this error: [error message and code]"
      },
      {
        title: "Convert code to another language",
        prompt: "Convert this Python code to JavaScript: [your code here]"
      }
    ],
    capabilities: [
      {
        title: "Code Analysis",
        description: "Reviews and explains code snippets across multiple programming languages.",
        icon: "Terminal"
      },
      {
        title: "Debugging Help",
        description: "Identifies potential issues and suggests fixes for problematic code.",
        icon: "Box"
      },
      {
        title: "Best Practices",
        description: "Recommends coding standards and optimization techniques for cleaner code.",
        icon: "LightbulbIcon"
      }
    ]
  }
};

// Sample reviews data
const personaReviewsData: Record<string, PersonaReview[]> = {
  "persona-1": [
    {
      id: "review-1",
      user: "Alex Rivera",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alex",
      rating: 5,
      comment: "This creative writer persona has revolutionized my content creation workflow. The quality of writing is exceptional, and it captures the tone I'm looking for perfectly.",
      date: "2 days ago",
      likes: 24,
      replies: 3
    },
    {
      id: "review-2",
      user: "Sarah Johnson",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah",
      rating: 4,
      comment: "Great for creative writing and brainstorming. Helped me overcome writer's block multiple times. Occasionally needs fine-tuning to match my specific style.",
      date: "1 week ago",
      likes: 17,
      replies: 1
    }
  ],
  "persona-2": [
    {
      id: "review-3",
      user: "Michael Chen",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Michael",
      rating: 5,
      comment: "The code assistant persona is incredibly helpful for debugging and explaining complex code patterns. It's like having a senior developer at your fingertips.",
      date: "3 days ago",
      likes: 32,
      replies: 5
    }
  ]
};

// Sample showcases data
const personaShowcasesData: Record<string, PersonaShowcase[]> = {
  "persona-1": [
    {
      id: "showcase-1",
      title: "Short Story: The Last Lighthouse",
      description: "A short story about a lighthouse keeper in a post-apocalyptic world",
      type: "text",
      preview: "The last lighthouse stood tall against the crimson horizon, its beam cutting through the perpetual dusk that had become our world. Marcus had maintained the light for fifteen years since the Event...",
      user: "Alex Rivera",
      userAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alex",
      date: "1 week ago",
      tags: ["fiction", "short-story", "post-apocalyptic"],
      likes: 42,
      comments: 7
    },
    {
      id: "showcase-2",
      title: "Marketing Copy for Tech Product",
      description: "Product description for a new AI-powered smart home device",
      type: "text",
      preview: "Introducing HomeSense AI - The intelligent heart of your smart home. HomeSense doesn't just connect your devices; it learns from them, anticipating your needs before you even realize them...",
      user: "Emma Wilson",
      userAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Emma",
      date: "3 days ago",
      tags: ["marketing", "copywriting", "product-description"],
      likes: 28,
      comments: 4
    }
  ],
  "persona-2": [
    {
      id: "showcase-3",
      title: "React Custom Hook Pattern",
      description: "An example of a reusable data fetching hook in React",
      type: "code",
      preview: "import { useState, useEffect } from 'react';\n\nexport const useFetch = (url) => {\n  const [data, setData] = useState(null);\n  const [loading, setLoading] = useState(true);\n  const [error, setError] = useState(null);\n\n  useEffect(() => {\n    const fetchData = async () => {\n      try {\n        const response = await fetch(url);\n        if (!response.ok) throw new Error('Network response was not ok');\n        const result = await response.json();\n        setData(result);\n      } catch (err) {\n        setError(err.message);\n      } finally {\n        setLoading(false);\n      }\n    };\n\n    fetchData();\n  }, [url]);\n\n  return { data, loading, error };\n};",
      user: "Michael Chen",
      userAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Michael",
      date: "5 days ago",
      tags: ["react", "hooks", "javascript"],
      likes: 56,
      comments: 12
    }
  ]
};

// Sample use cases data
const personaUseCasesData: Record<string, PersonaUseCase[]> = {
  "persona-1": [
    {
      id: "usecase-1",
      title: "Blog Content Creation",
      description: "Used the creative writer to draft and refine tech blog posts",
      industry: "Digital Marketing",
      results: "Increased content production by 3x while maintaining quality",
      user: "Mark Thompson",
      userAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Mark",
      date: "2 months ago",
      likes: 24
    },
    {
      id: "usecase-2",
      title: "Fiction Podcast Scripts",
      description: "Generated script ideas and dialogue for a fiction podcast series",
      industry: "Entertainment",
      results: "Created 12 episodes with unique storylines in record time",
      user: "Amanda Lee",
      userAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Amanda",
      date: "3 months ago",
      likes: 18
    }
  ],
  "persona-2": [
    {
      id: "usecase-3",
      title: "Legacy Code Refactoring",
      description: "Used the code assistant to help refactor a legacy Java application",
      industry: "FinTech",
      results: "Reduced technical debt by 40% and improved performance by 25%",
      user: "Robert Chen",
      userAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Robert",
      date: "1 month ago",
      likes: 32
    }
  ]
};

// Implement all required service methods
export const personaService = {
  getPersonaDetails: async (personaId: string): Promise<PersonaData> => {
    await new Promise(resolve => setTimeout(resolve, 800));
    return personaDetailsData[personaId] || personaDetailsData["persona-1"];
  },
  
  getPersonaReviews: async (personaId: string): Promise<PersonaReview[]> => {
    await new Promise(resolve => setTimeout(resolve, 600));
    return personaReviewsData[personaId] || [];
  },
  
  getPersonaShowcases: async (personaId: string): Promise<PersonaShowcase[]> => {
    await new Promise(resolve => setTimeout(resolve, 600));
    return personaShowcasesData[personaId] || [];
  },
  
  getPersonaUseCases: async (personaId: string): Promise<PersonaUseCase[]> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    return personaUseCasesData[personaId] || [];
  },

  submitReview: async (personaId: string, rating: number, comment: string): Promise<boolean> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    // In a real app, this would send the review to a database
    console.log(`Submitting review for persona ${personaId}: ${rating} stars - ${comment}`);
    return true;
  },

  submitUseCase: async (personaId: string, useCase: Partial<PersonaUseCase>): Promise<boolean> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    console.log(`Submitting use case for persona ${personaId}:`, useCase);
    return true;
  },

  copyShowcase: async (showcaseId: string): Promise<void> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    console.log(`Copying showcase: ${showcaseId}`);
  }
};
