
// This file is deprecated - import from the new location instead
import {
  componentCategories,
  getComponentLibrary
} from './componentLibrary';

import type {
  ComponentCategory,
  ComponentState,
  ComponentAction,
  LibraryComponent
} from './componentLibrary/types';

export type { 
  ComponentCategory,
  ComponentState,
  ComponentAction,
  LibraryComponent
};

export {
  componentCategories,
  getComponentLibrary
};
