import { ComponentType } from '../types/workspace';

export interface ComponentProperty {
  id: string;
  name: string;
  type: 'text' | 'number' | 'select' | 'color' | 'boolean' | 'link' | 'font' | 'alignment' | 'background' | 'opacity';
  value: any;
  options?: string[];
  category: 'style' | 'layout' | 'advanced' | 'typography' | 'background';
  presetColors?: string[];
}

const buttonProperties: ComponentProperty[] = [
  {
    id: 'text',
    name: 'Text',
    type: 'text',
    value: 'Button Start',
    category: 'typography'
  },
  {
    id: 'fontFamily',
    name: 'Font Family',
    type: 'font',
    value: 'Plus Jakarta Sans',
    options: ['Plus Jakarta Sans', 'Inter', 'Roboto', 'Arial'],
    category: 'typography'
  },
  {
    id: 'fontSize',
    name: 'Font Size',
    type: 'number',
    value: 14,
    category: 'typography'
  },
  {
    id: 'bold',
    name: 'Bold',
    type: 'boolean',
    value: false,
    category: 'typography'
  },
  {
    id: 'alignment',
    name: 'Alignment',
    type: 'alignment',
    value: 'left',
    category: 'typography'
  },
  {
    id: 'textColor',
    name: 'Color',
    type: 'color',
    value: '#000000',
    category: 'typography',
    presetColors: ['#000000', '#FFFFFF', '#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF']
  },
  {
    id: 'backgroundColor',
    name: 'Background',
    type: 'background',
    value: {
      type: 'solid',
      color: '#FFFFFF',
      gradient: {
        from: '#FFFFFF',
        to: '#000000',
        direction: 'to right'
      }
    },
    category: 'background'
  },
  {
    id: 'opacity',
    name: 'Opacity',
    type: 'opacity',
    value: 100,
    category: 'background'
  }
];

const textProperties: ComponentProperty[] = [
  {
    id: 'content',
    name: 'Text',
    type: 'text',
    value: 'Text content',
    category: 'typography'
  },
  {
    id: 'fontFamily',
    name: 'Font Family',
    type: 'font',
    value: 'Plus Jakarta Sans',
    options: ['Plus Jakarta Sans', 'Inter', 'Roboto', 'Arial'],
    category: 'typography'
  },
  {
    id: 'fontSize',
    name: 'Font Size',
    type: 'number',
    value: 14,
    category: 'typography'
  },
  {
    id: 'bold',
    name: 'Bold',
    type: 'boolean',
    value: false,
    category: 'typography'
  },
  {
    id: 'alignment',
    name: 'Alignment',
    type: 'alignment',
    value: 'left',
    category: 'typography'
  },
  {
    id: 'textColor',
    name: 'Color',
    type: 'color',
    value: '#000000',
    category: 'typography',
    presetColors: ['#000000', '#FFFFFF', '#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF']
  },
  {
    id: 'backgroundColor',
    name: 'Background',
    type: 'background',
    value: {
      type: 'solid',
      color: 'transparent',
      gradient: {
        from: '#FFFFFF',
        to: '#000000',
        direction: 'to right'
      }
    },
    category: 'background'
  },
  {
    id: 'opacity',
    name: 'Opacity',
    type: 'opacity',
    value: 100,
    category: 'background'
  }
];

const imageProperties: ComponentProperty[] = [
  {
    id: 'src',
    name: 'Image Source',
    type: 'text',
    value: 'https://example.com/image.jpg',
    category: 'style'
  },
  {
    id: 'alt',
    name: 'Alt Text',
    type: 'text',
    value: 'Image description',
    category: 'advanced'
  },
  {
    id: 'width',
    name: 'Width',
    type: 'number',
    value: 200,
    category: 'layout'
  },
  {
    id: 'height',
    name: 'Height',
    type: 'number',
    value: 200,
    category: 'layout'
  },
  {
    id: 'opacity',
    name: 'Opacity',
    type: 'opacity',
    value: 100,
    category: 'background'
  }
];

const componentPropertiesMap = new Map<ComponentType, ComponentProperty[]>([
  ['button', buttonProperties],
  ['text', textProperties],
  ['image', imageProperties]
]);

export const getComponentProperties = (type: ComponentType): ComponentProperty[] => {
  return componentPropertiesMap.get(type) || [];
};

export const updateComponentProperty = (
  type: ComponentType,
  propertyId: string,
  value: any
): ComponentProperty[] => {
  const properties = [...(componentPropertiesMap.get(type) || [])];
  const propertyIndex = properties.findIndex(p => p.id === propertyId);
  
  if (propertyIndex !== -1) {
    properties[propertyIndex] = {
      ...properties[propertyIndex],
      value
    };
  }
  
  return properties;
}; 