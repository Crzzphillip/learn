
import { toast } from "sonner";

interface ManufacturingProcess {
  id: string;
  name: string;
  description: string;
  efficiency: number; // percentage
  automationLevel: 'low' | 'medium' | 'high';
  maintenanceStatus: 'optimal' | 'needs-attention' | 'critical';
}

interface SupplyChainMetric {
  id: string;
  name: string;
  description: string;
  currentValue: number;
  targetValue: number;
  unit: string;
  trend: 'improving' | 'stable' | 'deteriorating';
}

interface ProductionResource {
  id: string;
  name: string;
  category: 'raw-material' | 'component' | 'equipment' | 'human-resource';
  availability: number; // percentage
  costEfficiency: 'low' | 'medium' | 'high';
  sustainabilityRating: 'poor' | 'average' | 'excellent';
}

// Mock data for manufacturing processes
const manufacturingProcesses: ManufacturingProcess[] = [
  {
    id: 'process-1',
    name: 'Assembly Line A',
    description: 'Main product assembly line with robotics',
    efficiency: 87,
    automationLevel: 'high',
    maintenanceStatus: 'optimal'
  },
  {
    id: 'process-2',
    name: 'Quality Control Station',
    description: 'Automated quality inspection system',
    efficiency: 92,
    automationLevel: 'high',
    maintenanceStatus: 'needs-attention'
  },
  {
    id: 'process-3',
    name: 'Packaging Line',
    description: 'Product packaging and labeling system',
    efficiency: 76,
    automationLevel: 'medium',
    maintenanceStatus: 'needs-attention'
  },
  {
    id: 'process-4',
    name: 'Raw Material Processing',
    description: 'Initial processing of incoming materials',
    efficiency: 65,
    automationLevel: 'low',
    maintenanceStatus: 'critical'
  }
];

// Mock data for supply chain metrics
const supplyChainMetrics: SupplyChainMetric[] = [
  {
    id: 'metric-1',
    name: 'On-Time Delivery',
    description: 'Percentage of orders delivered on schedule',
    currentValue: 92,
    targetValue: 98,
    unit: '%',
    trend: 'improving'
  },
  {
    id: 'metric-2',
    name: 'Inventory Turnover',
    description: 'Rate at which inventory is used and replaced',
    currentValue: 12,
    targetValue: 15,
    unit: 'turns/year',
    trend: 'stable'
  },
  {
    id: 'metric-3',
    name: 'Lead Time',
    description: 'Time between order placement and delivery',
    currentValue: 5.2,
    targetValue: 3.0,
    unit: 'days',
    trend: 'deteriorating'
  },
  {
    id: 'metric-4',
    name: 'Defect Rate',
    description: 'Percentage of products with defects',
    currentValue: 2.1,
    targetValue: 1.0,
    unit: '%',
    trend: 'improving'
  }
];

// Mock data for production resources
const productionResources: ProductionResource[] = [
  {
    id: 'resource-1',
    name: 'Aluminum Alloy',
    category: 'raw-material',
    availability: 78,
    costEfficiency: 'medium',
    sustainabilityRating: 'average'
  },
  {
    id: 'resource-2',
    name: 'Circuit Boards',
    category: 'component',
    availability: 92,
    costEfficiency: 'high',
    sustainabilityRating: 'average'
  },
  {
    id: 'resource-3',
    name: 'CNC Machine',
    category: 'equipment',
    availability: 85,
    costEfficiency: 'high',
    sustainabilityRating: 'excellent'
  },
  {
    id: 'resource-4',
    name: 'Assembly Technicians',
    category: 'human-resource',
    availability: 90,
    costEfficiency: 'medium',
    sustainabilityRating: 'excellent'
  }
];

export const manufacturingSpaceService = {
  getManufacturingProcesses: async (): Promise<ManufacturingProcess[]> => {
    try {
      // In a real application, this would fetch from an API
      return manufacturingProcesses;
    } catch (error) {
      console.error("Error fetching manufacturing processes:", error);
      toast.error("Failed to load manufacturing processes");
      return [];
    }
  },

  getSupplyChainMetrics: async (): Promise<SupplyChainMetric[]> => {
    try {
      return supplyChainMetrics;
    } catch (error) {
      console.error("Error fetching supply chain metrics:", error);
      toast.error("Failed to load supply chain metrics");
      return [];
    }
  },

  getProductionResources: async (): Promise<ProductionResource[]> => {
    try {
      return productionResources;
    } catch (error) {
      console.error("Error fetching production resources:", error);
      toast.error("Failed to load production resources");
      return [];
    }
  }
};
