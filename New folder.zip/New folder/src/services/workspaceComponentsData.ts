
import { ComponentCategory, WorkspaceComponent, WorkspaceTemplate } from '@/types/workspace';

// Define custom types that include iconName
type WorkspaceComponentData = Omit<WorkspaceComponent, 'icon'> & { iconName?: string };
type WorkspaceTemplateData = Omit<WorkspaceTemplate, 'icon'> & { iconName?: string };

// Component categories
export const componentCategories: ComponentCategory[] = [
  {
    id: 'ai-agents',
    name: 'AI Agents',
    type: 'agent',
    description: 'Intelligent AI agents that perform specific tasks'
  },
  {
    id: 'workflows',
    name: 'Workflows',
    type: 'workflow',
    description: 'Automated processes and sequences'
  },
  {
    id: 'apps',
    name: 'Apps',
    type: 'app',
    description: 'Specialized applications and tools'
  },
  {
    id: 'integrations',
    name: 'Integrations',
    type: 'integration',
    description: 'Connect to external services and APIs'
  },
  {
    id: 'templates',
    name: 'Templates',
    type: 'template',
    description: 'Pre-configured setups for specific purposes'
  },
  {
    id: 'extensions',
    name: 'Extensions',
    type: 'extension',
    description: 'Add-ons that enhance workspace functionality'
  },
  {
    id: 'tools',
    name: 'Tools',
    type: 'tool',
    description: 'Developer tools for specific tasks'
  }
];

// Sample workspace components without React elements
export const workspaceComponentsData: WorkspaceComponentData[] = [
  // AI Agents - Code Generation
  {
    id: 'agent-code-generator',
    type: 'agent',
    category: 'development',
    name: 'Code Generator',
    description: 'Generates high-quality code based on requirements',
    iconName: 'Code',
    tags: ['coding', 'development', 'automation'],
    compatibleWith: ['agent-code-reviewer', 'workflow-deployment', 'app-ui-builder'],
    capabilities: ['code-generation'],
    aiPowered: true,
    configOptions: [
      {
        name: 'preferredLanguage',
        type: 'select',
        options: ['JavaScript', 'TypeScript', 'Python', 'Java', 'Go'],
        default: 'TypeScript'
      },
      {
        name: 'frameworkPreference',
        type: 'select',
        options: ['React', 'Vue', 'Angular', 'Next.js', 'None'],
        default: 'React'
      }
    ]
  },
  {
    id: 'agent-code-reviewer',
    type: 'agent',
    category: 'development',
    name: 'Code Reviewer',
    description: 'Reviews code for bugs, performance issues, and best practices',
    iconName: 'Bot',
    tags: ['code quality', 'review', 'best practices'],
    compatibleWith: ['agent-code-generator', 'workflow-testing'],
    capabilities: ['code-generation'],
    aiPowered: true
  },
  {
    id: 'agent-framework-optimizer',
    type: 'agent',
    category: 'development',
    name: 'Framework Optimizer',
    description: 'Optimizes code for specific frameworks like React, Vue.js, and Angular',
    iconName: 'RefreshCw',
    tags: ['frameworks', 'optimization', 'performance'],
    compatibleWith: ['agent-code-generator', 'agent-code-reviewer'],
    capabilities: ['code-generation'],
    aiPowered: true
  },
  {
    id: 'agent-code-refactor',
    type: 'agent',
    category: 'development',
    name: 'Code Refactoring Agent',
    description: 'Automatically refactors and improves code quality and maintainability',
    iconName: 'BrainCircuit',
    tags: ['refactoring', 'code quality', 'automation'],
    compatibleWith: ['agent-code-generator', 'agent-code-reviewer'],
    capabilities: ['code-generation'],
    aiPowered: true
  },
  
  // AI Agents - UI/UX
  {
    id: 'agent-ui-designer',
    type: 'agent',
    category: 'design',
    name: 'UI Designer',
    description: 'Designs user interfaces with optimal UX patterns',
    iconName: 'PenTool',
    tags: ['design', 'UI', 'UX'],
    compatibleWith: ['app-ui-builder', 'workflow-design-to-code'],
    capabilities: ['ui-design'],
    aiPowered: true
  }
];

// Template data without React elements
export const workspaceTemplateData: WorkspaceTemplateData[] = [
  {
    id: 'aiforge-app',
    name: 'AIForge App Development',
    description: 'Complete AI-powered app development workspace with code generation',
    iconName: 'BrainCircuit',
    components: ['gpt-agent', 'code-generator', 'ui-builder', 'database-connector', 'deployment-pipeline'],
    connections: [
      {source: 'gpt-agent', target: 'code-generator'},
      {source: 'code-generator', target: 'ui-builder'},
      {source: 'ui-builder', target: 'database-connector'},
      {source: 'database-connector', target: 'deployment-pipeline'}
    ],
    category: 'AI Development',
    tags: ['app-development', 'fullstack', 'ai', 'popular'],
    aiForgeTemplate: true,
    complexity: 'intermediate'
  },
  {
    id: 'frontend-ai',
    name: 'AI Frontend Developer',
    description: 'Design and build UI/UX with AI assistance',
    iconName: 'PenTool',
    components: ['gpt-agent', 'ui-builder', 'component-library'],
    connections: [
      {source: 'gpt-agent', target: 'ui-builder'},
      {source: 'ui-builder', target: 'component-library'}
    ],
    category: 'Frontend Development',
    tags: ['ui', 'design', 'frontend', 'ai', 'popular'],
    aiForgeTemplate: true,
    complexity: 'beginner'
  },
  {
    id: 'backend-ai',
    name: 'AI Backend Developer',
    description: 'Build backend services and APIs with AI assistance',
    iconName: 'Server',
    components: ['gpt-agent', 'code-generator', 'api-generator', 'database-connector'],
    connections: [
      {source: 'gpt-agent', target: 'code-generator'},
      {source: 'code-generator', target: 'api-generator'},
      {source: 'api-generator', target: 'database-connector'}
    ],
    category: 'Backend Development',
    tags: ['api', 'backend', 'database', 'ai', 'popular'],
    aiForgeTemplate: true,
    complexity: 'intermediate'
  },
  // Add more templates with various tags to ensure we have enough data
  {
    id: 'chatbot-template',
    name: 'AI Chatbot Builder',
    description: 'Create intelligent conversational agents with ease',
    iconName: 'MessageSquare',
    components: ['gpt-agent', 'memory-module', 'ui-builder', 'api-connector'],
    connections: [
      {source: 'gpt-agent', target: 'memory-module'},
      {source: 'memory-module', target: 'ui-builder'},
      {source: 'ui-builder', target: 'api-connector'}
    ],
    category: 'Conversational AI',
    tags: ['chatbot', 'nlp', 'conversation', 'ai', 'popular'],
    aiForgeTemplate: true,
    complexity: 'beginner'
  },
  {
    id: 'data-analytics',
    name: 'Data Analytics Platform',
    description: 'Build powerful data dashboards with AI insights',
    iconName: 'BarChart3',
    components: ['db-connector', 'chart-builder', 'insight-generator'],
    connections: [
      {source: 'db-connector', target: 'insight-generator'},
      {source: 'insight-generator', target: 'chart-builder'}
    ],
    category: 'Analytics',
    tags: ['data', 'visualization', 'insights', 'dashboard', 'popular'],
    aiForgeTemplate: false,
    complexity: 'intermediate'
  },
  {
    id: 'fullstack-app',
    name: 'Full-Stack App Builder',
    description: 'Complete end-to-end application development platform',
    iconName: 'Layers',
    components: ['frontend-builder', 'backend-generator', 'db-connector', 'platform-compiler'],
    connections: [
      {source: 'frontend-builder', target: 'backend-generator'},
      {source: 'backend-generator', target: 'db-connector'},
      {source: 'db-connector', target: 'platform-compiler'}
    ],
    category: 'Full-Stack',
    tags: ['fullstack', 'app-development', 'deployment', 'popular'],
    aiForgeTemplate: false,
    complexity: 'advanced'
  }
];
