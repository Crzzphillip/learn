
import { jsonDatabaseService } from './jsonDatabaseService';
import { toast } from "sonner";

export interface ForumPost {
  id: string;
  title: string;
  content: string;
  author: {
    name: string;
    avatar: string;
    role: string;
  };
  timestamp: string;
  tags: string[];
  likes: number;
  replies: number;
  isLiked: boolean;
  isBookmarked: boolean;
  createdAt: string;
}

export interface Resource {
  id: string;
  title: string;
  description: string;
  type: string;
  author: {
    name: string;
    avatar: string;
  };
  downloadCount: number;
  likes: number;
  isLiked: boolean;
  tags: string[];
  thumbnailUrl?: string;
  createdAt: string;
}

export interface ContentReviewItem {
  id: string;
  title: string;
  description: string;
  type: string;
  author: string;
  submittedAt: string;
  status: string;
  createdAt: string;
}

export const communityService = {
  // Get all forum posts
  getForumPosts: async (): Promise<ForumPost[]> => {
    try {
      return await jsonDatabaseService.getAll<ForumPost>('forum_posts');
    } catch (error) {
      console.error("Error fetching forum posts:", error);
      toast.error("Failed to load forum posts");
      return [];
    }
  },

  // Add a new post
  addPost: async (content: string, author: { name: string; avatar: string; role: string }): Promise<ForumPost> => {
    try {
      const title = content.split("\n")[0] || "New discussion";
      const newPost = {
        title,
        content,
        author,
        timestamp: "Just now",
        tags: [],
        likes: 0,
        replies: 0,
        isLiked: false,
        isBookmarked: false,
        createdAt: new Date().toISOString()
      };
      
      const result = await jsonDatabaseService.create<ForumPost>('forum_posts', newPost);
      toast.success("Your post has been published!");
      return result;
    } catch (error) {
      console.error("Error adding post:", error);
      toast.error("Failed to publish post");
      throw error;
    }
  },

  // Toggle like on a post
  toggleLike: async (postId: string): Promise<ForumPost | null> => {
    try {
      const post = await jsonDatabaseService.getById<ForumPost>('forum_posts', postId);
      if (!post) return null;
      
      const isLiked = !post.isLiked;
      const updatedPost = {
        ...post,
        isLiked,
        likes: isLiked ? post.likes + 1 : post.likes - 1
      };
      
      return await jsonDatabaseService.update<ForumPost>('forum_posts', postId, updatedPost);
    } catch (error) {
      console.error(`Error toggling like on post ${postId}:`, error);
      toast.error("Failed to update like status");
      return null;
    }
  },

  // Toggle bookmark on a post
  toggleBookmark: async (postId: string): Promise<ForumPost | null> => {
    try {
      const post = await jsonDatabaseService.getById<ForumPost>('forum_posts', postId);
      if (!post) return null;
      
      const updatedPost = {
        ...post,
        isBookmarked: !post.isBookmarked
      };
      
      const result = await jsonDatabaseService.update<ForumPost>('forum_posts', postId, updatedPost);
      toast.success("Post saved to your bookmarks");
      return result;
    } catch (error) {
      console.error(`Error toggling bookmark on post ${postId}:`, error);
      toast.error("Failed to update bookmark status");
      return null;
    }
  },

  // Get all resources
  getResources: async (): Promise<Resource[]> => {
    try {
      return await jsonDatabaseService.getAll<Resource>('resources');
    } catch (error) {
      console.error("Error fetching resources:", error);
      toast.error("Failed to load resources");
      return [];
    }
  },

  // Toggle like on a resource
  toggleResourceLike: async (resourceId: string): Promise<Resource | null> => {
    try {
      const resource = await jsonDatabaseService.getById<Resource>('resources', resourceId);
      if (!resource) return null;
      
      const isLiked = !resource.isLiked;
      const updatedResource = {
        ...resource,
        isLiked,
        likes: isLiked ? resource.likes + 1 : resource.likes - 1
      };
      
      return await jsonDatabaseService.update<Resource>('resources', resourceId, updatedResource);
    } catch (error) {
      console.error(`Error toggling like on resource ${resourceId}:`, error);
      toast.error("Failed to update resource like status");
      return null;
    }
  },

  // Increment download count for a resource
  incrementResourceDownload: async (resourceId: string): Promise<Resource | null> => {
    try {
      const resource = await jsonDatabaseService.getById<Resource>('resources', resourceId);
      if (!resource) return null;
      
      const updatedResource = { 
        ...resource, 
        downloadCount: resource.downloadCount + 1 
      };
      
      const result = await jsonDatabaseService.update<Resource>('resources', resourceId, updatedResource);
      toast.success("Resource downloaded successfully");
      return result;
    } catch (error) {
      console.error(`Error incrementing download count for resource ${resourceId}:`, error);
      toast.error("Failed to download resource");
      return null;
    }
  },

  // Get all content review items
  getContentReviewItems: async (): Promise<ContentReviewItem[]> => {
    try {
      return await jsonDatabaseService.getAll<ContentReviewItem>('content_reviews');
    } catch (error) {
      console.error("Error fetching content review items:", error);
      toast.error("Failed to load content review items");
      return [];
    }
  },

  // Approve content
  approveContent: async (itemId: string): Promise<ContentReviewItem | null> => {
    try {
      const item = await jsonDatabaseService.getById<ContentReviewItem>('content_reviews', itemId);
      if (!item) return null;
      
      const updatedItem = { ...item, status: 'approved' };
      const result = await jsonDatabaseService.update<ContentReviewItem>('content_reviews', itemId, updatedItem);
      toast.success("Content approved successfully");
      return result;
    } catch (error) {
      console.error(`Error approving content ${itemId}:`, error);
      toast.error("Failed to approve content");
      return null;
    }
  },

  // Reject content
  rejectContent: async (itemId: string): Promise<ContentReviewItem | null> => {
    try {
      const item = await jsonDatabaseService.getById<ContentReviewItem>('content_reviews', itemId);
      if (!item) return null;
      
      const updatedItem = { ...item, status: 'rejected' };
      const result = await jsonDatabaseService.update<ContentReviewItem>('content_reviews', itemId, updatedItem);
      toast.error("Content rejected");
      return result;
    } catch (error) {
      console.error(`Error rejecting content ${itemId}:`, error);
      toast.error("Failed to reject content");
      return null;
    }
  }
};
