
import React, { ReactNode } from 'react';
import { Box, Heading, Text, Layout, Image, Link } from 'lucide-react';
import { 
  componentCategories,
  getComponentLibrary,
  getComponentById,
  getComponentsByCategory
} from './componentLibrary';
import { createIcon } from './componentLibrary/icons';
import { LibraryComponent, ComponentCategory } from './componentLibrary/types';

// Export types
export type { LibraryComponent, ComponentCategory };

// Export main functions
export {
  componentCategories,
  getComponentLibrary,
  getComponentById,
  getComponentsByCategory
};

// Helper function to get a default icon for a component type
export const getIconForComponent = (type: string): ReactNode => {
  switch (type.toLowerCase()) {
    case 'section':
    case 'div':
      return createIcon(Layout);
    case 'h1':
    case 'h2':
    case 'h3':
    case 'h4':
    case 'h5':
    case 'h6':
      return createIcon(Heading);
    case 'p':
    case 'span':
      return createIcon(Text);
    case 'img':
      return createIcon(Image);
    case 'a':
    case 'button':
      return createIcon(Link);
    default:
      return createIcon(Box);
  }
};
