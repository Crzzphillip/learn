
import React from 'react';
import { WorkspaceTemplate, WorkspaceComponent } from '@/types/workspace';

// Interface for templates with React elements
export interface WorkspaceTemplateWithComponent extends Omit<WorkspaceTemplate, 'icon'> {
  icon: React.ReactElement;
  iconName?: string; // Added iconName property
}

// Interface for components with React elements
export interface WorkspaceComponentWithIcon extends Omit<WorkspaceComponent, 'icon'> {
  icon: React.ReactElement;
  iconName?: string; // Added iconName property
}
