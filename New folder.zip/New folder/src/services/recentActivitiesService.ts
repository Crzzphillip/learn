
import { Activity } from "@/types/activity";

// This would come from an API in a real application
const dummyActivities: Activity[] = [
  {
    id: "1",
    type: "agent-creation",
    title: "Created AI Assistant",
    description: "New agent created for content writing",
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    user: {
      id: "user1",
      name: "Alex Rivera",
      email: "alex@example.com", // Added email
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alex"
    }
  },
  {
    id: "2",
    type: "workflow-update",
    title: "Updated Data Processing Workflow",
    description: "Added new nodes for data transformation",
    timestamp: new Date(Date.now() - 7200000).toISOString(),
    user: {
      id: "user2",
      name: "Emma Wilson",
      email: "emma@example.com", // Added email
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Emma"
    }
  },
  {
    id: "3",
    type: "resource-share",
    title: "Shared Python Tutorial",
    description: "Added 'Advanced Python for AI' to resources",
    timestamp: new Date(Date.now() - 18000000).toISOString(),
    user: {
      id: "user3",
      name: "Michael Chen",
      email: "michael@example.com", // Added email
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Michael"
    }
  },
  {
    id: "4",
    type: "app-deployment",
    title: "Deployed New App",
    description: "Weather forecast app is now live",
    timestamp: new Date(Date.now() - 86400000).toISOString(),
    user: {
      id: "user1",
      name: "Alex Rivera",
      email: "alex@example.com", // Added email
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alex"
    }
  },
  {
    id: "5",
    type: "discussion",
    title: "Started Discussion",
    description: "New thread on AI ethics in the community forum",
    timestamp: new Date(Date.now() - 172800000).toISOString(),
    user: {
      id: "user4",
      name: "Sarah Johnson",
      email: "sarah@example.com", // Added email
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah"
    }
  }
];

export const getRecentActivities = async (spaceId?: string): Promise<Activity[]> => {
  // In a real app, you would make an API call here with the spaceId
  // For now, we'll just return dummy data
  console.log(`Fetching recent activities for space: ${spaceId}`);
  
  // Simulate API latency
  await new Promise(resolve => setTimeout(resolve, 500));
  
  return dummyActivities;
};

export const getActivityById = async (activityId: string): Promise<Activity | undefined> => {
  // In a real app, you would make an API call here
  return dummyActivities.find(activity => activity.id === activityId);
};

export const getRecentActivitiesByType = async (type: string, spaceId?: string): Promise<Activity[]> => {
  // In a real app, you would make an API call here
  return dummyActivities.filter(activity => activity.type === type);
};

export const recentActivitiesService = {
  getRecentActivities,
  getActivityById,
  getRecentActivitiesByType
};
