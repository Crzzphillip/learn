
import { RecentSpace, RecentItem } from "@/components/Layout/types/sidebar";
import { Bot, GitBranch, AppWindow } from "lucide-react";

// Service to manage workspace tabs data
export const workspaceTabsService = {
  // Get recent spaces visited by the user
  getRecentSpaces: (): RecentSpace[] => {
    // In a real app, this would fetch from an API or local storage
    return [
      {
        id: "crypto",
        name: "Crypto Insights",
        gradient: "from-yellow-400/20 to-orange-500/20"
      },
      {
        id: "image-generation",
        name: "Creative Canvas",
        gradient: "from-pink-500/20 to-purple-500/20"
      },
      {
        id: "development",
        name: "Development",
        gradient: "from-purple-500/20 to-pink-500/20"
      },
      {
        id: "education",
        name: "Edu Nexus",
        gradient: "from-blue-400/20 to-cyan-500/20"
      },
       {
        id: "flora",
        name: "Flora Focus",
        gradient: "from-green-400/20 to-lime-500/20"
      },
       {
        id: "finance",
        name: "FinanceFlow",
        gradient: "from-green-600/20 to-emerald-500/20"
      },
      {
        id: "manufacturing",
        name: "ManuMind",
        gradient: "from-gray-600/20 to-slate-500/20"
      },
       {
        id: "leonardo",
        name: "Leonardo",
        gradient: "from-emerald-500/20 to-teal-500/20"
      },
      {
        id: "codecraft",
        name: "CodeCraft",
        gradient: "from-blue-500/20 to-indigo-500/20"
      },
      {
        id: "cad",
        name: "cad",
        gradient: "from-blue-500/20 to-indigo-500/20"
      }
    ];
  },

  // Get recent agents used by the user
  getRecentAgents: (): RecentItem[] => {
    return [
      {
        id: "codemaster",
        name: "CodeMaster",
        type: "agent",
        icon: Bot
      },
      {
        id: "datawiz",
        name: "DataWiz",
        type: "agent",
        icon: Bot
      },
      {
        id: "datawiz2",
        name: "DataWiz2",
        type: "agent",
        icon: Bot
      }
    ];
  },

  // Get recent workflows used by the user
  getRecentWorkflows: (): RecentItem[] => {
    return [
      {
        id: "content-pipeline",
        name: "Content Pipeline",
        type: "workflow",
        icon: GitBranch
      },
      {
        id: "code-review",
        name: "Code Review",
        type: "workflow",
        icon: GitBranch
      },
      {
        id: "code-review2",
        name: "Code Review2",
        type: "workflow",
        icon: GitBranch
      }
    ];
  },

  // Get recent apps used by the user
  getRecentApps: (): RecentItem[] => {
    return [
      {
        id: "web-builder",
        name: "Web Builder",
        type: "app",
        icon: AppWindow
      },
      {
        id: "data-visualizer",
        name: "Data Visualizer",
        type: "app",
        icon: AppWindow
      },
      {
        id: "data-visualizer2",
        name: "Data Visualizer2",
        type: "app",
        icon: AppWindow
      }
    ];
  }
};
