import { v4 as uuidv4 } from 'uuid';
import { LibraryComponent, ComponentState, ComponentAction } from './componentLibrary/types';

export interface CanvasComponent {
  id: string;
  name: string;
  type: string;
  category: string;
  icon: React.ReactNode;
  iconName: string;
  props: Record<string, any>;
  style: Record<string, any>;
  content?: string;
  children: CanvasComponent[];
  isSelectable: boolean;
  isDraggable: boolean;
  isDroppable: boolean;
  position?: { x: number; y: number };
  description?: string;
  states?: { id: string; name: string; defaultValue: any; type: string; value: any; }[];
  actions?: { id: string; name: string; description: string; type: string; }[];
}

export interface CanvasState {
  components: CanvasComponent[];
  selectedComponentId: string | null;
  gridEnabled: boolean;
  snapToGrid: boolean;
  gridSize: number;
  history: Array<{
    components: CanvasComponent[];
    selectedComponentId: string | null;
  }>;
  historyIndex: number;
}

export const initialCanvasState: CanvasState = {
  components: [],
  selectedComponentId: null,
  gridEnabled: true,
  snapToGrid: true,
  gridSize: 10,
  history: [],
  historyIndex: -1
};

const getInitialPosition = (existingComponents: CanvasComponent[]) => {
  if (existingComponents.length === 0) {
    return { x: 100, y: 100 };
  }
  
  const lastComponent = existingComponents[existingComponents.length - 1];
  const lastPos = lastComponent.position || { x: 100, y: 100 };
  
  return {
    x: lastPos.x + 50,
    y: lastPos.y + 50
  };
};

const makeHistorySnapshot = (
  state: CanvasState
): { components: CanvasComponent[]; selectedComponentId: string | null } => {
  return {
    components: JSON.parse(JSON.stringify(state.components)),
    selectedComponentId: state.selectedComponentId
  };
};

const updateHistory = (state: CanvasState): CanvasState => {
  const newHistory = state.history.slice(0, state.historyIndex + 1);
  newHistory.push(makeHistorySnapshot(state));
  
  return {
    ...state,
    history: newHistory,
    historyIndex: newHistory.length - 1
  };
};

export const addComponentToCanvas = (state: CanvasState, component: LibraryComponent): CanvasState => {
  const newComponent: CanvasComponent = {
    id: `${component.type}-${Date.now()}`,
    name: component.name,
    type: component.type,
    category: component.category,
    icon: component.icon,
    iconName: component.iconName,
    props: component.props || {},
    style: component.style || {},
    content: component.content,
    children: [],
    isSelectable: component.isSelectable !== false,
    isDraggable: component.isDraggable !== false,
    isDroppable: component.isDroppable !== false,
    position: { x: 100, y: 100 },
    description: component.description,
    states: component.states ? component.states.map(state => ({
      id: state.id,
      name: state.name,
      defaultValue: state.defaultValue || null,
      type: state.type,
      value: state.value !== undefined ? state.value : state.defaultValue
    })) : [],
    actions: component.actions ? component.actions.map(action => ({
      id: action.id,
      name: action.name,
      description: action.description || '',
      type: action.type
    })) : []
  };

  return {
    ...state,
    components: [...state.components, newComponent]
  };
};

export const removeComponentFromCanvas = (
  state: CanvasState,
  componentId: string
): CanvasState => {
  const newComponents = state.components.filter(c => c.id !== componentId);
  
  const newState = {
    ...state,
    components: newComponents,
    selectedComponentId: state.selectedComponentId === componentId
      ? null
      : state.selectedComponentId
  };
  
  return updateHistory(newState);
};

export const updateComponentPosition = (
  state: CanvasState,
  componentId: string,
  position: { x: number; y: number }
): CanvasState => {
  const newComponents = state.components.map(c => {
    if (c.id === componentId) {
      return {
        ...c,
        position: state.snapToGrid
          ? {
              x: Math.round(position.x / state.gridSize) * state.gridSize,
              y: Math.round(position.y / state.gridSize) * state.gridSize
            }
          : position
      };
    }
    return c;
  });
  
  const newState = {
    ...state,
    components: newComponents
  };
  
  return updateHistory(newState);
};

export const updateComponentProperty = (
  state: CanvasState,
  componentId: string,
  property: string,
  value: any
): CanvasState => {
  const newComponents = state.components.map(c => {
    if (c.id === componentId) {
      if (property.startsWith('props.')) {
        const propKey = property.substring(6);
        return {
          ...c,
          props: {
            ...c.props,
            [propKey]: value
          }
        };
      } else if (property.startsWith('style.')) {
        const styleKey = property.substring(6);
        return {
          ...c,
          style: {
            ...c.style,
            [styleKey]: value
          }
        };
      } else {
        return {
          ...c,
          [property]: value
        };
      }
    }
    return c;
  });
  
  const newState = {
    ...state,
    components: newComponents
  };
  
  return updateHistory(newState);
};

export const selectComponent = (
  state: CanvasState,
  componentId: string | null
): CanvasState => {
  return {
    ...state,
    selectedComponentId: componentId
  };
};

export const saveCanvasState = (
  state: CanvasState
): CanvasState => {
  console.log('Saving canvas state:', state);
  return state;
};

export const toggleGrid = (
  state: CanvasState
): CanvasState => {
  return {
    ...state,
    gridEnabled: !state.gridEnabled
  };
};

export const toggleSnapToGrid = (
  state: CanvasState
): CanvasState => {
  return {
    ...state,
    snapToGrid: !state.snapToGrid
  };
};

export const undo = (state: CanvasState): CanvasState => {
  if (state.historyIndex <= 0) {
    return state;
  }
  
  const newIndex = state.historyIndex - 1;
  const historyItem = state.history[newIndex];
  
  return {
    ...state,
    components: historyItem.components,
    selectedComponentId: historyItem.selectedComponentId,
    historyIndex: newIndex
  };
};

export const redo = (state: CanvasState): CanvasState => {
  if (state.historyIndex >= state.history.length - 1) {
    return state;
  }
  
  const newIndex = state.historyIndex + 1;
  const historyItem = state.history[newIndex];
  
  return {
    ...state,
    components: historyItem.components,
    selectedComponentId: historyItem.selectedComponentId,
    historyIndex: newIndex
  };
};
