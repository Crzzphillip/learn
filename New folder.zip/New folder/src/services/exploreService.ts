
import { jsonDatabaseService } from './jsonDatabaseService';
import { toast } from "sonner";

export interface PopularAgent {
  id: string;
  name: string;
  category: string;
  posts: string;
  avatar: string;
}

export interface FeaturedSpace {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: string;
  listens: string;
  rating: string;
  image: string;
}

export const exploreService = {
  // Get all popular agents
  getPopularAgents: async (): Promise<PopularAgent[]> => {
    try {
      return await jsonDatabaseService.getAll<PopularAgent>('popular_agents');
    } catch (error) {
      console.error("Error fetching popular agents:", error);
      toast.error("Failed to load popular agents");
      return [];
    }
  },

  // Get all featured spaces
  getFeaturedSpaces: async (): Promise<FeaturedSpace[]> => {
    try {
      return await jsonDatabaseService.getAll<FeaturedSpace>('featured_spaces');
    } catch (error) {
      console.error("Error fetching featured spaces:", error);
      toast.error("Failed to load featured spaces");
      return [];
    }
  },

  // Get personas with pagination
  getPersonas: async (page: number, limit: number, search: string = ""): Promise<{
    items: any[],
    nextPage: number | undefined
  }> => {
    try {
      const allPersonas = await jsonDatabaseService.getAll('personas');
      const filteredPersonas = allPersonas.filter((persona: any) => 
        persona.name.toLowerCase().includes(search.toLowerCase()) ||
        persona.description.toLowerCase().includes(search.toLowerCase())
      );
      
      const start = page * limit;
      const end = start + limit;
      const items = filteredPersonas.slice(start, end);
      
      return {
        items,
        nextPage: end < filteredPersonas.length ? page + 1 : undefined
      };
    } catch (error) {
      console.error("Error fetching personas:", error);
      toast.error("Failed to load personas");
      return { items: [], nextPage: undefined };
    }
  },

  // Get spaces with pagination
  getSpaces: async (page: number, limit: number, search: string = ""): Promise<{
    items: any[],
    nextPage: number | undefined
  }> => {
    try {
      const allSpaces = await jsonDatabaseService.getAll('spaces');
      const filteredSpaces = allSpaces.filter((space: any) => 
        space.name.toLowerCase().includes(search.toLowerCase()) ||
        space.description.toLowerCase().includes(search.toLowerCase())
      );
      
      const start = page * limit;
      const end = start + limit;
      const items = filteredSpaces.slice(start, end);
      
      return {
        items,
        nextPage: end < filteredSpaces.length ? page + 1 : undefined
      };
    } catch (error) {
      console.error("Error fetching spaces:", error);
      toast.error("Failed to load spaces");
      return { items: [], nextPage: undefined };
    }
  }
};
