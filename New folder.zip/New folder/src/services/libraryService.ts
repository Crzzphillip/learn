
import { jsonDatabaseService } from './jsonDatabaseService';
import { LucideIcon } from 'lucide-react';

export interface UserSubscription {
  id: string;
  title: string;
  plan: string;
  creditsLeft: number;
  totalCredits: number;
  renewalDate: string;
  agents: number;
  workflows: number;
  apps: number;
  icon: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface ActivityItem {
  id: string;
  type: string;
  title: string;
  space: string;
  icon: string;
  timestamp: string;
  creditsUsed: number;
  createdAt?: string;
  updatedAt?: string;
}

export const libraryService = {
  getUserSubscriptions: async (): Promise<UserSubscription[]> => {
    try {
      return await jsonDatabaseService.getAll<UserSubscription>('library_subscriptions');
    } catch (error) {
      console.error("Error fetching user subscriptions:", error);
      return [];
    }
  },

  getSubscriptionById: async (id: string): Promise<UserSubscription | null> => {
    try {
      return await jsonDatabaseService.getById<UserSubscription>('library_subscriptions', id);
    } catch (error) {
      console.error(`Error fetching subscription with ID ${id}:`, error);
      return null;
    }
  },

  getRecentActivity: async (): Promise<ActivityItem[]> => {
    try {
      const activities = await jsonDatabaseService.getAll<ActivityItem>('library_activities');
      // Sort by timestamp, newest first
      return activities.sort((a, b) => 
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      );
    } catch (error) {
      console.error("Error fetching recent activities:", error);
      return [];
    }
  },

  updateSubscription: async (id: string, data: Partial<UserSubscription>): Promise<UserSubscription | null> => {
    try {
      return await jsonDatabaseService.update<UserSubscription>('library_subscriptions', id, data);
    } catch (error) {
      console.error(`Error updating subscription with ID ${id}:`, error);
      throw error;
    }
  }
};
