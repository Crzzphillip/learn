
import { exploreService } from './exploreService';

export const ITEMS_PER_PAGE = 12;

export const fetchItems = async ({ pageParam = 0, type, searchQuery = "" }) => {
  if (type === "personas" || type === "agents") {
    return await exploreService.getPersonas(pageParam, ITEMS_PER_PAGE, searchQuery);
  } else {
    return await exploreService.getSpaces(pageParam, ITEMS_PER_PAGE, searchQuery);
  }
};
