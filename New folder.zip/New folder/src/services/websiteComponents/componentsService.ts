
import { WebsiteComponent } from './types';
import { createInitialComponents } from './initial';

// Simulate fetching components from a server
export const fetchWebsiteComponents = async (): Promise<WebsiteComponent[]> => {
  // In a real application, this would be an API call
  // For now, we'll use our initial components
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(createInitialComponents());
    }, 300);
  });
};

// Simulate saving components to a server
export const saveWebsiteComponents = async (components: WebsiteComponent[]): Promise<boolean> => {
  // In a real application, this would be an API call
  // Return a deep clone of the components without circular references
  const componentsToSave = JSON.parse(JSON.stringify(
    components.map(component => {
      const { parent, ...componentWithoutParent } = component;
      return componentWithoutParent;
    })
  ));
  
  return new Promise((resolve) => {
    setTimeout(() => {
      console.log('Components saved to server:', componentsToSave);
      resolve(true);
    }, 300);
  });
};

// Get a specific component by ID
export const fetchComponentById = async (id: string): Promise<WebsiteComponent | null> => {
  const components = await fetchWebsiteComponents();
  
  // Helper function to search through components recursively
  const findComponent = (comps: WebsiteComponent[], searchId: string): WebsiteComponent | null => {
    for (const comp of comps) {
      if (comp.id === searchId) {
        return comp;
      }
      
      if (comp.children && comp.children.length > 0) {
        const found = findComponent(comp.children, searchId);
        if (found) return found;
      }
    }
    
    return null;
  };
  
  return findComponent(components, id);
};
