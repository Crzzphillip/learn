
import { WebsiteComponent } from './types';
import { createIcon } from '../componentLibrary/icons';
import { Box, Heading, Text, Layout, Image, Link } from 'lucide-react';

// Get website components (sample data function)
export const getWebsiteComponents = (): WebsiteComponent[] => {
  return [
    {
      id: 'section-1',
      name: 'Main Section',
      type: 'section',
      category: 'layout',
      icon: createIcon(Layout),
      iconName: 'Layout',
      props: {
        className: 'w-full p-6'
      },
      style: {
        minHeight: '300px',
        backgroundColor: '#f9fafb',
      },
      isSelectable: true,
      isDraggable: true,
      isDroppable: true,
      children: [
        {
          id: 'heading-1',
          name: 'Header',
          type: 'h1',
          category: 'text',
          icon: createIcon(Heading),
          iconName: 'Heading',
          props: {},
          style: {
            fontSize: '32px',
            fontWeight: 'bold',
            color: '#111827',
            marginBottom: '16px',
          },
          content: 'Welcome to Your Website',
          isSelectable: true,
          isDraggable: true,
          isDroppable: false,
          children: [],
          position: { x: 20, y: 20 },
          parent: null
        },
        {
          id: 'paragraph-1',
          name: 'Description',
          type: 'p',
          category: 'text',
          icon: createIcon(Text),
          iconName: 'Text',
          props: {},
          style: {
            fontSize: '16px',
            lineHeight: '1.5',
            color: '#4b5563',
            marginBottom: '24px',
          },
          content: 'Start building your website by adding components from the panel on the right.',
          isSelectable: true,
          isDraggable: true,
          isDroppable: false,
          children: [],
          position: { x: 20, y: 80 },
          parent: null
        },
        {
          id: 'button-1',
          name: 'Primary Button',
          type: 'button',
          category: 'basic',
          icon: createIcon(Link),
          iconName: 'Link',
          props: {
            className: 'px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700'
          },
          style: {
            fontSize: '14px',
            fontWeight: '500',
            border: 'none',
            cursor: 'pointer',
          },
          content: 'Get Started',
          isSelectable: true,
          isDraggable: true,
          isDroppable: false,
          children: [],
          position: { x: 20, y: 140 },
          parent: null
        }
      ],
      position: { x: 50, y: 50 },
      parent: null
    }
  ];
};
