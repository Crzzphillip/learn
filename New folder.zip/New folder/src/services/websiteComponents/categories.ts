
import { createIcon } from './icons';
import { 
  Layout,
  Box,
  Text,
  AlignLeft,
  BarChart3,
  Image
} from 'lucide-react';

// Categories of components
export const componentCategories = [
  { id: 'layout', name: 'Layout Components', icon: createIcon(Layout), iconName: 'Layout' },
  { id: 'basic', name: 'Basic Elements', icon: createIcon(Box), iconName: 'Box' },
  { id: 'text', name: 'Typography', icon: createIcon(Text), iconName: 'Text' },
  { id: 'input', name: 'Form Elements', icon: createIcon(AlignLeft), iconName: 'AlignLeft' },
  { id: 'data', name: 'Data Display', icon: createIcon(BarChart3), iconName: 'BarChart3' },
  { id: 'media', name: 'Media', icon: createIcon(Image), iconName: 'Image' },
];
