
import { ReactNode } from 'react';

export interface WebsiteComponent {
  id: string;
  name: string;
  type: string;
  category: string;
  icon: ReactNode;
  iconName: string;
  props: Record<string, any>;
  style: Record<string, any>;
  content?: string;
  isSelectable: boolean;
  isDraggable: boolean;
  isDroppable: boolean;
  children: WebsiteComponent[];
  position: { x: number; y: number };
  description?: string;
  parent?: WebsiteComponent | null;
}
