
import React from 'react';
import { 
  AlignCenter,
  AlignLeft,
  AlignRight,
  BarChart3,
  Box,
  Calendar,
  CheckCircle,
  Clock,
  Code,
  Database,
  FileText,
  Headphones,
  Heading,
  Image,
  Layout,
  Link,
  List,
  ListOrdered,
  Mail,
  Map,
  Menu,
  MessageCircle,
  Navigation,
  Phone,
  Search,
  ShoppingCart,
  Sliders,
  Table,
  Text,
  User,
  Users,
  Video,
  FormInput,
  ToggleLeft
} from 'lucide-react';

// Helper function to create icons safely without JSX syntax issues in TS files
export const createIcon = (IconComponent: React.ComponentType<any>, size: number = 4): React.ReactNode => {
  return React.createElement(IconComponent, { className: `w-${size} h-${size}` });
};

// Export a function to get default icon based on component type
export const getDefaultIconForComponent = (type: string): React.ReactNode => {
  switch (type.toLowerCase()) {
    case 'section':
      return createIcon(Layout);
    case 'div':
    case 'container':
      return createIcon(Box);
    case 'h1':
    case 'h2':
    case 'h3':
    case 'h4':
    case 'h5':
    case 'h6':
      return createIcon(Heading);
    case 'p':
    case 'span':
      return createIcon(Text);
    case 'button':
      return createIcon(Code);
    case 'a':
    case 'link':
      return createIcon(Link);
    case 'input':
    case 'textarea':
      return createIcon(FormInput);
    case 'img':
    case 'image':
      return createIcon(Image);
    case 'ul':
    case 'ol':
    case 'li':
      return createIcon(List);
    case 'table':
      return createIcon(Table);
    case 'nav':
      return createIcon(Navigation);
    default:
      return createIcon(Box);
  }
};

// Utility function to get icon by name
export const getIconByName = (iconName: string): React.ReactNode => {
  switch(iconName) {
    case 'Layout':
      return createIcon(Layout);
    case 'Heading':
      return createIcon(Heading);
    case 'Type':
    case 'Text':
      return createIcon(Text);
    case 'AlignLeft':
    case 'Input':
      return createIcon(AlignLeft);
    case 'Code':
    case 'Button':
      return createIcon(Code);
    case 'Image':
      return createIcon(Image);
    case 'Link':
      return createIcon(Link);
    case 'Box':
    case 'Div':
    case 'Section':
    default:
      return createIcon(Box);
  }
};
