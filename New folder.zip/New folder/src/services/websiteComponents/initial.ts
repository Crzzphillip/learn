
import { WebsiteComponent } from './types';
import { createIcon } from './icons';
import { getWebsiteComponents } from './components';
import { Layout, Heading, Text } from 'lucide-react';

export const createInitialComponents = (): WebsiteComponent[] => {
  return [
    {
      id: 'section-main',
      name: 'Main Section',
      type: 'section',
      category: 'layout',
      icon: createIcon(Layout),
      iconName: 'Layout',
      props: { className: 'container mx-auto px-4 py-8' },
      style: { width: '100%' },
      isDroppable: true,
      isDraggable: true,
      isSelectable: true,
      children: [
        {
          id: 'h1-main',
          name: 'Main Heading',
          type: 'h1',
          category: 'text',
          icon: createIcon(Heading),
          iconName: 'Heading',
          props: { className: 'text-3xl font-bold mb-6' },
          style: {},
          isDraggable: true,
          isSelectable: true,
          isDroppable: false,
          children: [],
          position: { x: 20, y: 20 },
          content: 'Welcome to the Website Builder'
        },
        {
          id: 'p-main',
          name: 'Description',
          type: 'p',
          category: 'text',
          icon: createIcon(Text),
          iconName: 'Text',
          props: { className: 'text-lg mb-8' },
          style: {},
          isDraggable: true,
          isSelectable: true,
          isDroppable: false,
          children: [],
          position: { x: 20, y: 80 },
          content: 'Start building your website by adding components from the panel on the right.'
        }
      ],
      position: { x: 50, y: 50 }
    }
  ];
};
