
// Helper functions for managing website components
import { WebsiteComponent } from './types';

export const findComponentById = (
  components: WebsiteComponent[],
  id: string
): WebsiteComponent | null => {
  for (const component of components) {
    if (component.id === id) {
      return component;
    }
    
    if (component.children && component.children.length > 0) {
      const foundInChildren = findComponentById(component.children, id);
      if (foundInChildren) {
        return foundInChildren;
      }
    }
  }
  
  return null;
};

export const updateComponentInTree = (
  components: WebsiteComponent[],
  updatedComponent: WebsiteComponent
): WebsiteComponent[] => {
  return components.map(component => {
    if (component.id === updatedComponent.id) {
      return { ...component, ...updatedComponent };
    }
    
    if (component.children && component.children.length > 0) {
      return {
        ...component,
        children: updateComponentInTree(component.children, updatedComponent)
      };
    }
    
    return component;
  });
};

export const deleteComponentFromTree = (
  components: WebsiteComponent[],
  id: string
): WebsiteComponent[] => {
  return components.filter(component => {
    if (component.id === id) {
      return false;
    }
    
    if (component.children && component.children.length > 0) {
      component.children = deleteComponentFromTree(component.children, id);
    }
    
    return true;
  });
};

export const addComponentToParent = (
  components: WebsiteComponent[],
  parentId: string,
  newComponent: WebsiteComponent
): WebsiteComponent[] => {
  return components.map(component => {
    if (component.id === parentId) {
      return {
        ...component,
        children: [...component.children, newComponent]
      };
    }
    
    if (component.children && component.children.length > 0) {
      return {
        ...component,
        children: addComponentToParent(component.children, parentId, newComponent)
      };
    }
    
    return component;
  });
};
