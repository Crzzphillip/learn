
import React from "react";
import { WorkspaceTemplate } from "@/types/workspace";
import { workspaceTemplateData } from "./workspaceComponentsData";
import { getIconByName } from "@/components/WorkspaceCreator/workspaceCreatorUtils";
import { WorkspaceTemplateWithComponent, WorkspaceComponentWithIcon } from "./workspaceTemplateTypes";

// Service to provide template data for workspace builder
export const workspaceBuilderService = {
  getTemplateById: (templateId: string): WorkspaceTemplateWithComponent | null => {
    const template = templates.find(t => t.id === templateId);
    return template || null;
  },

  getAllTemplates: (): WorkspaceTemplateWithComponent[] => {
    // Make sure we have templates
    if (templates.length === 0) {
      console.error("No templates available. Check workspaceTemplateData.");
    }
    return templates;
  },

  getPopularTemplates: (): WorkspaceTemplateWithComponent[] => {
    const popularTemplates = templates.filter(t => t.tags.includes('popular')).slice(0, 6);
    if (popularTemplates.length === 0) {
      // Return all templates if no popular ones found
      return templates.slice(0, 6);
    }
    return popularTemplates;
  },

  getRecentTemplates: (): WorkspaceTemplateWithComponent[] => {
    // In a real app, this would be fetched from a database or local storage
    return templates.slice(0, 4);
  },

  getCategoryTemplates: (category: string): WorkspaceTemplateWithComponent[] => {
    return templates.filter(t => t.category === category);
  }
};

// Function for workspaceService.ts
export const getWorkspaceTemplates = (spaceId: string): any[] => {
  // For now, simply return some templates filtered by space ID if needed
  // In a real implementation, you would filter templates based on the spaceId
  if (spaceId) {
    return templates.map(template => ({
      id: `${spaceId}-${template.id}`,
      type: 'aiforge',
      spaceId,
      title: template.name,
      description: template.description,
      creator: { name: "AI Forge", avatar: "https://i.pravatar.cc/150?u=aiforge" },
      members: ["user1", "user2"],
      favorites: Math.floor(Math.random() * 100),
      lastUpdated: new Date().toISOString(),
      componentCount: template.components.length,
      savePoints: 3,
      template: true,
      templateType: template.category,
      templateIcon: template.id,
      components: [{ type: "ai", count: template.components.length }]
    }));
  }
  return [];
};

// Transform the template data to include React component icons
const templates: WorkspaceTemplateWithComponent[] = workspaceTemplateData.map(template => {
  return {
    ...template,
    icon: getIconByName(template.iconName || "", "h-5 w-5") as React.ReactElement
  };
});

// Available components for builder with React components for icons
const builderComponentsData = [
  {
    id: "gpt-agent",
    name: "GPT Agent",
    type: "agent",
    category: "AI Components",
    description: "Versatile AI agent based on GPT models for natural language tasks",
    iconName: "Bot",
    aiPowered: true,
    capabilities: ["text-generation", "reasoning", "conversation"],
  },
  {
    id: "ui-designer",
    name: "UI Designer",
    type: "tool",
    category: "Design Tools",
    description: "Visual design tool for creating responsive interfaces",
    iconName: "PenLine",
    aiPowered: true,
    capabilities: ["ui-design", "responsive-design"],
  },
  {
    id: "db-connector",
    name: "Database Connector",
    type: "integration",
    category: "Data",
    description: "Connect to various database types with automatic schema detection",
    iconName: "Database",
    aiPowered: false,
    capabilities: ["data-storage", "data-retrieval"],
  },
  {
    id: "frontend-builder",
    name: "Frontend Builder",
    type: "tool",
    category: "Development",
    description: "Drag-and-drop builder for web interfaces with code generation",
    iconName: "Code",
    aiPowered: true,
    capabilities: ["ui-design", "code-generation"],
  },
  {
    id: "backend-generator",
    name: "Backend Generator",
    type: "tool",
    category: "Development",
    description: "AI-powered backend code generator with API endpoints",
    iconName: "Code",
    aiPowered: true,
    capabilities: ["code-generation", "api-design"],
  },
  {
    id: "api-connector",
    name: "API Connector",
    type: "integration",
    category: "Integration",
    description: "Connect to external APIs with automatic documentation parsing",
    iconName: "Puzzle",
    aiPowered: true,
    capabilities: ["api-integration"],
  },
  {
    id: "workflow-builder",
    name: "Workflow Builder",
    type: "tool",
    category: "Automation",
    description: "Create complex workflows with conditional logic and triggers",
    iconName: "Workflow",
    aiPowered: true,
    capabilities: ["workflow-automation"],
  },
  {
    id: "insight-generator",
    name: "AI Insights",
    type: "agent",
    category: "Analytics",
    description: "Generate data insights and predictions using machine learning",
    iconName: "Sparkles",
    aiPowered: true,
    capabilities: ["data-analysis", "prediction"],
  },
  {
    id: "chart-builder",
    name: "Chart Builder",
    type: "tool",
    category: "Analytics",
    description: "Create interactive charts and dashboards from your data",
    iconName: "BarChart3",
    aiPowered: false,
    capabilities: ["data-visualization"],
  },
  {
    id: "platform-compiler",
    name: "Platform Compiler",
    type: "tool",
    category: "Development",
    description: "Compile your app for multiple platforms including iOS, Android, and web",
    iconName: "Rocket",
    aiPowered: true,
    capabilities: ["cross-platform", "deployment"],
  },
  {
    id: "memory-module",
    name: "Memory Module",
    type: "extension",
    category: "AI Components",
    description: "Long-term memory storage for AI agents to recall past interactions",
    iconName: "BrainCircuit",
    aiPowered: true,
    capabilities: ["data-storage", "retrieval"],
  },
  {
    id: "personalization-engine",
    name: "Personalization Engine",
    type: "agent",
    category: "User Experience",
    description: "Dynamically adapt content and UI based on user behavior",
    iconName: "Zap",
    aiPowered: true,
    capabilities: ["personalization", "user-analysis"],
  },
  {
    id: "testing-debugger",
    name: "AI Testing & Debugging",
    type: "tool",
    category: "Development",
    description: "Automatically test and debug your application code",
    iconName: "Settings",
    aiPowered: true,
    capabilities: ["testing", "debugging"],
  }
];

// Transform the data to include React component icons
export const builderComponents = builderComponentsData.map(component => {
  return {
    ...component,
    icon: getIconByName(component.iconName || "", "h-5 w-5") as React.ReactElement
  };
});

// Export the type for use in other files - using 'export type' syntax
export type { WorkspaceTemplateWithComponent, WorkspaceComponentWithIcon };
