
import { roles, users, permissions, Role, User, Permission } from '@/data/securityPermissionsData';
import { toast } from "sonner";

export const securityService = {
  getRoles: async (): Promise<Role[]> => {
    try {
      // In a real application, this would fetch from an API or database
      return roles;
    } catch (error) {
      console.error("Error fetching roles:", error);
      toast.error("Failed to load roles");
      return [];
    }
  },

  getUsers: async (): Promise<User[]> => {
    try {
      return users;
    } catch (error) {
      console.error("Error fetching users:", error);
      toast.error("Failed to load users");
      return [];
    }
  },

  getPermissions: async (): Promise<Permission[]> => {
    try {
      return permissions;
    } catch (error) {
      console.error("Error fetching permissions:", error);
      toast.error("Failed to load permissions");
      return [];
    }
  },

  getUserById: async (id: string): Promise<User | null> => {
    try {
      const user = users.find(user => user.id === id);
      if (!user) return null;
      return user;
    } catch (error) {
      console.error(`Error fetching user ${id}:`, error);
      toast.error("Failed to load user details");
      return null;
    }
  },

  getRoleById: async (id: string): Promise<Role | null> => {
    try {
      const role = roles.find(role => role.id === id);
      if (!role) return null;
      return role;
    } catch (error) {
      console.error(`Error fetching role ${id}:`, error);
      toast.error("Failed to load role details");
      return null;
    }
  },

  createUser: async (userData: Omit<User, 'id'>): Promise<boolean> => {
    try {
      // Simulate creating a user
      toast.success("User created successfully");
      return true;
    } catch (error) {
      console.error("Error creating user:", error);
      toast.error("Failed to create user");
      return false;
    }
  },

  updateUserRole: async (userId: string, roleId: string): Promise<boolean> => {
    try {
      // Simulate updating a user's role
      toast.success("User role updated");
      return true;
    } catch (error) {
      console.error(`Error updating role for user ${userId}:`, error);
      toast.error("Failed to update user role");
      return false;
    }
  },

  updateUserStatus: async (userId: string, status: 'active' | 'inactive' | 'pending'): Promise<boolean> => {
    try {
      // Simulate updating a user's status
      toast.success(`User status updated to ${status}`);
      return true;
    } catch (error) {
      console.error(`Error updating status for user ${userId}:`, error);
      toast.error("Failed to update user status");
      return false;
    }
  },

  createRole: async (roleData: Omit<Role, 'id'>): Promise<boolean> => {
    try {
      // Simulate creating a role
      toast.success("Role created successfully");
      return true;
    } catch (error) {
      console.error("Error creating role:", error);
      toast.error("Failed to create role");
      return false;
    }
  },

  updateRolePermissions: async (roleId: string, permissionIds: string[]): Promise<boolean> => {
    try {
      // Simulate updating role permissions
      toast.success("Role permissions updated");
      return true;
    } catch (error) {
      console.error(`Error updating permissions for role ${roleId}:`, error);
      toast.error("Failed to update role permissions");
      return false;
    }
  }
};
