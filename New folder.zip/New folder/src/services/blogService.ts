
import { jsonDatabaseService } from './jsonDatabaseService';

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  author: {
    name: string;
    avatar: string;
  };
  featuredImage: string;
  category: string;
  tags: string[];
  publishedAt: string;
  readTime: number;
  createdAt?: string;
  updatedAt?: string;
}

export const blogService = {
  getAllPosts: async (): Promise<BlogPost[]> => {
    try {
      const posts = await jsonDatabaseService.getAll<BlogPost>('blog');
      // Sort by published date, newest first
      return posts.sort((a, b) => 
        new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
      );
    } catch (error) {
      console.error("Error fetching blog posts:", error);
      return [];
    }
  },

  getPostById: async (id: string): Promise<BlogPost | null> => {
    try {
      return await jsonDatabaseService.getById<BlogPost>('blog', id);
    } catch (error) {
      console.error(`Error fetching blog post with ID ${id}:`, error);
      return null;
    }
  },

  getPostBySlug: async (slug: string): Promise<BlogPost | null> => {
    try {
      const posts = await jsonDatabaseService.query<BlogPost>('blog', 
        post => post.slug === slug
      );
      return posts.length > 0 ? posts[0] : null;
    } catch (error) {
      console.error(`Error fetching blog post with slug ${slug}:`, error);
      return null;
    }
  },

  getPostsByCategory: async (category: string): Promise<BlogPost[]> => {
    try {
      return await jsonDatabaseService.query<BlogPost>('blog', 
        post => post.category === category
      );
    } catch (error) {
      console.error(`Error fetching blog posts in category ${category}:`, error);
      return [];
    }
  },

  getPostsByTag: async (tag: string): Promise<BlogPost[]> => {
    try {
      return await jsonDatabaseService.query<BlogPost>('blog', 
        post => post.tags.includes(tag)
      );
    } catch (error) {
      console.error(`Error fetching blog posts with tag ${tag}:`, error);
      return [];
    }
  },

  createPost: async (post: Omit<BlogPost, 'id'>): Promise<BlogPost> => {
    try {
      return await jsonDatabaseService.create<BlogPost>('blog', post);
    } catch (error) {
      console.error("Error creating blog post:", error);
      throw error;
    }
  },

  updatePost: async (id: string, data: Partial<BlogPost>): Promise<BlogPost | null> => {
    try {
      return await jsonDatabaseService.update<BlogPost>('blog', id, data);
    } catch (error) {
      console.error(`Error updating blog post with ID ${id}:`, error);
      throw error;
    }
  },

  deletePost: async (id: string): Promise<boolean> => {
    try {
      return await jsonDatabaseService.delete('blog', id);
    } catch (error) {
      console.error(`Error deleting blog post with ID ${id}:`, error);
      throw error;
    }
  }
};
