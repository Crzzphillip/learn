
import { Workflow } from "@/types/explore";

// Service to provide Leonardo AI-specific workflows
export const leonardoWorkflowService = {
  getLeonardoWorkflows: async (): Promise<Workflow[]> => {
    // Simulate API call with a delay
    return new Promise(resolve => {
      setTimeout(() => {
        resolve([
          {
            id: "leo-workflow-1",
            title: "Portrait Enhancement",
            description: "Enhance portrait photos with AI-powered tools",
            agents: ["Image Analyzer", "Style Enhancer"],
            credits: "25",
            locked: false,
            image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Portrait+Enhancement",
            author: {
              name: "Leonardo AI",
              avatar: "/lovable-uploads/92e31f95-4874-41ef-b38a-12bfb2ea47b3.png"
            },
            usageStats: {
              runs: "1,250",
              rating: "4.8"
            },
            tags: ["photo", "portrait", "enhancement"]
          },
          {
            id: "leo-workflow-2",
            title: "Creative Painting",
            description: "Create digital paintings with AI assistance",
            agents: ["Canvas Assistant", "Style Generator"],
            credits: "35",
            locked: false,
            image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Creative+Painting",
            author: {
              name: "Leonardo AI",
              avatar: "/lovable-uploads/92e31f95-4874-41ef-b38a-12bfb2ea47b3.png"
            },
            usageStats: {
              runs: "875",
              rating: "4.6"
            },
            tags: ["painting", "creative", "digital-art"]
          },
          {
            id: "leo-workflow-3",
            title: "Image Upscaler",
            description: "Enhance image resolution with AI algorithms",
            agents: ["Resolution Enhancer"],
            credits: "15",
            locked: false,
            image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Image+Upscaler",
            author: {
              name: "Leonardo AI",
              avatar: "/lovable-uploads/92e31f95-4874-41ef-b38a-12bfb2ea47b3.png"
            },
            usageStats: {
              runs: "2,320",
              rating: "4.9"
            },
            tags: ["upscaling", "enhancement"]
          }
        ]);
      }, 300);
    });
  },
  
  getFeaturedLeonardoWorkflows: async (): Promise<Workflow[]> => {
    // Simulate API call with a delay
    return new Promise(resolve => {
      setTimeout(() => {
        resolve([
          {
            id: "leo-featured-1",
            title: "AI Portrait Generator",
            description: "Generate artistic portraits in various styles",
            agents: ["Style Transfer", "Portrait Generator"],
            credits: "50",
            locked: false,
            image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=AI+Portrait+Generator",
            author: {
              name: "Leonardo AI",
              avatar: "/lovable-uploads/92e31f95-4874-41ef-b38a-12bfb2ea47b3.png"
            },
            usageStats: {
              runs: "3,450",
              rating: "4.9"
            },
            tags: ["featured", "portrait", "generation"]
          },
          {
            id: "leo-featured-2",
            title: "Background Removal Pro",
            description: "Remove backgrounds from images with precision",
            agents: ["Image Segmentation"],
            credits: "20",
            locked: false,
            image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Background+Removal",
            author: {
              name: "Leonardo AI",
              avatar: "/lovable-uploads/92e31f95-4874-41ef-b38a-12bfb2ea47b3.png"
            },
            usageStats: {
              runs: "5,200",
              rating: "4.7"
            },
            tags: ["featured", "background", "removal"]
          }
        ]);
      }, 300);
    });
  }
};
