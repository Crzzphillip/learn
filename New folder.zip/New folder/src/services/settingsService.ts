
import { jsonDatabaseService } from './jsonDatabaseService';

export interface UserProfile {
  id: string;
  firstName: string;
  lastName: string;
  displayName: string;
  email: string;
  bio: string;
  location: string;
  timezone: string;
  avatar: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface UserPreferences {
  id: string;
  userId: string;
  theme: 'light' | 'dark' | 'system';
  emailNotifications: boolean;
  usageAlerts: boolean;
  agentUpdates: boolean;
  workflowCompletions: boolean;
  communityActivity: boolean;
  fontSize: 'small' | 'medium' | 'large';
  syntaxHighlighting: boolean;
  lineNumbers: boolean;
  autoFormatting: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface SubscriptionPlan {
  id: string;
  userId: string;
  planName: string;
  planPrice: number;
  billingCycle: 'monthly' | 'annually';
  creditsLimit: number;
  creditsUsed: number;
  renewalDate: string;
  isActive: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export const settingsService = {
  getUserProfile: async (): Promise<UserProfile | null> => {
    try {
      const profiles = await jsonDatabaseService.getAll<UserProfile>('settings_profiles');
      // For now, just return the first profile found
      // In a real app, we'd filter by the logged-in user
      return profiles.length > 0 ? profiles[0] : null;
    } catch (error) {
      console.error("Error fetching user profile:", error);
      return null;
    }
  },

  getUserPreferences: async (): Promise<UserPreferences | null> => {
    try {
      const preferences = await jsonDatabaseService.getAll<UserPreferences>('settings_preferences');
      // For now, just return the first preferences found
      // In a real app, we'd filter by the logged-in user
      return preferences.length > 0 ? preferences[0] : null;
    } catch (error) {
      console.error("Error fetching user preferences:", error);
      return null;
    }
  },

  getSubscriptionPlan: async (): Promise<SubscriptionPlan | null> => {
    try {
      const plans = await jsonDatabaseService.getAll<SubscriptionPlan>('settings_plans');
      // For now, just return the first active plan found
      // In a real app, we'd filter by the logged-in user
      return plans.find(plan => plan.isActive) || null;
    } catch (error) {
      console.error("Error fetching subscription plan:", error);
      return null;
    }
  },

  updateUserProfile: async (data: Partial<UserProfile>): Promise<UserProfile | null> => {
    try {
      const profiles = await jsonDatabaseService.getAll<UserProfile>('settings_profiles');
      const currentProfile = profiles.length > 0 ? profiles[0] : null;
      
      if (!currentProfile) {
        console.error("No user profile found to update");
        return null;
      }
      
      return await jsonDatabaseService.update<UserProfile>(
        'settings_profiles',
        currentProfile.id,
        data
      );
    } catch (error) {
      console.error("Error updating user profile:", error);
      throw error;
    }
  },

  updateUserPreferences: async (data: Partial<UserPreferences>): Promise<UserPreferences | null> => {
    try {
      const preferences = await jsonDatabaseService.getAll<UserPreferences>('settings_preferences');
      const currentPreferences = preferences.length > 0 ? preferences[0] : null;
      
      if (!currentPreferences) {
        console.error("No user preferences found to update");
        return null;
      }
      
      return await jsonDatabaseService.update<UserPreferences>(
        'settings_preferences',
        currentPreferences.id,
        data
      );
    } catch (error) {
      console.error("Error updating user preferences:", error);
      throw error;
    }
  }
};
