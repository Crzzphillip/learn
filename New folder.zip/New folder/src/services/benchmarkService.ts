
import { Benchmark, BenchmarkCategory } from '@/types/explore';
import { 
  agentBenchmarks, 
  workflowBenchmarks, 
  workspaceBenchmarks, 
  appBenchmarks,
  getBenchmarks,
  getBenchmarksBySpace
} from '@/data/benchmarksData';
import { toast } from 'sonner';

export const benchmarkService = {
  getAgentBenchmarks: async (agentId: string): Promise<Benchmark[]> => {
    try {
      // Simulate API call with a delay
      return new Promise((resolve) => {
        setTimeout(() => {
          const benchmarks = agentBenchmarks[agentId] || [];
          resolve(benchmarks);
        }, 300);
      });
    } catch (error) {
      console.error("Error fetching agent benchmarks:", error);
      toast.error("Failed to load agent benchmarks");
      return [];
    }
  },

  getWorkflowBenchmarks: async (workflowId: string): Promise<Benchmark[]> => {
    try {
      // Simulate API call with a delay
      return new Promise((resolve) => {
        setTimeout(() => {
          const benchmarks = workflowBenchmarks[workflowId] || [];
          resolve(benchmarks);
        }, 300);
      });
    } catch (error) {
      console.error("Error fetching workflow benchmarks:", error);
      toast.error("Failed to load workflow benchmarks");
      return [];
    }
  },

  getWorkspaceBenchmarks: async (workspaceId: string): Promise<Benchmark[]> => {
    try {
      // Simulate API call with a delay
      return new Promise((resolve) => {
        setTimeout(() => {
          const benchmarks = workspaceBenchmarks[workspaceId] || [];
          resolve(benchmarks);
        }, 300);
      });
    } catch (error) {
      console.error("Error fetching workspace benchmarks:", error);
      toast.error("Failed to load workspace benchmarks");
      return [];
    }
  },

  getAppBenchmarks: async (appId: string): Promise<Benchmark[]> => {
    try {
      // Simulate API call with a delay
      return new Promise((resolve) => {
        setTimeout(() => {
          const benchmarks = appBenchmarks[appId] || [];
          resolve(benchmarks);
        }, 300);
      });
    } catch (error) {
      console.error("Error fetching app benchmarks:", error);
      toast.error("Failed to load app benchmarks");
      return [];
    }
  },

  getEntityBenchmarks: async (
    type: 'agent' | 'workflow' | 'workspace' | 'app',
    entityId: string
  ): Promise<Benchmark[]> => {
    try {
      // Simulate API call with a delay
      return new Promise((resolve) => {
        setTimeout(() => {
          const benchmarks = getBenchmarks(type, entityId);
          resolve(benchmarks);
        }, 300);
      });
    } catch (error) {
      console.error(`Error fetching ${type} benchmarks:`, error);
      toast.error(`Failed to load ${type} benchmarks`);
      return [];
    }
  },

  getSpaceBenchmarks: async (spaceId: string): Promise<Benchmark[]> => {
    try {
      // Simulate API call with a delay
      return new Promise((resolve) => {
        setTimeout(() => {
          const benchmarks = getBenchmarksBySpace(spaceId);
          resolve(benchmarks);
        }, 300);
      });
    } catch (error) {
      console.error("Error fetching space benchmarks:", error);
      toast.error("Failed to load space benchmarks");
      return [];
    }
  },

  getBenchmarksByCategory: async (category: BenchmarkCategory): Promise<Benchmark[]> => {
    try {
      // Simulate API call with a delay
      return new Promise((resolve) => {
        setTimeout(() => {
          // Gather all benchmarks
          const allBenchmarks = [
            ...Object.values(agentBenchmarks).flat(),
            ...Object.values(workflowBenchmarks).flat(),
            ...Object.values(workspaceBenchmarks).flat(),
            ...Object.values(appBenchmarks).flat()
          ];
          
          // Filter by category
          const filteredBenchmarks = allBenchmarks.filter(bench => bench.category === category);
          resolve(filteredBenchmarks);
        }, 300);
      });
    } catch (error) {
      console.error(`Error fetching benchmarks for category ${category}:`, error);
      toast.error(`Failed to load benchmarks for category ${category}`);
      return [];
    }
  }
};
