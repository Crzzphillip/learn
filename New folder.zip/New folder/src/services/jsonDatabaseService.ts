
import { v4 as uuidv4 } from 'uuid';
import { toast } from "sonner";

// Import the JSON database
// We'll use dynamic import to ensure this works in both dev and production builds
let dbData: any = null;

// Function to load the database
const loadDatabase = async () => {
  try {
    if (!dbData) {
      // In a production environment, we'd use a different approach
      // For now, we're importing the JSON file directly
      const module = await import('../data/db.json');
      dbData = module.default || module;
    }
    return dbData;
  } catch (error) {
    console.error("Error loading database:", error);
    toast.error("Error loading database");
    return {
      users: [],
      models: [],
      workflows: [],
      blog: [],
      notifications: [],
      library: [],
      settings: []
    };
  }
};

// Generic type for database records
interface DatabaseRecord {
  id: string;
  [key: string]: any;
}

// Generic CRUD operations
export const jsonDatabaseService = {
  // Get all records of a specific type
  getAll: async <T extends DatabaseRecord>(entity: string): Promise<T[]> => {
    const db = await loadDatabase();
    return (db[entity] || []) as T[];
  },

  // Get a single record by ID
  getById: async <T extends DatabaseRecord>(entity: string, id: string): Promise<T | null> => {
    const db = await loadDatabase();
    const items = db[entity] || [];
    return items.find((item: T) => item.id === id) as T || null;
  },

  // Create a new record
  create: async <T extends DatabaseRecord>(entity: string, data: Omit<T, 'id'>): Promise<T> => {
    const db = await loadDatabase();
    if (!db[entity]) db[entity] = [];
    
    // Create the new item with the required fields
    const newItem = {
      id: uuidv4(),
      ...data,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    db[entity].push(newItem);
    // In a real app, we would write to the file here
    // For now, we're just updating the in-memory object
    
    // Properly cast using "as unknown as T" to avoid TypeScript error
    return newItem as unknown as T;
  },

  // Update an existing record
  update: async <T extends DatabaseRecord>(entity: string, id: string, data: Partial<T>): Promise<T | null> => {
    const db = await loadDatabase();
    if (!db[entity]) return null;
    
    const index = db[entity].findIndex((item: T) => item.id === id);
    if (index === -1) return null;
    
    const updatedItem = {
      ...db[entity][index],
      ...data,
      updatedAt: new Date().toISOString()
    };
    
    db[entity][index] = updatedItem;
    // In a real app, we would write to the file here
    
    // Properly cast using "as unknown as T" to avoid TypeScript error
    return updatedItem as unknown as T;
  },

  // Delete a record
  delete: async (entity: string, id: string): Promise<boolean> => {
    const db = await loadDatabase();
    if (!db[entity]) return false;
    
    const initialLength = db[entity].length;
    db[entity] = db[entity].filter((item: DatabaseRecord) => item.id !== id);
    
    // In a real app, we would write to the file here
    
    return db[entity].length < initialLength;
  },

  // Custom queries
  query: async <T extends DatabaseRecord>(
    entity: string, 
    predicate: (item: T) => boolean
  ): Promise<T[]> => {
    const db = await loadDatabase();
    if (!db[entity]) return [];
    
    return db[entity].filter(predicate) as T[];
  }
};
