
import { marketplaceItems, MarketplaceItem } from '@/data/marketplaceData';
import { toast } from "sonner";

export const marketplaceService = {
  getMarketplaceItems: async (): Promise<MarketplaceItem[]> => {
    try {
      // In a real application, this would fetch from an API or database
      return marketplaceItems;
    } catch (error) {
      console.error("Error fetching marketplace items:", error);
      toast.error("Failed to load marketplace items");
      return [];
    }
  },

  getItemById: async (id: string): Promise<MarketplaceItem | null> => {
    try {
      const item = marketplaceItems.find(item => item.id === id);
      if (!item) return null;
      return item;
    } catch (error) {
      console.error(`Error fetching marketplace item ${id}:`, error);
      toast.error("Failed to load item details");
      return null;
    }
  },

  purchaseItem: async (id: string): Promise<boolean> => {
    try {
      // Simulate purchasing an item
      toast.success("Item purchased successfully");
      return true;
    } catch (error) {
      console.error(`Error purchasing item ${id}:`, error);
      toast.error("Failed to purchase item");
      return false;
    }
  },

  downloadItem: async (id: string): Promise<boolean> => {
    try {
      // Simulate downloading an item
      toast.success("Download started");
      return true;
    } catch (error) {
      console.error(`Error downloading item ${id}:`, error);
      toast.error("Failed to download item");
      return false;
    }
  },

  rateItem: async (id: string, rating: number): Promise<boolean> => {
    try {
      // Simulate rating an item
      toast.success("Rating submitted");
      return true;
    } catch (error) {
      console.error(`Error rating item ${id}:`, error);
      toast.error("Failed to submit rating");
      return false;
    }
  }
};
