import { SpaceTemplate, SpaceStat } from '@/types/space';
import { spaceTemplates } from '@/config/spaceTemplates';
import { dummyDatabase, ContentReviewItem } from '@/services/dummyDatabase';
import { Agent, Workflow, Tool, Resource, App, TrendingWorkspace } from '@/types/explore';
import { leonardoService } from '@/services/leonardoService';
import { 
  Code, 
  Wand, 
  Palette, 
  Layers,
  GitBranch,
  Database,
  Shield,
  BookOpen,
  GraduationCap,
  AppWindow
} from 'lucide-react';

// Mock data for trending workspaces
const TRENDING_WORKSPACES: TrendingWorkspace[] = [
  {
    id: "tw-1",
    title: "AI Development Studio",
    description: "Comprehensive environment for AI model development",
    owner: {
      name: "AI Research Team",
      avatar: "https://placehold.co/600x400/232323/FFFFFF/png?text=AI+Dev+Studio"
    },
    usageStats: {
      users: 8,
      runs: 120,
      lastRun: "2023-10-15"
    },
    tags: ["AI", "Development", "Machine Learning"],
    savedCredits: 180,
    totalCredits: 250,
    testimonial: "Boosted our AI development efficiency by 40%",
    reviews: 42,
    upvotes: 156,
    price: {
      value: 25,
      type: "credits"
    }
  },
  {
    id: "tw-2",
    title: "Content Creation Hub",
    description: "Create and manage content with AI assistance",
    owner: {
      name: "Creative Labs",
      avatar: "https://placehold.co/600x400/232323/FFFFFF/png?text=Content+Hub"
    },
    usageStats: {
      users: 12,
      runs: 85,
      lastRun: "2023-11-20"
    },
    tags: ["Content", "Creativity", "Marketing"],
    savedCredits: 150,
    totalCredits: 200,
    testimonial: "Created a month's worth of content in just one afternoon",
    reviews: 36,
    upvotes: 128,
    price: {
      value: 20,
      type: "credits"
    }
  },
  {
    id: "tw-3",
    title: "Data Analysis Platform",
    description: "Analyze and visualize data with AI-powered tools",
    owner: {
      name: "Data Science Group",
      avatar: "https://placehold.co/600x400/232323/FFFFFF/png?text=Data+Analysis"
    },
    usageStats: {
      users: 6,
      runs: 60,
      lastRun: "2023-09-05"
    },
    tags: ["Data", "Analysis", "Visualization"],
    savedCredits: 120,
    totalCredits: 180,
    testimonial: "Reduced analysis time by 65% with AI assistance",
    reviews: 28,
    upvotes: 95,
    price: {
      value: 18,
      type: "credits"
    }
  }
];

// Mock data for agents
const AGENTS: Agent[] = [
  {
    id: "agent-1",
    title: "Code Assistant",
    description: "AI-powered code generation and debugging",
    icon: Code,
    category: "Development",
    rating: "4.8",
    credits: "500",
    locked: false,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Code+Assistant"
  },
  {
    id: "agent-2",
    title: "Content Writer",
    description: "Create engaging content for various platforms",
    icon: Wand,
    category: "Creative",
    rating: "4.6",
    credits: "450",
    locked: false,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Content+Writer"
  },
  {
    id: "agent-3",
    title: "Data Analyzer",
    description: "Analyze and interpret complex datasets",
    icon: Database,
    category: "Analytics",
    rating: "4.9",
    credits: "600",
    locked: true,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Data+Analyzer"
  }
];

// Mock data for workflows
const WORKFLOWS: Workflow[] = [
  {
    id: "workflow-1",
    title: "Automated Code Review",
    description: "Automatically review and improve code quality",
    category: "Development",
    rating: "4.7",
    credits: "800",
    locked: false,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Code+Review",
    agents: ["Code Assistant", "Documentation Writer"]
  },
  {
    id: "workflow-2",
    title: "Content Pipeline",
    description: "End-to-end content creation and publishing",
    category: "Creative",
    rating: "4.5",
    credits: "750",
    locked: false,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Content+Pipeline",
    agents: ["Content Writer", "Design Assistant"]
  },
  {
    id: "workflow-3",
    title: "Data ETL Process",
    description: "Extract, transform, and load data efficiently",
    category: "Analytics",
    rating: "4.8",
    credits: "900",
    locked: true,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=ETL+Process",
    agents: ["Data Analyzer", "Database Engineer"]
  }
];

// Mock data for tools
const TOOLS: Tool[] = [
  {
    id: "tool-1",
    title: "Code Generator",
    description: "Generate code snippets from natural language",
    icon: Code,
    category: "Development",
    credits: "300",
    locked: false,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Code+Generator"
  },
  {
    id: "tool-2",
    title: "Image Enhancer",
    description: "Enhance and optimize images with AI",
    icon: Palette,
    category: "Creative",
    credits: "250",
    locked: false,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Image+Enhancer"
  },
  {
    id: "tool-3",
    title: "Data Cleaner",
    description: "Clean and preprocess datasets automatically",
    icon: Database,
    category: "Analytics",
    credits: "350",
    locked: true,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Data+Cleaner"
  }
];

// Mock data for apps
const APPS: App[] = [
  {
    id: "app-1",
    title: "Code Studio",
    description: "Integrated development environment for AI coding",
    icon: Code,
    credits: "1000",
    locked: false,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Code+Studio"
  },
  {
    id: "app-2",
    title: "Creative Canvas",
    description: "Digital canvas for AI-assisted creation",
    icon: Palette,
    credits: "950",
    locked: false,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Creative+Canvas"
  },
  {
    id: "app-3",
    title: "Data Dashboard",
    description: "Interactive dashboard for data visualization",
    icon: Database,
    credits: "1100",
    locked: true,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Data+Dashboard"
  }
];

// Mock data for resources
const RESOURCES: Resource[] = [
  {
    id: "resource-1",
    title: "Coding Best Practices",
    description: "Guide to writing clean and efficient code",
    icon: BookOpen,
    category: "Development",
    type: "Guide",
    rating: "4.5",
    locked: false,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Coding+Guide"
  },
  {
    id: "resource-2",
    title: "Creative Design Templates",
    description: "Collection of design templates for various projects",
    icon: Layers,
    category: "Creative",
    type: "Templates",
    rating: "4.4",
    locked: false,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Design+Templates"
  },
  {
    id: "resource-3",
    title: "Data Analysis Techniques",
    description: "Advanced techniques for data analysis",
    icon: GraduationCap,
    category: "Analytics",
    type: "Tutorial",
    rating: "4.7",
    locked: true,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Analysis+Techniques"
  }
];

// Mock data for enhanced workflows
const ENHANCED_WORKFLOWS: Workflow[] = [
  {
    id: "enhanced-1",
    title: "AI-Enhanced Code Pipeline",
    description: "End-to-end code development with AI enhancements",
    category: "Development",
    rating: "4.9",
    credits: "1200",
    locked: false,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Enhanced+Pipeline"
  },
  {
    id: "enhanced-2",
    title: "Creative Content System",
    description: "Comprehensive system for content creation and management",
    category: "Creative",
    rating: "4.8",
    credits: "1150",
    locked: false,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Content+System"
  }
];

// Mock data for featured workflows
const FEATURED_WORKFLOWS: Workflow[] = [
  {
    id: "featured-1",
    title: "Top-Rated Development Flow",
    description: "The most highly rated development workflow",
    category: "Development",
    rating: "5.0",
    credits: "1500",
    locked: false,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Top+Workflow"
  },
  {
    id: "featured-2",
    title: "Editor's Choice Creative Flow",
    description: "Editor's pick for creative workflows",
    category: "Creative",
    rating: "4.9",
    credits: "1450",
    locked: false,
    image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Editors+Choice"
  }
];

// Mock data for stats and trends
const SPACE_STATS: SpaceStat[] = [
  {
    icon: Code,
    label: "Active Users",
    value: "2,456"
  },
  {
    icon: Layers,
    label: "Daily Sessions",
    value: "1,287"
  },
  {
    icon: Wand,
    label: "Avg. Session Time",
    value: "28m"
  },
  {
    icon: Database,
    label: "Workflow Runs",
    value: "9.2k"
  }
];

const TREND_DATA = [
  {
    title: "User Growth",
    change: "+12%",
    description: "Compared to last month",
    isUp: true,
    gradient: "from-green-500 to-emerald-700"
  },
  {
    title: "Workspace Activity",
    change: "+8%",
    description: "Compared to last month",
    isUp: true,
    gradient: "from-blue-500 to-indigo-700"
  },
  {
    title: "Resource Usage",
    change: "+15%",
    description: "Compared to last month",
    isUp: true,
    gradient: "from-purple-500 to-violet-700"
  }
];

// Function to filter data based on spaceId
export const spaceDataService = {
  // Get space template based on spaceId
  getSpaceTemplate: (spaceId: string): SpaceTemplate => {
    return spaceTemplates[spaceId] || spaceTemplates.development;
  },
  
  // Get space stats
  getSpaceStats: (): SpaceStat[] => {
    return SPACE_STATS;
  },
  
  // Get trend data
  getTrendData: () => {
    return TREND_DATA;
  },
  
  // Get trending workspaces
  getTrendingWorkspaces: (): TrendingWorkspace[] => {
    return TRENDING_WORKSPACES;
  },
  
  // Get agents filtered by spaceId
  getFilteredAgents: (): Agent[] => {
    return AGENTS;
  },
  
  // Get workflows filtered by spaceId
  getFilteredWorkflows: async (spaceId?: string): Promise<Workflow[]> => {
    try {
      // Import workflowService dynamically to avoid circular dependencies
      const { workflowService } = await import('@/services/workflowService');
      return await workflowService.getWorkflows(spaceId);
    } catch (error) {
      console.error("Error fetching workflows:", error);
      return [];
    }
  },
  
  // Get tools filtered by spaceId
  getFilteredTools: (): Tool[] => {
    return TOOLS;
  },
  
  // Get apps filtered by spaceId
  getFilteredApps: (): App[] => {
    return APPS;
  },
  
  // Get resources filtered by spaceId
  getFilteredResources: (): Resource[] => {
    return RESOURCES;
  },
  
  // Get enhanced workflows filtered by spaceId
  getFilteredEnhancedWorkflows: (): Workflow[] => {
    return ENHANCED_WORKFLOWS;
  },
  
  // Get featured workflows filtered by spaceId
  getFilteredFeaturedWorkflows: async (spaceId?: string): Promise<Workflow[]> => {
    try {
      // Import workflowService dynamically to avoid circular dependencies
      const { workflowService } = await import('@/services/workflowService');
      return await workflowService.getFeaturedWorkflows(spaceId);
    } catch (error) {
      console.error("Error fetching featured workflows:", error);
      return [];
    }
  },
  
  // Get review items
  getReviewItems: async (): Promise<ContentReviewItem[]> => {
    try {
      const items = await dummyDatabase.getReviewItems();
      return items;
    } catch (error) {
      console.error("Error getting review items:", error);
      return [];
    }
  },
  
  // Approve content
  approveContent: async (id: string): Promise<void> => {
    try {
      await dummyDatabase.approveContent(id);
    } catch (error) {
      console.error("Error approving content:", error);
    }
  },
  
  // Reject content
  rejectContent: async (id: string): Promise<void> => {
    try {
      await dummyDatabase.rejectContent(id);
    } catch (error) {
      console.error("Error rejecting content:", error);
    }
  }
};
