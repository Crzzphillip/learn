
import { spaceRecentActivity } from "@/components/Layout/components/data/recentActivity";
import { LucideIcon } from "lucide-react";

export interface SpaceActivity {
  id: string;
  type: string;
  title: string;
  timestamp: string;
  icon: LucideIcon;
  description: string;
}

export const getSpaceRecentActivity = (spaceId: string): SpaceActivity[] => {
  // In a real application, this would fetch data from an API based on the spaceId
  // For now we're returning mock data
  return spaceRecentActivity;
};
