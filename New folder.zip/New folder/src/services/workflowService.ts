
import { Workflow } from "@/types/explore";

// Create a centralized service for workflows with proper data type handling
export const workflowService = {
  // Get filtered workflows by space ID
  getWorkflows: async (spaceId?: string): Promise<Workflow[]> => {
    try {
      // This is a placeholder - in a real app, you would fetch from an API
      // or database based on the spaceId
      
      // Ensure we have a valid spaceId, otherwise return empty array
      if (!spaceId || spaceId === 'undefined') {
        console.warn('Invalid spaceId provided to workflowService:', spaceId);
        return [];
      }
      
      // Dummy data for demo purposes
      const demoWorkflows: Workflow[] = [
        {
          id: "workflow-1",
          title: "Automated Code Review",
          description: "Automatically review and improve code quality",
          category: "Development",
          rating: "4.7",
          credits: "800",
          locked: false,
          image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Code+Review",
          agents: ["Code Assistant", "Documentation Writer"]
        },
        {
          id: "workflow-2",
          title: "Content Pipeline",
          description: "End-to-end content creation and publishing",
          category: "Creative",
          rating: "4.5",
          credits: "750",
          locked: false,
          image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Content+Pipeline",
          agents: ["Content Writer", "Design Assistant"]
        }
      ];
      
      return demoWorkflows;
    } catch (error) {
      console.error("Error fetching workflows:", error);
      // Always return an empty array on error, never null or undefined
      return [];
    }
  },
  
  // Get featured workflows by space ID
  getFeaturedWorkflows: async (spaceId?: string): Promise<Workflow[]> => {
    try {
      // Ensure we have a valid spaceId, otherwise return empty array
      if (!spaceId || spaceId === 'undefined') {
        console.warn('Invalid spaceId provided to workflowService:', spaceId);
        return [];
      }
      
      // Dummy data for demo purposes
      const demoFeaturedWorkflows: Workflow[] = [
        {
          id: "featured-1",
          title: "Top-Rated Development Flow",
          description: "The most highly rated development workflow",
          category: "Development",
          rating: "5.0",
          credits: "1500",
          locked: false,
          image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Top+Workflow",
          author: {
            name: "AI Research Team",
            avatar: "https://placehold.co/100/232323/FFFFFF/png",
            role: "Developer"
          },
          usageStats: {
            runs: "1.2k",
            copies: "356",
            rating: "4.9"
          },
          tags: ["AI", "Development", "High Performance"]
        },
        {
          id: "featured-2",
          title: "Editor's Choice Creative Flow",
          description: "Editor's pick for creative workflows",
          category: "Creative",
          rating: "4.9",
          credits: "1450",
          locked: false,
          image: "https://placehold.co/600x400/232323/FFFFFF/png?text=Editors+Choice",
          author: {
            name: "Creative Labs",
            avatar: "https://placehold.co/100/232323/FFFFFF/png",
            role: "Designer"
          },
          usageStats: {
            runs: "956",
            copies: "243",
            rating: "4.8"
          },
          tags: ["Creative", "Design", "Content"]
        }
      ];
      
      return demoFeaturedWorkflows;
    } catch (error) {
      console.error("Error fetching featured workflows:", error);
      // Always return an empty array on error, never null or undefined
      return [];
    }
  }
};
