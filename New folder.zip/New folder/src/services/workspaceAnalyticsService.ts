
import { Workspace } from "./workspaceService";

export interface WorkspaceAnalytics {
  leads: number;
  conversions: number;
  revenue: string;
  growth: string;
  lastUpdated: string;
}

/**
 * Generate default analytics data for workspaces that don't have any
 */
export const generateDefaultAnalytics = (): WorkspaceAnalytics => {
  return {
    leads: Math.floor(Math.random() * 100) + 50,
    conversions: Math.floor(Math.random() * 50) + 10,
    revenue: '$' + ((Math.random() * 10000) + 1000).toFixed(2),
    growth: '+' + (Math.floor(Math.random() * 20) + 5) + '%',
    lastUpdated: new Date().toISOString()
  };
};

/**
 * Get analytics data for a specific workspace
 * This function ensures analytics data is always available
 */
export const getWorkspaceAnalytics = (workspace: Workspace): WorkspaceAnalytics => {
  // If workspace is null or undefined, return default analytics
  if (!workspace) {
    console.warn("Workspace is undefined or null, returning default analytics");
    return generateDefaultAnalytics();
  }
  
  // If workspace has analytics data, return it
  if (workspace.analytics) {
    return workspace.analytics;
  }
  
  // If no analytics data exists, generate default data
  console.info("No analytics data found for workspace, generating default");
  return generateDefaultAnalytics();
};

/**
 * Get performance data for charts in the workspace overview
 */
export const getPerformanceData = (workspace: Workspace) => {
  // This would typically come from a real API call
  // For now we're generating random data
  return [
    { name: 'Mon', leads: 12, conversions: 4 },
    { name: 'Tue', leads: 19, conversions: 7 },
    { name: 'Wed', leads: 15, conversions: 5 },
    { name: 'Thu', leads: 22, conversions: 9 },
    { name: 'Fri', leads: 28, conversions: 11 },
    { name: 'Sat', leads: 16, conversions: 6 },
    { name: 'Sun', leads: 15, conversions: 5 },
  ];
};
