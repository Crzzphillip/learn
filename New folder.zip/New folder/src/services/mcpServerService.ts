
import { mcpServers, MCPServerItem } from '@/data/mcpServerData';
import { toast } from "sonner";

export const mcpServerService = {
  getServers: async (): Promise<MCPServerItem[]> => {
    try {
      // In a real application, this would fetch from an API or database
      return mcpServers;
    } catch (error) {
      console.error("Error fetching MCP servers:", error);
      toast.error("Failed to load MCP servers");
      return [];
    }
  },

  getServerById: async (id: string): Promise<MCPServerItem | null> => {
    try {
      const server = mcpServers.find(server => server.id === id);
      if (!server) return null;
      return server;
    } catch (error) {
      console.error(`Error fetching MCP server ${id}:`, error);
      toast.error("Failed to load server details");
      return null;
    }
  },

  restartServer: async (id: string): Promise<boolean> => {
    try {
      // Simulate restarting a server
      toast.success("Server restart initiated");
      return true;
    } catch (error) {
      console.error(`Error restarting server ${id}:`, error);
      toast.error("Failed to restart server");
      return false;
    }
  },

  updateServerStatus: async (id: string, status: 'online' | 'offline' | 'maintenance'): Promise<boolean> => {
    try {
      // Simulate updating server status
      toast.success(`Server status updated to ${status}`);
      return true;
    } catch (error) {
      console.error(`Error updating server ${id} status:`, error);
      toast.error("Failed to update server status");
      return false;
    }
  }
};
