
import { Workflow } from "@/types/explore";
import { WorkspaceComponent } from "@/types/workspace";
import { getWorkspaceTemplates } from "./workspaceTemplateService";

export type WorkspaceType = 'standard' | 'aiforge' | 'canvas';

export interface Workspace {
  id: string;
  type: WorkspaceType;
  spaceId: string;
  title: string;
  name?: string;
  description: string;
  creator: { name: string; avatar: string; };
  members: string[];
  favorites: number;
  lastUpdated: string;
  componentCount: number;
  savePoints: number;
  template: boolean;
  templateType?: string;
  templateIcon?: string;
  components: { type: string; count: number; }[];
  activeCollaborators?: { name: string; avatar: string; }[];
  // For canvas workspaces
  canvasType?: 'drawing' | 'inpainting' | 'generation';
  // Performance metrics
  performance?: {
    processingTime: string;
    responseTime: string;
    accuracy: string;
    usageCost: string;
  };
  // Team info
  team?: {
    name: string;
    avatar: string;
    role: string;
    lastActive?: string;
  }[];
  // Integration info
  integrations?: {
    name: string;
    type: string;
    status: 'active' | 'inactive' | 'pending';
    icon: string;
  }[];
  // Analytics data
  analytics?: {
    leads: number;
    conversions: number;
    revenue: string;
    growth: string;
    lastUpdated: string;
  };
  // Saved states for workspace versioning
  savedStates?: {
    id: string;
    title: string;
    description: string;
    timestamp: string;
  }[];
  // Export options
  exportOptions?: {
    id: string;
    type: string;
    name: string;
    icon: string;
  }[];
  // Owner information
  owner?: {
    id: string;
    name: string;
    avatar: string;
  };
}

// All workspaces are now sourced from the template service 
export const getWorkspaces = (spaceId?: string): Workspace[] => {
  if (spaceId) {
    return getWorkspaceTemplates(spaceId);
  }
  
  // If no spaceId is provided, return all workspaces from all spaces
  const allSpaces = ['leonardo', 'development', 'creative', 'aiforge', 'productivity', 'default'];
  return allSpaces.flatMap(spaceId => getWorkspaceTemplates(spaceId));
};

export const getWorkspaceById = (workspaceId: string): Workspace | undefined => {
  const allWorkspaces = getWorkspaces();
  const workspace = allWorkspaces.find(workspace => workspace.id === workspaceId);
  
  // Enhance workspace with additional data for the detailed view
  if (workspace) {
    // Add performance metrics if not present
    if (!workspace.performance) {
      workspace.performance = {
        processingTime: Math.floor(Math.random() * 200) + 50 + 'ms',
        responseTime: Math.floor(Math.random() * 100) + 20 + 'ms',
        accuracy: Math.floor(Math.random() * 20) + 80 + '%',
        usageCost: '$' + ((Math.random() * 10) + 1).toFixed(2)
      };
    }
    
    // Add owner if not present
    if (!workspace.owner) {
      workspace.owner = {
        id: 'owner-1',
        name: workspace.creator.name,
        avatar: workspace.creator.avatar
      };
    }
    
    // Add team members if not present
    if (!workspace.team) {
      workspace.team = [
        {
          name: workspace.creator.name,
          avatar: workspace.creator.avatar,
          role: 'Owner',
          lastActive: 'Just now'
        },
        {
          name: 'Alex Johnson',
          avatar: 'https://i.pravatar.cc/150?u=alex',
          role: 'Editor',
          lastActive: '2 hours ago'
        },
        {
          name: 'Sam Chen',
          avatar: 'https://i.pravatar.cc/150?u=sam',
          role: 'Viewer',
          lastActive: 'Yesterday'
        }
      ];
    }
    
    // Add integrations if not present
    if (!workspace.integrations) {
      workspace.integrations = [
        {
          name: 'Google Drive',
          type: 'Storage',
          status: 'active',
          icon: '📁'
        },
        {
          name: 'Slack',
          type: 'Communication',
          status: 'active',
          icon: '💬'
        },
        {
          name: 'GitHub',
          type: 'Code Repository',
          status: 'pending',
          icon: '📊'
        }
      ];
    }
    
    // Add export options if not present
    if (!workspace.exportOptions) {
      workspace.exportOptions = [
        {
          id: 'web-app',
          type: 'web',
          name: 'Web Application',
          icon: '🌐'
        },
        {
          id: 'mobile-app',
          type: 'mobile',
          name: 'Mobile Application',
          icon: '📱'
        },
        {
          id: 'desktop-app',
          type: 'desktop',
          name: 'Desktop Application',
          icon: '💻'
        },
        {
          id: 'browser-extension',
          type: 'extension',
          name: 'Browser Extension',
          icon: '🔌'
        }
      ];
    }
    
    // Add active collaborators if not present
    if (!workspace.activeCollaborators) {
      workspace.activeCollaborators = [
        {
          name: workspace.creator.name,
          avatar: workspace.creator.avatar
        },
        {
          name: 'Alex Johnson',
          avatar: 'https://i.pravatar.cc/150?u=alex'
        }
      ];
    }
    
    // Add analytics data if not present
    if (!workspace.analytics) {
      workspace.analytics = {
        leads: Math.floor(Math.random() * 100) + 50,
        conversions: Math.floor(Math.random() * 50) + 10,
        revenue: '$' + ((Math.random() * 10000) + 1000).toFixed(2),
        growth: '+' + (Math.floor(Math.random() * 20) + 5) + '%',
        lastUpdated: new Date().toISOString()
      };
    }
    
    // Add saved states if not present
    if (!workspace.savedStates) {
      workspace.savedStates = [
        {
          id: "state-1",
          title: "Initial version",
          description: "First saved version of this workspace",
          timestamp: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString() // 7 days ago
        },
        {
          id: "state-2",
          title: "Version with updated workflows",
          description: "Added optimized workflow connections",
          timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString() // 3 days ago
        },
        {
          id: "state-3",
          title: "Latest backup",
          description: "Pre-deployment snapshot",
          timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString() // 1 day ago
        }
      ];
    }
  }
  
  return workspace;
};

export const getWorkspaceType = (workspaceId: string): WorkspaceType => {
  const workspace = getWorkspaceById(workspaceId);
  return workspace?.type || 'standard';
};

// Get Leonardo Canvas Workspaces
export const getLeonardoCanvasWorkspaces = (): Workspace[] => {
  return getWorkspaces().filter(workspace => workspace.type === 'canvas' && workspace.spaceId === 'leonardo');
};

// Get AI Forge Workspaces
export const getAIForgeWorkspaces = (): Workspace[] => {
  return getWorkspaces().filter(workspace => workspace.type === 'aiforge' && workspace.spaceId === 'aiforge');
};
