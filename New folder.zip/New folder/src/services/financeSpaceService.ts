
import { toast } from "sonner";

interface FinancialInstrument {
  id: string;
  name: string;
  type: 'stock' | 'bond' | 'forex' | 'crypto' | 'commodity';
  description: string;
  marketStatus: 'bull' | 'bear' | 'neutral';
  volatility: 'low' | 'medium' | 'high';
  recommendation: 'buy' | 'sell' | 'hold';
}

interface FinancialRegulation {
  id: string;
  name: string;
  region: string;
  description: string;
  complianceLevel: 'basic' | 'intermediate' | 'advanced';
  requiredFor: string[];
}

interface MarketTrend {
  id: string;
  name: string;
  description: string;
  impact: 'low' | 'medium' | 'high';
  duration: 'short-term' | 'mid-term' | 'long-term';
  sectors: string[];
}

// Mock data for financial instruments
const financialInstruments: FinancialInstrument[] = [
  {
    id: 'instr-1',
    name: 'Tech Sector ETF',
    type: 'stock',
    description: 'An ETF focused on technology sector companies',
    marketStatus: 'bull',
    volatility: 'medium',
    recommendation: 'buy'
  },
  {
    id: 'instr-2',
    name: 'Corporate Bond Portfolio',
    type: 'bond',
    description: 'A diversified portfolio of corporate bonds',
    marketStatus: 'neutral',
    volatility: 'low',
    recommendation: 'hold'
  },
  {
    id: 'instr-3',
    name: 'EUR/USD',
    type: 'forex',
    description: 'Euro to US Dollar exchange pair',
    marketStatus: 'bear',
    volatility: 'medium',
    recommendation: 'sell'
  },
  {
    id: 'instr-4',
    name: 'Bitcoin',
    type: 'crypto',
    description: 'Bitcoin cryptocurrency',
    marketStatus: 'bull',
    volatility: 'high',
    recommendation: 'buy'
  },
  {
    id: 'instr-5',
    name: 'Gold Futures',
    type: 'commodity',
    description: 'Gold commodity futures contracts',
    marketStatus: 'bull',
    volatility: 'medium',
    recommendation: 'buy'
  }
];

// Mock data for financial regulations
const financialRegulations: FinancialRegulation[] = [
  {
    id: 'reg-1',
    name: 'Basel III',
    region: 'Global',
    description: 'International regulatory framework for banks',
    complianceLevel: 'advanced',
    requiredFor: ['Banking', 'Finance', 'Investment']
  },
  {
    id: 'reg-2',
    name: 'MiFID II',
    region: 'Europe',
    description: 'Markets in Financial Instruments Directive',
    complianceLevel: 'advanced',
    requiredFor: ['Trading', 'Investment Banking']
  },
  {
    id: 'reg-3',
    name: 'Dodd-Frank Act',
    region: 'United States',
    description: 'Financial regulation reform legislation',
    complianceLevel: 'intermediate',
    requiredFor: ['Banking', 'Financial Services']
  }
];

// Mock data for market trends
const marketTrends: MarketTrend[] = [
  {
    id: 'trend-1',
    name: 'ESG Investing',
    description: 'Focus on environmental, social, and governance factors',
    impact: 'high',
    duration: 'long-term',
    sectors: ['Energy', 'Manufacturing', 'Technology']
  },
  {
    id: 'trend-2',
    name: 'Digital Transformation',
    description: 'Adoption of digital technologies across industries',
    impact: 'high',
    duration: 'long-term',
    sectors: ['Banking', 'Retail', 'Healthcare']
  },
  {
    id: 'trend-3',
    name: 'Supply Chain Resilience',
    description: 'Building robust supply chains after disruptions',
    impact: 'medium',
    duration: 'mid-term',
    sectors: ['Manufacturing', 'Retail', 'Transportation']
  }
];

export const financeSpaceService = {
  getFinancialInstruments: async (): Promise<FinancialInstrument[]> => {
    try {
      // In a real application, this would fetch from an API
      return financialInstruments;
    } catch (error) {
      console.error("Error fetching financial instruments:", error);
      toast.error("Failed to load financial instruments");
      return [];
    }
  },

  getFinancialRegulations: async (): Promise<FinancialRegulation[]> => {
    try {
      return financialRegulations;
    } catch (error) {
      console.error("Error fetching financial regulations:", error);
      toast.error("Failed to load regulations");
      return [];
    }
  },

  getMarketTrends: async (): Promise<MarketTrend[]> => {
    try {
      return marketTrends;
    } catch (error) {
      console.error("Error fetching market trends:", error);
      toast.error("Failed to load market trends");
      return [];
    }
  }
};
