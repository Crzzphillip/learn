
import React, { ReactNode } from 'react';
import { Box, Heading, Text, Layout, Image, Link } from 'lucide-react';
import { LibraryComponent } from './componentLibrary/types';
import { createIcon } from './componentLibrary/icons';
import { WebsiteComponent } from './websiteComponents/types';
export type { WebsiteComponent } from './websiteComponents/types';
export { getWebsiteComponents } from './websiteComponents/components';

// Create a component instance from a library component
export const createComponentInstance = (component: LibraryComponent | WebsiteComponent): WebsiteComponent => {
  return {
    id: `${component.type}-${Date.now()}`,
    name: component.name,
    type: component.type,
    category: component.category,
    icon: component.icon,
    iconName: component.iconName,
    props: { ...(component.props || {}) },
    style: { ...(component.style || {}) },
    content: component.content,
    isSelectable: component.isSelectable !== false,
    isDraggable: component.isDraggable !== false,
    isDroppable: component.isDroppable !== false,
    children: component.children?.map(child => createComponentInstance(child)) || [],
    position: { x: 100, y: 100 },
    description: component.description,
    parent: null
  };
};

// Create initial components for a new website
export const createInitialComponents = (): WebsiteComponent[] => {
  return [
    {
      id: 'section-1',
      name: 'Main Section',
      type: 'section',
      category: 'layout',
      icon: createIcon(Layout),
      iconName: 'Layout',
      props: {
        className: 'w-full p-6'
      },
      style: {
        minHeight: '300px',
        backgroundColor: '#f9fafb',
      },
      isSelectable: true,
      isDraggable: true,
      isDroppable: true,
      children: [
        {
          id: 'heading-1',
          name: 'Header',
          type: 'h1',
          category: 'text',
          icon: createIcon(Heading),
          iconName: 'Heading',
          props: {},
          style: {
            fontSize: '32px',
            fontWeight: 'bold',
            color: '#111827',
            marginBottom: '16px',
          },
          content: 'Welcome to Your Website',
          isSelectable: true,
          isDraggable: true,
          isDroppable: false,
          children: [],
          position: { x: 20, y: 20 }
        },
        {
          id: 'paragraph-1',
          name: 'Description',
          type: 'p',
          category: 'text',
          icon: createIcon(Text),
          iconName: 'Text',
          props: {},
          style: {
            fontSize: '16px',
            lineHeight: '1.5',
            color: '#4b5563',
            marginBottom: '24px',
          },
          content: 'Start building your website by adding components from the panel on the right.',
          isSelectable: true,
          isDraggable: true,
          isDroppable: false,
          children: [],
          position: { x: 20, y: 80 }
        },
        {
          id: 'button-1',
          name: 'Primary Button',
          type: 'button',
          category: 'basic',
          icon: createIcon(Link),
          iconName: 'Link',
          props: {
            className: 'px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700'
          },
          style: {
            fontSize: '14px',
            fontWeight: '500',
            border: 'none',
            cursor: 'pointer',
          },
          content: 'Get Started',
          isSelectable: true,
          isDraggable: true,
          isDroppable: false,
          children: [],
          position: { x: 20, y: 140 }
        }
      ],
      position: { x: 50, y: 50 },
    }
  ];
};

// Find a component by ID
export const findComponentById = (
  components: WebsiteComponent[],
  id: string
): WebsiteComponent | null => {
  for (const component of components) {
    if (component.id === id) {
      return component;
    }
    
    if (component.children && component.children.length > 0) {
      const foundInChildren = findComponentById(component.children, id);
      if (foundInChildren) {
        return foundInChildren;
      }
    }
  }
  
  return null;
};

// Update a component in the component tree
export const updateComponentInTree = (
  components: WebsiteComponent[],
  updatedComponent: WebsiteComponent
): WebsiteComponent[] => {
  return components.map(component => {
    if (component.id === updatedComponent.id) {
      return { ...component, ...updatedComponent };
    }
    
    if (component.children && component.children.length > 0) {
      return {
        ...component,
        children: updateComponentInTree(component.children, updatedComponent)
      };
    }
    
    return component;
  });
};

// Delete a component from the tree
export const deleteComponentFromTree = (
  components: WebsiteComponent[],
  id: string
): WebsiteComponent[] => {
  return components.filter(component => {
    if (component.id === id) {
      return false;
    }
    
    if (component.children && component.children.length > 0) {
      component.children = deleteComponentFromTree(component.children, id);
    }
    
    return true;
  });
};

// Add a component as a child to a parent component
export const addComponentToParent = (
  components: WebsiteComponent[],
  parentId: string,
  newComponent: WebsiteComponent
): WebsiteComponent[] => {
  return components.map(component => {
    if (component.id === parentId) {
      return {
        ...component,
        children: [...component.children, newComponent]
      };
    }
    
    if (component.children && component.children.length > 0) {
      return {
        ...component,
        children: addComponentToParent(component.children, parentId, newComponent)
      };
    }
    
    return component;
  });
};

// Helper function to get a default icon for a component type (for utility use)
export const getDefaultIconForComponent = (type: string): ReactNode => {
  switch (type.toLowerCase()) {
    case 'section':
    case 'div':
      return createIcon(Layout);
    case 'h1':
    case 'h2':
    case 'h3':
    case 'h4':
    case 'h5':
    case 'h6':
      return createIcon(Heading);
    case 'p':
    case 'span':
      return createIcon(Text);
    case 'img':
      return createIcon(Image);
    case 'a':
    case 'button':
      return createIcon(Link);
    default:
      return createIcon(Box);
  }
};
