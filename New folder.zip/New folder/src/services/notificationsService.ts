
import { jsonDatabaseService } from './jsonDatabaseService';

export type NotificationType = "message" | "alert" | "credit" | "space" | "workflow" | "app";

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  time: string;
  read: boolean;
  spaceId?: string;
  spaceName?: string;
  creditAmount?: number;
  createdAt?: string;
  updatedAt?: string;
}

export const notificationsService = {
  getAllNotifications: async (): Promise<Notification[]> => {
    try {
      const notifications = await jsonDatabaseService.getAll<Notification>('notifications');
      // Sort by time, newest first
      return notifications.sort((a, b) => 
        new Date(b.time).getTime() - new Date(a.time).getTime()
      );
    } catch (error) {
      console.error("Error fetching notifications:", error);
      return [];
    }
  },

  getUnreadNotifications: async (): Promise<Notification[]> => {
    try {
      return await jsonDatabaseService.query<Notification>('notifications', 
        notification => notification.read === false
      );
    } catch (error) {
      console.error("Error fetching unread notifications:", error);
      return [];
    }
  },

  getNotificationById: async (id: string): Promise<Notification | null> => {
    try {
      return await jsonDatabaseService.getById<Notification>('notifications', id);
    } catch (error) {
      console.error(`Error fetching notification with ID ${id}:`, error);
      return null;
    }
  },

  markAsRead: async (id: string): Promise<Notification | null> => {
    try {
      return await jsonDatabaseService.update<Notification>('notifications', id, { read: true });
    } catch (error) {
      console.error(`Error marking notification as read with ID ${id}:`, error);
      return null;
    }
  },

  markAllAsRead: async (): Promise<boolean> => {
    try {
      const notifications = await jsonDatabaseService.getAll<Notification>('notifications');
      const unreadNotifications = notifications.filter(n => !n.read);
      
      await Promise.all(
        unreadNotifications.map(notification => 
          jsonDatabaseService.update<Notification>('notifications', notification.id, { read: true })
        )
      );
      
      return true;
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
      return false;
    }
  },

  createNotification: async (notification: Omit<Notification, 'id' | 'read'>): Promise<Notification> => {
    try {
      return await jsonDatabaseService.create<Notification>('notifications', {
        ...notification,
        read: false
      });
    } catch (error) {
      console.error("Error creating notification:", error);
      throw error;
    }
  },

  deleteNotification: async (id: string): Promise<boolean> => {
    try {
      return await jsonDatabaseService.delete('notifications', id);
    } catch (error) {
      console.error(`Error deleting notification with ID ${id}:`, error);
      throw error;
    }
  }
};
