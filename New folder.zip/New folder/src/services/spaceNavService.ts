
import { SpaceNavPage } from "@/types/space";

export const getSpaceNavPages = (primaryColor: string, accentColor: string): SpaceNavPage[] => {
  return [
    {
      name: "Overview",
      path: "",
      description: "Get a complete overview of the space",
      color: primaryColor
    },
    {
      name: "Agents",
      path: "agents",
      description: "Discover AI agents to assist with your tasks",
      color: primaryColor
    },
    {
      name: "Workflows",
      path: "workflows",
      description: "Create and manage automated workflows",
      color: accentColor
    },
    {
      name: "Apps",
      path: "apps",
      description: "Explore applications built for this space",
      color: primaryColor
    },
    {
      name: "Tools",
      path: "tools",
      description: "Access specialized tools for your projects",
      color: accentColor
    },
    {
      name: "Resources",
      path: "resources",
      description: "Browse helpful resources and documentation",
      color: primaryColor
    },
    {
      name: "Workspaces",
      path: "workspaces",
      description: "Manage and create collaborative workspaces",
      color: accentColor
    },
    {
      name: "Integrations",
      path: "integrations",
      description: "Connect with third-party services and tools",
      color: primaryColor
    },
    {
      name: "MCP Server",
      path: "mcpserver",
      description: "Access and manage server configurations",
      color: accentColor
    },
    {
      name: "Marketplace",
      path: "marketplace",
      description: "Discover and install space extensions",
      color: primaryColor
    },
    {
      name: "Security",
      path: "security",
      description: "Manage access controls and permissions",
      color: accentColor
    },
    {
      name: "Community",
      path: "community",
      description: "Connect with other users in this space",
      color: primaryColor
    },
    {
      name: "Settings",
      path: "settings",
      description: "Configure space preferences and options",
      color: accentColor
    }
  ];
};
