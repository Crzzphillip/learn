
import { Showcase } from '@/types/explore';
import { showcases, showcasesByType, showcaseCategories } from '@/data/showcasesData';
import { toast } from 'sonner';

export const showcasesService = {
  getAllShowcases: async (): Promise<Showcase[]> => {
    // Simulate API call with a delay
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(showcases);
      }, 300);
    });
  },

  getShowcaseById: async (id: string): Promise<Showcase | undefined> => {
    try {
      // Simulate API call with a delay
      return new Promise((resolve) => {
        setTimeout(() => {
          const showcase = showcases.find(item => item.id === id);
          resolve(showcase);
        }, 300);
      });
    } catch (error) {
      console.error("Error fetching showcase:", error);
      toast.error("Failed to load showcase");
      return undefined;
    }
  },
  
  getShowcasesByType: async (type: 'agent' | 'workflow' | 'workspace' | 'app'): Promise<Showcase[]> => {
    try {
      // Simulate API call with a delay
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(showcasesByType[type] || []);
        }, 300);
      });
    } catch (error) {
      console.error(`Error fetching ${type} showcases:`, error);
      toast.error(`Failed to load ${type} showcases`);
      return [];
    }
  },
  
  getShowcasesByCategory: async (category: string): Promise<Showcase[]> => {
    try {
      // Simulate API call with a delay
      return new Promise((resolve) => {
        setTimeout(() => {
          const filteredShowcases = showcases.filter(
            showcase => showcase.category === category
          );
          resolve(filteredShowcases);
        }, 300);
      });
    } catch (error) {
      console.error(`Error fetching showcases for category ${category}:`, error);
      toast.error(`Failed to load showcases for category ${category}`);
      return [];
    }
  },
  
  getAllCategories: async (): Promise<string[]> => {
    // Simulate API call with a delay
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(showcaseCategories);
      }, 300);
    });
  },

  getRelatedShowcases: async (showcaseId: string): Promise<Showcase[]> => {
    try {
      // Simulate API call with a delay
      return new Promise((resolve) => {
        setTimeout(() => {
          const currentShowcase = showcases.find(item => item.id === showcaseId);
          if (!currentShowcase) {
            resolve([]);
            return;
          }
          
          // Get showcases with the same category or type, excluding the current one
          const related = showcases.filter(
            item => (item.category === currentShowcase.category || 
                    item.type === currentShowcase.type) && 
                    item.id !== showcaseId
          ).slice(0, 3); // Limit to 3 related showcases
          
          resolve(related);
        }, 300);
      });
    } catch (error) {
      console.error("Error fetching related showcases:", error);
      toast.error("Failed to load related showcases");
      return [];
    }
  },

  getRemixedShowcases: async (showcaseId: string): Promise<Showcase[]> => {
    try {
      // In a real app, this would fetch showcases that were remixed from the original
      // For now, we'll simulate by returning random showcases
      return new Promise((resolve) => {
        setTimeout(() => {
          // Randomly select 2 showcases to simulate remixes
          const remixed = [...showcases]
            .sort(() => 0.5 - Math.random())
            .filter(item => item.id !== showcaseId)
            .slice(0, 2);
          
          resolve(remixed);
        }, 300);
      });
    } catch (error) {
      console.error("Error fetching remixed showcases:", error);
      toast.error("Failed to load remixed showcases");
      return [];
    }
  }
};
