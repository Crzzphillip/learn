import { Wand2, Image, Video, Pencil, Layers, ArrowUpDown, FileText, Database, Palette } from "lucide-react";
import { Tool } from "@/types/space";

// Tools specific to the Leonardo.ai space
const LEONARDO_TOOLS: Tool[] = [
  {
    id: "image-creation",
    title: "Image Creation",
    description: "Generate high-quality images from text descriptions with advanced AI models",
    icon: Image,
    credits: "500",
    locked: false,
    image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Image+Creation",
    category: "generation",
    themeColor: "#8B5CF6"
  },
  {
    id: "motion",
    title: "Motion",
    description: "Transform static images into short animations with AI-powered motion effects",
    icon: Video,
    credits: "1200",
    locked: false,
    image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Motion",
    category: "animation",
    themeColor: "#9F8AC1"
  },
  {
    id: "canvas-editor",
    title: "Canvas Editor",
    description: "Advanced editing capabilities for fine-tuning and adjusting AI-generated images",
    icon: Palette,
    credits: "750",
    locked: false,
    image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Canvas+Editor",
    category: "editing",
    themeColor: "#7E69AB",
    route: "/space/leonardo/canvas"
  },
  {
    id: "realtime-canvas",
    title: "Realtime Canvas",
    description: "Draw and see AI-generated results in real-time as you sketch",
    icon: Pencil,
    credits: "800",
    locked: false,
    image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Realtime+Canvas",
    category: "interactive",
    themeColor: "#7E69AB",
    route: "/space/leonardo/canvas"
  },
  {
    id: "realtime-generation",
    title: "Realtime Generation",
    description: "Generate images instantly with minimal latency for rapid iteration",
    icon: Layers,
    credits: "650",
    locked: false,
    image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Realtime+Generation",
    category: "generation",
    themeColor: "#8B5CF6"
  },
  {
    id: "universal-upscaler",
    title: "Universal Upscaler",
    description: "Enhance image resolution without losing detail using AI upscaling technology",
    icon: ArrowUpDown,
    credits: "400",
    locked: false,
    image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Universal+Upscaler",
    category: "enhancement",
    themeColor: "#9F8AC1"
  },
  {
    id: "finetuned-models",
    title: "Finetuned Models",
    description: "Access specialized AI models fine-tuned for specific styles and applications",
    icon: Wand2,
    credits: "1500",
    locked: true,
    image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Finetuned+Models",
    category: "models",
    themeColor: "#8B5CF6"
  },
  {
    id: "training-datasets",
    title: "Training & Datasets",
    description: "Create and manage custom datasets to train personalized AI models",
    icon: Database,
    credits: "2000",
    locked: true,
    image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Training+%26+Datasets",
    category: "models",
    themeColor: "#7E69AB"
  },
  {
    id: "texture-generation",
    title: "Texture Generation",
    description: "Generate seamless textures and patterns for 3D models and environments",
    icon: FileText,
    credits: "900",
    locked: true,
    image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Texture+Generation",
    category: "3d",
    themeColor: "#9F8AC1"
  }
];

// Tools specific to the cryptocurrency space
const CRYPTO_TOOLS: Tool[] = [
  {
    id: "market-analysis",
    title: "Market Analysis",
    description: "Advanced tools for analyzing cryptocurrency market trends and patterns",
    icon: Layers,
    credits: "800",
    locked: false,
    image: "https://placehold.co/600x400/0EA5E9/FFFFFF/png?text=Market+Analysis",
    category: "analysis",
    themeColor: "#0EA5E9"
  },
  {
    id: "trading-bot",
    title: "Trading Bot",
    description: "Automated trading bots with customizable strategies and real-time execution",
    icon: Wand2,
    credits: "1500",
    locked: true,
    image: "https://placehold.co/600x400/0EA5E9/FFFFFF/png?text=Trading+Bot",
    category: "automation",
    themeColor: "#0284C7"
  },
  {
    id: "portfolio-tracker",
    title: "Portfolio Tracker",
    description: "Track and analyze your cryptocurrency portfolio performance across multiple exchanges",
    icon: Layers,
    credits: "500",
    locked: false,
    image: "https://placehold.co/600x400/0EA5E9/FFFFFF/png?text=Portfolio+Tracker",
    category: "portfolio",
    themeColor: "#38BDF8"
  },
  {
    id: "news-sentiment",
    title: "News Sentiment Analyzer",
    description: "AI-powered analysis of news and social media sentiment affecting cryptocurrency markets",
    icon: FileText,
    credits: "700",
    locked: false,
    image: "https://placehold.co/600x400/0EA5E9/FFFFFF/png?text=News+Sentiment",
    category: "analysis",
    themeColor: "#0EA5E9"
  },
  {
    id: "tax-calculator",
    title: "Tax Calculator",
    description: "Calculate cryptocurrency tax obligations and generate reports for compliance",
    icon: Database,
    credits: "600",
    locked: false,
    image: "https://placehold.co/600x400/0EA5E9/FFFFFF/png?text=Tax+Calculator",
    category: "finance",
    themeColor: "#38BDF8"
  }
];

// A default set of tools for spaces that don't have specific tools defined
const DEFAULT_TOOLS: Tool[] = [
  {
    id: "default-tool-1",
    title: "AI Assistant",
    description: "General-purpose AI assistant to help with various tasks in this space",
    icon: Wand2,
    credits: "500",
    locked: false,
    image: "https://placehold.co/600x400/7E69AB/FFFFFF/png?text=AI+Assistant",
    category: "general",
    themeColor: "#7E69AB"
  },
  {
    id: "default-tool-2",
    title: "Content Generator",
    description: "Generate various types of content with AI assistance",
    icon: FileText,
    credits: "700",
    locked: false,
    image: "https://placehold.co/600x400/7E69AB/FFFFFF/png?text=Content+Generator",
    category: "creation",
    themeColor: "#9F8AC1"
  },
  {
    id: "default-tool-3",
    title: "Workflow Automator",
    description: "Automate repetitive tasks and create efficient workflows",
    icon: Layers,
    credits: "900",
    locked: true,
    image: "https://placehold.co/600x400/7E69AB/FFFFFF/png?text=Workflow+Automator",
    category: "automation",
    themeColor: "#7E69AB"
  }
];

export const toolsService = {
  getToolsForSpace: (spaceId: string): Tool[] => {
    // Return specific tools based on spaceId
    switch (spaceId) {
      case 'leonardo':
        return LEONARDO_TOOLS;
      case 'crypto':
      case 'crypto-analyst':
        return CRYPTO_TOOLS;
      default:
        // For other spaces, return a default set of tools
        return DEFAULT_TOOLS;
    }
  },
  
  getToolById: (spaceId: string, toolId: string): Tool | undefined => {
    const tools = toolsService.getToolsForSpace(spaceId);
    return tools.find(tool => tool.id === toolId);
  },
  
  // Group tools by category
  getToolsByCategory: (spaceId: string): Record<string, Tool[]> => {
    const tools = toolsService.getToolsForSpace(spaceId);
    return tools.reduce((acc, tool) => {
      const category = tool.category || 'other';
      if (!acc[category]) {
        acc[category] = [];
      }
      acc[category].push(tool);
      return acc;
    }, {} as Record<string, Tool[]>);
  },
  
  // Get a list of all categories for a space
  getCategories: (spaceId: string): string[] => {
    const tools = toolsService.getToolsForSpace(spaceId);
    const categories = tools.map(tool => tool.category || 'other');
    return [...new Set(categories)];
  }
};
