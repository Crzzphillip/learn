
import { Workspace } from "./workspaceService";

export interface WorkspaceSavedState {
  id: string;
  title: string;
  description: string;
  timestamp: string;
}

export interface WorkspaceSettings {
  visibility: 'Team only' | 'Public within organization' | 'Public';
  autoSave: boolean;
  saveInterval: string;
  shareLinks: boolean;
  lockEditing: boolean;
  theme: 'Default' | 'Custom';
  customThemeColor: string;
  customCSS: boolean;
}

export const getWorkspaceSavedStates = (workspace?: Workspace): WorkspaceSavedState[] => {
  if (!workspace) {
    return [];
  }
  
  // Return workspace saved states if they exist, or default states if not
  return workspace.savedStates || [
    {
      id: "state-1",
      title: "Initial version",
      description: "First saved version of this workspace",
      timestamp: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString() // 7 days ago
    },
    {
      id: "state-2",
      title: "Version with updated workflows",
      description: "Added optimized workflow connections",
      timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString() // 3 days ago
    },
    {
      id: "state-3",
      title: "Latest backup",
      description: "Pre-deployment snapshot",
      timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString() // 1 day ago
    }
  ];
};

export const getWorkspaceSettings = (workspace?: Workspace): WorkspaceSettings => {
  if (!workspace) {
    return {
      visibility: 'Team only',
      autoSave: true,
      saveInterval: '5 minutes',
      shareLinks: true,
      lockEditing: false,
      theme: 'Default',
      customThemeColor: '#3b82f6',
      customCSS: false
    };
  }
  
  // In a real implementation, these would be fetched from workspace.settings
  // For now we're returning default values as a fallback
  return {
    visibility: 'Team only',
    autoSave: true,
    saveInterval: '5 minutes',
    shareLinks: true,
    lockEditing: false,
    theme: 'Default',
    customThemeColor: '#3b82f6',
    customCSS: false
  };
};

export const updateWorkspaceSettings = (
  workspaceId: string, 
  settingId: string, 
  value: any
): Promise<void> => {
  // This would typically involve an API call to update settings on the backend
  console.log(`Setting ${settingId} updated to ${value} for workspace ${workspaceId}`);
  return Promise.resolve();
};

export const resetWorkspaceSettingsToDefault = (
  workspaceId: string
): Promise<WorkspaceSettings> => {
  // This would typically involve an API call to reset settings on the backend
  console.log(`Settings reset to default for workspace ${workspaceId}`);
  const defaultSettings: WorkspaceSettings = {
    visibility: 'Team only',
    autoSave: true,
    saveInterval: '5 minutes',
    shareLinks: true,
    lockEditing: false,
    theme: 'Default',
    customThemeColor: '#3b82f6',
    customCSS: false
  };
  
  return Promise.resolve(defaultSettings);
};
