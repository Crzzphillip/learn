
import { toast } from "sonner";
import { Workflow } from "@/types/explore";

// Sample data for Leonardo.ai workflows
const LEONARDO_WORKFLOWS: Workflow[] = [
  {
    id: "leonardo-1",
    title: "Concept Art Generator",
    description: "Generate concept art for characters, environments, and props",
    credits: "800",
    locked: false,
    image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Concept+Art",
    agents: ["Style Transfer", "Image Enhancer"],
    author: {
      name: "Creative AI Team",
      avatar: "https://placehold.co/100/8B5CF6/FFFFFF/png?text=CAI",
      role: "AI Studio"
    },
    usageStats: {
      runs: "1.2k",
      copies: "340",
      rating: "4.8"
    },
    tags: ["concept art", "creative", "characters"]
  },
  {
    id: "leonardo-2",
    title: "Style Transfer Pipeline",
    description: "Apply artistic styles to images with fine-tuned control",
    credits: "650",
    locked: false,
    image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Style+Transfer",
    agents: ["Style Artist", "Detail Enhancer"],
    author: {
      name: "Visual Lab",
      avatar: "https://placehold.co/100/8B5CF6/FFFFFF/png?text=VL",
      role: "Design Studio"
    },
    usageStats: {
      runs: "950",
      copies: "280",
      rating: "4.7"
    },
    tags: ["style transfer", "artistic", "design"]
  },
  {
    id: "leonardo-3",
    title: "Product Visualization",
    description: "Generate realistic product visualizations from descriptions or sketches",
    credits: "950",
    locked: true,
    image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Product+Viz",
    agents: ["3D Renderer", "Detail Generator"],
    author: {
      name: "Product Design AI",
      avatar: "https://placehold.co/100/8B5CF6/FFFFFF/png?text=PDA",
      role: "Commercial Studio"
    },
    usageStats: {
      runs: "780",
      copies: "210",
      rating: "4.9"
    },
    tags: ["product", "commercial", "visualization"]
  },
  {
    id: "leonardo-4",
    title: "Architectural Visualizer",
    description: "Transform architectural plans into photorealistic renderings",
    credits: "1200",
    locked: true,
    image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Arch+Viz",
    agents: ["3D Space Generator", "Lighting Specialist"],
    author: {
      name: "Arch AI Studio",
      avatar: "https://placehold.co/100/8B5CF6/FFFFFF/png?text=AAS",
      role: "Architectural Firm"
    },
    usageStats: {
      runs: "620",
      copies: "180",
      rating: "4.8"
    },
    tags: ["architecture", "rendering", "professional"]
  }
];

// Sample data for featured Leonardo.ai workflows
const FEATURED_LEONARDO_WORKFLOWS: Workflow[] = [
  {
    id: "featured-leonardo-1",
    title: "Character Design Suite",
    description: "Complete workflow for designing game and film characters",
    credits: "1500",
    locked: false,
    image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Character+Suite",
    agents: ["Character Designer", "Texture Artist", "Pose Generator"],
    author: {
      name: "Game Dev Studio",
      avatar: "https://placehold.co/100/8B5CF6/FFFFFF/png?text=GDS",
      role: "Featured Creator"
    },
    usageStats: {
      runs: "2.4k",
      copies: "560",
      rating: "4.9"
    },
    tags: ["character design", "game development", "professional"]
  },
  {
    id: "featured-leonardo-2",
    title: "Art Direction Pipeline",
    description: "Enterprise-grade workflow for maintaining visual consistency",
    credits: "2000",
    locked: false,
    image: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Art+Direction",
    agents: ["Style Enforcer", "Quality Control", "Batch Processor"],
    author: {
      name: "Studio Consistency",
      avatar: "https://placehold.co/100/8B5CF6/FFFFFF/png?text=SC",
      role: "Enterprise Studio"
    },
    usageStats: {
      runs: "1.8k",
      copies: "380",
      rating: "4.7"
    },
    tags: ["art direction", "consistency", "enterprise"]
  }
];

export const leonardoService = {
  // Get Leonardo.ai workflows
  getLeonardoWorkflows: async (): Promise<Workflow[]> => {
    try {
      // In a real application, this would fetch from an API
      return LEONARDO_WORKFLOWS;
    } catch (error) {
      console.error("Error fetching Leonardo workflows:", error);
      toast.error("Failed to load Leonardo.ai workflows");
      return [];
    }
  },
  
  // Get featured Leonardo.ai workflows
  getFeaturedLeonardoWorkflows: async (): Promise<Workflow[]> => {
    try {
      // In a real application, this would fetch from an API
      return FEATURED_LEONARDO_WORKFLOWS;
    } catch (error) {
      console.error("Error fetching featured Leonardo workflows:", error);
      toast.error("Failed to load featured Leonardo.ai workflows");
      return [];
    }
  }
};
