import { TextStyle, LinkSettings } from '../types/workspace';

export const updateTextStyle = (
  currentStyles: TextStyle,
  property: keyof TextStyle,
  value: string | number | boolean
): TextStyle => {
  return {
    ...currentStyles,
    [property]: value,
  };
};

export const generateTextStyleString = (styles: TextStyle): string => {
  const styleProperties: string[] = [];

  if (styles.bold) styleProperties.push('font-weight: bold');
  if (styles.fontSize) styleProperties.push(`font-size: ${styles.fontSize}px`);
  if (styles.alignment) styleProperties.push(`text-align: ${styles.alignment}`);

  return styleProperties.join('; ');
};

export const validateUrl = (url: string): boolean => {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
};

export const updateLinkSettings = (
  currentSettings: LinkSettings,
  property: keyof LinkSettings,
  value: string | boolean
): LinkSettings => {
  return {
    ...currentSettings,
    [property]: value,
  };
};

export const getDevicePreviewWidth = (device: 'desktop' | 'tablet' | 'mobile'): string => {
  const widths = {
    desktop: '100%',
    tablet: '768px',
    mobile: '375px',
  };
  return widths[device];
};

export const copyToClipboard = async (text: string): Promise<boolean> => {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}; 