
import { SpaceTemplate } from "@/types/space";
import { Code, Zap, TrendingUp, User, Workflow, PenTool, BarChart, Film, BookOpen, GraduationCap } from "lucide-react";

export interface ThemeContent {
  title: string;
  description: string;
  featuredAgents: {
    title: string;
    description: string;
    icon: typeof Code;
    stats: { usedBy: string; rating: string };
    gradient: string;
  }[];
  featuredWorkflows: {
    title: string;
    description: string;
    icon: typeof Workflow;
    stats: { runs: string; copies: string };
    gradient: string;
  }[];
  trends: {
    title: string;
    change: string;
    description: string;
    isUp: boolean;
    gradient: string;
  }[];
}

export interface ThemeStyles {
  cardBg: string;
  buttonGradient: string;
  heading: string;
  divider: string;
}

export const getThemeContent = (spaceTemplate: SpaceTemplate): ThemeContent => {
  switch (spaceTemplate.type) {
    case 'crypto':
      return {
        title: "Crypto Trading World",
        description: "Advanced AI-powered platform for cryptocurrency trading and automated strategies",
        featuredAgents: [
          {
            title: "Crypto Analyst",
            description: "AI-powered market analysis and predictions",
            icon: BarChart,
            stats: { usedBy: "22k", rating: "4.8" },
            gradient: "from-blue-500/20 to-indigo-500/20"
          },
          {
            title: "Trading Bot",
            description: "Automated trading strategies execution",
            icon: TrendingUp,
            stats: { usedBy: "18k", rating: "4.7" },
            gradient: "from-indigo-500/20 to-blue-500/20"
          }
        ],
        featuredWorkflows: [
          {
            title: "Arbitrage Trading",
            description: "Automated cross-exchange price difference exploitation",
            icon: Workflow,
            stats: { runs: "5.6k", copies: "1.2k" },
            gradient: "from-blue-500/20 to-cyan-500/20"
          }
        ],
        trends: [
          {
            title: "DeFi Integration",
            change: "+38%",
            description: "Growing adoption of DeFi protocols",
            isUp: true,
            gradient: "from-blue-500/20 to-indigo-500/20"
          }
        ]
      };
    case 'image-generation':
      return {
        title: "Image Generation World",
        description: "Create, customize, and share AI-generated images with advanced models",
        featuredAgents: [
          {
            title: "Image Creator",
            description: "Generate images from text prompts",
            icon: PenTool,
            stats: { usedBy: "26k", rating: "4.9" },
            gradient: "from-purple-500/20 to-pink-500/20"
          },
          {
            title: "Style Transfer",
            description: "Apply artistic styles to existing images",
            icon: Film,
            stats: { usedBy: "19k", rating: "4.8" },
            gradient: "from-pink-500/20 to-purple-500/20"
          }
        ],
        featuredWorkflows: [
          {
            title: "Image Batch Generator",
            description: "Create multiple variations with one prompt",
            icon: Workflow,
            stats: { runs: "6.4k", copies: "1.7k" },
            gradient: "from-purple-500/20 to-fuchsia-500/20"
          }
        ],
        trends: [
          {
            title: "Model Fine-tuning",
            change: "+42%",
            description: "More users customizing generation models",
            isUp: true,
            gradient: "from-purple-500/20 to-pink-500/20"
          }
        ]
      };
    case 'education':
      return {
        title: "Education World",
        description: "Interactive learning environment with courses, tutorials, and community-driven education",
        featuredAgents: [
          {
            title: "Learning Assistant",
            description: "AI tutor that adapts to your learning style",
            icon: GraduationCap,
            stats: { usedBy: "32k", rating: "4.9" },
            gradient: "from-blue-500/20 to-cyan-500/20"
          },
          {
            title: "Code Mentor",
            description: "Provides coding guidance and feedback",
            icon: Code,
            stats: { usedBy: "24k", rating: "4.8" },
            gradient: "from-cyan-500/20 to-blue-500/20"
          }
        ],
        featuredWorkflows: [
          {
            title: "Learning Path Creator",
            description: "Design customized learning journeys",
            icon: Workflow,
            stats: { runs: "8.2k", copies: "2.1k" },
            gradient: "from-blue-500/20 to-cyan-500/20"
          }
        ],
        trends: [
          {
            title: "Hands-on Learning",
            change: "+45%",
            description: "Growing preference for interactive exercises",
            isUp: true,
            gradient: "from-blue-500/20 to-cyan-500/20"
          }
        ]
      };
    case 'creative':
      return {
        title: "Creative Art World",
        description: "Explore a digital art studio with tools for design, illustration, and creative expression",
        featuredAgents: [
          {
            title: "Digital Illustrator",
            description: "Create stunning digital illustrations and artwork",
            icon: PenTool,
            stats: { usedBy: "18k", rating: "4.8" },
            gradient: "from-pink-500/20 to-purple-500/20"
          },
          {
            title: "UI Designer",
            description: "Design beautiful user interfaces and components",
            icon: User,
            stats: { usedBy: "15k", rating: "4.7" },
            gradient: "from-purple-500/20 to-violet-500/20"
          }
        ],
        featuredWorkflows: [
          {
            title: "Digital Art Portfolio",
            description: "Create and showcase your digital artwork",
            icon: Workflow,
            stats: { runs: "4.2k", copies: "980" },
            gradient: "from-pink-500/20 to-rose-500/20"
          }
        ],
        trends: [
          {
            title: "AI Art Generation",
            change: "+46%",
            description: "Growing use of AI in digital art creation",
            isUp: true,
            gradient: "from-fuchsia-500/20 to-pink-500/20"
          }
        ]
      };
    case 'marketing':
      return {
        title: "Marketing World",
        description: "Everything you need for content creation, analytics, and campaign management",
        featuredAgents: [
          {
            title: "Content Creator",
            description: "Generate engaging marketing content for multiple channels",
            icon: PenTool,
            stats: { usedBy: "22k", rating: "4.8" },
            gradient: "from-amber-500/20 to-orange-500/20"
          },
          {
            title: "Analytics Expert",
            description: "Interpret marketing data and provide actionable insights",
            icon: BarChart,
            stats: { usedBy: "16k", rating: "4.7" },
            gradient: "from-orange-500/20 to-red-500/20"
          }
        ],
        featuredWorkflows: [
          {
            title: "Social Media Campaign",
            description: "End-to-end social media campaign management",
            icon: Workflow,
            stats: { runs: "6.8k", copies: "1.5k" },
            gradient: "from-yellow-500/20 to-amber-500/20"
          }
        ],
        trends: [
          {
            title: "Video Marketing",
            change: "+38%",
            description: "Increased use of video in marketing campaigns",
            isUp: true,
            gradient: "from-amber-500/20 to-orange-500/20"
          }
        ]
      };
    case 'productivity':
      return {
        title: "Productivity World",
        description: "Boost your efficiency with workflow automation and task management tools",
        featuredAgents: [
          {
            title: "Task Manager",
            description: "Organize, prioritize and track your tasks efficiently",
            icon: Zap,
            stats: { usedBy: "25k", rating: "4.9" },
            gradient: "from-emerald-500/20 to-teal-500/20"
          },
          {
            title: "Meeting Assistant",
            description: "Schedule, prepare for, and get more out of your meetings",
            icon: User,
            stats: { usedBy: "20k", rating: "4.8" },
            gradient: "from-teal-500/20 to-cyan-500/20"
          }
        ],
        featuredWorkflows: [
          {
            title: "Project Management",
            description: "Comprehensive project planning and tracking",
            icon: Workflow,
            stats: { runs: "7.5k", copies: "1.8k" },
            gradient: "from-green-500/20 to-emerald-500/20"
          }
        ],
        trends: [
          {
            title: "Automation Adoption",
            change: "+52%",
            description: "More teams embracing workflow automation",
            isUp: true,
            gradient: "from-teal-500/20 to-green-500/20"
          }
        ]
      };
    default: // development
      return {
        title: "Development World",
        description: "Your coding dojo with all the tools for modern software development",
        featuredAgents: [
          {
            title: "Code Assistant",
            description: "AI coding companion for software development",
            icon: Code,
            stats: { usedBy: "20k", rating: "4.9" },
            gradient: "from-blue-500/20 to-indigo-500/20"
          },
          {
            title: "DevOps Engineer",
            description: "Automate deployment pipelines and infrastructure",
            icon: Zap,
            stats: { usedBy: "15k", rating: "4.8" },
            gradient: "from-purple-500/20 to-pink-500/20"
          },
          {
            title: "Documentation Writer",
            description: "Generate technical documentation and guides",
            icon: User,
            stats: { usedBy: "12k", rating: "4.7" },
            gradient: "from-emerald-500/20 to-green-500/20"
          }
        ],
        featuredWorkflows: [
          {
            title: "Automated Code Review",
            description: "End-to-end code review and optimization",
            icon: Workflow,
            stats: { runs: "5k", copies: "1.2k" },
            gradient: "from-cyan-500/20 to-blue-500/20"
          },
          {
            title: "CI/CD Pipeline Setup",
            description: "Complete deployment pipeline configuration",
            icon: Workflow,
            stats: { runs: "3.8k", copies: "950" },
            gradient: "from-orange-500/20 to-amber-500/20"
          },
          {
            title: "API Development",
            description: "Design, implement and document RESTful APIs",
            icon: Workflow,
            stats: { runs: "4.2k", copies: "1.1k" },
            gradient: "from-blue-500/20 to-purple-500/20"
          }
        ],
        trends: [
          {
            title: "AI-Assisted Programming",
            change: "+32%",
            description: "Growing adoption of AI pair programming",
            isUp: true,
            gradient: "from-green-500/20 to-emerald-500/20"
          },
          {
            title: "Workflow Automation",
            change: "+24%",
            description: "Increased use of automated workflows",
            isUp: true,
            gradient: "from-blue-500/20 to-indigo-500/20"
          },
          {
            title: "Code Reviews",
            change: "+18%",
            description: "More teams using automated review tools",
            isUp: true,
            gradient: "from-violet-500/20 to-purple-500/20"
          }
        ]
      };
  }
};

export const getThemeStyles = (spaceTemplate: SpaceTemplate): ThemeStyles => {
  switch (spaceTemplate.type) {
    case 'crypto':
      return {
        cardBg: "bg-black/20 border-white/10 hover:border-blue-500/30 hover:bg-black/30",
        buttonGradient: "bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700",
        heading: "text-blue-300",
        divider: "bg-blue-900/20"
      };
    case 'image-generation':
      return {
        cardBg: "bg-black/20 border-white/10 hover:border-purple-500/30 hover:bg-black/30",
        buttonGradient: "bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700",
        heading: "text-purple-300",
        divider: "bg-purple-900/20"
      };
    case 'education':
      return {
        cardBg: "bg-black/20 border-white/10 hover:border-blue-500/30 hover:bg-black/30",
        buttonGradient: "bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-600 hover:to-cyan-700",
        heading: "text-blue-300",
        divider: "bg-blue-900/20"
      };
    case 'creative':
      return {
        cardBg: "bg-black/20 border-white/10 hover:border-pink-500/30 hover:bg-black/30",
        buttonGradient: "bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700",
        heading: "text-pink-300",
        divider: "bg-pink-900/20"
      };
    case 'marketing':
      return {
        cardBg: "bg-black/20 border-white/10 hover:border-orange-500/30 hover:bg-black/30",
        buttonGradient: "bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700",
        heading: "text-amber-300",
        divider: "bg-amber-900/20"
      };
    case 'productivity':
      return {
        cardBg: "bg-black/20 border-white/10 hover:border-emerald-500/30 hover:bg-black/30",
        buttonGradient: "bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700",
        heading: "text-emerald-300",
        divider: "bg-emerald-900/20"
      };
    default: // development
      return {
        cardBg: "bg-black/20 border-white/10 hover:border-blue-500/30 hover:bg-black/30",
        buttonGradient: "bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700",
        heading: "text-blue-300",
        divider: "bg-blue-900/20"
      };
  }
};
