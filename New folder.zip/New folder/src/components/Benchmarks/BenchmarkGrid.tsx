
import { Benchmark, BenchmarkCategory } from '@/types/explore';
import BenchmarkCard from './BenchmarkCard';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState, useEffect } from 'react';
import { benchmarkCategories } from '@/data/benchmarksData';
import { benchmarkService } from '@/services/benchmarkService';
import { Card } from '@/components/ui/card';

interface BenchmarkGridProps {
  benchmarks: Benchmark[];
  title?: string;
  compact?: boolean;
  showCategories?: boolean;
  loading?: boolean;
}

const BenchmarkGrid = ({ 
  benchmarks, 
  title, 
  compact = false,
  showCategories = true,
  loading = false
}: BenchmarkGridProps) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [filteredBenchmarks, setFilteredBenchmarks] = useState<Benchmark[]>(benchmarks);
  
  useEffect(() => {
    if (selectedCategory === 'all') {
      setFilteredBenchmarks(benchmarks);
    } else {
      setFilteredBenchmarks(
        benchmarks.filter(benchmark => benchmark.category === selectedCategory)
      );
    }
  }, [selectedCategory, benchmarks]);
  
  // Get unique categories from benchmarks
  const categories = [...new Set(benchmarks.map(b => b.category))];

  if (loading) {
    return (
      <div className="space-y-4">
        {title && <h2 className="text-2xl font-semibold">{title}</h2>}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map(i => (
            <Card key={i} className="h-[180px] bg-card/50 animate-pulse"></Card>
          ))}
        </div>
      </div>
    );
  }
  
  if (benchmarks.length === 0) {
    return (
      <div className="space-y-4">
        {title && <h2 className="text-2xl font-semibold">{title}</h2>}
        <Card className="p-8 text-center bg-card/50">
          <p className="text-muted-foreground">No benchmarks available</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {title && <h2 className="text-2xl font-semibold">{title}</h2>}
      
      {showCategories && categories.length > 1 && (
        <Tabs defaultValue="all" value={selectedCategory} onValueChange={setSelectedCategory}>
          <TabsList className="mb-4">
            <TabsTrigger value="all">All</TabsTrigger>
            {categories.map(category => (
              <TabsTrigger key={category} value={category}>
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </TabsTrigger>
            ))}
          </TabsList>
          
          <TabsContent value="all" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {benchmarks.map(benchmark => (
              <BenchmarkCard key={benchmark.id} benchmark={benchmark} compact={compact} />
            ))}
          </TabsContent>
          
          {categories.map(category => (
            <TabsContent key={category} value={category} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {benchmarks
                .filter(benchmark => benchmark.category === category)
                .map(benchmark => (
                  <BenchmarkCard key={benchmark.id} benchmark={benchmark} compact={compact} />
                ))
              }
            </TabsContent>
          ))}
        </Tabs>
      )}
      
      {(!showCategories || categories.length <= 1) && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredBenchmarks.map(benchmark => (
            <BenchmarkCard key={benchmark.id} benchmark={benchmark} compact={compact} />
          ))}
        </div>
      )}
    </div>
  );
};

export default BenchmarkGrid;
