
import { Benchmark } from '@/types/explore';
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";

interface BenchmarkSummaryProps {
  benchmarks: Benchmark[];
  type: 'agent' | 'workflow' | 'workspace' | 'app';
  entityId: string;
  spaceId?: string;
  compact?: boolean;
}

const BenchmarkSummary = ({ benchmarks, type, entityId, spaceId, compact = false }: BenchmarkSummaryProps) => {
  if (!benchmarks || benchmarks.length === 0) {
    return null;
  }
  
  const topBenchmarks = benchmarks.slice(0, compact ? 1 : 3);
  
  const getProgressColor = (score: number) => {
    if (score >= 85) return "bg-emerald-500";
    if (score >= 70) return "bg-blue-500";
    if (score >= 50) return "bg-amber-500";
    return "bg-rose-500";
  };
  
  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'performance': 'bg-blue-500/10 text-blue-500',
      'accuracy': 'bg-emerald-500/10 text-emerald-500',
      'reliability': 'bg-amber-500/10 text-amber-500',
      'efficiency': 'bg-purple-500/10 text-purple-500',
      'cost': 'bg-gray-500/10 text-gray-500',
      'reasoning': 'bg-indigo-500/10 text-indigo-500',
      'planning': 'bg-cyan-500/10 text-cyan-500',
      'adaptability': 'bg-pink-500/10 text-pink-500',
      'tool-use': 'bg-orange-500/10 text-orange-500',
      'multi-step': 'bg-violet-500/10 text-violet-500',
      'human-alignment': 'bg-teal-500/10 text-teal-500'
    };
    
    return colors[category] || 'bg-gray-500/10 text-gray-500';
  };
  
  // Create the path to the entity
  let entityPath = `/${type}/${entityId}`;
  if (spaceId) {
    entityPath = `/space/${spaceId}/${type}/${entityId}`;
  }
  
  // Path to benchmarks
  const benchmarksPath = `${entityPath}/benchmarks`;
  
  return (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Benchmarks</h3>
        {benchmarks.length > topBenchmarks.length && (
          <Link to={benchmarksPath}>
            <Button variant="ghost" size="sm" className="text-xs">
              View All <ChevronRight className="ml-1 h-3 w-3" />
            </Button>
          </Link>
        )}
      </div>
      
      <div className="space-y-3">
        {topBenchmarks.map(benchmark => (
          <div key={benchmark.id} className="bg-black/20 rounded-lg p-3">
            <div className="flex justify-between items-center mb-2">
              <div className="flex items-center gap-2">
                <span className="font-medium text-sm">{benchmark.name}</span>
                <Badge className={cn("text-xs", getCategoryColor(benchmark.category))}>
                  {benchmark.category}
                </Badge>
              </div>
              <span className="font-bold">{benchmark.score}/{benchmark.maxScore}</span>
            </div>
            
            <Progress 
              value={(benchmark.score / benchmark.maxScore) * 100} 
              className="h-1.5"
              indicatorClassName={getProgressColor(benchmark.score)}
            />
            
            {benchmark.comparison && (
              <div className="text-xs text-muted-foreground mt-1 flex justify-between">
                <span>Low: {benchmark.comparison.bottomScore}</span>
                <span>Avg: {benchmark.comparison.avgScore}</span>
                <span>High: {benchmark.comparison.topScore}</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default BenchmarkSummary;
