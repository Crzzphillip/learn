
import { Benchmark } from '@/types/explore';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ChevronUp, ChevronDown, Minus, Info } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface BenchmarkCardProps {
  benchmark: Benchmark;
  className?: string;
  compact?: boolean;
}

const BenchmarkCard = ({ benchmark, className, compact = false }: BenchmarkCardProps) => {
  const [expanded, setExpanded] = useState(!compact);
  
  const getTrendIcon = (trend?: 'up' | 'down' | 'neutral') => {
    switch (trend) {
      case 'up':
        return <ChevronUp className="h-3 w-3 text-emerald-500" />;
      case 'down':
        return <ChevronDown className="h-3 w-3 text-rose-500" />;
      default:
        return <Minus className="h-3 w-3 text-gray-400" />;
    }
  };
  
  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'performance': 'bg-blue-500/10 text-blue-500',
      'accuracy': 'bg-emerald-500/10 text-emerald-500',
      'reliability': 'bg-amber-500/10 text-amber-500',
      'efficiency': 'bg-purple-500/10 text-purple-500',
      'cost': 'bg-gray-500/10 text-gray-500',
      'reasoning': 'bg-indigo-500/10 text-indigo-500',
      'planning': 'bg-cyan-500/10 text-cyan-500',
      'adaptability': 'bg-pink-500/10 text-pink-500',
      'tool-use': 'bg-orange-500/10 text-orange-500',
      'multi-step': 'bg-violet-500/10 text-violet-500',
      'human-alignment': 'bg-teal-500/10 text-teal-500'
    };
    
    return colors[category] || 'bg-gray-500/10 text-gray-500';
  };
  
  const getProgressColor = (score: number) => {
    if (score >= 85) return "bg-emerald-500";
    if (score >= 70) return "bg-blue-500";
    if (score >= 50) return "bg-amber-500";
    return "bg-rose-500";
  };

  return (
    <Card className={cn("overflow-hidden bg-card/50 border-primary/10 hover:border-primary/20 transition-all", className)}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-medium flex items-center gap-2">
            {benchmark.name}
            {!compact && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="h-4 w-4 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-[300px]">
                    <p>{benchmark.description}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </CardTitle>
          
          <Badge className={cn("text-xs font-medium", getCategoryColor(benchmark.category))}>
            {benchmark.category.charAt(0).toUpperCase() + benchmark.category.slice(1)}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className={cn("space-y-4", !expanded && "pt-0")}>
        <div className="space-y-2">
          <div className="flex justify-between items-center text-sm">
            <span>Score: {benchmark.score}/{benchmark.maxScore}</span>
            
            {benchmark.comparison && (
              <span className="text-muted-foreground text-xs">
                Avg: {benchmark.comparison.avgScore}
              </span>
            )}
          </div>
          
          <Progress 
            value={(benchmark.score / benchmark.maxScore) * 100} 
            className="h-2"
            indicatorClassName={getProgressColor(benchmark.score)}
          />
          
          {benchmark.comparison && (
            <div className="relative h-1.5 bg-muted/30 rounded-full overflow-hidden mt-1">
              <div 
                className="absolute h-full bg-muted/20 rounded-full" 
                style={{ 
                  left: `${(benchmark.comparison.bottomScore / benchmark.maxScore) * 100}%`,
                  width: `${((benchmark.comparison.topScore - benchmark.comparison.bottomScore) / benchmark.maxScore) * 100}%`
                }}
              />
              <div 
                className="absolute h-full w-0.5 bg-white/40" 
                style={{ 
                  left: `${(benchmark.comparison.avgScore / benchmark.maxScore) * 100}%`,
                }}
              />
              <div 
                className="absolute h-full w-1.5 bg-primary rounded-full" 
                style={{ 
                  left: `${(benchmark.score / benchmark.maxScore) * 100}%`,
                  transform: 'translateX(-50%)'
                }}
              />
            </div>
          )}
        </div>
        
        {expanded && benchmark.details && (
          <div className="space-y-1 pt-2">
            <h4 className="text-sm font-medium mb-2">Metrics</h4>
            {benchmark.details.map((detail, index) => (
              <div key={index} className="flex items-center justify-between text-sm bg-black/20 rounded-md px-3 py-1.5">
                <span>{detail.metric}</span>
                <div className="flex items-center gap-1.5">
                  <span>{detail.value}</span>
                  {detail.change && (
                    <div className="flex items-center text-xs">
                      {getTrendIcon(detail.trend)}
                      <span className={cn(
                        detail.trend === 'up' ? 'text-emerald-500' : 
                        detail.trend === 'down' ? 'text-rose-500' : 
                        'text-gray-400'
                      )}>
                        {detail.change}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
        
        {compact && (
          <Button 
            variant="ghost" 
            size="sm" 
            className="w-full text-xs mt-2"
            onClick={() => setExpanded(!expanded)}
          >
            {expanded ? "Show Less" : "Show Details"}
          </Button>
        )}
        
        <div className="text-xs text-muted-foreground">
          Last updated: {benchmark.lastUpdated}
        </div>
      </CardContent>
    </Card>
  );
};

export default BenchmarkCard;
