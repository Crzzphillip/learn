
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles, PlusCircle, ArrowUpRight, BarChart, Zap, Award } from "lucide-react";

interface ForesightOrbsProps {
  className?: string;
}

const foresightData = [
  {
    id: "1",
    title: "Ad Workflow Optimization",
    description: "Your ad workflow could reach 20% more viewers with AI targeting",
    improvement: "20%",
    area: "reach",
    actionRequired: true,
    icon: BarChart
  },
  {
    id: "2",
    title: "Credit Usage Efficiency",
    description: "Consolidate similar agent calls to save 35 credits per day",
    improvement: "35",
    area: "credits",
    actionRequired: false,
    icon: Zap
  },
  {
    id: "3",
    title: "Agent Performance",
    description: "Your Content Writer shows 15% better results than average",
    improvement: "15%",
    area: "performance",
    actionRequired: false,
    icon: Award
  }
];

const ForesightOrbs = ({ className = "" }: ForesightOrbsProps) => {
  return (
    <Card className={`glass-panel border-primary/10 ${className}`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            <CardTitle className="text-lg font-semibold">Foresight Orbs</CardTitle>
          </div>
          <button className="text-xs flex items-center gap-1 text-muted-foreground hover:text-primary transition-colors">
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Add Custom Insight</span>
          </button>
        </div>
        <CardDescription>AI-powered optimization suggestions for your spaces</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {foresightData.map((insight) => {
          const Icon = insight.icon;
          return (
            <div 
              key={insight.id} 
              className={`
                flex items-start gap-4 p-4 rounded-lg
                ${insight.actionRequired 
                  ? 'bg-primary/10 border border-primary/20' 
                  : 'bg-secondary/20 border border-secondary/10'
                }
              `}
            >
              <div className={`
                w-10 h-10 rounded-full grid place-items-center flex-shrink-0
                ${insight.actionRequired 
                  ? 'bg-primary/20' 
                  : 'bg-secondary/30'
                }
              `}>
                <Icon className={`
                  w-5 h-5
                  ${insight.actionRequired 
                    ? 'text-primary' 
                    : 'text-secondary-foreground'
                  }
                `} />
              </div>
              <div className="flex-1">
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-medium">{insight.title}</h4>
                    <p className="text-sm text-muted-foreground mt-1">{insight.description}</p>
                  </div>
                  <div className={`
                    flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium
                    ${insight.actionRequired 
                      ? 'bg-primary/20 text-primary' 
                      : 'bg-secondary/30 text-secondary-foreground'
                    }
                  `}>
                    +{insight.improvement} {insight.area}
                  </div>
                </div>
                {insight.actionRequired && (
                  <button className="mt-3 text-xs flex items-center gap-1 text-primary hover:underline">
                    <span>Apply Optimization</span>
                    <ArrowUpRight className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
};

export default ForesightOrbs;
