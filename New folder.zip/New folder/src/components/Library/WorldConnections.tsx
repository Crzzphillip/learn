
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Link2, ExternalLink, Download, Check, X } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

const connectionsData = [
  {
    id: "1",
    name: "Figma",
    type: "Design",
    description: "Connect your Frontend Space with Figma",
    icon: "/lovable-uploads/0a1baea5-6a03-47a0-87a5-2d8084ef4e3d.png",
    connected: true,
    space: "Creative Space"
  },
  {
    id: "2",
    name: "Adobe Creative Cloud",
    type: "Design",
    description: "Connect your Art Space with Adobe tools",
    icon: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png",
    connected: false,
    space: "Creative Space"
  },
  {
    id: "3",
    name: "GitHub",
    type: "Development",
    description: "Link your Development Space with GitHub",
    icon: "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png",
    connected: true,
    space: "Development Space"
  },
  {
    id: "4",
    name: "Slack",
    type: "Communication",
    description: "Integrate notifications with Slack",
    icon: "/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png",
    connected: false,
    space: "Development Space"
  }
];

const WorldConnections = () => {
  return (
    <Card className="glass-panel border-primary/10">
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <Link2 className="w-5 h-5 text-primary" />
          <CardTitle className="text-lg font-semibold">World Connections</CardTitle>
        </div>
        <CardDescription>Connect your spaces with external tools</CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[320px]">
          <div className="divide-y divide-border/10">
            {connectionsData.map((connection) => (
              <div key={connection.id} className="p-4 hover:bg-secondary/5 transition-colors">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-secondary/20 grid place-items-center overflow-hidden">
                    {connection.icon ? (
                      <img src={connection.icon} alt={connection.name} className="w-full h-full object-cover" />
                    ) : (
                      <Link2 className="w-5 h-5" />
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium flex items-center gap-2">
                          {connection.name}
                          <span className="text-xs px-2 py-0.5 rounded-full bg-secondary/20 text-secondary-foreground">
                            {connection.type}
                          </span>
                        </h4>
                        <p className="text-sm text-muted-foreground">{connection.description}</p>
                      </div>
                      {connection.connected ? (
                        <div className="flex items-center gap-2">
                          <span className="flex items-center gap-1 text-xs text-green-500">
                            <Check className="w-3 h-3" />
                            Connected
                          </span>
                          <button className="text-xs px-2 py-1 rounded border border-destructive/20 text-destructive hover:bg-destructive/10 transition-colors">
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <button className="text-xs flex items-center gap-1 text-primary hover:underline">
                          <span>Connect</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                    <div className="mt-1">
                      <span className="text-xs text-muted-foreground">For: {connection.space}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
        <div className="p-3 border-t border-border/10 bg-secondary/5">
          <button className="w-full text-sm flex items-center justify-center gap-2 p-2 rounded-lg border border-dashed border-border/30 text-muted-foreground hover:text-primary hover:border-primary/30 transition-colors">
            <Download className="w-4 h-4" />
            <span>Browse Extension Market</span>
          </button>
        </div>
      </CardContent>
    </Card>
  );
};

export default WorldConnections;
