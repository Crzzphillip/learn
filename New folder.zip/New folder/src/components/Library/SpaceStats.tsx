
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { RefreshCw, TrendingUp, BarChart2, PieChart } from "lucide-react";

interface SpaceStatsProps {
  space: any;
  className?: string;
}

const usageData = [
  { name: "Mon", value: 45 },
  { name: "Tue", value: 72 },
  { name: "Wed", value: 63 },
  { name: "Thu", value: 54 },
  { name: "Fri", value: 83 },
  { name: "Sat", value: 42 },
  { name: "Sun", value: 30 },
];

const SpaceStats = ({ space, className = "" }: SpaceStatsProps) => {
  return (
    <Card className={`glass-panel border-primary/10 overflow-hidden ${className}`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Space Performance</CardTitle>
          <button className="text-xs flex items-center gap-1 text-muted-foreground hover:text-primary transition-colors">
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
        </div>
        <CardDescription>{space.title} usage metrics</CardDescription>
      </CardHeader>
      <CardContent className="px-0 pb-0">
        <div className="grid grid-cols-3 gap-0 border-b border-primary/10">
          <div className="p-4 border-r border-primary/10">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-green-500" />
              <span className="text-sm font-medium">ROI</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-bold">127%</span>
              <span className="text-xs text-green-500">+12%</span>
            </div>
          </div>
          <div className="p-4 border-r border-primary/10">
            <div className="flex items-center gap-2 mb-1">
              <BarChart2 className="w-4 h-4 text-blue-500" />
              <span className="text-sm font-medium">Efficiency</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-bold">83%</span>
              <span className="text-xs text-blue-500">+5%</span>
            </div>
          </div>
          <div className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <PieChart className="w-4 h-4 text-purple-500" />
              <span className="text-sm font-medium">Utilization</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-bold">76%</span>
              <span className="text-xs text-purple-500">+3%</span>
            </div>
          </div>
        </div>
        
        <div className="h-40 pt-4">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={usageData} margin={{ top: 0, right: 10, left: -20, bottom: 0 }}>
              <XAxis 
                dataKey="name" 
                axisLine={false}
                tickLine={false}
                fontSize={12}
                tickMargin={8}
              />
              <YAxis 
                hide 
                domain={[0, 'dataMax + 20']}
              />
              <Tooltip 
                cursor={{ fill: 'rgba(155, 135, 245, 0.05)' }}
                contentStyle={{ 
                  background: 'rgba(17, 17, 17, 0.8)', 
                  border: '1px solid rgba(155, 135, 245, 0.2)',
                  borderRadius: '6px',
                  fontSize: '12px'
                }}
              />
              <Bar 
                dataKey="value" 
                fill="rgba(155, 135, 245, 0.7)" 
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default SpaceStats;
