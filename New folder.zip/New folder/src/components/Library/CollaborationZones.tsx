
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, History, CheckSquare, Calendar, Clock, Plus } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

const collaborationData = [
  {
    id: "1",
    title: "Marketing Campaign Workshop",
    type: "workshop",
    status: "active",
    participants: 5,
    time: "Today, 2:30 PM",
    space: "Creative Space"
  },
  {
    id: "2",
    title: "Website Redesign Review",
    type: "approval",
    status: "pending",
    participants: 3,
    time: "Tomorrow, 10:00 AM",
    space: "Creative Space"
  },
  {
    id: "3",
    title: "Code Review Session",
    type: "workshop",
    status: "scheduled",
    participants: 4,
    time: "May 18, 3:00 PM",
    space: "Development Space"
  },
  {
    id: "4",
    title: "New Feature Approval",
    type: "approval",
    status: "pending",
    participants: 2,
    time: "May 20, 11:00 AM",
    space: "Development Space"
  }
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'active':
      return 'bg-green-500/20 text-green-500';
    case 'pending':
      return 'bg-amber-500/20 text-amber-500';
    case 'scheduled':
      return 'bg-blue-500/20 text-blue-500';
    default:
      return 'bg-secondary/20 text-secondary-foreground';
  }
};

const getTypeIcon = (type: string) => {
  switch (type) {
    case 'workshop':
      return <Users className="w-4 h-4" />;
    case 'approval':
      return <CheckSquare className="w-4 h-4" />;
    default:
      return <Users className="w-4 h-4" />;
  }
};

const CollaborationZones = () => {
  return (
    <Card className="glass-panel border-primary/10">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" />
            <CardTitle className="text-lg font-semibold">Collaboration Zones</CardTitle>
          </div>
          <button className="text-xs flex items-center gap-1 text-muted-foreground hover:text-primary transition-colors">
            <Plus className="w-3.5 h-3.5" />
            <span>New Zone</span>
          </button>
        </div>
        <CardDescription>Team workshops, approvals, and version control</CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[320px]">
          <div className="divide-y divide-border/10">
            {collaborationData.map((collab) => (
              <div key={collab.id} className="p-4 hover:bg-secondary/5 transition-colors">
                <div className="mb-2 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-secondary/20 grid place-items-center">
                      {getTypeIcon(collab.type)}
                    </div>
                    <h4 className="font-medium">{collab.title}</h4>
                  </div>
                  <div className={`text-xs px-2 py-0.5 rounded-full ${getStatusColor(collab.status)}`}>
                    {collab.status.charAt(0).toUpperCase() + collab.status.slice(1)}
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5" />
                      <span>{collab.participants} participants</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{collab.time}</span>
                    </div>
                  </div>
                  <div className="text-xs">
                    {collab.space}
                  </div>
                </div>
                <div className="mt-3 flex items-center gap-2">
                  {collab.type === 'workshop' && (
                    <button className="text-xs flex-1 py-1.5 rounded-md border border-primary/20 bg-primary/10 text-primary hover:bg-primary/20 transition-colors">
                      Join Session
                    </button>
                  )}
                  {collab.type === 'approval' && (
                    <button className="text-xs flex-1 py-1.5 rounded-md border border-primary/20 bg-primary/10 text-primary hover:bg-primary/20 transition-colors">
                      Review Changes
                    </button>
                  )}
                  <button className="text-xs px-2 py-1.5 rounded-md border border-secondary/20 bg-secondary/10 text-secondary-foreground hover:bg-secondary/20 transition-colors">
                    <History className="w-3.5 h-3.5" />
                  </button>
                  <button className="text-xs px-2 py-1.5 rounded-md border border-secondary/20 bg-secondary/10 text-secondary-foreground hover:bg-secondary/20 transition-colors">
                    <Calendar className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
        <div className="p-3 border-t border-border/10 bg-secondary/5">
          <button className="w-full text-sm flex items-center justify-center gap-2 p-2 rounded-lg border border-dashed border-border/30 text-muted-foreground hover:text-primary hover:border-primary/30 transition-colors">
            <Plus className="w-4 h-4" />
            <span>Schedule Collaboration</span>
          </button>
        </div>
      </CardContent>
    </Card>
  );
};

export default CollaborationZones;
