
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FlaskConical, AlertTriangle, Gauge, Play, Code, FileText, RefreshCw } from "lucide-react";
import { Progress } from "@/components/ui/progress";

const testingData = [
  {
    id: "1",
    name: "Creative Writer Agent",
    type: "agent",
    status: "ready",
    errors: 0,
    performance: 92,
    space: "Creative Space"
  },
  {
    id: "2",
    name: "Content Creation Workflow",
    type: "workflow",
    status: "issues",
    errors: 2,
    performance: 68,
    space: "Creative Space"
  },
  {
    id: "3",
    name: "Code Assistant",
    type: "agent",
    status: "ready",
    errors: 0,
    performance: 95,
    space: "Development Space"
  }
];

const getStatusIcon = (status: string) => {
  switch (status) {
    case 'ready':
      return <Gauge className="w-4 h-4 text-green-500" />;
    case 'issues':
      return <AlertTriangle className="w-4 h-4 text-amber-500" />;
    default:
      return <Gauge className="w-4 h-4" />;
  }
};

const getTypeIcon = (type: string) => {
  switch (type) {
    case 'agent':
      return <Code className="w-4 h-4" />;
    case 'workflow':
      return <FileText className="w-4 h-4" />;
    default:
      return <Code className="w-4 h-4" />;
  }
};

const getStatusColor = (performance: number) => {
  if (performance >= 90) return 'bg-green-500';
  if (performance >= 70) return 'bg-amber-500';
  return 'bg-red-500';
};

const TestingGrounds = () => {
  return (
    <Card className="glass-panel border-primary/10">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-primary" />
            <CardTitle className="text-lg font-semibold">Testing Grounds</CardTitle>
          </div>
          <button className="text-xs flex items-center gap-1 text-muted-foreground hover:text-primary transition-colors">
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Run All Tests</span>
          </button>
        </div>
        <CardDescription>Sandbox environments for testing and optimization</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {testingData.map((item) => (
          <div 
            key={item.id} 
            className="p-4 rounded-lg border border-border/20 bg-secondary/5"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className={`
                  w-8 h-8 rounded-lg grid place-items-center
                  ${item.status === 'issues' ? 'bg-amber-500/20' : 'bg-secondary/20'}
                `}>
                  {getTypeIcon(item.type)}
                </div>
                <div>
                  <h4 className="font-medium">{item.name}</h4>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span>{item.space}</span>
                    <span>•</span>
                    <span className="capitalize">{item.type}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {getStatusIcon(item.status)}
                <span className={`text-sm ${item.status === 'issues' ? 'text-amber-500' : 'text-green-500'}`}>
                  {item.status === 'issues' ? 'Issues Found' : 'Ready'}
                </span>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Performance</span>
                <span className="font-medium">{item.performance}%</span>
              </div>
              <Progress
                value={item.performance}
                className="h-2"
                indicatorClassName={getStatusColor(item.performance)}
              />
            </div>
            
            {item.status === 'issues' && (
              <div className="mt-3 flex items-center gap-1 text-xs text-amber-500">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>{item.errors} errors detected</span>
              </div>
            )}
            
            <div className="mt-3 flex gap-2">
              <button className="text-xs flex-1 py-1.5 rounded-md border border-primary/20 bg-primary/10 text-primary hover:bg-primary/20 transition-colors flex items-center justify-center gap-1">
                <Play className="w-3.5 h-3.5" />
                <span>Run Test</span>
              </button>
              {item.status === 'issues' && (
                <button className="text-xs flex-1 py-1.5 rounded-md border border-amber-500/20 bg-amber-500/10 text-amber-500 hover:bg-amber-500/20 transition-colors">
                  Fix Issues
                </button>
              )}
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};

export default TestingGrounds;
