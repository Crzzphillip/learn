import React, { useState, useRef, useEffect } from 'react';
import { WebsiteComponent, updateComponentInTree, findComponentById, addComponentToParent } from '@/services/websiteComponentsService';
import { LibraryComponent } from '@/services/componentLibrary/types';
import { Button } from '@/components/ui/button';
import { 
  Layout, 
  Eye, 
  EyeOff, 
  Move, 
  Grid, 
  ArrowUp, 
  ArrowDown, 
  ChevronUp, 
  ChevronDown,
  AlignLeft, 
  AlignCenter, 
  AlignRight, 
  Copy, 
  Trash2,
  Undo,
  Redo,
  Plus
} from 'lucide-react';
import { toast } from 'sonner';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import ComponentLibrary from './ComponentLibrary';

interface CanvasEditorProps {
  components: WebsiteComponent[];
  selectedComponentId: string | null;
  onSelectComponent: (component: WebsiteComponent) => void;
  onUpdateComponents: (components: WebsiteComponent[]) => void;
  onDuplicateComponent: (id: string) => void;
  onDeleteComponent: (id: string) => void;
}

// Helper function to remove circular references from components
const removeCircularReferences = (components: WebsiteComponent[]): WebsiteComponent[] => {
  return components.map(component => {
    // Create a new component object without the parent property
    const { parent, ...cleanComponent } = component;
    
    // Process children recursively
    if (cleanComponent.children && cleanComponent.children.length > 0) {
      cleanComponent.children = removeCircularReferences(cleanComponent.children);
    }
    
    return cleanComponent as WebsiteComponent;
  });
};

const CanvasEditor: React.FC<CanvasEditorProps> = ({
  components,
  selectedComponentId,
  onSelectComponent,
  onUpdateComponents,
  onDuplicateComponent,
  onDeleteComponent
}) => {
  const [showGrid, setShowGrid] = useState(false);
  const [snapToGrid, setSnapToGrid] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  const [draggedComponent, setDraggedComponent] = useState<WebsiteComponent | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [history, setHistory] = useState<WebsiteComponent[][]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [showAddChildDialog, setShowAddChildDialog] = useState(false);
  const [parentIdForNewChild, setParentIdForNewChild] = useState<string | null>(null);
  const canvasRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (components.length > 0) {
      try {
        // Remove circular references before adding to history
        const cleanComponents = removeCircularReferences(components);
        // try {
          
        //   console.log('comps', JSON.stringify({a:cleanComponents}))
        // } catch (error){
        //   console.log('compo error', error)

        // }
        // Create a deep copy using JSON.stringify/parse
        const componentsClone = JSON.parse(JSON.stringify(cleanComponents));
        
        const newHistory = [...history.slice(0, historyIndex + 1), componentsClone];
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
      } catch (error) {
        console.error("Error updating history:", error);
      }
    }
  }, [components]);

  const handleUndo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      onUpdateComponents(JSON.parse(JSON.stringify(history[historyIndex - 1])));
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      onUpdateComponents(JSON.parse(JSON.stringify(history[historyIndex + 1])));
    }
  };

  const handleAddChildComponent = (parentId: string) => {
    setParentIdForNewChild(parentId);
    setShowAddChildDialog(true);
  };

  const handleAddComponentToParent = (component: LibraryComponent) => {
    if (!parentIdForNewChild) return;
    
    const parent = findComponentById(components, parentIdForNewChild);
    if (!parent || !parent.isDroppable) return;
    
    const childId = `${component.type}-${Date.now()}`;
    const newComponent: WebsiteComponent = {
      id: childId,
      name: component.name,
      type: component.type,
      category: component.category,
      icon: component.icon,
      iconName: component.iconName,
      props: { ...component.props },
      style: { ...component.style },
      content: component.content || '',
      isSelectable: true,
      isDraggable: true,
      isDroppable: component.type === 'section' || component.type === 'div',
      children: [],
      position: { x: 0, y: 0 }
    };
    
    const updatedComponents = addComponentToParent(components, parentIdForNewChild, newComponent);
    onUpdateComponents(updatedComponents);
    
    toast.success(`Added ${component.name} to ${parent.name}`, {
      duration: 2000
    });
    
    setShowAddChildDialog(false);
    setParentIdForNewChild(null);
  };

  const handleMouseDown = (e: React.MouseEvent, component: WebsiteComponent) => {
    if (!component.isDraggable) return;
    
    e.stopPropagation();
    setIsDragging(true);
    setDraggedComponent(component);
    
    const target = e.currentTarget as HTMLElement;
    const rect = target.getBoundingClientRect();
    setDragOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    });
    
    onSelectComponent(component);
  };
  
  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !draggedComponent || !canvasRef.current) return;
    
    const canvasRect = canvasRef.current.getBoundingClientRect();
    let newX = e.clientX - canvasRect.left - dragOffset.x;
    let newY = e.clientY - canvasRect.top - dragOffset.y;
    
    if (snapToGrid) {
      const gridSize = 8;
      newX = Math.round(newX / gridSize) * gridSize;
      newY = Math.round(newY / gridSize) * gridSize;
    }
    
    const updatedComponent = {
      ...draggedComponent,
      position: { x: newX, y: newY }
    };
    
    const updatedComponents = updateComponentInTree(components, updatedComponent);
    onUpdateComponents(updatedComponents);
  };
  
  const handleMouseUp = () => {
    if (!isDragging) return;
    
    setIsDragging(false);
    setDraggedComponent(null);
    
    toast.success("Component position updated", {
      duration: 2000
    });
  };
  
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };
  
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    
    try {
      const componentData = JSON.parse(e.dataTransfer.getData('application/json'));
      
      if (!componentData) return;
      
      const newComponent = {
        ...componentData,
        id: `${componentData.id}-${Date.now()}`,
      };
      
      if (canvasRef.current) {
        const canvasRect = canvasRef.current.getBoundingClientRect();
        
        let posX = e.clientX - canvasRect.left;
        let posY = e.clientY - canvasRect.top;
        
        if (snapToGrid) {
          const gridSize = 8;
          posX = Math.round(posX / gridSize) * gridSize;
          posY = Math.round(posY / gridSize) * gridSize;
        }
        
        newComponent.position = { x: posX, y: posY };
      }
      
      const updatedComponents = [...components, newComponent];
      onUpdateComponents(updatedComponents);
      
      toast.success("Component added to canvas", {
        duration: 2000
      });
    } catch (error) {
      console.error("Error adding component:", error);
      toast.error("Failed to add component");
    }
  };
  
  const handleAlignComponent = (alignment: 'left' | 'center' | 'right') => {
    if (!selectedComponentId || !canvasRef.current) return;
    
    const component = findComponentById(components, selectedComponentId);
    if (!component || !component.position) return;
    
    const canvasRect = canvasRef.current.getBoundingClientRect();
    let newX = component.position.x;
    
    switch (alignment) {
      case 'left':
        newX = 16;
        break;
      case 'center':
        newX = (canvasRect.width / 2) - 100;
        break;
      case 'right':
        newX = canvasRect.width - 216;
        break;
    }
    
    const updatedComponent = {
      ...component,
      position: { ...component.position, x: newX }
    };
    
    const updatedComponents = updateComponentInTree(components, updatedComponent);
    onUpdateComponents(updatedComponents);
    
    toast.success(`Component aligned ${alignment}`, {
      duration: 2000
    });
  };
  
  const handleMoveComponent = (direction: 'up' | 'down') => {
    if (!selectedComponentId || !canvasRef.current) return;
    
    const component = findComponentById(components, selectedComponentId);
    if (!component || !component.position) return;
    
    const amount = 8;
    let newY = component.position.y;
    
    switch (direction) {
      case 'up':
        newY = Math.max(0, newY - amount);
        break;
      case 'down':
        newY = newY + amount;
        break;
    }
    
    const updatedComponent = {
      ...component,
      position: { ...component.position, x: component.position.x, y: newY }
    };
    
    const updatedComponents = updateComponentInTree(components, updatedComponent);
    onUpdateComponents(updatedComponents);
  };
  
  const renderComponent = (component: WebsiteComponent) => {
    const isSelected = component.id === selectedComponentId;
    
    return (
      <div
        key={component.id}
        className={`absolute ${isSelected ? 'ring-2 ring-blue-500' : ''}`}
        style={{
          left: component.position?.x || 0,
          top: component.position?.y || 0,
          cursor: component.isDraggable ? 'move' : 'pointer'
        }}
        onMouseDown={(e) => handleMouseDown(e, component)}
        onClick={(e) => {
          e.stopPropagation();
          onSelectComponent(component);
        }}
      >
        <div 
          className={`bg-white border ${isSelected ? 'border-blue-500' : 'border-gray-200'} rounded-md p-2`}
          style={component.style}
        >
          <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
            <span>{component.name}</span>
            
            {component.isDroppable && (
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  handleAddChildComponent(component.id);
                }}
                className="ml-2 p-1 hover:bg-gray-100 rounded"
                title="Add child component"
              >
                <Plus className="h-3 w-3" />
              </button>
            )}
          </div>
          
          {component.content ? (
            <div>{component.content}</div>
          ) : component.children?.length ? (
            <div className="p-2 border border-dashed border-gray-200 rounded min-h-[30px] min-w-[100px]">
              {component.children.map(child => renderComponent(child))}
            </div>
          ) : (
            <div className="w-20 h-10 flex items-center justify-center bg-gray-100 rounded">
              {component.icon}
            </div>
          )}
        </div>
        
        {isSelected && (
          <div className="absolute bottom-0 right-0 w-3 h-3 bg-blue-500 rounded-sm cursor-se-resize" />
        )}
      </div>
    );
  };
  
  return (
    <div className="relative flex flex-col h-full">
      <div className="bg-white border-b p-2 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Button 
            size="sm" 
            variant={showGrid ? "default" : "outline"} 
            onClick={() => setShowGrid(!showGrid)}
            title="Toggle Grid"
          >
            <Grid className="h-4 w-4" />
          </Button>
          
          <div className="h-4 border-r border-gray-300 mx-1" />
          
          <Button 
            size="sm" 
            variant="outline" 
            onClick={handleUndo}
            disabled={historyIndex <= 0}
            title="Undo"
          >
            <Undo className="h-4 w-4" />
          </Button>
          <Button 
            size="sm" 
            variant="outline" 
            onClick={handleRedo}
            disabled={historyIndex >= history.length - 1}
            title="Redo"
          >
            <Redo className="h-4 w-4" />
          </Button>
        </div>
        
        {selectedComponentId && (
          <div className="flex items-center space-x-1">
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => handleAlignComponent('left')}
              title="Align Left"
            >
              <AlignLeft className="h-4 w-4" />
            </Button>
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => handleAlignComponent('center')}
              title="Align Center"
            >
              <AlignCenter className="h-4 w-4" />
            </Button>
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => handleAlignComponent('right')}
              title="Align Right"
            >
              <AlignRight className="h-4 w-4" />
            </Button>
            
            <div className="h-4 border-r border-gray-300 mx-1" />
            
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => handleMoveComponent('up')}
              title="Move Up"
            >
              <ChevronUp className="h-4 w-4" />
            </Button>
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => handleMoveComponent('down')}
              title="Move Down"
            >
              <ChevronDown className="h-4 w-4" />
            </Button>
            
            <div className="h-4 border-r border-gray-300 mx-1" />
            
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => onDuplicateComponent(selectedComponentId)}
              title="Duplicate"
            >
              <Copy className="h-4 w-4" />
            </Button>
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => onDeleteComponent(selectedComponentId)}
              title="Delete"
              className="hover:bg-red-50 hover:text-red-500"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>
      
      <div 
        ref={canvasRef}
        className="relative flex-1 overflow-auto bg-gray-50"
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
      >
        {showGrid && (
          <div 
            className="absolute inset-0 pointer-events-none"
            style={{ 
              backgroundSize: '8px 8px',
              backgroundImage: 'linear-gradient(to right, #e5e7eb 1px, transparent 1px), linear-gradient(to bottom, #e5e7eb 1px, transparent 1px)',
              backgroundPosition: '0 0'
            }}
          />
        )}
        
        <div className="relative min-h-full">
          {components.map(component => renderComponent(component))}
        </div>
      </div>

      <Dialog open={showAddChildDialog} onOpenChange={setShowAddChildDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Child Component</DialogTitle>
            <DialogDescription>
              {parentIdForNewChild && (
                <span>
                  Select a component to add as a child to{' '}
                  <strong>
                    {findComponentById(components, parentIdForNewChild)?.name || 'component'}
                  </strong>
                </span>
              )}
            </DialogDescription>
          </DialogHeader>
          <div className="max-h-[70vh] overflow-y-auto p-4">
            <ComponentLibrary onAddComponent={handleAddComponentToParent} />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CanvasEditor;
