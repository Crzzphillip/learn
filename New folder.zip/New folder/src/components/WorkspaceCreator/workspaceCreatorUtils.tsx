
import React from 'react';
import { Bot, Database, FileText, Zap, Code, Server, Puzzle, Layout, Cloud, Workflow, 
  GitPullRequest, Link, Terminal, Globe, Key, Settings, Shield, Search, BookOpen, 
  BrainCircuit, Cpu, RefreshCw, TestTube, Network, PenTool, Boxes, Users, Lock, 
  Share, Rocket, AlertCircle, PlayCircle, Infinity } from 'lucide-react';
import { ComponentCategory, WorkspaceComponent, WorkspaceTemplate } from '@/types/workspace';
import { workspaceComponentsData, workspaceTemplateData, componentCategories } from '@/services/workspaceComponentsData';
import { WorkspaceTemplateWithComponent, WorkspaceComponentWithIcon } from '@/services/workspaceTemplateTypes';

// Define node component for the ReactFlow component
export function CustomNode({ data }: { data: any }) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 min-w-[300px]">
      <div className="flex flex-col gap-4">
        <h3 className="text-xl font-semibold">{data.label}</h3>
        <p className="text-sm text-muted-foreground">{data.description}</p>
      </div>
    </div>
  );
}

// Sample initial nodes for the workspace
export const initialNodes = [
  {
    id: 'welcome-node',
    type: 'custom',
    position: { x: 100, y: 100 },
    data: {
      label: 'Welcome to AIForge Workspace Creator',
      description: 'Design your AI-powered development workspace by connecting agents, workflows, and apps',
    },
  }
];

// Sample initial edges for the workspace
export const initialEdges = [];

// Map of Lucide icon components
export const iconMap = {
  Bot: Bot,
  Database: Database,
  FileText: FileText,
  Zap: Zap,
  Code: Code,
  Server: Server,
  Puzzle: Puzzle,
  Layout: Layout,
  Cloud: Cloud,
  Workflow: Workflow,
  GitPullRequest: GitPullRequest,
  Link: Link,
  Terminal: Terminal,
  Globe: Globe,
  Key: Key,
  Settings: Settings,
  Shield: Shield,
  Search: Search,
  BookOpen: BookOpen,
  BrainCircuit: BrainCircuit,
  Cpu: Cpu,
  RefreshCw: RefreshCw,
  TestTube: TestTube,
  Network: Network,
  PenTool: PenTool,
  Boxes: Boxes,
  Users: Users,
  Lock: Lock,
  Share: Share,
  Rocket: Rocket,
  AlertCircle: AlertCircle,
  PlayCircle: PlayCircle,
  Infinity: Infinity
};

// Helper function to get an icon component by name
export const getIconByName = (iconName: string, className: string = "h-5 w-5"): React.ReactElement | null => {
  const IconComponent = iconMap[iconName as keyof typeof iconMap];
  if (!IconComponent) return null;
  return <IconComponent className={className} />;
};

// Generate workspace components with React elements for icons
export const workspaceComponents: WorkspaceComponentWithIcon[] = workspaceComponentsData.map(component => ({
  ...component,
  icon: getIconByName(component.iconName || "")
}));

// Node types for ReactFlow
export const nodeTypes = {
  custom: CustomNode
};

// Function to get AIForge templates with React elements for icons
export const getAIForgeTemplates = (): WorkspaceTemplateWithComponent[] => {
  return workspaceTemplateData.map(template => ({
    ...template,
    icon: getIconByName(template.iconName || "", "w-4 h-4")
  }));
};

// Exporting the templates to be used in other components
export const workspaceTemplates = getAIForgeTemplates();

// Export component categories from data file
export { componentCategories } from '@/services/workspaceComponentsData';

// Helper functions
export const getComponentsByCategory = (category: string): WorkspaceComponentWithIcon[] => {
  return workspaceComponents.filter(comp => comp.category === category);
};

export const getCompatibleComponents = (componentId: string): WorkspaceComponentWithIcon[] => {
  const component = workspaceComponents.find(comp => comp.id === componentId);
  if (!component || !component.compatibleWith) return [];
  
  return workspaceComponents.filter(comp => 
    component.compatibleWith?.includes(comp.id)
  );
};

export const getComponentsByType = (type: string): WorkspaceComponentWithIcon[] => {
  return workspaceComponents.filter(comp => comp.type === type);
};

export const getComponentsByCapability = (capability: string): WorkspaceComponentWithIcon[] => {
  return workspaceComponents.filter(comp => 
    comp.capabilities && comp.capabilities.includes(capability)
  );
};

export const getTemplateById = (templateId: string): WorkspaceTemplateWithComponent | undefined => {
  return getAIForgeTemplates().find(template => template.id === templateId);
};
