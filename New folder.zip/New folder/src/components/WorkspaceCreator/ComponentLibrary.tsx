
import React, { useState, useEffect } from 'react';
import { 
  getComponentLibrary, 
  componentCategories
} from '@/services/componentLibrary';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search, Filter } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import type { LibraryComponent } from '@/services/componentLibrary/types';

interface ComponentLibraryProps {
  onAddComponent: (component: LibraryComponent) => void;
}

const ComponentLibrary: React.FC<ComponentLibraryProps> = ({ onAddComponent }) => {
  const [components, setComponents] = useState<LibraryComponent[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  
  useEffect(() => {
    // Load components from the service
    const libraryComponents = getComponentLibrary();
    setComponents(libraryComponents);
  }, []);
  
  // Filter components based on search query and active category
  const filteredComponents = components.filter(component => {
    const matchesSearch = 
      component.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (component.description?.toLowerCase().includes(searchQuery.toLowerCase()) || false) ||
      component.type.toLowerCase().includes(searchQuery.toLowerCase());
      
    const matchesCategory = 
      activeCategory === 'all' || 
      component.category === activeCategory;
      
    return matchesSearch && matchesCategory;
  });
  
  // Group components by subcategory within the active category
  const groupedComponents: Record<string, LibraryComponent[]> = {};
  
  filteredComponents.forEach(component => {
    const category = component.category || 'other';
    if (!groupedComponents[category]) {
      groupedComponents[category] = [];
    }
    groupedComponents[category].push(component);
  });
  
  const handleDragStart = (e: React.DragEvent, component: LibraryComponent) => {
    e.dataTransfer.setData('application/json', JSON.stringify(component));
    e.dataTransfer.effectAllowed = 'copy';
  };
  
  return (
    <div className="h-full flex flex-col border-l">
      <div className="p-4 border-b">
        <h3 className="font-medium mb-3">Component Library</h3>
        <div className="relative mb-3">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search components..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8"
          />
        </div>
        
        <Tabs value={activeCategory} onValueChange={setActiveCategory}>
          <TabsList className="w-full flex flex-wrap h-auto gap-1 justify-start bg-transparent">
            <TabsTrigger value="all" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              All
            </TabsTrigger>
            {componentCategories.map(category => (
              <TabsTrigger 
                key={category.id} 
                value={category.id}
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                <span className="flex items-center gap-1">
                  {category.icon}
                  <span>{category.name}</span>
                </span>
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </div>
      
      <ScrollArea className="flex-1 p-4">
        {Object.keys(groupedComponents).length > 0 ? (
          <div className="space-y-6">
            {Object.entries(groupedComponents).map(([category, comps]) => {
              // Find the category object to get its name
              const categoryObj = componentCategories.find(c => c.id === category);
              
              return (
                <div key={category} className="space-y-2">
                  <h4 className="text-sm font-medium capitalize">
                    {categoryObj ? categoryObj.name : category}
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {comps.map((component) => (
                      <div 
                        key={component.id}
                        className="border rounded-md p-3 bg-card hover:border-primary cursor-move transition-colors"
                        draggable
                        onDragStart={(e) => handleDragStart(e, component)}
                        onClick={() => onAddComponent(component)}
                      >
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-8 h-8 bg-primary/10 rounded-md flex items-center justify-center">
                            {component.icon}
                          </div>
                          <div>
                            <div className="font-medium text-sm">{component.name}</div>
                            <div className="text-xs text-muted-foreground">{component.type}</div>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2">
                          {component.description || ''}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-muted-foreground">
            <p>No components found matching your criteria</p>
          </div>
        )}
      </ScrollArea>
    </div>
  );
};

export default ComponentLibrary;
