
import { workspaceBuilderService } from '@/services/workspaceTemplateService';
import { WorkspaceTemplateWithComponent } from '@/services/workspaceTemplateTypes';
import { WorkspaceTemplate } from '@/types/workspace';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, Search, Layers, Filter } from 'lucide-react';
import { toast } from 'sonner';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useState, useEffect } from 'react';

interface TemplateSelectorProps {
  onSelectTemplate: (template: WorkspaceTemplate) => void;
}

const TemplateSelector = ({ onSelectTemplate }: TemplateSelectorProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedComplexity, setSelectedComplexity] = useState('all');
  const [isLoading, setIsLoading] = useState(true);
  
  // Get all templates from our service
  const allTemplates = workspaceBuilderService.getAllTemplates();
  
  useEffect(() => {
    // Add debugging log to see if templates are loaded
    console.log("Templates loaded:", allTemplates);
    setIsLoading(false);
  }, [allTemplates]);
  
  // Filter templates based on search query, category, and complexity
  const filteredTemplates = allTemplates.filter(template => {
    const matchesSearch = 
      template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (template.industry && template.industry.toLowerCase().includes(searchQuery.toLowerCase()));
      
    const matchesCategory = 
      selectedCategory === 'all' || 
      template.category === selectedCategory ||
      (selectedCategory === 'aiforge' && template.aiForgeTemplate);
      
    const matchesComplexity = 
      selectedComplexity === 'all' || 
      template.complexity === selectedComplexity;
      
    return matchesSearch && matchesCategory && matchesComplexity;
  });
  
  // Get unique categories for filtering
  const categories = ['all', ...new Set(allTemplates.map(template => template.category))];
  
  // Add AIForge category if there are AIForge templates
  if (allTemplates.some(template => template.aiForgeTemplate)) {
    if (!categories.includes('aiforge')) {
      categories.push('aiforge');
    }
  }
  
  if (isLoading) {
    return (
      <div className="p-6 flex justify-center">
        <div className="animate-pulse">Loading templates...</div>
      </div>
    );
  }
  
  return (
    <div className="p-6 space-y-6">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold tracking-tight">Workspace Templates</h2>
        <p className="text-muted-foreground">Start with a pre-configured workspace template to save time.</p>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-grow">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search templates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8"
          />
        </div>
        
        <div className="flex gap-2">
          <select 
            className="px-3 py-2 rounded-md border bg-background"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            {categories.map((category) => (
              <option key={category} value={category}>
                {category === 'all' 
                  ? 'All Categories' 
                  : category === 'aiforge' 
                    ? 'AIForge Templates' 
                    : category.charAt(0).toUpperCase() + category.slice(1)}
              </option>
            ))}
          </select>
          
          <select 
            className="px-3 py-2 rounded-md border bg-background"
            value={selectedComplexity}
            onChange={(e) => setSelectedComplexity(e.target.value)}
          >
            <option value="all">All Levels</option>
            <option value="beginner">Beginner</option>
            <option value="intermediate">Intermediate</option>
            <option value="advanced">Advanced</option>
          </select>
        </div>
      </div>
      
      <Tabs defaultValue="grid" className="w-full">
        <div className="flex justify-end mb-4">
          <TabsList>
            <TabsTrigger value="grid" className="flex items-center gap-1">
              <Layers className="h-4 w-4" />
              <span>Grid</span>
            </TabsTrigger>
            <TabsTrigger value="list" className="flex items-center gap-1">
              <Filter className="h-4 w-4" />
              <span>List</span>
            </TabsTrigger>
          </TabsList>
        </div>
        
        <TabsContent value="grid" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTemplates.map((template) => (
              <Card key={template.id} className="overflow-hidden flex flex-col">
                {template.previewImage && (
                  <div className="aspect-video w-full overflow-hidden">
                    <img 
                      src={template.previewImage} 
                      alt={template.name} 
                      className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
                    />
                  </div>
                )}
                
                <CardHeader className="pb-2">
                  <div className="flex items-center gap-2">
                    {template.icon}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1">
                        <CardTitle className="text-lg truncate">{template.name}</CardTitle>
                        {template.aiForgeTemplate && (
                          <Badge variant="success" className="ml-1">AIForge</Badge>
                        )}
                      </div>
                    </div>
                  </div>
                  <CardDescription className="line-clamp-2">{template.description}</CardDescription>
                </CardHeader>
                
                <CardContent className="flex-grow pb-2">
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm font-medium mb-1">Includes:</p>
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="outline" className="text-xs">
                          {template.components.length} Components
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {template.connections.length} Connections
                        </Badge>
                        {template.complexity && (
                          <Badge variant="outline" className="text-xs">
                            {template.complexity.charAt(0).toUpperCase() + template.complexity.slice(1)}
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium mb-1">Tags:</p>
                      <div className="flex flex-wrap gap-1">
                        {template.tags.map((tag) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    {template.industry && (
                      <div>
                        <p className="text-sm font-medium mb-1">Industry:</p>
                        <Badge variant="info" className="text-xs">
                          {template.industry}
                        </Badge>
                      </div>
                    )}
                  </div>
                </CardContent>
                
                <CardFooter>
                  <Button 
                    className="w-full gap-1" 
                    onClick={() => {
                      onSelectTemplate(template);
                      toast.success(`Template "${template.name}" selected`, {
                        description: "Components and connections will be added to your workspace."
                      });
                    }}
                  >
                    Use Template <ArrowRight className="w-4 h-4" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="list" className="mt-0">
          <div className="space-y-2">
            {filteredTemplates.map((template) => (
              <div 
                key={template.id} 
                className="flex items-start justify-between p-4 rounded-lg border bg-card hover:bg-accent/5 transition-colors"
              >
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg grid place-items-center bg-muted">
                    {template.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1 mb-1">
                      <h3 className="font-medium">{template.name}</h3>
                      {template.aiForgeTemplate && (
                        <Badge variant="success" className="ml-1">AIForge</Badge>
                      )}
                      {template.complexity && (
                        <Badge variant="outline" className="text-xs ml-auto">
                          {template.complexity.charAt(0).toUpperCase() + template.complexity.slice(1)}
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{template.description}</p>
                    <div className="flex flex-wrap gap-1">
                      {template.tags.slice(0, 4).map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                      {template.tags.length > 4 && (
                        <Badge variant="outline" className="text-xs">
                          +{template.tags.length - 4} more
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
                <Button 
                  size="sm"
                  className="ml-4 whitespace-nowrap"
                  onClick={() => {
                    onSelectTemplate(template);
                    toast.success(`Template "${template.name}" selected`, {
                      description: "Components and connections will be added to your workspace."
                    });
                  }}
                >
                  Use Template
                </Button>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
      
      {filteredTemplates.length === 0 && (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="rounded-full bg-muted w-12 h-12 flex items-center justify-center mb-4">
            <Search className="h-6 w-6 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-medium mb-1">No templates found</h3>
          <p className="text-muted-foreground max-w-md">
            Try adjusting your search query or filters to find what you're looking for.
          </p>
        </div>
      )}
    </div>
  );
};

export default TemplateSelector;
