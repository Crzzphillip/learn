
import { Button } from "@/components/ui/button";
import { Monitor, Share } from "lucide-react";

interface WorkspaceHeaderProps {
  workspaceName: string;
  setWorkspaceName: (name: string) => void;
  workspaceDescription: string;
  setWorkspaceDescription: (description: string) => void;
  saveWorkspace: () => void;
}

const WorkspaceHeader = ({
  workspaceName,
  setWorkspaceName,
  workspaceDescription,
  setWorkspaceDescription,
  saveWorkspace
}: WorkspaceHeaderProps) => {
  return (
    <div className="border-b bg-background/95 backdrop-blur-sm">
      <div className="container py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-semibold">Create New Workspace</h1>
            <div className="flex-1 max-w-md">
              <input
                type="text"
                placeholder="Workspace Name"
                className="w-full px-3 py-1 rounded-md border text-sm"
                value={workspaceName}
                onChange={(e) => setWorkspaceName(e.target.value)}
              />
            </div>
            <div className="flex-1 max-w-md">
              <input
                type="text"
                placeholder="Description (optional)"
                className="w-full px-3 py-1 rounded-md border text-sm"
                value={workspaceDescription}
                onChange={(e) => setWorkspaceDescription(e.target.value)}
              />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-2">
              <Monitor className="w-4 h-4" />
              Preview
            </Button>
            <Button
              size="sm"
              className="gap-2"
              onClick={saveWorkspace}
            >
              <Share className="w-4 h-4" />
              Save Workspace
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorkspaceHeader;
