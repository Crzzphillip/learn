import React, { useState } from 'react';
import { 
  Box, Type, ToggleLeft, Zap, Play, Palette, Layout, Settings, Move, 
  ArrowRight, ArrowLeft, ArrowUp, ArrowDown, AlignLeft, AlignCenter, 
  AlignRight, AlignJustify, Code, Image, Video, FileText, Table, List, 
  Square, Menu, Star, ChevronDown, Circle, HelpCircle, Search
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';

const COMPONENT_CATEGORIES = [
  {
    id: 'layout',
    name: 'Layout',
    icon: Layout,
    components: [
      { id: 'container', name: 'Container', icon: Box, description: 'A responsive container' },
      { id: 'grid', name: 'Grid', icon: Box, description: 'Grid layout system' },
      { id: 'flex', name: 'Flex', icon: Box, description: 'Flexible box layout' },
      { id: 'section', name: 'Section', icon: Box, description: 'Content section' }
    ]
  },
  {
    id: 'basic',
    name: 'Basic',
    icon: Type,
    components: [
      { id: 'heading', name: 'Heading', icon: Type, description: 'Text heading' },
      { id: 'text', name: 'Text', icon: Type, description: 'Text content' },
      { id: 'button', name: 'Button', icon: Box, description: 'Clickable button' },
      { id: 'link', name: 'Link', icon: Box, description: 'Hyperlink' }
    ]
  },
  {
    id: 'media',
    name: 'Media',
    icon: Image,
    components: [
      { id: 'image', name: 'Image', icon: Image, description: 'Image element' },
      { id: 'video', name: 'Video', icon: Video, description: 'Video player' },
      { id: 'icon', name: 'Icon', icon: Star, description: 'Icon element' }
    ]
  }
];

interface ComponentPaletteProps {
  onComponentSelect: (componentId: string) => void;
}

export const ComponentPalette: React.FC<ComponentPaletteProps> = ({ onComponentSelect }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const handleDragStart = (e: React.DragEvent, componentId: string) => {
    e.dataTransfer.setData('text/plain', componentId);
  };

  const filteredCategories = COMPONENT_CATEGORIES.map(category => ({
    ...category,
    components: category.components.filter(component =>
      component.name.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })).filter(category => category.components.length > 0);

  return (
    <div className="w-64 h-full bg-background border-r border-border">
      <div className="p-4 border-b border-border">
            <Input
              placeholder="Search components..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full"
            />
          </div>
      <ScrollArea className="h-[calc(100vh-4rem)]">
        <div className="p-4 space-y-4">
          {filteredCategories.map(category => (
            <div key={category.id} className="space-y-2">
              <div 
                className="flex items-center justify-between cursor-pointer"
                onClick={() => setSelectedCategory(
                  selectedCategory === category.id ? null : category.id
                )}
                >
                <div className="flex items-center gap-2">
                  <category.icon className="w-4 h-4" />
                  <span className="font-medium">{category.name}</span>
        </div>
                <ChevronDown 
                  className={`w-4 h-4 transition-transform ${
                    selectedCategory === category.id ? 'rotate-180' : ''
                  }`}
                />
      </div>
              {selectedCategory === category.id && (
                <div className="pl-6 space-y-2">
                  {category.components.map(component => (
                    <div 
                      key={component.id} 
                      draggable
                      onDragStart={(e) => handleDragStart(e, component.id)}
                      onClick={() => onComponentSelect(component.id)}
                      className="flex items-center gap-2 p-2 rounded-md hover:bg-accent cursor-pointer"
                    >
                      <component.icon className="w-4 h-4" />
                      <div className="flex-1">
                        <div className="text-sm font-medium">{component.name}</div>
                        <div className="text-xs text-muted-foreground">
                          {component.description}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              </div>
            ))}
          </div>
      </ScrollArea>
    </div>
  );
};
