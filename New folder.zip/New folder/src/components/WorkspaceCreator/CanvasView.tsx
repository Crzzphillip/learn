
import React from 'react';
import { ReactFlow, Background, Controls, MiniMap, Panel } from '@xyflow/react';
import { Link, Square, Zap } from 'lucide-react';

interface CanvasViewProps {
  nodes: any[];
  edges: any[];
  onNodesChange: (changes: any) => void;
  onEdgesChange: (changes: any) => void;
  onConnect: (connection: any) => void;
  nodeTypes: any;
  onNodeClick?: (event: React.MouseEvent, node: any) => void;
}

// Define the BackgroundVariant enum
enum BackgroundVariant {
  Dots = 'dots',
  Lines = 'lines',
  Cross = 'cross'
}

const CanvasView = ({
  nodes,
  edges,
  onNodesChange,
  onEdgesChange,
  onConnect,
  nodeTypes,
  onNodeClick
}: CanvasViewProps) => {
  return (
    <div className="h-full relative">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        nodeTypes={nodeTypes}
        onNodeClick={onNodeClick}
        fitView
        minZoom={0.2}
        maxZoom={2}
        proOptions={{ hideAttribution: true }}
        className="bg-[#121212]"
      >
        <Background 
          variant={BackgroundVariant.Dots}
          gap={20} 
          size={1} 
          color="rgba(120, 74, 245, 0.05)" 
          style={{ backgroundColor: '#121212' }}
        />
        <Controls 
          className="bg-[#252525] border border-[#333] rounded-md p-1"
          showInteractive={false} 
          position="bottom-right"
        />
        <MiniMap 
          nodeStrokeColor={(n) => {
            if (n.type === 'agentNode') return '#c4a8ff';
            if (n.type === 'toolNode') return '#a8d1ff';
            if (n.type === 'integrationNode') return '#a8ffbc';
            return '#ffd5a8';
          }}
          nodeColor={(n) => {
            if (n.type === 'agentNode') return '#7c4dff50';
            if (n.type === 'toolNode') return '#4d94ff50';
            if (n.type === 'integrationNode') return '#4dff8950';
            return '#ffa64d50';
          }}
          maskColor="#12121230"
          className="bg-[#252525] border border-[#333] rounded-md"
          style={{ top: 'auto', right: 10, bottom: 60, left: 'auto' }}
        />
        
        <Panel position="top-right" className="bg-[#252525]/80 backdrop-blur-sm rounded p-1 m-3 border border-[#333] flex gap-1">
          <button className="p-1 hover:bg-[#333] rounded">
            <Square className="h-4 w-4 text-gray-400" />
          </button>
          <button className="p-1 hover:bg-[#333] rounded">
            <Link className="h-4 w-4 text-gray-400" />
          </button>
          <button className="p-1 hover:bg-[#333] rounded">
            <Zap className="h-4 w-4 text-gray-400" />
          </button>
        </Panel>
      </ReactFlow>
    </div>
  );
};

export default CanvasView;
