import React from 'react';
import { WebsiteComponent } from '@/services/websiteComponentsService';

interface WebsitePreviewProps {
  components: WebsiteComponent[];
  selectedComponentId: string | null;
  onSelectComponent: (component: WebsiteComponent) => void;
}

const WebsitePreview: React.FC<WebsitePreviewProps> = ({
  components,
  selectedComponentId,
  onSelectComponent
}) => {
  // Recursive function to render components and their children
  const renderComponent = (component: WebsiteComponent) => {
    const isSelected = component.id === selectedComponentId;
    const ElementType = component.type as keyof JSX.IntrinsicElements;
    
    // Prepare props for the component
    const componentProps = {
      ...component.props,
      style: component.style,
      className: `${component.props.className || ''} ${isSelected ? 'outline outline-2 outline-blue-500' : ''}`,
      onClick: (e: React.MouseEvent) => {
        e.stopPropagation();
        onSelectComponent(component);
      }
    };
    
    // If the component has children, render them inside
    if (component.children && component.children.length > 0) {
      return (
        <ElementType {...componentProps} key={component.id}>
          {component.children.map(child => renderComponent(child))}
        </ElementType>
      );
    }
    
    // If the component has content (text), render it
    if (component.content) {
      return (
        <ElementType {...componentProps} key={component.id}>
          {component.content}
        </ElementType>
      );
    }
    
    // Otherwise, render an empty element
    return <ElementType {...componentProps} key={component.id} />;
  };
  
  return (
    <div className="h-full w-full bg-white overflow-auto">
      {components.map(component => renderComponent(component))}
    </div>
  );
};

export default WebsitePreview;
