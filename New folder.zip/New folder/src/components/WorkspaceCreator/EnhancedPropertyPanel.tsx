import React, { useState, useEffect } from 'react';
import { 
  Box, Type, ToggleLeft, Zap, Play, Palette, Layout, Settings, Move, 
  ArrowRight, ArrowLeft, ArrowUp, ArrowDown, AlignLeft, AlignCenter, 
  AlignRight, AlignJustify, Code, Image, Video, FileText, Table, List, 
  Square, Menu, FileText as FooterIcon, Star, Box as SectionIcon, 
  Image as CarouselIcon, ChevronDown as AccordionIcon, 
  Layout as TabsIcon, Square as ModalIcon, AlertCircle as AlertIcon, 
  Badge as BadgeIcon, User, Activity, Loader2, Minus 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { WebsiteComponent } from '@/services/websiteComponents/types';
import { fetchComponentById } from '@/services/websiteComponents/componentsService';
import { toast } from 'sonner';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";

// EnhancedPropertyPanel Props
interface EnhancedPropertyPanelProps {
  selectedComponentId: string | null;
  onUpdateComponent: (componentId: string, property: string, value: any) => void;
}

const EnhancedPropertyPanel: React.FC<EnhancedPropertyPanelProps> = ({
  selectedComponentId,
  onUpdateComponent
}) => {
  const [activeTab, setActiveTab] = useState('style');
  const [selectedComponent, setSelectedComponent] = useState<WebsiteComponent | null>(null);
  
  // Fetch component data when selectedComponentId changes
  useEffect(() => {
    const fetchComponentData = async () => {
      if (selectedComponentId) {
        try {
          const component = await fetchComponentById(selectedComponentId);
          setSelectedComponent(component);
        } catch (error) {
          console.error("Error fetching component:", error);
          setSelectedComponent(null);
        }
      } else {
        setSelectedComponent(null);
      }
    };
    
    fetchComponentData();
  }, [selectedComponentId]);

  if (!selectedComponentId) {
    return (
      <div className="h-full flex items-center justify-center p-4 bg-[#1a1a1a] text-gray-400">
        <p className="text-sm">Select a component to edit its properties</p>
      </div>
    );
  }

  const renderComponentSpecificProperties = () => {
    if (!selectedComponent) return null;

    switch (selectedComponent.type) {
      case 'heading':
        return (
          <AccordionItem value="content" className="border-[#333]">
            <AccordionTrigger className="hover:bg-[#252525] px-3 text-sm">
              Content
            </AccordionTrigger>
            <AccordionContent className="p-3 space-y-4">
              <div className="space-y-2">
                <Label className="text-xs text-gray-400">Heading Level</Label>
                <Select 
                  defaultValue={selectedComponent.props?.level || 'h1'}
                  onValueChange={(value) => onUpdateComponent(selectedComponentId, 'props.level', value)}
                >
                  <SelectTrigger className="bg-[#252525] border-[#333]">
                    <SelectValue placeholder="Select level" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#252525] border-[#333]">
                    <SelectItem value="h1">H1</SelectItem>
                    <SelectItem value="h2">H2</SelectItem>
                    <SelectItem value="h3">H3</SelectItem>
                    <SelectItem value="h4">H4</SelectItem>
                    <SelectItem value="h5">H5</SelectItem>
                    <SelectItem value="h6">H6</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-xs text-gray-400">Text</Label>
                <Textarea
                  defaultValue={selectedComponent.content}
                  onChange={(e) => onUpdateComponent(selectedComponentId, 'content', e.target.value)}
                  className="bg-[#252525] border-[#333] text-gray-200"
                />
              </div>
            </AccordionContent>
          </AccordionItem>
        );

      case 'button':
        return (
          <AccordionItem value="content" className="border-[#333]">
            <AccordionTrigger className="hover:bg-[#252525] px-3 text-sm">
              Content
            </AccordionTrigger>
            <AccordionContent className="p-3 space-y-4">
              <div className="space-y-2">
                <Label className="text-xs text-gray-400">Button Text</Label>
                <Input
                  defaultValue={selectedComponent.content}
                  onChange={(e) => onUpdateComponent(selectedComponentId, 'content', e.target.value)}
                  className="bg-[#252525] border-[#333] text-gray-200"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-xs text-gray-400">Variant</Label>
                <Select 
                  defaultValue={selectedComponent.props?.variant || 'default'}
                  onValueChange={(value) => onUpdateComponent(selectedComponentId, 'props.variant', value)}
                >
                  <SelectTrigger className="bg-[#252525] border-[#333]">
                    <SelectValue placeholder="Select variant" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#252525] border-[#333]">
                    <SelectItem value="default">Default</SelectItem>
                    <SelectItem value="secondary">Secondary</SelectItem>
                    <SelectItem value="outline">Outline</SelectItem>
                    <SelectItem value="ghost">Ghost</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-xs text-gray-400">Size</Label>
                <Select 
                  defaultValue={selectedComponent.props?.size || 'default'}
                  onValueChange={(value) => onUpdateComponent(selectedComponentId, 'props.size', value)}
                >
                  <SelectTrigger className="bg-[#252525] border-[#333]">
                    <SelectValue placeholder="Select size" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#252525] border-[#333]">
                    <SelectItem value="sm">Small</SelectItem>
                    <SelectItem value="default">Default</SelectItem>
                    <SelectItem value="lg">Large</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </AccordionContent>
          </AccordionItem>
        );

      case 'image':
        return (
          <AccordionItem value="content" className="border-[#333]">
            <AccordionTrigger className="hover:bg-[#252525] px-3 text-sm">
              Content
            </AccordionTrigger>
            <AccordionContent className="p-3 space-y-4">
              <div className="space-y-2">
                <Label className="text-xs text-gray-400">Image URL</Label>
                <Input
                  defaultValue={selectedComponent.props?.src}
                  onChange={(e) => onUpdateComponent(selectedComponentId, 'props.src', e.target.value)}
                  className="bg-[#252525] border-[#333] text-gray-200"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-xs text-gray-400">Alt Text</Label>
                <Input
                  defaultValue={selectedComponent.props?.alt}
                  onChange={(e) => onUpdateComponent(selectedComponentId, 'props.alt', e.target.value)}
                  className="bg-[#252525] border-[#333] text-gray-200"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-xs text-gray-400">Object Fit</Label>
                <Select 
                  defaultValue={selectedComponent.props?.objectFit || 'cover'}
                  onValueChange={(value) => onUpdateComponent(selectedComponentId, 'props.objectFit', value)}
                >
                  <SelectTrigger className="bg-[#252525] border-[#333]">
                    <SelectValue placeholder="Select fit" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#252525] border-[#333]">
                    <SelectItem value="contain">Contain</SelectItem>
                    <SelectItem value="cover">Cover</SelectItem>
                    <SelectItem value="fill">Fill</SelectItem>
                    <SelectItem value="none">None</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </AccordionContent>
          </AccordionItem>
        );

      // Add more component-specific properties here...

      default:
        return null;
    }
  };

  return (
    <div className="h-full flex flex-col bg-[#1a1a1a] text-gray-200">
      <div className="border-b border-[#333] p-2">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 bg-[#252525]">
            <TabsTrigger value="style" className="data-[state=active]:bg-purple-500/20">
              <Palette className="h-4 w-4" />
            </TabsTrigger>
            <TabsTrigger value="layout" className="data-[state=active]:bg-purple-500/20">
              <Layout className="h-4 w-4" />
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-purple-500/20">
              <Settings className="h-4 w-4" />
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4">
          <TabsContent value="style" className="m-0">
            <Accordion type="multiple" defaultValue={["typography", "colors", "spacing"]}>
              {/* Typography */}
              <AccordionItem value="typography" className="border-[#333]">
                <AccordionTrigger className="hover:bg-[#252525] px-3 text-sm">
                  Typography
                </AccordionTrigger>
                <AccordionContent className="p-3 space-y-4">
                  <div className="space-y-2">
                    <Label className="text-xs text-gray-400">Font Family</Label>
                    <Select onValueChange={(value) => onUpdateComponent(selectedComponentId, "style.fontFamily", value)}>
                      <SelectTrigger className="bg-[#252525] border-[#333]">
                        <SelectValue placeholder="Select font" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#252525] border-[#333]">
                        <SelectItem value="inter">Inter</SelectItem>
                        <SelectItem value="roboto">Roboto</SelectItem>
                        <SelectItem value="poppins">Poppins</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs text-gray-400">Font Size</Label>
                    <div className="flex gap-2">
                      <Slider 
                        defaultValue={[16]} 
                        max={72} 
                        step={1}
                        className="flex-1"
                        onValueChange={([value]) => onUpdateComponent(selectedComponentId, "style.fontSize", `${value}px`)}
                      />
                      <Input 
                        type="number" 
                        className="w-16 bg-[#252525] border-[#333]" 
                        defaultValue="16"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs text-gray-400">Text Alignment</Label>
                    <div className="flex gap-1">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="flex-1 bg-[#252525] hover:bg-[#333] data-[state=active]:bg-purple-500/20"
                        onClick={() => onUpdateComponent(selectedComponentId, "style.textAlign", "left")}
                      >
                        <AlignLeft className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="flex-1 bg-[#252525] hover:bg-[#333]"
                        onClick={() => onUpdateComponent(selectedComponentId, "style.textAlign", "center")}
                      >
                        <AlignCenter className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="flex-1 bg-[#252525] hover:bg-[#333]"
                        onClick={() => onUpdateComponent(selectedComponentId, "style.textAlign", "right")}
                      >
                        <AlignRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Colors */}
              <AccordionItem value="colors" className="border-[#333]">
                <AccordionTrigger className="hover:bg-[#252525] px-3 text-sm">
                  Colors
                </AccordionTrigger>
                <AccordionContent className="p-3 space-y-4">
                  <div className="space-y-2">
                    <Label className="text-xs text-gray-400">Text Color</Label>
                    <div className="flex gap-2">
                      <Input 
                        type="color" 
                        className="w-10 h-10 bg-[#252525] border-[#333] p-1"
                        onChange={(e) => onUpdateComponent(selectedComponentId, "style.color", e.target.value)}
                      />
                      <Input 
                        type="text" 
                        className="flex-1 bg-[#252525] border-[#333]"
                        placeholder="#000000"
                      />
              </div>
            </div>

                  <div className="space-y-2">
                    <Label className="text-xs text-gray-400">Background Color</Label>
                    <div className="flex gap-2">
                      <Input 
                        type="color" 
                        className="w-10 h-10 bg-[#252525] border-[#333] p-1"
                        onChange={(e) => onUpdateComponent(selectedComponentId, "style.backgroundColor", e.target.value)}
                      />
              <Input 
                        type="text" 
                        className="flex-1 bg-[#252525] border-[#333]"
                        placeholder="#ffffff"
              />
            </div>
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Spacing */}
              <AccordionItem value="spacing" className="border-[#333]">
                <AccordionTrigger className="hover:bg-[#252525] px-3 text-sm">
                  Spacing
                </AccordionTrigger>
                <AccordionContent className="p-3">
                  <div className="border border-[#333] rounded-md p-4 bg-[#252525] relative">
                    <div className="space-y-4">
                      {/* Margin controls */}
                      <div className="grid grid-cols-4 gap-2">
                        <Input 
                          type="number" 
                          className="bg-[#1a1a1a] border-[#333] text-center"
                          placeholder="M"
                          onChange={(e) => onUpdateComponent(selectedComponentId, "style.marginTop", `${e.target.value}px`)}
                        />
                        <Input 
                          type="number" 
                          className="bg-[#1a1a1a] border-[#333] text-center"
                          placeholder="M"
                          onChange={(e) => onUpdateComponent(selectedComponentId, "style.marginRight", `${e.target.value}px`)}
                        />
                        <Input 
                          type="number" 
                          className="bg-[#1a1a1a] border-[#333] text-center"
                          placeholder="M"
                          onChange={(e) => onUpdateComponent(selectedComponentId, "style.marginBottom", `${e.target.value}px`)}
                        />
              <Input 
                          type="number" 
                          className="bg-[#1a1a1a] border-[#333] text-center"
                          placeholder="M"
                          onChange={(e) => onUpdateComponent(selectedComponentId, "style.marginLeft", `${e.target.value}px`)}
              />
            </div>

                      {/* Padding controls */}
                      <div className="grid grid-cols-4 gap-2">
                        <Input 
                          type="number" 
                          className="bg-[#1a1a1a] border-[#333] text-center"
                          placeholder="P"
                          onChange={(e) => onUpdateComponent(selectedComponentId, "style.paddingTop", `${e.target.value}px`)}
                        />
                        <Input 
                          type="number" 
                          className="bg-[#1a1a1a] border-[#333] text-center"
                          placeholder="P"
                          onChange={(e) => onUpdateComponent(selectedComponentId, "style.paddingRight", `${e.target.value}px`)}
                        />
                        <Input 
                          type="number" 
                          className="bg-[#1a1a1a] border-[#333] text-center"
                          placeholder="P"
                          onChange={(e) => onUpdateComponent(selectedComponentId, "style.paddingBottom", `${e.target.value}px`)}
                        />
                  <Input 
                          type="number" 
                          className="bg-[#1a1a1a] border-[#333] text-center"
                          placeholder="P"
                          onChange={(e) => onUpdateComponent(selectedComponentId, "style.paddingLeft", `${e.target.value}px`)}
                  />
                </div>
                    </div>
            </div>
                </AccordionContent>
              </AccordionItem>

              {/* Component-specific properties */}
              {renderComponentSpecificProperties()}
            </Accordion>
          </TabsContent>

          <TabsContent value="layout" className="m-0">
            <Accordion type="multiple" defaultValue={["position", "size", "flex"]}>
              {/* Position */}
              <AccordionItem value="position" className="border-[#333]">
                <AccordionTrigger className="hover:bg-[#252525] px-3 text-sm">
                  Position
                </AccordionTrigger>
                <AccordionContent className="p-3 space-y-4">
                  <div className="space-y-2">
                    <Label className="text-xs text-gray-400">Position Type</Label>
                    <Select onValueChange={(value) => onUpdateComponent(selectedComponentId, "style.position", value)}>
                      <SelectTrigger className="bg-[#252525] border-[#333]">
                        <SelectValue placeholder="Select position" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#252525] border-[#333]">
                        <SelectItem value="static">Static</SelectItem>
                        <SelectItem value="relative">Relative</SelectItem>
                        <SelectItem value="absolute">Absolute</SelectItem>
                        <SelectItem value="fixed">Fixed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-xs text-gray-400">X Position</Label>
                      <Input 
                        type="number" 
                        className="bg-[#252525] border-[#333]"
                        onChange={(e) => onUpdateComponent(selectedComponentId, "style.left", `${e.target.value}px`)}
                      />
                </div>
                    <div className="space-y-2">
                      <Label className="text-xs text-gray-400">Y Position</Label>
                      <Input 
                        type="number" 
                        className="bg-[#252525] border-[#333]"
                        onChange={(e) => onUpdateComponent(selectedComponentId, "style.top", `${e.target.value}px`)}
                      />
              </div>
            </div>
                </AccordionContent>
              </AccordionItem>

              {/* Size */}
              <AccordionItem value="size" className="border-[#333]">
                <AccordionTrigger className="hover:bg-[#252525] px-3 text-sm">
                  Size
                </AccordionTrigger>
                <AccordionContent className="p-3 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-xs text-gray-400">Width</Label>
                      <Input 
                        type="text" 
                        className="bg-[#252525] border-[#333]"
                        placeholder="auto"
                        onChange={(e) => onUpdateComponent(selectedComponentId, "style.width", e.target.value)}
                  />
              </div>
                    <div className="space-y-2">
                      <Label className="text-xs text-gray-400">Height</Label>
                      <Input 
                        type="text" 
                        className="bg-[#252525] border-[#333]"
                        placeholder="auto"
                        onChange={(e) => onUpdateComponent(selectedComponentId, "style.height", e.target.value)}
                  />
              </div>
            </div>
                </AccordionContent>
              </AccordionItem>

              {/* Flex Layout */}
              <AccordionItem value="flex" className="border-[#333]">
                <AccordionTrigger className="hover:bg-[#252525] px-3 text-sm">
                  Flex Layout
                </AccordionTrigger>
                <AccordionContent className="p-3 space-y-4">
                  <div className="space-y-2">
                    <Label className="text-xs text-gray-400">Display</Label>
                    <Select onValueChange={(value) => onUpdateComponent(selectedComponentId, "style.display", value)}>
                      <SelectTrigger className="bg-[#252525] border-[#333]">
                        <SelectValue placeholder="Select display" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#252525] border-[#333]">
                        <SelectItem value="flex">Flex</SelectItem>
                        <SelectItem value="block">Block</SelectItem>
                        <SelectItem value="inline">Inline</SelectItem>
                        <SelectItem value="grid">Grid</SelectItem>
                      </SelectContent>
                    </Select>
            </div>

                  <div className="space-y-2">
                    <Label className="text-xs text-gray-400">Flex Direction</Label>
                    <Select onValueChange={(value) => onUpdateComponent(selectedComponentId, "style.flexDirection", value)}>
                      <SelectTrigger className="bg-[#252525] border-[#333]">
                        <SelectValue placeholder="Select direction" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#252525] border-[#333]">
                        <SelectItem value="row">Row</SelectItem>
                        <SelectItem value="column">Column</SelectItem>
                      </SelectContent>
                    </Select>
                </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </TabsContent>

          <TabsContent value="settings" className="m-0">
            <Accordion type="multiple" defaultValue={["general", "advanced"]}>
              {/* General */}
              <AccordionItem value="general" className="border-[#333]">
                <AccordionTrigger className="hover:bg-[#252525] px-3 text-sm">
                  General
                </AccordionTrigger>
                <AccordionContent className="p-3 space-y-4">
                  <div className="space-y-2">
                    <Label className="text-xs text-gray-400">Component ID</Label>
                    <Input 
                      type="text" 
                      className="bg-[#252525] border-[#333]"
                      value={selectedComponentId}
                      readOnly
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs text-gray-400">Custom Classes</Label>
                    <Input 
                      type="text" 
                      className="bg-[#252525] border-[#333]"
                      placeholder="Enter custom classes"
                      onChange={(e) => onUpdateComponent(selectedComponentId, "props.className", e.target.value)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label className="text-xs text-gray-400">Visible</Label>
                    <Switch 
                      defaultChecked
                      onCheckedChange={(checked) => onUpdateComponent(selectedComponentId, "style.display", checked ? "block" : "none")}
                    />
                  </div>
                </AccordionContent>
              </AccordionItem>

              {/* Advanced */}
              <AccordionItem value="advanced" className="border-[#333]">
                <AccordionTrigger className="hover:bg-[#252525] px-3 text-sm">
                  Advanced
                </AccordionTrigger>
                <AccordionContent className="p-3 space-y-4">
                  <div className="space-y-2">
                    <Label className="text-xs text-gray-400">Custom CSS</Label>
                    <textarea 
                      className="w-full h-24 bg-[#252525] border-[#333] rounded-md p-2 text-sm"
                      placeholder="Enter custom CSS"
                      onChange={(e) => onUpdateComponent(selectedComponentId, "style", e.target.value)}
                    />
              </div>

                  <div className="space-y-2">
                    <Label className="text-xs text-gray-400">Data Attributes</Label>
                    <Input 
                      type="text" 
                      className="bg-[#252525] border-[#333]"
                      placeholder="data-*"
                    />
            </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </TabsContent>
        </div>
      </ScrollArea>
    </div>
  );
};

export default EnhancedPropertyPanel;
