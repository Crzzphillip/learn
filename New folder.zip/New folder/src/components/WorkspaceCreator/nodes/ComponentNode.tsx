
import React, { memo } from 'react';
import { Handle, Position, NodeProps } from '@xyflow/react';
import { WebsiteComponent } from '@/services/websiteComponentsService';
import { Trash2, Move, Copy, Settings, ChevronDown } from 'lucide-react';

interface ComponentNodeProps extends NodeProps {
  data: {
    component: WebsiteComponent;
    onSelect: (component: WebsiteComponent) => void;
    onDelete: (id: string) => void;
    onDuplicate: (id: string) => void;
    isSelected: boolean;
  };
}

const ComponentNode = ({ data, selected }: ComponentNodeProps) => {
  const { component, onSelect, onDelete, onDuplicate, isSelected } = data;
  const isContainer = component.isDroppable;

  const handleSelect = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSelect(component);
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete(component.id);
  };

  const handleDuplicate = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDuplicate(component.id);
  };

  const getBackgroundColor = () => {
    switch (component.category) {
      case 'layout':
        return 'bg-blue-50';
      case 'text':
        return 'bg-green-50';
      case 'basic':
        return 'bg-purple-50';
      case 'input':
        return 'bg-orange-50';
      case 'media':
        return 'bg-pink-50';
      default:
        return 'bg-gray-50';
    }
  };

  const getBorderColor = () => {
    switch (component.category) {
      case 'layout':
        return selected || isSelected ? 'border-blue-500' : 'border-blue-200';
      case 'text':
        return selected || isSelected ? 'border-green-500' : 'border-green-200';
      case 'basic':
        return selected || isSelected ? 'border-purple-500' : 'border-purple-200';
      case 'input':
        return selected || isSelected ? 'border-orange-500' : 'border-orange-200';
      case 'media':
        return selected || isSelected ? 'border-pink-500' : 'border-pink-200';
      default:
        return selected || isSelected ? 'border-gray-500' : 'border-gray-200';
    }
  };

  return (
    <div 
      className={`${getBackgroundColor()} border-2 ${getBorderColor()} rounded-lg shadow-sm min-w-64 transition-colors ${selected || isSelected ? 'ring-2 ring-offset-2 ring-blue-500' : ''}`}
      onClick={handleSelect}
    >
      <div className="p-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-md bg-white/70 flex items-center justify-center">
              {component.icon}
            </div>
            <div>
              <div className="font-medium text-sm">{component.name}</div>
              <div className="text-xs text-muted-foreground truncate max-w-32">
                {component.type} - {component.id.split('-')[1] || 'root'}
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-1">
            <button 
              className="p-1 rounded hover:bg-white/50 text-gray-500"
              onClick={handleDuplicate}
              aria-label="Duplicate component"
            >
              <Copy size={14} />
            </button>
            <button 
              className="p-1 rounded hover:bg-white/50 text-gray-500"
              onClick={handleDelete}
              aria-label="Delete component"
            >
              <Trash2 size={14} />
            </button>
          </div>
        </div>
        
        {isContainer && component.children && component.children.length > 0 && (
          <div className="mt-2 text-xs text-gray-500 flex items-center">
            <ChevronDown size={14} className="mr-1" />
            {component.children.length} child component{component.children.length !== 1 ? 's' : ''}
          </div>
        )}
      </div>
      
      {component.isDroppable && (
        <Handle
          type="target"
          position={Position.Top}
          className="w-10 h-2 rounded-none rounded-t-sm !bg-gray-400 border-0 opacity-50"
        />
      )}
      
      <Handle
        type="source"
        position={Position.Bottom}
        className="w-10 h-2 rounded-none rounded-b-sm !bg-gray-400 border-0 opacity-50"
      />
    </div>
  );
};

export default memo(ComponentNode);
