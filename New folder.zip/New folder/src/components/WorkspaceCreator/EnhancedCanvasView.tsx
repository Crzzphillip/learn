import React, { useState, useEffect } from 'react';
import { CanvasComponent } from '@/services/canvasService';
import { Button } from '@/components/ui/button';
import { 
  Grid,
  MoveHorizontal,
  ZoomIn, 
  ZoomOut, 
  Undo, 
  Redo, 
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Laptop,
  Smartphone,
  Tablet,
  Copy,
  Trash2,
  Move,
  MousePointer,
  Plus,
  Minus
} from 'lucide-react';
import { LibraryComponent } from '@/services/componentLibraryService';
import { getDefaultIconForComponent } from '@/services/websiteComponentsService';
import { cn } from '@/lib/utils';

// Add new interface for breakpoints
type Breakpoint = 'desktop' | 'tablet' | 'mobile';

interface EnhancedCanvasViewProps {
  components: CanvasComponent[];
  selectedComponentId: string | null;
  gridEnabled: boolean;
  snapToGrid: boolean;
  gridSize: number;
  viewportZoom: number;
  onSelectComponent: (componentId: string | null) => void;
  onUpdateComponent: (componentId: string, position: { x: number; y: number }) => void;
  onDuplicateComponent: (componentId: string) => void;
  onDeleteComponent: (componentId: string) => void;
  onDropComponent: (component: LibraryComponent, position: { x: number; y: number }) => void;
  onToggleGrid: () => void;
  onToggleSnapToGrid: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
}

const EnhancedCanvasView: React.FC<EnhancedCanvasViewProps> = ({
  components,
  selectedComponentId,
  gridEnabled,
  snapToGrid,
  gridSize,
  viewportZoom,
  onSelectComponent,
  onUpdateComponent,
  onDuplicateComponent,
  onDeleteComponent,
  onDropComponent,
  onToggleGrid,
  onToggleSnapToGrid,
  onUndo,
  onRedo,
  onZoomIn,
  onZoomOut
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [activeBreakpoint, setActiveBreakpoint] = useState<Breakpoint>('desktop');
  const [showGuides, setShowGuides] = useState(false);
  const [guides, setGuides] = useState<{ x: number[]; y: number[] }>({ x: [], y: [] });
  
  // Function to handle drag start
  const handleDragStart = (e: React.MouseEvent, componentId: string) => {
    e.stopPropagation();
    
    const component = components.find(c => c.id === componentId);
    if (!component || !component.position) return;
    
    const rect = (e.target as HTMLElement).getBoundingClientRect();
    const offsetX = e.clientX - rect.left;
    const offsetY = e.clientY - rect.top;
    
    setDragOffset({ x: offsetX, y: offsetY });
    setIsDragging(true);
    setShowGuides(true);
    
    document.addEventListener('mousemove', handleDragMove);
    document.addEventListener('mouseup', () => handleDragEnd(componentId));
    
    onSelectComponent(componentId);
  };
  
  // Function to calculate alignment guides
  const calculateGuides = (currentId: string, position: { x: number; y: number }) => {
    const newGuides = { x: [] as number[], y: [] as number[] };
    
    components.forEach(comp => {
      if (comp.id === currentId || !comp.position) return;
      
      // Add guides for left, center, and right alignment
      newGuides.x.push(comp.position.x);
      newGuides.x.push(comp.position.x + 100); // Assuming component width
      
      // Add guides for top, middle, and bottom alignment
      newGuides.y.push(comp.position.y);
      newGuides.y.push(comp.position.y + 40); // Assuming component height
    });
    
    setGuides(newGuides);
  };
  
  // Function to handle drag movement
  const handleDragMove = (e: MouseEvent) => {
    if (!isDragging || !selectedComponentId) return;
    
    const component = components.find(c => c.id === selectedComponentId);
    if (!component) return;
    
    const canvasElement = document.getElementById('canvas-area');
    if (!canvasElement) return;
    
    const canvasRect = canvasElement.getBoundingClientRect();
    
    let newX = (e.clientX - canvasRect.left - dragOffset.x) / viewportZoom;
    let newY = (e.clientY - canvasRect.top - dragOffset.y) / viewportZoom;
    
    // Snap to grid if enabled
    if (snapToGrid) {
      newX = Math.round(newX / gridSize) * gridSize;
      newY = Math.round(newY / gridSize) * gridSize;
    }
    
    calculateGuides(selectedComponentId, { x: newX, y: newY });
    onUpdateComponent(selectedComponentId, { x: newX, y: newY });
  };
  
  // Function to handle drag end
  const handleDragEnd = (componentId: string) => {
    setIsDragging(false);
    setShowGuides(false);
    document.removeEventListener('mousemove', handleDragMove);
  };
  
  // Function to handle click on canvas area (deselect)
  const handleCanvasClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onSelectComponent(null);
    }
  };

  // Get canvas width based on breakpoint
  const getCanvasWidth = () => {
    switch (activeBreakpoint) {
      case 'mobile': return 375;
      case 'tablet': return 768;
      case 'desktop': return 1440;
    }
  };
  
  // Render the canvas components
  const renderComponents = () => {
    return components.map(component => {
      const position = component.position || { x: 0, y: 0 };
      const isSelected = component.id === selectedComponentId;
      
      return (
        <div
          key={component.id}
          className={cn(
            'absolute rounded-md transition-all duration-150',
            'backdrop-blur-[1px]',
            isSelected ? 'ring-2 ring-purple-500 shadow-lg' : 'hover:ring-1 hover:ring-purple-400',
            isDragging && isSelected ? 'opacity-70' : 'opacity-100'
          )}
          style={{
            left: `${position.x}px`,
            top: `${position.y}px`,
            transform: `scale(${viewportZoom})`,
            transformOrigin: 'top left',
            backgroundColor: 'rgba(18, 18, 18, 0.8)',
            padding: '8px',
            cursor: isDragging ? 'grabbing' : 'grab',
            border: '1px solid rgba(51, 51, 51, 0.8)',
            minWidth: '100px',
            minHeight: '40px',
          }}
          onMouseDown={(e) => handleDragStart(e, component.id)}
          onClick={(e) => {
            e.stopPropagation();
            onSelectComponent(component.id);
          }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs text-gray-300 font-medium">
              {getDefaultIconForComponent(component.type)}
              <span>{component.name}</span>
            </div>
            
            {isSelected && (
              <div className="flex items-center gap-1">
                <button 
                  className="p-1 text-gray-400 hover:text-purple-400 transition-colors"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDuplicateComponent(component.id);
                  }}
                >
                  <Copy size={14} />
                </button>
                <button 
                  className="p-1 text-gray-400 hover:text-red-400 transition-colors"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteComponent(component.id);
                  }}
                >
                  <Trash2 size={14} />
                </button>
              </div>
            )}
          </div>
          
          <div className="text-xs text-gray-400 mt-1">
            {component.content || component.type}
          </div>
        </div>
      );
    });
  };
  
  // Render alignment guides
  const renderGuides = () => {
    if (!showGuides) return null;
    
    return (
      <>
        {guides.x.map((x, i) => (
          <div
            key={`x-${i}`}
            className="absolute w-px bg-purple-500/50"
            style={{
              left: `${x * viewportZoom}px`,
              top: 0,
              height: '100%',
              pointerEvents: 'none'
            }}
          />
        ))}
        {guides.y.map((y, i) => (
          <div
            key={`y-${i}`}
            className="absolute h-px bg-purple-500/50"
            style={{
              top: `${y * viewportZoom}px`,
              left: 0,
              width: '100%',
              pointerEvents: 'none'
            }}
          />
        ))}
      </>
    );
  };
  
  // Render the grid
  const renderGrid = () => {
    if (!gridEnabled) return null;
    
    const dots = [];
    const canvasWidth = getCanvasWidth();
    const canvasHeight = 2000;
    const gridSizeScaled = gridSize * viewportZoom;
    
    for (let x = 0; x < canvasWidth / gridSize; x++) {
      for (let y = 0; y < canvasHeight / gridSize; y++) {
        dots.push(
          <div
            key={`${x}-${y}`}
            className="absolute rounded-full bg-purple-500/10"
            style={{
              width: '2px',
              height: '2px',
              left: `${x * gridSizeScaled}px`,
              top: `${y * gridSizeScaled}px`,
            }}
          />
        );
      }
    }
    
    return dots;
  };
  
  return (
    <div className="h-full flex flex-col relative bg-[#121212]">
      {/* Top Toolbar */}
      <div className="absolute top-3 left-1/2 -translate-x-1/2 z-10 bg-[#252525] rounded-md shadow-lg border border-[#333] flex items-center p-1 gap-1">
        <Button 
          variant="ghost" 
          size="sm" 
          className={cn(
            "h-8 w-8 p-0",
            activeBreakpoint === 'desktop' && "bg-purple-500/20 text-purple-400"
          )}
          onClick={() => setActiveBreakpoint('desktop')}
        >
          <Laptop className="h-4 w-4" />
        </Button>
        <Button 
          variant="ghost" 
          size="sm" 
          className={cn(
            "h-8 w-8 p-0",
            activeBreakpoint === 'tablet' && "bg-purple-500/20 text-purple-400"
          )}
          onClick={() => setActiveBreakpoint('tablet')}
        >
          <Tablet className="h-4 w-4" />
        </Button>
        <Button 
          variant="ghost" 
          size="sm" 
          className={cn(
            "h-8 w-8 p-0",
            activeBreakpoint === 'mobile' && "bg-purple-500/20 text-purple-400"
          )}
          onClick={() => setActiveBreakpoint('mobile')}
        >
          <Smartphone className="h-4 w-4" />
        </Button>
        
        <div className="h-5 w-px bg-[#333] mx-1" />
        
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-8 w-8 p-0" 
          onClick={onUndo}
        >
          <Undo className="h-4 w-4 text-gray-400" />
        </Button>
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-8 w-8 p-0" 
          onClick={onRedo}
        >
          <Redo className="h-4 w-4 text-gray-400" />
        </Button>
        
        <div className="h-5 w-px bg-[#333] mx-1" />
        
        <Button 
          variant="ghost" 
          size="sm" 
          className={cn(
            "h-8 w-8 p-0",
            gridEnabled && "bg-purple-500/20 text-purple-400"
          )}
          onClick={onToggleGrid}
        >
          <Grid className="h-4 w-4" />
        </Button>
        <Button 
          variant="ghost" 
          size="sm" 
          className={cn(
            "h-8 w-8 p-0",
            snapToGrid && "bg-purple-500/20 text-purple-400"
          )}
          onClick={onToggleSnapToGrid}
        >
          <MoveHorizontal className="h-4 w-4" />
        </Button>
      </div>
      
      {/* Left Toolbar */}
      <div className="absolute left-3 top-1/2 -translate-y-1/2 z-10 bg-[#252525] rounded-md shadow-lg border border-[#333] flex flex-col p-1 gap-1">
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-8 w-8 p-0"
        >
          <MousePointer className="h-4 w-4 text-gray-400" />
        </Button>
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-8 w-8 p-0"
        >
          <Move className="h-4 w-4 text-gray-400" />
        </Button>
        
        <div className="h-px w-full bg-[#333] my-1" />
        
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-8 w-8 p-0" 
          onClick={onZoomIn}
        >
          <Plus className="h-4 w-4 text-gray-400" />
        </Button>
        <div className="text-xs font-medium text-center text-gray-400 py-1">
          {Math.round(viewportZoom * 100)}%
        </div>
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-8 w-8 p-0" 
          onClick={onZoomOut}
        >
          <Minus className="h-4 w-4 text-gray-400" />
        </Button>
      </div>
      
      {/* Canvas Area */}
      <div
        id="canvas-area"
        className="flex-1 relative overflow-auto"
        onClick={handleCanvasClick}
        style={{
          width: `${getCanvasWidth() * viewportZoom}px`,
          margin: '0 auto',
          backgroundColor: '#121212',
          backgroundImage: gridEnabled ? 'none' : undefined
        }}
      >
        {renderGrid()}
        {renderGuides()}
        {renderComponents()}
      </div>
    </div>
  );
};

export default EnhancedCanvasView;
