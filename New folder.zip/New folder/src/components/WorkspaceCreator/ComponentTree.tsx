
import React, { useState } from 'react';
import { WebsiteComponent } from '@/services/websiteComponentsService';
import { cn } from '@/lib/utils';
import { ChevronRight, ChevronDown, Plus, Eye, EyeOff, Trash2, Copy, Search, Move } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

interface ComponentTreeProps {
  components: WebsiteComponent[];
  selectedComponentId: string | null;
  onSelectComponent: (component: WebsiteComponent) => void;
  onDeleteComponent: (id: string) => void;
  onDuplicateComponent: (id: string) => void;
  onToggleVisibility?: (id: string) => void;
  onAddChildComponent?: (parentId: string) => void;
}

const ComponentTree: React.FC<ComponentTreeProps> = ({
  components,
  selectedComponentId,
  onSelectComponent,
  onDeleteComponent,
  onDuplicateComponent,
  onToggleVisibility,
  onAddChildComponent
}) => {
  const [expandedNodes, setExpandedNodes] = useState<Record<string, boolean>>({});
  const [searchQuery, setSearchQuery] = useState('');
  
  const toggleExpand = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedNodes(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };
  
  const renderComponentTree = (component: WebsiteComponent, depth = 0) => {
    const isExpanded = expandedNodes[component.id] !== false; // Default to expanded
    const isSelected = component.id === selectedComponentId;
    const hasChildren = component.children && component.children.length > 0;
    
    // Filter by search query if one exists
    if (searchQuery) {
      const matchesSearch = 
        component.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        component.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        component.type.toLowerCase().includes(searchQuery.toLowerCase());
      
      if (!matchesSearch) {
        // Check if any children match
        const childrenMatch = hasChildren && component.children!.some(child => {
          const childMatchesSearch = 
            child.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            child.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
            child.type.toLowerCase().includes(searchQuery.toLowerCase());
          
          return childMatchesSearch;
        });
        
        if (!childrenMatch) {
          return null;
        }
      }
    }
    
    return (
      <div key={component.id} className="relative">
        <div 
          className={cn(
            "flex items-center px-2 py-1.5 rounded hover:bg-[#333] cursor-pointer group",
            isSelected ? "bg-purple-500/20" : ""
          )}
          style={{ paddingLeft: `${depth * 12 + 8}px` }}
        >
          {hasChildren ? (
            <button 
              onClick={(e) => toggleExpand(component.id, e)}
              className="w-5 h-5 flex items-center justify-center text-gray-400 hover:text-gray-200"
            >
              {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            </button>
          ) : (
            <div className="w-5"></div>
          )}
          
          <div 
            className={cn(
              "flex-1 flex items-center gap-1.5 ml-1 text-xs",
              isSelected ? "text-purple-400" : "text-gray-300"
            )}
            onClick={() => onSelectComponent(component)}
          >
            {component.icon}
            <span>{component.name}</span>
            <span className="text-gray-500 text-[10px]">({component.type})</span>
          </div>
          
          <div className="opacity-0 group-hover:opacity-100 flex items-center">
            {component.isDroppable && onAddChildComponent && (
              <button 
                className="p-1 text-gray-400 hover:text-gray-200"
                onClick={(e) => {
                  e.stopPropagation();
                  onAddChildComponent(component.id);
                }}
                title="Add child component"
              >
                <Plus size={12} />
              </button>
            )}
            <button 
              className="p-1 text-gray-400 hover:text-gray-200"
              onClick={(e) => {
                e.stopPropagation();
                onDuplicateComponent(component.id);
              }}
              title="Duplicate"
            >
              <Copy size={12} />
            </button>
            {onToggleVisibility && (
              <button 
                className="p-1 text-gray-400 hover:text-gray-200"
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleVisibility(component.id);
                }}
                title="Toggle visibility"
              >
                <Eye size={12} />
              </button>
            )}
            <button 
              className="p-1 text-gray-400 hover:text-gray-200"
              onClick={(e) => {
                e.stopPropagation();
                onDeleteComponent(component.id);
              }}
              title="Delete"
            >
              <Trash2 size={12} />
            </button>
          </div>
        </div>
        
        {hasChildren && (
          <Collapsible open={isExpanded}>
            <CollapsibleContent>
              <div className="ml-4 border-l border-[#444] pl-2">
                {component.children!.map(child => renderComponentTree(child, depth + 1))}
              </div>
            </CollapsibleContent>
          </Collapsible>
        )}
      </div>
    );
  };
  
  return (
    <div className="flex flex-col h-full">
      <div className="relative mb-3">
        <Input 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-8 py-1.5 h-8 bg-[#333] border-[#444] text-sm rounded-md" 
          placeholder="Search components..."
        />
        <div className="absolute left-2.5 top-2">
          <Search className="h-4 w-4 text-gray-400" />
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        {components.map(component => renderComponentTree(component))}
      </div>
      
      <div className="mt-3 border-t border-[#444] pt-3">
        <Button variant="ghost" size="sm" className="w-full justify-start text-xs">
          <Plus className="h-3.5 w-3.5 mr-1.5" />
          Add Root Component
        </Button>
      </div>
    </div>
  );
};

export default ComponentTree;
