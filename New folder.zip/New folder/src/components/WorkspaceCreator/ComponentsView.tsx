
import { Button } from "@/components/ui/button";
import { ArrowRight, Bot, PlusCircle, Radio, Wand2 } from "lucide-react";
import { toast } from "sonner";
import { WorkspaceComponent } from "@/types/workspace";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { getCompatibleComponents } from "./workspaceCreatorUtils";
import { useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";

interface ComponentsViewProps {
  activeComponents: WorkspaceComponent[];
  edges: any[];
  setNodes: (updater: any) => void;
  setEdges: (updater: any) => void;
  setActiveComponents: (updater: any) => void;
  connectComponents: (sourceId: string, targetId: string) => void;
}

const ComponentsView = ({ 
  activeComponents, 
  edges, 
  setNodes, 
  setEdges, 
  setActiveComponents,
  connectComponents
}: ComponentsViewProps) => {
  const [selectedComponent, setSelectedComponent] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>("components");
  
  // Get suggested connections for the selected component
  const suggestedConnections = selectedComponent 
    ? getCompatibleComponents(selectedComponent) 
    : [];
    
  // Filter suggested connections to only show components that are in the workspace
  // but not already connected to the selected component
  const availableSuggestions = suggestedConnections.filter(suggestion => {
    // Check if this suggested component is in the workspace
    const isInWorkspace = activeComponents.some(comp => comp.id === suggestion.id);
    
    // Check if there's already a connection between these components
    const isAlreadyConnected = edges.some(edge => 
      (edge.source === selectedComponent && edge.target === suggestion.id) ||
      (edge.target === selectedComponent && edge.source === suggestion.id)
    );
    
    return isInWorkspace && !isAlreadyConnected && suggestion.id !== selectedComponent;
  });
  
  // Auto-connect components based on their compatibility
  const suggestConnections = () => {
    if (activeComponents.length < 2) {
      toast.error("Need at least two components", {
        description: "Add more components to create automatic connections."
      });
      return;
    }
    
    let newConnectionsAdded = 0;
    
    // Check each component against others for compatibility
    activeComponents.forEach(source => {
      const compatibleTargets = getCompatibleComponents(source.id);
      
      // Filter compatible targets to only those in the workspace
      const availableTargets = compatibleTargets.filter(target => 
        activeComponents.some(comp => comp.id === target.id)
      );
      
      // For each compatible target, check if there's already a connection
      availableTargets.forEach(target => {
        const isAlreadyConnected = edges.some(edge => 
          (edge.source === source.id && edge.target === target.id) ||
          (edge.target === source.id && edge.source === target.id)
        );
        
        // If no connection exists, add one
        if (!isAlreadyConnected && source.id !== target.id) {
          connectComponents(source.id, target.id);
          newConnectionsAdded++;
        }
      });
    });
    
    if (newConnectionsAdded > 0) {
      toast.success(`Added ${newConnectionsAdded} connections`, {
        description: "Components have been connected based on compatibility."
      });
    } else {
      toast.info("No new connections to add", {
        description: "All compatible components are already connected."
      });
    }
  };
  
  return (
    <div className="border rounded-lg h-full flex flex-col">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <div className="border-b px-6">
          <TabsList className="mt-2">
            <TabsTrigger value="components">Components</TabsTrigger>
            <TabsTrigger value="connections">Connections</TabsTrigger>
            {selectedComponent && (
              <TabsTrigger value="configure">Configure</TabsTrigger>
            )}
          </TabsList>
        </div>
        
        <TabsContent value="components" className="flex-1 m-0 overflow-hidden flex flex-col">
          <div className="p-4 flex justify-between items-center border-b">
            <h3 className="text-xl font-medium">Selected Components</h3>
            {activeComponents.length > 1 && (
              <Button 
                variant="outline" 
                size="sm" 
                className="gap-1"
                onClick={suggestConnections}
              >
                <Wand2 className="w-4 h-4" />
                Auto-connect
              </Button>
            )}
          </div>
          
          <ScrollArea className="flex-1">
            {activeComponents.length > 0 ? (
              <div className="p-4 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {activeComponents.map((component) => (
                    <div 
                      key={component.id} 
                      className={`p-4 rounded-lg border transition-all
                        ${selectedComponent === component.id 
                          ? 'border-primary ring-2 ring-primary/20' 
                          : 'hover:border-primary/50'
                        }`}
                      onClick={() => setSelectedComponent(component.id)}
                    >
                      <div className="flex items-center gap-3 mb-3">
                        <div className={`w-10 h-10 rounded-md grid place-items-center 
                          ${component.type === 'agent' 
                            ? 'bg-purple-500/10' 
                            : component.type === 'workflow' 
                              ? 'bg-blue-500/10' 
                              : component.type === 'app'
                                ? 'bg-green-500/10'
                                : component.type === 'integration'
                                  ? 'bg-orange-500/10'
                                  : component.type === 'template'
                                    ? 'bg-pink-500/10'
                                    : 'bg-teal-500/10'
                          }`}
                        >
                          {component.icon}
                        </div>
                        <div>
                          <div className="font-medium">{component.name}</div>
                          <div className="text-xs text-muted-foreground flex items-center gap-1">
                            <Badge variant="outline" className="text-xs px-1.5 py-0">
                              {component.type}
                            </Badge>
                            {component.category && (
                              <Badge variant="secondary" className="text-xs px-1.5 py-0">
                                {component.category}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                        {component.description}
                      </p>
                      
                      <div className="grid grid-cols-2 gap-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full text-xs"
                          onClick={(e) => {
                            e.stopPropagation();
                            setNodes((nds: any[]) => nds.filter(node => node.id !== component.id));
                            setEdges((eds: any[]) => eds.filter(edge => edge.source !== component.id && edge.target !== component.id));
                            setActiveComponents((comps: WorkspaceComponent[]) => comps.filter(c => c.id !== component.id));
                            if (selectedComponent === component.id) {
                              setSelectedComponent(null);
                            }
                          }}
                        >
                          Remove
                        </Button>
                        
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full text-xs"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (activeComponents.length > 1) {
                              setSelectedComponent(component.id);
                              setActiveTab("connections");
                            } else {
                              toast.error("No Other Components", {
                                description: "Add at least one more component to make connections."
                              });
                            }
                          }}
                        >
                          Connect
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center p-12">
                <Bot className="w-16 h-16 mx-auto mb-4 opacity-20" />
                <h4 className="text-lg font-medium mb-2">No Components Selected</h4>
                <p className="text-muted-foreground max-w-md mx-auto">
                  Add components from the Canvas tab to start building your workspace.
                </p>
              </div>
            )}
          </ScrollArea>
        </TabsContent>
        
        <TabsContent value="connections" className="flex-1 m-0 overflow-hidden flex flex-col">
          <div className="p-4 border-b">
            <h3 className="text-xl font-medium mb-1">Connections</h3>
            <p className="text-sm text-muted-foreground">
              Link components together to create workflows and enable communication between them.
            </p>
          </div>
          
          <ScrollArea className="flex-1">
            <div className="p-4 space-y-4">
              {selectedComponent ? (
                <div className="space-y-4">
                  <div className="p-4 bg-muted/50 rounded-lg border">
                    <h4 className="font-medium mb-2">Selected Component</h4>
                    {activeComponents.map(component => {
                      if (component.id === selectedComponent) {
                        return (
                          <div key={component.id} className="flex items-center gap-2">
                            <div className={`w-8 h-8 rounded-md grid place-items-center 
                              ${component.type === 'agent' 
                                ? 'bg-purple-500/10' 
                                : component.type === 'workflow' 
                                  ? 'bg-blue-500/10' 
                                  : component.type === 'app'
                                    ? 'bg-green-500/10'
                                    : component.type === 'integration'
                                      ? 'bg-orange-500/10'
                                      : component.type === 'template'
                                        ? 'bg-pink-500/10'
                                        : 'bg-teal-500/10'
                              }`}
                            >
                              {component.icon}
                            </div>
                            <div>
                              <div className="font-medium">{component.name}</div>
                              <div className="text-xs text-muted-foreground">{component.type}</div>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    })}
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium">Recommended Connections</h4>
                    {availableSuggestions.length > 0 ? (
                      <div className="space-y-2">
                        {availableSuggestions.map((suggestion) => (
                          <div key={suggestion.id} className="flex items-center justify-between p-3 bg-card rounded-lg border">
                            <div className="flex items-center gap-2">
                              <div className={`w-8 h-8 rounded-md grid place-items-center 
                                ${suggestion.type === 'agent' 
                                  ? 'bg-purple-500/10' 
                                  : suggestion.type === 'workflow' 
                                    ? 'bg-blue-500/10' 
                                    : suggestion.type === 'app'
                                      ? 'bg-green-500/10'
                                      : suggestion.type === 'integration'
                                        ? 'bg-orange-500/10'
                                        : suggestion.type === 'template'
                                          ? 'bg-pink-500/10'
                                          : 'bg-teal-500/10'
                                }`}
                              >
                                {suggestion.icon}
                              </div>
                              <div>
                                <div className="font-medium">{suggestion.name}</div>
                                <div className="text-xs text-muted-foreground">{suggestion.type}</div>
                              </div>
                            </div>
                            <Button
                              size="sm"
                              onClick={() => {
                                connectComponents(selectedComponent, suggestion.id);
                                toast.success("Components Connected", {
                                  description: `Connected ${activeComponents.find(c => c.id === selectedComponent)?.name} to ${suggestion.name}`
                                });
                              }}
                            >
                              Connect
                            </Button>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="p-4 bg-muted/50 rounded-lg border text-center">
                        <p className="text-sm text-muted-foreground">
                          No recommended connections available for this component.
                        </p>
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium">Other Components</h4>
                    <div className="space-y-2">
                      {activeComponents
                        .filter(comp => 
                          comp.id !== selectedComponent && 
                          !edges.some(edge => 
                            (edge.source === selectedComponent && edge.target === comp.id) ||
                            (edge.target === selectedComponent && edge.source === comp.id)
                          )
                        )
                        .map((comp) => (
                          <div key={comp.id} className="flex items-center justify-between p-3 bg-card rounded-lg border">
                            <div className="flex items-center gap-2">
                              <div className={`w-8 h-8 rounded-md grid place-items-center 
                                ${comp.type === 'agent' 
                                  ? 'bg-purple-500/10' 
                                  : comp.type === 'workflow' 
                                    ? 'bg-blue-500/10' 
                                    : comp.type === 'app'
                                      ? 'bg-green-500/10'
                                      : comp.type === 'integration'
                                        ? 'bg-orange-500/10'
                                        : comp.type === 'template'
                                          ? 'bg-pink-500/10'
                                          : 'bg-teal-500/10'
                                }`}
                              >
                                {comp.icon}
                              </div>
                              <div>
                                <div className="font-medium">{comp.name}</div>
                                <div className="text-xs text-muted-foreground">{comp.type}</div>
                              </div>
                            </div>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                connectComponents(selectedComponent, comp.id);
                                toast.success("Components Connected", {
                                  description: `Connected ${activeComponents.find(c => c.id === selectedComponent)?.name} to ${comp.name}`
                                });
                              }}
                            >
                              Connect
                            </Button>
                          </div>
                        ))}
                    </div>
                  </div>
                </div>
              ) : (
                <>
                  {edges.length > 0 ? (
                    <div className="space-y-2">
                      {edges.map((edge) => {
                        const sourceComponent = activeComponents.find(c => c.id === edge.source);
                        const targetComponent = activeComponents.find(c => c.id === edge.target);
                        
                        return (
                          <div key={edge.id} className="flex items-center justify-between p-3 bg-card rounded-md border">
                            <div className="flex items-center gap-2">
                              <div className="flex items-center">
                                <span className="font-medium text-sm">{sourceComponent?.name}</span>
                                <ArrowRight className="w-4 h-4 mx-2" />
                                <span className="font-medium text-sm">{targetComponent?.name}</span>
                              </div>
                            </div>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => {
                                setEdges((eds: any[]) => eds.filter(e => e.id !== edge.id));
                                toast.info("Connection Removed", {
                                  description: `Removed connection between ${sourceComponent?.name} and ${targetComponent?.name}`
                                });
                              }}
                            >
                              Remove
                            </Button>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center p-8">
                      <Radio className="w-12 h-12 mx-auto mb-4 opacity-20" />
                      <h4 className="text-lg font-medium mb-2">No Connections Yet</h4>
                      <p className="text-muted-foreground max-w-md mx-auto mb-4">
                        Select a component and connect it to others to create workflows.
                      </p>
                      {activeComponents.length > 1 && (
                        <Button
                          onClick={suggestConnections}
                          className="gap-1"
                        >
                          <Wand2 className="w-4 h-4" />
                          Auto-connect Components
                        </Button>
                      )}
                    </div>
                  )}
                </>
              )}
            </div>
          </ScrollArea>
        </TabsContent>
        
        {selectedComponent && (
          <TabsContent value="configure" className="flex-1 m-0 overflow-hidden flex flex-col">
            <div className="p-4 border-b">
              <h3 className="text-xl font-medium mb-1">Configure Component</h3>
              <p className="text-sm text-muted-foreground">
                Customize settings and properties for this component.
              </p>
            </div>
            
            <ScrollArea className="flex-1">
              <div className="p-4">
                {activeComponents.map(component => {
                  if (component.id === selectedComponent) {
                    return (
                      <div key={component.id} className="space-y-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-12 h-12 rounded-md grid place-items-center 
                            ${component.type === 'agent' 
                              ? 'bg-purple-500/10' 
                              : component.type === 'workflow' 
                                ? 'bg-blue-500/10' 
                                : component.type === 'app'
                                  ? 'bg-green-500/10'
                                  : component.type === 'integration'
                                    ? 'bg-orange-500/10'
                                    : component.type === 'template'
                                      ? 'bg-pink-500/10'
                                      : 'bg-teal-500/10'
                            }`}
                          >
                            {component.icon}
                          </div>
                          <div>
                            <div className="font-medium text-lg">{component.name}</div>
                            <div className="text-sm text-muted-foreground">{component.type}</div>
                          </div>
                        </div>
                        
                        <p className="text-muted-foreground">
                          {component.description}
                        </p>
                        
                        <div className="p-4 rounded-lg border bg-muted/50">
                          <h4 className="font-medium mb-2">Configuration Options</h4>
                          <p className="text-sm text-muted-foreground mb-4">
                            Component configuration will be available in a future update.
                          </p>
                          <Button disabled variant="outline" className="gap-1">
                            <PlusCircle className="w-4 h-4" />
                            Add Configuration
                          </Button>
                        </div>
                      </div>
                    );
                  }
                  return null;
                })}
              </div>
            </ScrollArea>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
};

export default ComponentsView;
