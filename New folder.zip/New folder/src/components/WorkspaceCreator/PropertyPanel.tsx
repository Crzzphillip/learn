import React, { useState, useEffect } from 'react';
import { WebsiteComponent } from '@/services/websiteComponentsService';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ColorPicker } from '@/components/ui/color-picker';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { 
  Bold, 
  Italic, 
  Underline, 
  AlignLeft, 
  AlignCenter, 
  AlignRight, 
  AlignJustify,
  Type,
  Box,
  Paintbrush,
  Palette
} from 'lucide-react';

interface PropertyPanelProps {
  selectedComponent: WebsiteComponent | null;
  onUpdateComponent: (updatedComponent: WebsiteComponent) => void;
}

const PropertyPanel: React.FC<PropertyPanelProps> = ({
  selectedComponent,
  onUpdateComponent
}) => {
  const [activeTab, setActiveTab] = useState('properties');
  const [localComponent, setLocalComponent] = useState<WebsiteComponent | null>(null);
  
  useEffect(() => {
    setLocalComponent(selectedComponent);
  }, [selectedComponent]);
  
  if (!localComponent) {
    return (
      <div className="p-4 text-center text-muted-foreground">
        <div className="w-12 h-12 rounded-full bg-muted mx-auto flex items-center justify-center mb-2">
          <Box className="h-6 w-6 opacity-50" />
        </div>
        <p>Select a component to edit its properties</p>
      </div>
    );
  }
  
  const handleInputChange = (key: string, value: any, section: 'props' | 'style' | 'content' = 'props') => {
    if (!localComponent) return;
    
    const updatedComponent = { ...localComponent };
    
    if (section === 'content') {
      updatedComponent.content = value;
    } else if (section === 'style') {
      updatedComponent.style = {
        ...(updatedComponent.style || {}),
        [key]: value
      };
    } else if (section === 'props') {
      updatedComponent.props = {
        ...(updatedComponent.props || {}),
        [key]: value
      };
    }
    
    setLocalComponent(updatedComponent);
  };
  
  const handleApplyChanges = () => {
    if (!localComponent) return;
    onUpdateComponent(localComponent);
  };
  
  const renderContentEditor = () => {
    if (!localComponent) return null;
    
    if (localComponent.content !== undefined) {
      return (
        <div className="space-y-3">
          <Label>Text Content</Label>
          <Textarea
            value={localComponent.content || ''}
            onChange={(e) => handleInputChange('content', e.target.value, 'content')}
            rows={4}
            className="w-full"
          />
          
          <div className="flex flex-wrap gap-2 mt-2">
            <Button size="sm" variant="outline" className="h-8 w-8 p-0">
              <Bold className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="outline" className="h-8 w-8 p-0">
              <Italic className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="outline" className="h-8 w-8 p-0">
              <Underline className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="outline" className="h-8 w-8 p-0">
              <AlignLeft className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="outline" className="h-8 w-8 p-0">
              <AlignCenter className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="outline" className="h-8 w-8 p-0">
              <AlignRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      );
    }
    
    return <p className="text-sm text-muted-foreground">This component doesn't have editable text content.</p>;
  };
  
  const renderStyleEditor = () => {
    const style = localComponent?.style || {};
    
    return (
      <div className="space-y-4">
        <div>
          <h3 className="text-sm font-medium mb-2">Dimensions</h3>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Width</Label>
              <Input
                value={style.width || ''}
                onChange={(e) => handleInputChange('width', e.target.value, 'style')}
                className="h-8"
                placeholder="e.g. 100%, 200px"
              />
            </div>
            <div>
              <Label className="text-xs">Height</Label>
              <Input
                value={style.height || ''}
                onChange={(e) => handleInputChange('height', e.target.value, 'style')}
                className="h-8"
                placeholder="e.g. auto, 200px"
              />
            </div>
          </div>
        </div>
        
        <div>
          <h3 className="text-sm font-medium mb-2">Spacing</h3>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Margin</Label>
              <Input
                value={style.margin || ''}
                onChange={(e) => handleInputChange('margin', e.target.value, 'style')}
                className="h-8"
                placeholder="e.g. 10px 20px"
              />
            </div>
            <div>
              <Label className="text-xs">Padding</Label>
              <Input
                value={style.padding || ''}
                onChange={(e) => handleInputChange('padding', e.target.value, 'style')}
                className="h-8"
                placeholder="e.g. 10px 20px"
              />
            </div>
          </div>
        </div>
        
        <div>
          <h3 className="text-sm font-medium mb-2">Typography</h3>
          <div className="space-y-3">
            <div>
              <Label className="text-xs">Font Size</Label>
              <Input
                value={style.fontSize || ''}
                onChange={(e) => handleInputChange('fontSize', e.target.value, 'style')}
                className="h-8"
                placeholder="e.g. 16px, 1.2rem"
              />
            </div>
            <div>
              <Label className="text-xs">Font Weight</Label>
              <Select
                value={(style.fontWeight || 'normal').toString()}
                onValueChange={(value) => handleInputChange('fontWeight', value, 'style')}
              >
                <SelectTrigger className="h-8">
                  <SelectValue placeholder="Select weight" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="bold">Bold</SelectItem>
                  <SelectItem value="400">400</SelectItem>
                  <SelectItem value="500">500</SelectItem>
                  <SelectItem value="600">600</SelectItem>
                  <SelectItem value="700">700</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Text Color</Label>
              <Input
                value={style.color || ''}
                onChange={(e) => handleInputChange('color', e.target.value, 'style')}
                className="h-8"
                placeholder="e.g. #000000, rgba(0,0,0,0.5)"
              />
            </div>
          </div>
        </div>
        
        <div>
          <h3 className="text-sm font-medium mb-2">Background</h3>
          <div className="space-y-3">
            <div>
              <Label className="text-xs">Background Color</Label>
              <Input
                value={style.backgroundColor || ''}
                onChange={(e) => handleInputChange('backgroundColor', e.target.value, 'style')}
                className="h-8"
                placeholder="e.g. #ffffff, transparent"
              />
            </div>
          </div>
        </div>
        
        <div>
          <h3 className="text-sm font-medium mb-2">Border</h3>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Border Width</Label>
              <Input
                value={style.borderWidth || ''}
                onChange={(e) => handleInputChange('borderWidth', e.target.value, 'style')}
                className="h-8"
                placeholder="e.g. 1px"
              />
            </div>
            <div>
              <Label className="text-xs">Border Color</Label>
              <Input
                value={style.borderColor || ''}
                onChange={(e) => handleInputChange('borderColor', e.target.value, 'style')}
                className="h-8"
                placeholder="e.g. #cccccc"
              />
            </div>
            <div>
              <Label className="text-xs">Border Style</Label>
              <Select
                value={style.borderStyle || 'none'}
                onValueChange={(value) => handleInputChange('borderStyle', value, 'style')}
              >
                <SelectTrigger className="h-8">
                  <SelectValue placeholder="Select style" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  <SelectItem value="solid">Solid</SelectItem>
                  <SelectItem value="dashed">Dashed</SelectItem>
                  <SelectItem value="dotted">Dotted</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Border Radius</Label>
              <Input
                value={style.borderRadius || ''}
                onChange={(e) => handleInputChange('borderRadius', e.target.value, 'style')}
                className="h-8"
                placeholder="e.g. 4px"
              />
            </div>
          </div>
        </div>
      </div>
    );
  };
  
  const renderPropertiesEditor = () => {
    const { props } = localComponent;
    
    if (localComponent.type === 'img') {
      return (
        <div className="space-y-3">
          <div>
            <Label>Image Source (URL)</Label>
            <Input
              value={props.src || ''}
              onChange={(e) => handleInputChange('src', e.target.value)}
              placeholder="https://example.com/image.jpg"
            />
          </div>
          <div>
            <Label>Alt Text</Label>
            <Input
              value={props.alt || ''}
              onChange={(e) => handleInputChange('alt', e.target.value)}
              placeholder="Image description"
            />
          </div>
        </div>
      );
    }
    
    if (localComponent.type === 'a') {
      return (
        <div className="space-y-3">
          <div>
            <Label>Link URL</Label>
            <Input
              value={props.href || ''}
              onChange={(e) => handleInputChange('href', e.target.value)}
              placeholder="https://example.com"
            />
          </div>
          <div>
            <Label>Open in new tab</Label>
            <Select
              value={props.target || '_self'}
              onValueChange={(value) => handleInputChange('target', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select option" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="_self">Same window</SelectItem>
                <SelectItem value="_blank">New tab</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      );
    }
    
    return (
      <div className="space-y-4">
        <div>
          <Label>CSS Class</Label>
          <Input
            value={props.className || ''}
            onChange={(e) => handleInputChange('className', e.target.value)}
            placeholder="e.g. text-lg font-bold"
          />
          <p className="mt-1 text-xs text-muted-foreground">
            Enter Tailwind CSS classes separated by spaces
          </p>
        </div>
        
        <div>
          <Label>ID</Label>
          <Input
            value={props.id || ''}
            onChange={(e) => handleInputChange('id', e.target.value)}
            placeholder="element-id"
          />
        </div>
      </div>
    );
  };
  
  return (
    <div className="h-full flex flex-col">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <div className="px-4 py-2 border-b">
          <TabsList className="w-full">
            <TabsTrigger value="properties" className="flex-1">
              <Box className="w-4 h-4 mr-1" />
              Props
            </TabsTrigger>
            <TabsTrigger value="styles" className="flex-1">
              <Paintbrush className="w-4 h-4 mr-1" />
              Styles
            </TabsTrigger>
            <TabsTrigger value="content" className="flex-1">
              <Type className="w-4 h-4 mr-1" />
              Content
            </TabsTrigger>
          </TabsList>
        </div>
        
        <div className="p-4 flex-1 overflow-y-auto">
          <div className="mb-4">
            <h2 className="text-lg font-medium">{localComponent.name}</h2>
            <p className="text-xs text-muted-foreground">{localComponent.type} • {localComponent.id}</p>
          </div>
          
          <TabsContent value="properties" className="m-0">
            {renderPropertiesEditor()}
          </TabsContent>
          
          <TabsContent value="styles" className="m-0">
            {renderStyleEditor()}
          </TabsContent>
          
          <TabsContent value="content" className="m-0">
            {renderContentEditor()}
          </TabsContent>
        </div>
        
        <div className="p-4 border-t">
          <Button 
            className="w-full" 
            onClick={handleApplyChanges}
          >
            Apply Changes
          </Button>
        </div>
      </Tabs>
    </div>
  );
};

export default PropertyPanel;
