
import { MCPServerItem } from '@/data/mcpServerData';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { useState } from 'react';
import { RefreshCw, Server, Power } from 'lucide-react';

interface ServerStatusCardProps {
  server: MCPServerItem;
  onRestart: (id: string) => void;
  onStatusChange: (id: string, status: 'online' | 'offline' | 'maintenance') => void;
}

const ServerStatusCard = ({ server, onRestart, onStatusChange }: ServerStatusCardProps) => {
  const [isRestarting, setIsRestarting] = useState(false);
  
  const handleRestart = () => {
    setIsRestarting(true);
    setTimeout(() => {
      onRestart(server.id);
      setIsRestarting(false);
    }, 2000);
  };
  
  const getStatusColor = (status: string) => {
    switch(status) {
      case 'online': return 'text-green-500';
      case 'offline': return 'text-red-500';
      case 'maintenance': return 'text-yellow-500';
      default: return 'text-gray-500';
    }
  };
  
  const getLoadColor = (load: number) => {
    if (load > 80) return 'bg-red-500';
    if (load > 60) return 'bg-yellow-500';
    return 'bg-green-500';
  };
  
  return (
    <div className="border rounded-lg p-5 bg-card">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary/10 grid place-items-center">
            <Server className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="font-medium">{server.name}</h3>
            <div className="flex items-center gap-2">
              <span className={`inline-block w-2 h-2 rounded-full ${server.status === 'online' ? 'bg-green-500' : server.status === 'maintenance' ? 'bg-yellow-500' : 'bg-red-500'}`}></span>
              <span className={`text-sm ${getStatusColor(server.status)}`}>{server.status}</span>
            </div>
          </div>
        </div>
        <div className="text-sm text-right">
          <div>Region: {server.region}</div>
          <div>Type: {server.type}</div>
        </div>
      </div>
      
      <div className="mb-4">
        <div className="flex items-center justify-between mb-1">
          <span className="text-sm">Load</span>
          <span className="text-sm font-medium">{server.load}%</span>
        </div>
        <Progress value={server.load} className={getLoadColor(server.load)} />
      </div>
      
      <div className="grid grid-cols-2 gap-4 text-sm mb-4">
        <div>
          <span className="text-muted-foreground">Uptime:</span> {server.uptime}
        </div>
        <div>
          <span className="text-muted-foreground">Connections:</span> {server.connections}
        </div>
        <div>
          <span className="text-muted-foreground">IP:</span> {server.ip}
        </div>
        <div>
          <span className="text-muted-foreground">Last Ping:</span> {new Date(server.lastPing).toLocaleTimeString()}
        </div>
      </div>
      
      <div className="flex justify-end gap-2">
        <Button variant="outline" size="sm" className="gap-1" onClick={handleRestart} disabled={isRestarting || server.status === 'offline'}>
          <RefreshCw className="w-4 h-4" />
          {isRestarting ? 'Restarting...' : 'Restart'}
        </Button>
        {server.status !== 'maintenance' ? (
          <Button 
            variant="outline" 
            size="sm" 
            className="gap-1 border-yellow-500 text-yellow-500 hover:bg-yellow-500/10" 
            onClick={() => onStatusChange(server.id, 'maintenance')}
            disabled={server.status === 'offline'}
          >
            <Power className="w-4 h-4" />
            Set Maintenance
          </Button>
        ) : (
          <Button 
            variant="outline" 
            size="sm" 
            className="gap-1 border-green-500 text-green-500 hover:bg-green-500/10" 
            onClick={() => onStatusChange(server.id, 'online')}
          >
            <Power className="w-4 h-4" />
            Set Online
          </Button>
        )}
      </div>
    </div>
  );
};

export default ServerStatusCard;
