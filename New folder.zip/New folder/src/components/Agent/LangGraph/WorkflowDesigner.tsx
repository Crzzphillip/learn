
import { useState, useCallback, useEffect } from "react";
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  Panel,
  useNodesState,
  useEdgesState,
  addEdge,
  NodeTypes,
  Connection,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { Bot, Lightbulb, Database, MessageCircle, Zap, Plus, Cpu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import AgentNode from "@/components/Workflow/nodes/AgentNode";
import ActionNode from "@/components/Workflow/nodes/ActionNode";
import LangGraphNode from "./LangGraphNode";

// Define node types
const nodeTypes: NodeTypes = {
  agent: AgentNode,
  action: ActionNode,
  langGraphNode: LangGraphNode,
};

// Initial nodes for LangGraph workflow
const initialNodes = [
  {
    id: "entry",
    type: "langGraphNode",
    data: { 
      label: "Entry Point", 
      nodeType: "entry",
      icon: <Zap className="h-4 w-4 text-blue-500" />,
      description: "Starting point of the workflow"
    },
    position: { x: 250, y: 50 },
  },
];

// Initial edges
const initialEdges = [];

interface WorkflowDesignerProps {
  workspaceId?: string;
  onSave?: (workflow: any) => void;
}

export default function WorkflowDesigner({ workspaceId, onSave }: WorkflowDesignerProps) {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [isDirty, setIsDirty] = useState(false);

  // Node components available in the LangGraph workflow
  const nodeComponents = [
    {
      id: "llm",
      type: "langGraphNode",
      label: "LLM",
      description: "Large Language Model Node",
      icon: <Bot className="h-4 w-4 text-purple-500" />,
      category: "core",
    },
    {
      id: "tool",
      type: "langGraphNode",
      label: "Tool",
      description: "External tool or function call",
      icon: <Zap className="h-4 w-4 text-orange-500" />,
      category: "core",
    },
    {
      id: "memory",
      type: "langGraphNode",
      label: "Memory",
      description: "State management and memory",
      icon: <Database className="h-4 w-4 text-green-500" />,
      category: "core",
    },
    {
      id: "prompt",
      type: "langGraphNode",
      label: "Prompt",
      description: "Prompt template",
      icon: <MessageCircle className="h-4 w-4 text-blue-500" />,
      category: "core",
    },
    {
      id: "branching",
      type: "langGraphNode",
      label: "Branching",
      description: "Conditional logic branching",
      icon: <Lightbulb className="h-4 w-4 text-yellow-500" />,
      category: "advanced",
    },
    {
      id: "agent",
      type: "langGraphNode",
      label: "Agent",
      description: "Autonomous agent",
      icon: <Cpu className="h-4 w-4 text-indigo-500" />,
      category: "advanced",
    },
  ];

  // Handle connection between nodes
  const onConnect = useCallback(
    (params: Connection) => {
      setEdges((eds) => addEdge(params, eds));
      setIsDirty(true);
    },
    [setEdges]
  );

  // Add a new node to the workflow
  const addNode = (nodeType: any) => {
    const newNode = {
      id: `${nodeType.id}-${Date.now()}`,
      type: nodeType.type,
      data: { 
        label: nodeType.label, 
        nodeType: nodeType.id,
        icon: nodeType.icon,
        description: nodeType.description
      },
      position: {
        x: Math.random() * 300 + 100,
        y: Math.random() * 300 + 100,
      },
    };

    setNodes((nds) => nds.concat(newNode));
    setIsDirty(true);
  };

  // Handle saving the workflow
  const handleSaveWorkflow = () => {
    const workflow = {
      nodes,
      edges,
      metadata: {
        timestamp: new Date().toISOString(),
        workspaceId,
      },
    };

    if (onSave) {
      onSave(workflow);
    }

    toast.success("Workflow saved successfully");
    setIsDirty(false);
  };

  // Handle node selection
  const onNodeClick = (_: any, node: any) => {
    setSelectedNode(node.id);
  };

  return (
    <div className="flex h-full">
      <div className="flex-1 relative">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          onNodeClick={onNodeClick}
          nodeTypes={nodeTypes}
          fitView
          className="bg-grid-pattern"
        >
          <Background />
          <Controls />
          <MiniMap />
          
          <Panel position="top-right" className="bg-background/80 backdrop-blur-sm p-3 rounded-lg shadow-md border">
            <div className="flex gap-2">
              <Button 
                variant="default" 
                size="sm" 
                onClick={handleSaveWorkflow}
                disabled={!isDirty}
              >
                Save Workflow
              </Button>
            </div>
          </Panel>
        </ReactFlow>
      </div>
      
      <div className="w-64 border-l bg-background/95 backdrop-blur-sm flex flex-col h-full overflow-hidden">
        <div className="p-3 border-b">
          <h3 className="font-medium text-sm">LangGraph Components</h3>
        </div>
        
        <ScrollArea className="flex-1">
          <div className="p-3 space-y-4">
            <div>
              <h4 className="text-xs font-medium mb-2 text-muted-foreground">Core Components</h4>
              <div className="space-y-2">
                {nodeComponents
                  .filter(node => node.category === "core")
                  .map((node) => (
                    <Card 
                      key={node.id} 
                      className="cursor-pointer hover:border-primary/50 transition-colors"
                      onClick={() => addNode(node)}
                    >
                      <CardContent className="p-3 flex gap-2 items-center">
                        <div className="w-7 h-7 rounded bg-muted grid place-items-center">
                          {node.icon}
                        </div>
                        <div>
                          <div className="font-medium text-sm">{node.label}</div>
                          <div className="text-xs text-muted-foreground">{node.description}</div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </div>
            
            <div>
              <h4 className="text-xs font-medium mb-2 text-muted-foreground">Advanced Components</h4>
              <div className="space-y-2">
                {nodeComponents
                  .filter(node => node.category === "advanced")
                  .map((node) => (
                    <Card 
                      key={node.id} 
                      className="cursor-pointer hover:border-primary/50 transition-colors"
                      onClick={() => addNode(node)}
                    >
                      <CardContent className="p-3 flex gap-2 items-center">
                        <div className="w-7 h-7 rounded bg-muted grid place-items-center">
                          {node.icon}
                        </div>
                        <div>
                          <div className="font-medium text-sm">{node.label}</div>
                          <div className="text-xs text-muted-foreground">{node.description}</div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </div>
          </div>
        </ScrollArea>
        
        {selectedNode && (
          <div className="p-3 border-t">
            <h3 className="font-medium text-sm mb-2">Node Properties</h3>
            <p className="text-xs text-muted-foreground">
              Select a node to view and edit its properties.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
