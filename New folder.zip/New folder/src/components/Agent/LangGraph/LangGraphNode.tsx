
import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';

interface LangGraphNodeProps {
  data: {
    label: string;
    nodeType: string;
    icon: React.ReactNode;
    description?: string;
  };
}

const LangGraphNode = ({ data }: LangGraphNodeProps) => {
  // Determine if this node should have input/output handles based on node type
  const showInputHandle = data.nodeType !== 'entry';
  const showOutputHandle = data.nodeType !== 'output';

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 min-w-[200px]">
      {showInputHandle && <Handle type="target" position={Position.Top} />}
      
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg grid place-items-center" 
          style={{ 
            backgroundColor: getNodeColor(data.nodeType),
          }}
        >
          {data.icon}
        </div>
        <div>
          <h3 className="font-medium">{data.label}</h3>
          <p className="text-xs text-muted-foreground">{data.description || data.nodeType}</p>
        </div>
      </div>
      
      {showOutputHandle && <Handle type="source" position={Position.Bottom} />}
    </div>
  );
};

// Helper function to determine node background color based on node type
function getNodeColor(nodeType: string): string {
  switch (nodeType) {
    case 'llm':
      return 'rgba(168, 85, 247, 0.1)'; // purple
    case 'tool':
      return 'rgba(249, 115, 22, 0.1)'; // orange
    case 'memory':
      return 'rgba(34, 197, 94, 0.1)'; // green
    case 'prompt':
      return 'rgba(59, 130, 246, 0.1)'; // blue
    case 'branching':
      return 'rgba(234, 179, 8, 0.1)'; // yellow
    case 'agent':
      return 'rgba(99, 102, 241, 0.1)'; // indigo
    case 'entry':
      return 'rgba(6, 182, 212, 0.1)'; // cyan
    case 'output':
      return 'rgba(239, 68, 68, 0.1)'; // red
    default:
      return 'rgba(107, 114, 128, 0.1)'; // gray
  }
}

export default memo(LangGraphNode);
