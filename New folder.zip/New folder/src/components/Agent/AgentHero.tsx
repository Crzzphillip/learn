
import { Brain, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import type { AgentDetails } from "@/types/agent";

interface AgentHeroProps {
  agent: AgentDetails;
  spaceId: string;
  agentId: string;
}

const AgentHero = ({ agent, spaceId, agentId }: AgentHeroProps) => {
  const navigate = useNavigate();

  return (
    <div className="relative h-[400px]">
      <img 
        src="/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png" 
        alt={agent.title}
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-background/80 to-background" />
      
      <div className="absolute bottom-0 left-0 right-0">
        <div className="container py-8">
          <div className="flex items-start gap-6">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/10 grid place-items-center backdrop-blur-xl">
              <Brain className="w-10 h-10" />
            </div>
            <div className="flex-1">
              <h1 className="text-4xl font-semibold tracking-tight mb-3">{agent.title}</h1>
              <p className="text-xl text-muted-foreground max-w-2xl">{agent.description}</p>
            </div>
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary gap-2"
              onClick={() => navigate(`/agent/${agentId}/chat`)}
            >
              <MessageSquare className="w-5 h-5" />
              Start Chat
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgentHero;
