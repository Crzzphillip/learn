
import { useState } from "react";
import { Comment } from "@/types/agent";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ThumbsUp, Reply, Flag, MessageSquare, Filter } from "lucide-react";
import { toast } from "sonner";

interface CommentsSectionProps {
  comments: Comment[];
}

const CommentsSection = ({ comments: initialComments }: CommentsSectionProps) => {
  const [comments, setComments] = useState<Comment[]>(initialComments);
  const [newComment, setNewComment] = useState("");
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState("");
  const [expandedReplies, setExpandedReplies] = useState<Record<string, boolean>>({});

  const handleAddComment = () => {
    if (!newComment.trim()) return;
    
    const newCommentObj: Comment = {
      id: `comment-${Date.now()}`,
      user: "Current User",
      content: newComment,
      timestamp: new Date(),
      likes: 0,
      replies: [],
      isLiked: false
    };
    
    setComments([...comments, newCommentObj]);
    setNewComment("");
    toast.success("Comment added successfully");
  };

  const handleAddReply = (parentId: string) => {
    if (!replyContent.trim()) return;
    
    const updatedComments = comments.map(comment => {
      if (comment.id === parentId) {
        const newReply: Comment = {
          id: `reply-${Date.now()}`,
          user: "Current User",
          content: replyContent,
          timestamp: new Date(),
          likes: 0,
          replies: [],
          isLiked: false
        };
        
        return {
          ...comment,
          replies: [...(comment.replies || []), newReply]
        };
      }
      return comment;
    });
    
    setComments(updatedComments);
    setReplyContent("");
    setReplyingTo(null);
    toast.success("Reply added successfully");
  };

  const toggleLike = (commentId: string, isReply = false, parentId?: string) => {
    if (isReply && parentId) {
      // Handle likes for replies
      setComments(comments.map(comment => {
        if (comment.id === parentId) {
          return {
            ...comment,
            replies: (comment.replies || []).map(reply => {
              if (reply.id === commentId) {
                const newIsLiked = !reply.isLiked;
                return {
                  ...reply,
                  isLiked: newIsLiked,
                  likes: newIsLiked ? reply.likes + 1 : reply.likes - 1
                };
              }
              return reply;
            })
          };
        }
        return comment;
      }));
    } else {
      // Handle likes for top-level comments
      setComments(comments.map(comment => {
        if (comment.id === commentId) {
          const newIsLiked = !comment.isLiked;
          return {
            ...comment,
            isLiked: newIsLiked,
            likes: newIsLiked ? comment.likes + 1 : comment.likes - 1
          };
        }
        return comment;
      }));
    }
  };

  const toggleReplies = (commentId: string) => {
    setExpandedReplies(prev => ({
      ...prev,
      [commentId]: !prev[commentId]
    }));
  };

  const reportComment = (commentId: string) => {
    toast.success("Comment reported. Our moderators will review it.");
  };

  const CommentCard = ({ comment, isReply = false, parentId = "" }: { comment: Comment, isReply?: boolean, parentId?: string }) => (
    <div className={`glass-panel rounded-xl p-4 ${isReply ? 'bg-black/10' : ''}`}>
      <div className="flex items-start gap-3">
        <Avatar className="w-8 h-8 mt-1">
          <img 
            src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${comment.user}`} 
            alt={comment.user} 
          />
        </Avatar>
        <div className="flex-1">
          <div className="flex items-center justify-between mb-1">
            <div className="font-medium">{comment.user}</div>
            <span className="text-xs text-muted-foreground">
              {comment.timestamp instanceof Date 
                ? comment.timestamp.toLocaleTimeString() 
                : comment.timestamp}
            </span>
          </div>
          <p className="text-sm mb-3">{comment.content}</p>
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <Button 
              variant="ghost" 
              size="sm" 
              className={`px-2 h-8 ${comment.isLiked ? 'text-primary' : ''}`}
              onClick={() => toggleLike(comment.id, isReply, parentId)}
            >
              <ThumbsUp className={`w-4 h-4 mr-1 ${comment.isLiked ? 'fill-primary' : ''}`} />
              {comment.likes}
            </Button>
            
            {!isReply && (
              <Button 
                variant="ghost" 
                size="sm" 
                className="px-2 h-8"
                onClick={() => {
                  setReplyingTo(replyingTo === comment.id ? null : comment.id);
                  setReplyContent("");
                }}
              >
                <Reply className="w-4 h-4 mr-1" />
                Reply
              </Button>
            )}
            
            <Button 
              variant="ghost" 
              size="sm" 
              className="px-2 h-8"
              onClick={() => reportComment(comment.id)}
            >
              <Flag className="w-4 h-4 mr-1" />
              Report
            </Button>
            
            {!isReply && comment.replies && comment.replies.length > 0 && (
              <Button 
                variant="ghost" 
                size="sm" 
                className="px-2 h-8 ml-auto"
                onClick={() => toggleReplies(comment.id)}
              >
                <MessageSquare className="w-4 h-4 mr-1" />
                {comment.replies.length} {comment.replies.length === 1 ? 'reply' : 'replies'}
              </Button>
            )}
          </div>
          
          {/* Reply Form */}
          {replyingTo === comment.id && (
            <div className="mt-3 pl-4 border-l-2 border-primary/20">
              <Textarea
                value={replyContent}
                onChange={(e) => setReplyContent(e.target.value)}
                placeholder="Write a reply..."
                className="min-h-20 mb-2 bg-background/50"
              />
              <div className="flex justify-end gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setReplyingTo(null)}
                >
                  Cancel
                </Button>
                <Button 
                  size="sm"
                  onClick={() => handleAddReply(comment.id)}
                  disabled={!replyContent.trim()}
                >
                  Post Reply
                </Button>
              </div>
            </div>
          )}
          
          {/* Replies */}
          {!isReply && comment.replies && comment.replies.length > 0 && expandedReplies[comment.id] && (
            <div className="mt-3 pl-4 space-y-3 border-l-2 border-primary/20">
              {comment.replies.map((reply) => (
                <CommentCard 
                  key={reply.id} 
                  comment={reply} 
                  isReply={true}
                  parentId={comment.id}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="mt-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Comments</h2>
        <Button variant="outline" size="sm">
          <Filter className="w-4 h-4 mr-2" />
          Filter
        </Button>
      </div>
      
      <div className="space-y-4">
        <div className="glass-panel rounded-xl p-4">
          <Textarea
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Add a comment..."
            className="mb-3 min-h-24"
          />
          <div className="flex justify-between items-center">
            <div className="text-sm text-muted-foreground">
              Be respectful and constructive in your comments
            </div>
            <Button onClick={handleAddComment} disabled={!newComment.trim()}>
              Post Comment
            </Button>
          </div>
        </div>
        
        {comments.length === 0 ? (
          <div className="glass-panel rounded-xl p-6 text-center">
            <MessageSquare className="w-12 h-12 mx-auto text-muted-foreground mb-2" />
            <h3 className="text-lg font-medium mb-2">No comments yet</h3>
            <p className="text-muted-foreground">Be the first to share your thoughts!</p>
          </div>
        ) : (
          comments.map((comment) => (
            <CommentCard key={comment.id} comment={comment} />
          ))
        )}
      </div>
    </div>
  );
};

export default CommentsSection;
