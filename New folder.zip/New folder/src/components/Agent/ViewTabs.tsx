
import React, { useRef, useState } from "react";
import { Code, Image, Layout, FileText, MessageCircle, ChevronUp, ChevronDown, SplitSquareVertical, Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export type ViewType = "chat" | "code" | "image" | "canvas" | "file" | "dual";

interface DualViewConfig {
  id: string;
  views: [ViewType, ViewType];
  icon: React.ElementType;
}

interface ViewTabsProps {
  activeView: ViewType;
  onChange: (view: ViewType) => void;
  onDualSelect?: (views: [ViewType, ViewType], id: string) => void;
  dualViews?: [ViewType, ViewType] | null;
  className?: string;
  extraTabs?: Array<{
    id: string;
    icon: React.ElementType;
    label: string;
  }>;
}

const ViewTabs = ({ activeView, onChange, onDualSelect, dualViews, className, extraTabs = [] }: ViewTabsProps) => {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dualSelectMode, setDualSelectMode] = useState(false);
  const [firstDualSelection, setFirstDualSelection] = useState<ViewType | null>(null);
  const [savedDualViews, setSavedDualViews] = useState<DualViewConfig[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);
  
  const tabs = [
    {
      id: "chat" as ViewType,
      icon: MessageCircle,
      label: "Chat",
    },
    {
      id: "code" as ViewType,
      icon: Code,
      label: "Code",
    },
    {
      id: "image" as ViewType,
      icon: Image,
      label: "Image",
    },
    {
      id: "canvas" as ViewType,
      icon: Layout,
      label: "Canvas",
    },
    {
      id: "file" as ViewType,
      icon: FileText,
      label: "Files",
    },
  ];

  // Add extra tabs if provided
  const allBaseTabs = [
    ...tabs,
    ...extraTabs.map(tab => ({
      id: tab.id as ViewType,
      icon: tab.icon,
      label: tab.label,
    }))
  ];

  // Add saved dual view tabs
  const allTabs = [
    ...allBaseTabs,
    ...savedDualViews.map((dualView) => ({
      id: dualView.id as ViewType,
      icon: dualView.icon,
      label: "Dual View",
      isDualView: true,
      dualConfig: dualView
    }))
  ];
  
  const handleTabClick = (tabId: ViewType) => {
    // Check if this is a saved dual view
    const dualViewConfig = savedDualViews.find(dv => dv.id === tabId);
    
    if (dualViewConfig) {
      if (onDualSelect) {
        onDualSelect(dualViewConfig.views, dualViewConfig.id);
      }
      onChange("dual");
      return;
    }
    
    if (dualSelectMode) {
      if (!firstDualSelection) {
        // First selection in dual mode
        setFirstDualSelection(tabId);
      } else if (firstDualSelection !== tabId) {
        // Second selection - complete dual mode setup
        setDialogOpen(true);
      }
    } else {
      onChange(tabId);
    }
  };
  
  const createDualView = (icon: React.ElementType) => {
    if (firstDualSelection && dualSelectMode) {
      const newDualViewId = `dual-${Date.now()}`;
      const newDualView: DualViewConfig = {
        id: newDualViewId,
        views: [firstDualSelection, secondSelection!],
        icon: icon
      };
      
      setSavedDualViews(prev => [...prev, newDualView]);
      
      if (onDualSelect) {
        onDualSelect(newDualView.views, newDualView.id);
      }
      
      setDualSelectMode(false);
      setFirstDualSelection(null);
      setDialogOpen(false);
      onChange("dual");
    }
  };
  
  const startDualSelect = () => {
    setDualSelectMode(true);
    setFirstDualSelection(null);
  };
  
  const [secondSelection, setSecondSelection] = useState<ViewType | null>(null);
  
  const handleSecondSelection = (viewType: ViewType) => {
    setSecondSelection(viewType);
  };
  
  const dualViewIcons = [SplitSquareVertical, Layout];
  
  const scroll = (direction: 'up' | 'down') => {
    if (containerRef.current) {
      const scrollAmount = 40; // Height of one button
      const scrollValue = direction === 'up' 
        ? containerRef.current.scrollTop - scrollAmount 
        : containerRef.current.scrollTop + scrollAmount;
      
      containerRef.current.scrollTo({
        top: scrollValue,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className={cn("flex flex-col items-center gap-2", className)}>
      <Button 
        variant="ghost" 
        size="icon" 
        className="w-8 h-8 bg-black/30 text-primary/70 hover:text-primary/90 backdrop-blur-sm rounded-full mb-1"
        onClick={() => setDialogOpen(true)}
      >
        <Plus className="w-4 h-4" />
      </Button>
      
      <Button 
        variant="ghost" 
        size="icon" 
        className="w-8 h-8 bg-black/30 text-white/40 hover:text-white/60 backdrop-blur-sm rounded-full"
        onClick={() => scroll('up')}
      >
        <ChevronUp className="w-4 h-4" />
      </Button>
      
      <div 
        ref={containerRef} 
        className="flex flex-col gap-2 h-[140px] overflow-hidden relative"
      >
        {/* Top fade effect */}
        <div className="absolute top-0 left-0 right-0 h-6 bg-gradient-to-b from-background to-transparent z-10 pointer-events-none"></div>
        
        <div className="flex flex-col gap-2 py-2">
          {allTabs.map((tab) => {
            const isActive = activeView === tab.id;
            const isSelected = dualSelectMode && firstDualSelection === tab.id;
            
            return (
              <button
                key={tab.id}
                onClick={() => handleTabClick(tab.id)}
                className={cn(
                  "w-12 h-12 flex flex-col items-center justify-center rounded-lg transition-all duration-200 text-xs",
                  "shadow-[inset_1px_1px_2px_rgba(0,0,0,0.2),inset_-1px_-1px_2px_rgba(255,255,255,0.05)]",
                  "border border-white/5",
                  isActive
                    ? "bg-black/40 text-primary/90 backdrop-blur-sm"
                    : isSelected
                    ? "bg-black/40 text-yellow-400/90 backdrop-blur-sm" 
                    : "bg-black/20 text-white/30 hover:text-white/40 backdrop-blur-sm"
                )}
                title={tab.label}
              >
                <tab.icon
                  className={cn(
                    "w-5 h-5 mb-0.5", 
                    isActive 
                      ? "text-primary/90" 
                      : isSelected 
                      ? "text-yellow-400/90" 
                      : "text-white/30"
                  )}
                />
              </button>
            );
          })}
        </div>
        
        {/* Bottom fade effect */}
        <div className="absolute bottom-0 left-0 right-0 h-6 bg-gradient-to-t from-background to-transparent z-10 pointer-events-none"></div>
      </div>
      
      <Button 
        variant="ghost" 
        size="icon" 
        className="w-8 h-8 bg-black/30 text-white/40 hover:text-white/60 backdrop-blur-sm rounded-full"
        onClick={() => scroll('down')}
      >
        <ChevronDown className="w-4 h-4" />
      </Button>
      
      {dualSelectMode && (
        <div className="text-xs bg-black/40 text-white/70 backdrop-blur-sm px-2 py-1 rounded-md border border-white/10">
          {firstDualSelection ? "Select second" : "Select first"}
        </div>
      )}
      
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-black/70 backdrop-blur-md border border-white/10 shadow-lg text-white">
          <DialogHeader>
            <DialogTitle className="text-white/80">Add or Create View</DialogTitle>
          </DialogHeader>
          
          <div className="mt-4 space-y-4">
            {!dualSelectMode && (
              <div>
                <h3 className="text-sm font-medium text-white/70 mb-2">Add New View</h3>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={startDualSelect}
                  className="w-full text-xs bg-black/30 text-white/60 hover:text-white/80 backdrop-blur-sm px-2 py-1 h-auto rounded-md"
                >
                  Create Dual View
                </Button>
              </div>
            )}
            
            {dualSelectMode && firstDualSelection && (
              <div>
                <h3 className="text-sm font-medium text-white/70 mb-2">Select second view</h3>
                <div className="grid grid-cols-4 gap-2">
                  {allBaseTabs
                    .filter(tab => tab.id !== firstDualSelection)
                    .map(tab => (
                      <Button
                        key={tab.id}
                        variant="outline"
                        className={cn(
                          "p-2 h-auto text-white/60 hover:text-white/90",
                          secondSelection === tab.id && "border-primary text-primary"
                        )}
                        onClick={() => handleSecondSelection(tab.id as ViewType)}
                      >
                        <tab.icon className="w-5 h-5" />
                      </Button>
                    ))}
                </div>
                
                {secondSelection && (
                  <div className="mt-4">
                    <h3 className="text-sm font-medium text-white/70 mb-2">Choose an icon</h3>
                    <div className="grid grid-cols-4 gap-2">
                      {dualViewIcons.map((Icon, idx) => (
                        <Button
                          key={idx}
                          variant="outline"
                          className="p-2 h-auto text-white/60 hover:text-white/90"
                          onClick={() => createDualView(Icon)}
                        >
                          <Icon className="w-5 h-5" />
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ViewTabs;
