import { Clock, MessageSquare, User } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
interface Session {
  id: string;
  title: string;
  date: string;
  messages: number;
  icon: "message" | "clock" | "user";
}
interface AgentSessionsProps {
  agentId?: string;
  className?: string;
}
const AgentSessions = ({
  agentId,
  className
}: AgentSessionsProps) => {
  // Mock sessions data - in a real app, this would be fetched based on the agentId
  const sessions: Session[] = [{
    id: "session-1",
    title: "Project setup assistance",
    date: "Today, 2:30 PM",
    messages: 12,
    icon: "message"
  }, {
    id: "session-2",
    title: "Code review session",
    date: "Yesterday, 11:15 AM",
    messages: 24,
    icon: "user"
  }, {
    id: "session-3",
    title: "Bug fixing discussion",
    date: "June 12, 5:45 PM",
    messages: 18,
    icon: "clock"
  }, {
    id: "session-4",
    title: "API integration help",
    date: "June 10, 9:20 AM",
    messages: 32,
    icon: "message"
  }, {
    id: "session-5",
    title: "Database schema planning",
    date: "June 8, 3:10 PM",
    messages: 15,
    icon: "user"
  }, {
    id: "session-6",
    title: "Performance optimization",
    date: "June 5, 1:30 PM",
    messages: 28,
    icon: "clock"
  }];
  const getIcon = (iconType: Session["icon"]) => {
    switch (iconType) {
      case "message":
        return <MessageSquare className="w-4 h-4" />;
      case "clock":
        return <Clock className="w-4 h-4" />;
      case "user":
        return <User className="w-4 h-4" />;
      default:
        return <MessageSquare className="w-4 h-4" />;
    }
  };
  return <div className={`w-96 h-full ${className}`}>
      <Card className="bg-card/50 h-full border-none">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Recent Sessions</CardTitle>
        </CardHeader>
        <CardContent className="p-2">
          <ScrollArea className="h-[calc(100vh-8rem)]">
            <div className="grid grid-cols-3 gap-2">
              {sessions.map(session => <div key={session.id} className="flex flex-col p-2 rounded-lg bg-card/50 border border-primary/10 cursor-pointer">
                  <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center text-primary mb-2">
                    {getIcon(session.icon)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate">{session.title}</p>
                    <div className="flex items-center justify-between">
                      <p className="text-xs text-muted-foreground">{session.date}</p>
                      <span className="text-xs bg-primary/20 text-primary px-1.5 py-0.5 rounded">
                        {session.messages} msgs
                      </span>
                    </div>
                  </div>
                </div>)}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>;
};
export default AgentSessions;