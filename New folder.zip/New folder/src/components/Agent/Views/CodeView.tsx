
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Copy, Check, Terminal, Code, FileCode, Settings, Search } from "lucide-react";
import { cn } from "@/lib/utils";

interface CodeViewProps {
  code: string;
  language: string;
}

const CodeView = ({ code, language }: CodeViewProps) => {
  const [copied, setCopied] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [codeLines, setCodeLines] = useState<string[]>([]);
  
  useEffect(() => {
    // Split code into lines for line number display
    setCodeLines(code.split('\n'));
  }, [code]);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Function to colorize specific syntax based on the language
  const colorizeCode = (line: string) => {
    if (language === 'javascript' || language === 'typescript' || language === 'tsx') {
      // Basic syntax highlighting
      return line
        .replace(/(\bconst\b|\blet\b|\bvar\b|\bfunction\b|\breturn\b|\bimport\b|\bexport\b|\bfrom\b|\bclass\b|\bextends\b|\bif\b|\belse\b|\btry\b|\bcatch\b|\bfor\b|\bwhile\b)/g, '<span class="text-[#C586C0]">$1</span>')
        .replace(/(\b[A-Za-z]+\b)(?=\s*\()/g, '<span class="text-[#DCDCAA]">$1</span>')
        .replace(/(["'`])(?:(?=(\\?))\2.)*?\1/g, '<span class="text-[#CE9178]">$&</span>')
        .replace(/(\{|\}|\(|\)|\[|\]|;|,|=>|=|\+|-|\*|\/|&lt;|&gt;)/g, '<span class="text-[#D4D4D4]">$1</span>')
        .replace(/(\btrue\b|\bfalse\b|\bnull\b|\bundefined\b|\bNaN\b|\bnew\b|\bthis\b)/g, '<span class="text-[#569CD6]">$1</span>')
        .replace(/\/\/.*/g, '<span class="text-[#6A9955]">$&</span>')
        .replace(/\/\*[\s\S]*?\*\//g, '<span class="text-[#6A9955]">$&</span>')
        .replace(/(&lt;[^&]*&gt;)/g, '<span class="text-[#569CD6]">$1</span>');
    }
    return line;
  };

  return (
    <div className={cn(
      "flex flex-col h-full rounded-none bg-[#1E1E1E] border border-white/5 shadow-[inset_1px_1px_2px_rgba(255,255,255,0.05),inset_-1px_-1px_2px_rgba(0,0,0,0.3)]",
      fullscreen && "fixed inset-0 z-50 rounded-none"
    )}>
      {/* Editor header with file name and controls */}
      <div className="flex items-center justify-between p-2 border-b border-white/10 bg-[#252526]">
        <div className="flex items-center">
          <FileCode className="h-4 w-4 text-white/60 mr-2" />
          <div className="flex items-center">
            <span className="text-xs font-medium text-white/80 px-2 py-1 rounded bg-[#2D2D2D]">
              {language === 'javascript' ? 'index.js' : 
              language === 'typescript' ? 'index.ts' : 
              language === 'tsx' ? 'Component.tsx' : `file.${language}`}
            </span>
          </div>
        </div>
        <div className="flex items-center space-x-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-white/60 hover:text-white hover:bg-white/10"
          >
            <Search className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-white/60 hover:text-white hover:bg-white/10"
            onClick={handleCopy}
          >
            {copied ? (
              <Check className="h-4 w-4 text-green-400" />
            ) : (
              <Copy className="h-4 w-4" />
            )}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-white/60 hover:text-white hover:bg-white/10"
          >
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      {/* Editor tabs */}
      <div className="flex items-center bg-[#252526] border-b border-white/10 text-xs">
        <div className="flex items-center bg-[#1E1E1E] border-r border-white/10 px-3 py-1 text-white/80">
          <Code className="h-3.5 w-3.5 mr-1.5" />
          EXPLORER
        </div>
        <div className="flex items-center bg-[#2D2D2D] px-3 py-1 text-white">
          <span className="mr-2">
            {language === 'javascript' ? 'index.js' : 
            language === 'typescript' ? 'index.ts' : 
            language === 'tsx' ? 'Component.tsx' : `file.${language}`}
          </span>
          <button className="ml-2 text-white/60 hover:text-white">×</button>
        </div>
      </div>
      
      {/* Main editor area with line numbers and code */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left sidebar with file tree - collapsed */}
        <div className="w-10 bg-[#252526] border-r border-white/10 flex flex-col items-center py-2 space-y-4">
          <FileCode className="h-5 w-5 text-white/70" />
          <Search className="h-5 w-5 text-white/40" />
          <Terminal className="h-5 w-5 text-white/40" />
        </div>
        
        {/* Code area with line numbers and code */}
        <ScrollArea className="flex-1 h-full bg-[#1E1E1E] font-mono text-sm">
          <div className="flex">
            {/* Line numbers */}
            <div className="py-2 px-2 text-right text-white/40 bg-[#1E1E1E] select-none min-w-[3rem]">
              {codeLines.map((_, index) => (
                <div key={index} className="px-2">
                  {index + 1}
                </div>
              ))}
            </div>
            
            {/* Code content */}
            <div className="py-2 flex-1 text-white/90">
              {codeLines.map((line, index) => (
                <div key={index} className="pl-4 pr-8 hover:bg-white/5">
                  <span dangerouslySetInnerHTML={{ __html: colorizeCode(line) || '&nbsp;' }} />
                </div>
              ))}
            </div>
          </div>
        </ScrollArea>
      </div>
      
      {/* Status bar */}
      <div className="flex items-center justify-between text-xs px-3 py-1 bg-[#007ACC] text-white/80">
        <div className="flex items-center space-x-4">
          <span>Ln {codeLines.length}, Col 1</span>
          <span>Spaces: 2</span>
        </div>
        <div className="flex items-center space-x-4">
          <span>{language.toUpperCase()}</span>
          <span>UTF-8</span>
          <span>LF</span>
        </div>
      </div>
    </div>
  );
};

export default CodeView;
