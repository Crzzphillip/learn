
import React from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FileText, Download } from "lucide-react";
import { Button } from "@/components/ui/button";

interface File {
  name: string;
  url: string;
  size: string;
}

interface FileViewProps {
  files: File[];
}

const FileView = ({ files }: FileViewProps) => {
  return (
    <div className="flex flex-col h-full rounded-lg glass-panel bg-black/60 backdrop-blur-md border border-white/5 shadow-[inset_1px_1px_2px_rgba(255,255,255,0.05),inset_-1px_-1px_2px_rgba(0,0,0,0.3)]">
      <div className="p-3 border-b border-white/10 bg-black/40 rounded-t-lg">
        <h3 className="text-sm font-medium text-white/80">Files</h3>
      </div>
      <ScrollArea className="flex-1 p-4">
        {files.length > 0 ? (
          <div className="space-y-2">
            {files.map((file, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors shadow-[inset_1px_1px_2px_rgba(255,255,255,0.02)]"
              >
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-white/60" />
                  <div>
                    <p className="text-sm text-white/90">{file.name}</p>
                    <p className="text-xs text-white/50">{file.size}</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  asChild
                >
                  <a href={file.url} download target="_blank" rel="noreferrer">
                    <Download className="h-4 w-4" />
                  </a>
                </Button>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-white/60">No files available</p>
        )}
      </ScrollArea>
    </div>
  );
};

export default FileView;
