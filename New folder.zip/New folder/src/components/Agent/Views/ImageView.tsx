
import React from "react";
import { ScrollArea } from "@/components/ui/scroll-area";

interface ImageViewProps {
  images: string[];
}

const ImageView = ({ images }: ImageViewProps) => {
  return (
    <div className="flex flex-col h-full rounded-lg glass-panel bg-black/60 backdrop-blur-md border border-white/5 shadow-[inset_1px_1px_2px_rgba(255,255,255,0.05),inset_-1px_-1px_2px_rgba(0,0,0,0.3)]">
      <div className="p-3 border-b border-white/10 bg-black/40 rounded-t-lg">
        <h3 className="text-sm font-medium text-white/80">Generated Images</h3>
      </div>
      <ScrollArea className="flex-1 p-4">
        <div className="grid grid-cols-1 gap-4">
          {images.map((src, index) => (
            <div
              key={index}
              className="relative aspect-square overflow-hidden rounded-lg border border-white/10 shadow-[inset_1px_1px_2px_rgba(255,255,255,0.05)]"
            >
              <img
                src={src}
                alt={`Generated image ${index}`}
                className="w-full h-full object-cover"
              />
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};

export default ImageView;
