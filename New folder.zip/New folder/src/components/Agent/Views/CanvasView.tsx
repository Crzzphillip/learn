
import React from "react";

interface CanvasViewProps {
  canvasData?: string;
}

const CanvasView = ({ canvasData }: CanvasViewProps) => {
  return (
    <div className="flex flex-col h-full rounded-lg glass-panel bg-black/60 backdrop-blur-md border border-white/5 shadow-[inset_1px_1px_2px_rgba(255,255,255,0.05),inset_-1px_-1px_2px_rgba(0,0,0,0.3)]">
      <div className="p-3 border-b border-white/10 bg-black/40 rounded-t-lg flex items-center justify-between">
        <h3 className="text-sm font-medium text-white/80">Canvas View</h3>
      </div>
      <div className="flex-1 flex items-center justify-center p-4 overflow-hidden">
        {canvasData ? (
          <div
            className="w-full h-full rounded-lg border border-white/10 bg-black/20 backdrop-blur-sm shadow-[inset_1px_1px_2px_rgba(255,255,255,0.05)]"
            dangerouslySetInnerHTML={{ __html: canvasData }}
          />
        ) : (
          <div className="flex items-center justify-center h-full w-full rounded-lg border border-white/10 bg-black/20 backdrop-blur-sm">
            <p className="text-sm text-white/60">No canvas data available</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CanvasView;
