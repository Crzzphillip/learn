
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import WorkflowDesigner from "../LangGraph/WorkflowDesigner";
import { Button } from "@/components/ui/button";
import { Play, Save, Code, Settings } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";

interface LangGraphViewProps {
  workspaceId?: string;
  initialWorkflow?: any;
}

export default function LangGraphView({ workspaceId, initialWorkflow }: LangGraphViewProps) {
  const [activeTab, setActiveTab] = useState("designer");
  const [currentWorkflow, setCurrentWorkflow] = useState(initialWorkflow || null);
  const [isRunning, setIsRunning] = useState(false);

  // Handle saving the workflow
  const handleSaveWorkflow = (workflow: any) => {
    setCurrentWorkflow(workflow);
    // In a real implementation, we would save this to a backend
  };

  // Handle running the workflow
  const handleRunWorkflow = () => {
    if (!currentWorkflow) {
      toast.error("Please save your workflow before running");
      return;
    }

    setIsRunning(true);
    
    // Simulate workflow execution
    toast.info("Workflow execution started");
    
    setTimeout(() => {
      setIsRunning(false);
      toast.success("Workflow execution completed");
    }, 3000);
  };

  // Generate Python code from the workflow
  const generatePythonCode = () => {
    if (!currentWorkflow) {
      toast.error("Please save your workflow before generating code");
      return;
    }

    // This is a simplified example of code generation
    // In a real implementation, we would generate actual LangGraph code
    const pythonCode = `
import os
from typing import Dict, List, Any
from langchain_core.runnables import RunnablePassthrough
from langchain.graphs import graph
from langgraph.graph import StateGraph, END

# Define the nodes
def entry_point(state: Dict[str, Any]) -> Dict[str, Any]:
    """Entry point for the workflow"""
    return state

def llm_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """Process input with LLM"""
    # In a real implementation, we would use an actual LLM
    return {"response": "LLM generated response", **state}

def tool_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """Use external tool"""
    # In a real implementation, we would call an actual tool
    return {"tool_result": "Tool execution result", **state}

# Define the graph
workflow = StateGraph(name="LangGraph Workflow")

# Add nodes
workflow.add_node("entry", entry_point)
workflow.add_node("llm", llm_node)
workflow.add_node("tool", tool_node)

# Add edges
workflow.add_edge("entry", "llm")
workflow.add_edge("llm", "tool")
workflow.add_edge("tool", END)

# Compile the graph
app = workflow.compile()

# Run the workflow
result = app.invoke({"input": "User query"})
print(result)
`;

    return pythonCode;
  };

  return (
    <div className="flex flex-col h-full bg-background">
      <div className="flex items-center justify-between p-2 bg-muted/50">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList>
            <TabsTrigger value="designer">Visual Designer</TabsTrigger>
            <TabsTrigger value="code">Code View</TabsTrigger>
            <TabsTrigger value="execution">Execution</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>
        
          <div className="flex gap-2 ml-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleRunWorkflow}
              disabled={isRunning || !currentWorkflow}
              className="gap-1"
            >
              <Play className="h-4 w-4" />
              {isRunning ? "Running..." : "Run"}
            </Button>
          </div>
        </Tabs>
      </div>
      
      <div className="flex-1 overflow-hidden">
        <Tabs value={activeTab} className="h-full">
          <TabsContent value="designer" className="h-full m-0 p-0">
            <WorkflowDesigner workspaceId={workspaceId} onSave={handleSaveWorkflow} />
          </TabsContent>
          
          <TabsContent value="code" className="h-full m-0 p-0">
            <div className="flex flex-col h-full p-4">
              <div className="flex justify-between mb-4">
                <h3 className="text-lg font-medium">Generated LangGraph Code</h3>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="gap-1"
                  onClick={() => {
                    navigator.clipboard.writeText(generatePythonCode());
                    toast.success("Code copied to clipboard");
                  }}
                >
                  <Code className="h-4 w-4" />
                  Copy Code
                </Button>
              </div>
              
              <ScrollArea className="flex-1 border rounded-md p-4 bg-black text-white font-mono text-sm">
                <pre>{generatePythonCode()}</pre>
              </ScrollArea>
            </div>
          </TabsContent>
          
          <TabsContent value="execution" className="h-full m-0 p-0">
            <div className="flex flex-col h-full p-4">
              <h3 className="text-lg font-medium mb-4">Workflow Execution</h3>
              <div className="flex-1 border rounded-md p-4 bg-muted/30">
                {isRunning ? (
                  <div className="flex flex-col items-center justify-center h-full">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                    <p className="mt-4 text-muted-foreground">Executing workflow...</p>
                  </div>
                ) : currentWorkflow ? (
                  <div>
                    <p className="text-muted-foreground mb-4">
                      Click the Run button to execute this workflow. Results will appear here.
                    </p>
                    <div className="border rounded-md p-3 bg-background">
                      <h4 className="font-medium mb-2">Workflow Summary</h4>
                      <p className="text-sm text-muted-foreground">
                        Nodes: {currentWorkflow.nodes.length}<br />
                        Edges: {currentWorkflow.edges.length}<br />
                        Last saved: {new Date(currentWorkflow.metadata.timestamp).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                    <p className="text-muted-foreground">
                      No workflow available. Design and save a workflow to execute it.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="settings" className="h-full m-0 p-0">
            <div className="flex flex-col h-full p-4">
              <h3 className="text-lg font-medium mb-4">LangGraph Settings</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border rounded-md p-4">
                  <h4 className="font-medium mb-2">Runtime Configuration</h4>
                  <p className="text-sm text-muted-foreground mb-4">
                    Configure the execution environment for your LangGraph workflows.
                  </p>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Debug Mode</span>
                      <Button variant="outline" size="sm">Enable</Button>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Execution Timeout</span>
                      <span className="text-sm text-muted-foreground">30s</span>
                    </div>
                  </div>
                </div>
                
                <div className="border rounded-md p-4">
                  <h4 className="font-medium mb-2">LLM Configuration</h4>
                  <p className="text-sm text-muted-foreground mb-4">
                    Set up default language models for your LangGraph workflows.
                  </p>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Default Model</span>
                      <span className="text-sm text-muted-foreground">gpt-4o</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Temperature</span>
                      <span className="text-sm text-muted-foreground">0.7</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
