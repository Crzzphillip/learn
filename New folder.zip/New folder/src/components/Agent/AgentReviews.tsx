
import { Star } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import type { AgentDetails } from "@/types/agent";

interface AgentReviewsProps {
  agent: AgentDetails;
  onAddReview: (review: { user: string; rating: number; comment: string }) => void;
}

const AgentReviews = ({ agent, onAddReview }: AgentReviewsProps) => {
  const { toast } = useToast();
  const [newComment, setNewComment] = useState("");
  const [newRating, setNewRating] = useState(5);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleAddReview = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      onAddReview({
        user: "Current User",
        rating: newRating,
        comment: newComment
      });
      setNewComment("");
      setNewRating(5);
      setIsSubmitting(false);
      toast({
        title: "Review added",
        description: "Thank you for sharing your feedback!",
      });
    }, 1000);
  };

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-6">Reviews</h2>
      
      <div className="glass-panel rounded-2xl p-6 mb-6">
        <h3 className="text-lg font-medium mb-4">Add Your Review</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Rating</label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((rating) => (
                <button
                  key={rating}
                  onClick={() => setNewRating(rating)}
                  className="p-2 rounded-lg hover:bg-white/5 transition-colors"
                >
                  <Star 
                    className={`w-6 h-6 ${
                      rating <= newRating 
                        ? "fill-primary text-primary" 
                        : "text-white/20"
                    }`} 
                  />
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Comment</label>
            <Textarea
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Share your experience..."
              className="resize-none"
              rows={4}
            />
          </div>
          <Button 
            onClick={handleAddReview} 
            disabled={!newComment || isSubmitting}
            className="w-full"
          >
            Submit Review
          </Button>
        </div>
      </div>

      <div className="grid gap-4">
        {agent.reviews.map((review, index) => (
          <div key={index} className="glass-panel rounded-2xl p-6">
            <div className="flex items-center justify-between mb-3">
              <span className="font-medium text-lg">{review.user}</span>
              <div className="flex items-center gap-1">
                <Star className="w-5 h-5 fill-primary text-primary" />
                <span className="font-medium">{review.rating}</span>
              </div>
            </div>
            <p className="text-muted-foreground">{review.comment}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AgentReviews;
