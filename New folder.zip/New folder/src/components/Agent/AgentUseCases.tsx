
import { UseCase } from "@/types/agent";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, Star, ThumbsUp, UserRound } from "lucide-react";

interface AgentUseCasesProps {
  useCases?: UseCase[];
}

const AgentUseCases = ({ useCases = [] }: AgentUseCasesProps) => {
  if (!useCases || useCases.length === 0) {
    return (
      <div className="py-6">
        <h2 className="text-2xl font-semibold mb-6">User Success Stories</h2>
        <Card className="bg-muted/30">
          <CardContent className="pt-6 text-center py-12">
            <p className="text-muted-foreground">No success stories shared yet for this agent.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-6">User Success Stories</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {useCases.map((useCase) => (
          <Card key={useCase.id} className="overflow-hidden hover:border-primary/30 transition-colors">
            <CardContent className="p-0">
              <div className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  <Avatar className="h-12 w-12 border-2 border-primary/20">
                    <AvatarImage src={useCase.userAvatar} alt={useCase.user} />
                    <AvatarFallback>
                      <UserRound className="h-6 w-6 text-muted-foreground" />
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold">{useCase.user}</h3>
                    <Badge variant="outline" className="bg-primary/10 text-primary text-xs">
                      {useCase.industry}
                    </Badge>
                  </div>
                </div>
                
                <h4 className="text-lg font-medium mb-2">{useCase.title}</h4>
                <p className="text-sm text-muted-foreground mb-4">{useCase.description}</p>
                
                <div className="border-t pt-4">
                  <div className="flex items-center gap-1 text-sm font-medium text-primary">
                    <Star className="h-4 w-4" /> 
                    <span>Results:</span>
                  </div>
                  <p className="text-sm mt-1">{useCase.results}</p>
                </div>
              </div>
              
              <div className="bg-muted/30 px-6 py-3 flex items-center justify-between text-xs text-muted-foreground">
                <span>{useCase.date}</span>
                <div className="flex items-center gap-4">
                  <button className="flex items-center gap-1 hover:text-primary transition-colors">
                    <ThumbsUp className="h-3.5 w-3.5" /> Helpful
                  </button>
                  <button className="flex items-center gap-1 hover:text-primary transition-colors">
                    <MessageCircle className="h-3.5 w-3.5" /> Comment
                  </button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default AgentUseCases;
