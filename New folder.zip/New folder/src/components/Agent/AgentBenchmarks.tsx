
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import BenchmarkGrid from '../Benchmarks/BenchmarkGrid';
import { benchmarkService } from '@/services/benchmarkService';
import { Benchmark } from '@/types/explore';

interface AgentBenchmarksProps {
  agentId: string;
}

const AgentBenchmarks = ({ agentId }: AgentBenchmarksProps) => {
  const [benchmarks, setBenchmarks] = useState<Benchmark[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchBenchmarks = async () => {
      try {
        setIsLoading(true);
        const data = await benchmarkService.getAgentBenchmarks(agentId);
        setBenchmarks(data);
      } catch (error) {
        console.error("Error fetching agent benchmarks:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchBenchmarks();
  }, [agentId]);

  return (
    <div className="space-y-6">
      <BenchmarkGrid 
        benchmarks={benchmarks} 
        title="Performance Benchmarks" 
        loading={isLoading}
      />
    </div>
  );
};

export default AgentBenchmarks;
