
import type { AgentDetails } from "@/types/agent";

interface AgentPersonasProps {
  agent: AgentDetails;
}

const AgentPersonas = ({ agent }: AgentPersonasProps) => {
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-6">Available Personas</h2>
      <div className="flex flex-wrap gap-3">
        {agent.personas.map((persona, index) => (
          <div 
            key={index}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-primary/10 to-primary/5 backdrop-blur-xl text-base font-medium"
          >
            {persona}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AgentPersonas;
