
import { AgentDetails as AgentDetailsType } from "@/types/agent";
import { Button } from "@/components/ui/button";
import { MessageSquare, Star, Zap } from "lucide-react";

interface AgentDetailsProps {
  agent: AgentDetailsType;
  onStartChat: () => void;
}

const AgentDetails = ({ agent, onStartChat }: AgentDetailsProps) => {
  return (
    <div className="glass-panel rounded-xl p-8 mb-8">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight mb-2">{agent.title}</h1>
          <p className="text-muted-foreground">{agent.description}</p>
        </div>
        <Button variant="default" className="gap-2" onClick={onStartChat}>
          <MessageSquare className="w-4 h-4" />
          Start Chat
        </Button>
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="glass-panel rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Star className="w-4 h-4 fill-primary text-primary" />
            <span className="font-semibold">{agent.rating}</span>
          </div>
          <p className="text-sm text-muted-foreground">Rating</p>
        </div>
        <div className="glass-panel rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-4 h-4" />
            <span className="font-semibold">{agent.credits}</span>
          </div>
          <p className="text-sm text-muted-foreground">Credits per use</p>
        </div>
        <div className="glass-panel rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <MessageSquare className="w-4 h-4" />
            <span className="font-semibold">{agent.reviews.length}</span>
          </div>
          <p className="text-sm text-muted-foreground">Reviews</p>
        </div>
      </div>

      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">Available Personas</h2>
        <div className="flex flex-wrap gap-2">
          {agent.personas.map((persona, index) => (
            <div key={index} className="px-3 py-1.5 rounded-full bg-primary/10 text-sm">
              {persona}
            </div>
          ))}
        </div>
      </div>

      <div className="mt-8">
        <h2 className="text-xl font-semibold mb-4">Reviews</h2>
        <div className="space-y-4">
          {agent.reviews.map((review, index) => (
            <div key={index} className="glass-panel rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium">{review.user}</span>
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-primary text-primary" />
                  <span>{review.rating}</span>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">{review.comment}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AgentDetails;
