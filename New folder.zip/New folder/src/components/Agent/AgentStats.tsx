
import { Star, Brain, Zap } from "lucide-react";
import type { AgentDetails } from "@/types/agent";

interface AgentStatsProps {
  agent: AgentDetails;
}

const AgentStats = ({ agent }: AgentStatsProps) => {
  return (
    <div className="grid grid-cols-3 gap-6">
      <div className="glass-panel rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-2">
          <Star className="w-5 h-5 fill-primary text-primary" />
          <span className="text-2xl font-semibold">{agent.rating}</span>
        </div>
        <p className="text-muted-foreground">Rating</p>
      </div>
      <div className="glass-panel rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-2">
          <Brain className="w-5 h-5" />
          <span className="text-2xl font-semibold">2.4k</span>
        </div>
        <p className="text-muted-foreground">Active Users</p>
      </div>
      <div className="glass-panel rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-2">
          <Zap className="w-5 h-5" />
          <span className="text-2xl font-semibold">{agent.credits}</span>
        </div>
        <p className="text-muted-foreground">Credits per use</p>
      </div>
    </div>
  );
};

export default AgentStats;
