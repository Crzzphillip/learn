
import { Check } from "lucide-react";
import { LucideIcon } from "lucide-react";

interface Task {
  icon: LucideIcon;
  title: string;
  description: string;
  examples: string[];
}

interface AgentTasksProps {
  tasks: Task[];
}

const AgentTasks = ({ tasks }: AgentTasksProps) => {
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-6">What I Can Help You With</h2>
      <div className="grid grid-cols-2 gap-6">
        {tasks.map((task, index) => (
          <div key={index} className="glass-panel rounded-2xl p-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/10 grid place-items-center">
                <task.icon className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-medium mb-2">{task.title}</h3>
                <p className="text-muted-foreground mb-4">{task.description}</p>
                <div className="space-y-2">
                  {task.examples.map((example, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm">
                      <Check className="w-4 h-4 text-primary" />
                      <span>{example}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AgentTasks;
