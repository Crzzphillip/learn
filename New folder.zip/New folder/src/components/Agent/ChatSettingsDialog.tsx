
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { MessageSquare, Settings, Paintbrush, Lock, User } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

interface ChatSettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onPersonaSelect: (personaId: string) => void;
  selectedPersona: string | null;
}

type NavItem = "chat" | "settings" | "appearance" | "privacy" | "personas";

const ChatSettingsDialog = ({ open, onOpenChange, onPersonaSelect, selectedPersona }: ChatSettingsDialogProps) => {
  const [activeNav, setActiveNav] = useState<NavItem>("personas");
  const navigate = useNavigate();

  const renderContent = () => {
    switch (activeNav) {
      case "personas":
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-white">Choose a Persona</h3>
            <div className="space-y-3">
              {[
                { id: "creative", title: "Creative Writer", desc: "Perfect for storytelling and creative writing", color: "purple" },
                { id: "editor", title: "Editor", desc: "Helps with editing and proofreading", color: "blue" },
                { id: "brainstorm", title: "Brainstormer", desc: "Ideal for generating ideas and concepts", color: "green" }
              ].map((persona) => (
                <button
                  key={persona.id}
                  className={`w-full p-4 rounded-lg border transition-all text-left backdrop-blur-xl 
                    ${persona.color === "purple" ? "bg-gradient-to-br from-purple-500/20 to-purple-500/5" : ""}
                    ${persona.color === "blue" ? "bg-gradient-to-br from-blue-500/20 to-blue-500/5" : ""}
                    ${persona.color === "green" ? "bg-gradient-to-br from-green-500/20 to-green-500/5" : ""}
                    ${selectedPersona === persona.id ? "border-primary/50" : "border-white/10"}
                    hover:border-white/20`}
                  onClick={() => onPersonaSelect(persona.id)}
                >
                  <h4 className="font-medium text-white mb-1">{persona.title}</h4>
                  <p className="text-sm text-white/70">{persona.desc}</p>
                </button>
              ))}
            </div>
            <div className="pt-4 border-t border-white/10">
              <button 
                className="inline-flex items-center gap-2 h-10 px-4 py-2 w-full justify-between text-primary hover:bg-white/5 rounded-md transition-colors"
                onClick={() => {
                  onOpenChange(false); // Close dialog
                  navigate("/explore/personas"); // Navigate to personas page
                }}
              >
                See more personas
                <span className="text-lg">→</span>
              </button>
            </div>
          </div>
        );
      default:
        return (
          <div className="flex items-center justify-center h-full text-white/60">
            Coming soon...
          </div>
        );
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[800px] p-0 bg-black/95 backdrop-blur-xl border-white/10">
        <div className="flex h-[480px] flex-col overflow-hidden">
          <DialogHeader className="flex h-16 shrink-0 items-center px-4 border-b border-white/10">
            <DialogTitle className="text-lg font-semibold text-primary">story-assistant</DialogTitle>
          </DialogHeader>
          
          <div className="flex flex-1 overflow-hidden">
            <div className="w-64 border-r border-white/10">
              <nav className="p-4 space-y-2">
                <button
                  onClick={() => setActiveNav("chat")}
                  className={`w-full p-3 flex items-center gap-3 rounded-lg transition-colors text-white/80 hover:bg-white/5 
                    ${activeNav === "chat" ? "bg-white/10" : ""}`}
                >
                  <MessageSquare className="h-5 w-5 text-primary" />
                  <span>Chat History</span>
                </button>
                <button
                  onClick={() => setActiveNav("settings")}
                  className={`w-full p-3 flex items-center gap-3 rounded-lg transition-colors text-white/80 hover:bg-white/5 
                    ${activeNav === "settings" ? "bg-white/10" : ""}`}
                >
                  <Settings className="h-5 w-5 text-primary" />
                  <span>Settings</span>
                </button>
                <button
                  onClick={() => setActiveNav("appearance")}
                  className={`w-full p-3 flex items-center gap-3 rounded-lg transition-colors text-white/80 hover:bg-white/5 
                    ${activeNav === "appearance" ? "bg-white/10" : ""}`}
                >
                  <Paintbrush className="h-5 w-5 text-primary" />
                  <span>Appearance</span>
                </button>
                <button
                  onClick={() => setActiveNav("privacy")}
                  className={`w-full p-3 flex items-center gap-3 rounded-lg transition-colors text-white/80 hover:bg-white/5 
                    ${activeNav === "privacy" ? "bg-white/10" : ""}`}
                >
                  <Lock className="h-5 w-5 text-primary" />
                  <span>Privacy</span>
                </button>
                <button
                  onClick={() => setActiveNav("personas")}
                  className={`w-full p-3 flex items-center gap-3 rounded-lg transition-colors text-white/80 hover:bg-white/5 
                    ${activeNav === "personas" ? "bg-white/10" : ""}`}
                >
                  <User className="h-5 w-5 text-primary" />
                  <span>Personas</span>
                </button>
              </nav>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4">
              {renderContent()}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ChatSettingsDialog;
