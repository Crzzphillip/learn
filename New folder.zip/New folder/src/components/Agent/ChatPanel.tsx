import { useState, useRef, useEffect } from "react";
import { Message } from "@/types/agent";
import { Button } from "@/components/ui/button";
import { MessageSquare, Send, Paperclip, Code, X, Settings } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import ChatSettingsDialog from "./ChatSettingsDialog";
import { ScrollArea } from "@/components/ui/scroll-area";

interface ChatPanelProps {
  agentTitle: string;
  onClose: () => void;
}

const CHAT_PROMPTS = [
  { id: 1, title: "Help me write a blog post", content: "Can you help me write a blog post about..." },
  { id: 2, title: "Generate product description", content: "Create a compelling product description for..." },
  { id: 3, title: "Write an email", content: "Help me compose a professional email to..." },
  { id: 4, title: "Create social media post", content: "Generate engaging social media content for..." },
];

const ChatPanel = ({ agentTitle }: ChatPanelProps) => {
  const { toast } = useToast();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [availableCredits] = useState(100);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [showCodeView, setShowCodeView] = useState(false);
  const [showChatPrompts, setShowChatPrompts] = useState(false);
  const [showFileUpload, setShowFileUpload] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState("python");
  const [codeInput, setCodeInput] = useState("");
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [selectedPersona, setSelectedPersona] = useState<string | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (content: string = inputValue) => {
    if (!content.trim()) return;

    const messageCost = 10;

    if (availableCredits < messageCost) {
      toast({
        title: "Insufficient Credits",
        description: "Please add more credits to continue chatting.",
        variant: "destructive",
      });
      return;
    }

    const newMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content,
      timestamp: new Date(),
      credits: messageCost,
    };

    setMessages((prev) => [...prev, newMessage]);
    setInputValue("");
    setIsTyping(true);

    setTimeout(() => {
      const response: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "Thank you for your message! I'm the Creative Writer AI assistant. How can I help you with your writing today?",
        timestamp: new Date(),
        credits: 0,
      };
      setMessages((prev) => [...prev, response]);
      setIsTyping(false);
    }, 1000);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      const newFiles = Array.from(files).map(file => file.name);
      setUploadedFiles(prev => [...prev, ...newFiles]);
      toast({
        title: "File uploaded",
        description: `Successfully uploaded ${files.length} file(s)`,
      });
    }
  };

  const handlePromptSelect = (content: string) => {
    setInputValue(content);
    setShowChatPrompts(false);
  };

  const toggleContainer = (container: 'code' | 'chat' | 'files') => {
    setShowCodeView(container === 'code' ? !showCodeView : false);
    setShowChatPrompts(container === 'chat' ? !showChatPrompts : false);
    setShowFileUpload(container === 'files' ? !showFileUpload : false);
  };

  const handlePersonaSelect = (personaId: string) => {
    setSelectedPersona(personaId);
    setIsSettingsOpen(false); // Close settings dialog after selection
  };

  return (
    <div className="max-w-3xl mx-auto flex-1 flex flex-col relative">
      {messages.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6">
          <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-emerald-500/10 flex items-center justify-center mb-4">
            <MessageSquare className="w-5 h-5 md:w-6 md:h-6 text-emerald-500" />
          </div>
          <h1 className="text-xl md:text-2xl font-semibold text-white">
            How can I help you today?
          </h1>
          <p className="text-sm md:text-base text-white/60 max-w-md mx-auto">
            {selectedPersona ? 'Start chatting with your selected persona' : 'Please select a persona to start chatting'}
          </p>
          {!selectedPersona && (
            <Button
              onClick={() => setIsSettingsOpen(true)}
              variant="outline"
              className="mt-4"
            >
              <Settings className="w-4 h-4 mr-2" />
              Select Persona
            </Button>
          )}
        </div>
      ) : (
        <ScrollArea className="flex-1 h-[calc(100vh-160px)] px-4">
          <div className="space-y-6 pb-20">
            {messages.map((message) => (
              <div 
                key={message.id} 
                className={`flex gap-4 py-4 transition-all duration-300 ${
                  message.role === "user" ? "flex-row-reverse" : "flex-row"
                }`}
              >
                <div className={`h-8 w-8 rounded-lg flex items-center justify-center text-sm ${
                  message.role === "user" ? "bg-white/10" : "bg-emerald-500/10"
                }`}>
                  {message.role === "user" ? "U" : "A"}
                </div>
                <div className={`flex-1 space-y-2 items-${message.role === "user" ? "end" : "start"}`}>
                  <div className={`rounded-xl px-4 py-3 max-w-[85%] break-words ${
                    message.role === "user" 
                      ? "ml-auto bg-white/10" 
                      : "bg-black/40 backdrop-blur-sm"
                  }`}>
                    <p className="text-sm text-white/90 whitespace-pre-wrap">
                      {message.content}
                    </p>
                  </div>
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex gap-4 py-4">
                <div className="h-8 w-8 rounded-lg flex items-center justify-center text-sm bg-emerald-500/10">
                  A
                </div>
                <div className="flex-1 space-y-2 items-start">
                  <div className="rounded-xl px-4 py-3 max-w-[85%] break-words bg-black/40 backdrop-blur-sm">
                    <p className="text-sm text-white/90">AI is typing...</p>
                  </div>
                </div>
              </div>
            )}
          </div>
          <div ref={messagesEndRef} />
        </ScrollArea>
      )}

      <div className="fixed bottom-4 left-0 right-0 z-20">
        <div className="max-w-3xl mx-auto px-4">
          <div className="gradient-border shadow group-hover:shadow-green-500/20 relative bg-black rounded-xl overflow-hidden">
            <form onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }} className="relative">
              <div className={`transform transition-all duration-300 ease-in-out ${showCodeView ? 'translate-y-0 opacity-100' : '-translate-y-4 opacity-0 pointer-events-none'}`}>
                {showCodeView && (
                  <div className="p-3 md:p-4 group bg-black/95 backdrop-blur-2xl rounded-t-xl border-b border-white/10">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <h3 className="text-sm text-white/60">View Code</h3>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 hover:bg-white/10"
                          onClick={() => toggleContainer('code')}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                      <div className="flex gap-2 overflow-x-auto scrollbar-none py-1">
                        {["python", "javascript", "csharp", "blueprint", "shader"].map((lang) => (
                          <Button
                            key={lang}
                            variant="ghost"
                            size="sm"
                            className={`h-7 px-3 text-xs transition-all duration-200 ${
                              selectedLanguage === lang 
                                ? "bg-white/10 text-white" 
                                : "text-white/40 hover:text-white/60"
                            }`}
                            onClick={() => setSelectedLanguage(lang)}
                          >
                            #{lang}
                          </Button>
                        ))}
                      </div>
                      <div className="relative">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="absolute top-2 right-2 h-7 w-7 hover:bg-white/10"
                        >
                          <svg
                            className="h-4 w-4"
                            fill="none"
                            stroke="currentColor"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            viewBox="0 0 24 24"
                          >
                            <rect height="14" width="14" rx="2" ry="2" x="8" y="8" />
                            <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" />
                          </svg>
                        </Button>
                        <textarea
                          value={codeInput}
                          onChange={(e) => setCodeInput(e.target.value)}
                          className="w-full min-h-[300px] bg-[#0A0A0A] rounded-lg p-4 text-sm font-mono resize-none focus:outline-none border border-white/10 text-white/90 placeholder:text-white/20"
                          placeholder={`import torch\nimport torch.nn as nn\n\nclass Generator(nn.Module):\n    def __init__(self):\n        super(Generator, self).__init__()\n        # Your code here...`}
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className={`transform transition-all duration-300 ease-in-out ${showChatPrompts ? 'translate-y-0 opacity-100' : '-translate-y-4 opacity-0 pointer-events-none'}`}>
                {showChatPrompts && (
                  <div className="p-3 md:p-4 group bg-black/95 backdrop-blur-2xl rounded-t-xl border-b border-white/10">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <h3 className="text-sm text-white/60">Chat Prompts</h3>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 hover:bg-white/10"
                          onClick={() => toggleContainer('chat')}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                      <ScrollArea className="h-[300px]">
                        <div className="space-y-2">
                          {CHAT_PROMPTS.map((prompt) => (
                            <button
                              key={prompt.id}
                              onClick={() => handlePromptSelect(prompt.content)}
                              className="w-full text-left p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                            >
                              <h4 className="text-sm font-medium text-white/90">{prompt.title}</h4>
                              <p className="text-xs text-white/60 mt-1 line-clamp-2">{prompt.content}</p>
                            </button>
                          ))}
                        </div>
                      </ScrollArea>
                    </div>
                  </div>
                )}
              </div>

              <div className={`transform transition-all duration-300 ease-in-out ${showFileUpload ? 'translate-y-0 opacity-100' : '-translate-y-4 opacity-0 pointer-events-none'}`}>
                {showFileUpload && (
                  <div className="p-3 md:p-4 group bg-black/95 backdrop-blur-2xl rounded-t-xl border-b border-white/10">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <h3 className="text-sm text-white/60">Upload Files</h3>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 hover:bg-white/10"
                          onClick={() => toggleContainer('files')}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                      <div className="space-y-4">
                        <Button
                          variant="outline"
                          className="w-full border-dashed border-2 h-24 flex flex-col gap-2"
                          onClick={() => fileInputRef.current?.click()}
                        >
                          <Paperclip className="h-6 w-6" />
                          <span className="text-sm">Upload files</span>
                        </Button>
                        <input
                          type="file"
                          ref={fileInputRef}
                          className="hidden"
                          multiple
                          onChange={handleFileUpload}
                        />
                        {uploadedFiles.length > 0 && (
                          <ScrollArea className="h-[200px]">
                            <div className="space-y-2">
                              {uploadedFiles.map((file, index) => (
                                <div
                                  key={index}
                                  className="flex items-center gap-2 p-2 rounded-lg bg-white/5"
                                >
                                  <Paperclip className="h-4 w-4 text-white/60" />
                                  <span className="text-sm text-white/90">{file}</span>
                                </div>
                              ))}
                            </div>
                          </ScrollArea>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2 p-2 md:p-4 bg-black/95 backdrop-blur-lg border-t border-white/5">
                <div className="flex items-center gap-1">
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className={`h-8 w-8 md:h-9 md:w-9 rounded-lg transition-all duration-200 ${
                      showFileUpload 
                        ? "bg-white/10 text-green-400" 
                        : "bg-black hover:bg-white/10 hover:text-green-400"
                    }`}
                    onClick={() => toggleContainer('files')}
                  >
                    <Paperclip className="h-4 w-4 md:h-5 md:w-5" />
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => toggleContainer('code')}
                    className={`h-8 w-8 md:h-9 md:w-9 rounded-lg transition-all duration-200 ${
                      showCodeView 
                        ? "bg-white/10 text-green-400" 
                        : "bg-black hover:bg-white/10 hover:text-green-400"
                    }`}
                  >
                    <Code className="h-4 w-4 md:h-5 md:w-5" />
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => toggleContainer('chat')}
                    className={`h-8 w-8 md:h-9 md:w-9 rounded-lg transition-all duration-200 ${
                      showChatPrompts 
                        ? "bg-white/10 text-green-400" 
                        : "bg-black hover:bg-white/10 hover:text-green-400"
                    }`}
                  >
                    <MessageSquare className="h-4 w-4 md:h-5 md:w-5" />
                  </Button>
                </div>
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder={selectedPersona ? "Message Lovable..." : "Select a persona to start chatting..."}
                  className="flex-1 bg-transparent border-none focus:outline-none text-sm md:text-base text-white/90 placeholder:text-white/40"
                  disabled={!selectedPersona}
                />
                <Button
                  type="submit"
                  size="icon"
                  className="h-8 w-8 md:h-9 md:w-9 rounded-lg bg-green-500/20 hover:bg-green-500/30 disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={!inputValue.trim() || !selectedPersona}
                >
                  <Send className="h-4 w-4 md:h-5 md:w-5 text-green-400" />
                </Button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <ChatSettingsDialog 
        open={isSettingsOpen} 
        onOpenChange={setIsSettingsOpen}
        onPersonaSelect={handlePersonaSelect}
        selectedPersona={selectedPersona}
      />
    </div>
  );
};

export default ChatPanel;
