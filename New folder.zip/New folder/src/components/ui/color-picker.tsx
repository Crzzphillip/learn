
import React, { useState } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "./popover";
import { Input } from "./input";

interface ColorPickerProps {
  value?: string;
  onChange?: (value: string) => void;
}

export const ColorPicker: React.FC<ColorPickerProps> = ({ value = "#000000", onChange }) => {
  const [color, setColor] = useState(value);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newColor = e.target.value;
    setColor(newColor);
    onChange?.(newColor);
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <div className="flex items-center gap-2 cursor-pointer">
          <div
            className="w-5 h-5 rounded-sm border border-gray-300"
            style={{ backgroundColor: color }}
          />
          <Input
            value={color}
            onChange={handleChange}
            className="h-8 w-full"
          />
        </div>
      </PopoverTrigger>
      <PopoverContent className="w-56 p-3">
        <div className="space-y-2">
          <div>
            <input
              type="color"
              value={color}
              onChange={handleChange}
              className="w-full h-10 cursor-pointer"
            />
          </div>
          <Input
            value={color}
            onChange={handleChange}
            className="h-8"
          />
        </div>
      </PopoverContent>
    </Popover>
  );
};
