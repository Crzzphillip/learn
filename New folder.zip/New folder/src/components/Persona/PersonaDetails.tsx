
import { useState, useEffect } from "react";
import { AlertTriangle, BookOpen, Box, BrainCircuit, CheckCircle, LightbulbIcon, Sparkles, Terminal, HelpCircle, Copy } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { personaService } from "@/services/personaService";
import { PersonaData } from "@/data/personaData";

interface PersonaDetailsProps {
  personaId: string;
}

const PersonaDetails = ({ personaId }: PersonaDetailsProps) => {
  const [persona, setPersona] = useState<PersonaData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPersonaDetails = async () => {
      setLoading(true);
      const data = await personaService.getPersonaDetails(personaId);
      setPersona(data);
      setLoading(false);
    };

    fetchPersonaDetails();
  }, [personaId]);

  const copyPrompt = (prompt: string) => {
    navigator.clipboard.writeText(prompt);
    toast.success("Prompt copied to clipboard");
  };

  const getIconComponent = (iconName: string) => {
    const iconMap: Record<string, any> = {
      BrainCircuit: BrainCircuit,
      BookOpen: BookOpen,
      Sparkles: Sparkles,
      LightbulbIcon: LightbulbIcon,
      Terminal: Terminal,
      Box: Box
    };
    
    return iconMap[iconName] || Box;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!persona) {
    return (
      <div className="p-4 border border-red-300 bg-red-50 rounded-md text-red-800">
        Error loading persona details. Please try again later.
      </div>
    );
  }

  // Define default empty arrays for promptExamples and capabilities if they don't exist
  const promptExamples = persona.promptExamples || [];
  const capabilities = persona.capabilities || [];

  return (
    <div className="space-y-8">
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold">About this AI Persona</h2>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon">
                  <HelpCircle className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p className="max-w-xs">Learn about this AI persona's capabilities, limitations, and best practices for use.</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-card/50 border-primary/10">
            <CardHeader>
              <CardTitle>Description</CardTitle>
              <CardDescription>Comprehensive overview of this AI persona</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="leading-relaxed">{persona.description}</p>
              <p className="leading-relaxed">
                This AI persona is designed to assist with a variety of tasks related to {persona.category.toLowerCase()}, 
                providing expertise and guidance through natural conversation. It leverages advanced machine learning 
                techniques to understand context, generate insights, and adapt to your specific needs.
              </p>
              <p className="leading-relaxed">
                Whether you're looking for creative inspiration, technical assistance, or domain knowledge, 
                this persona aims to enhance your productivity and help you achieve your goals efficiently.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-primary/10">
            <CardHeader>
              <CardTitle>Specifications</CardTitle>
              <CardDescription>Technical details and performance metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Model Version</p>
                    <p className="font-medium">v2.3.5</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Parameters</p>
                    <p className="font-medium">170B</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Response Time</p>
                    <p className="font-medium">~1.2s avg</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Language Support</p>
                    <p className="font-medium">45+ languages</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Training Data</p>
                    <p className="font-medium">Up to 2023</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">API Integration</p>
                    <p className="font-medium">Full Support</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {promptExamples.length > 0 && (
        <div>
          <h2 className="text-2xl font-semibold mb-6">Example Prompts</h2>
          <Card className="bg-card/50 border-primary/10 mb-8">
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground mb-4">
                Try these example prompts to get started with this persona:
              </p>
              <Accordion type="single" collapsible className="w-full">
                {promptExamples.map((example, index) => (
                  <AccordionItem key={index} value={`item-${index}`}>
                    <AccordionTrigger className="text-base font-medium">
                      {example.title}
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="bg-muted/30 rounded-md p-3 relative">
                        <p className="text-sm pr-8">{example.prompt}</p>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="absolute top-2 right-2"
                          onClick={() => copyPrompt(example.prompt)}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </div>
      )}

      {capabilities.length > 0 && (
        <div>
          <h2 className="text-2xl font-semibold mb-6">Capabilities</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {capabilities.map((capability, index) => {
              const IconComponent = getIconComponent(capability.icon);
              return (
                <Card key={index} className="bg-card/50 border-primary/10">
                  <CardContent className="pt-6">
                    <div className="flex flex-col items-center text-center">
                      <div className="w-12 h-12 rounded-full bg-primary/20 grid place-items-center mb-4">
                        <IconComponent className="w-6 h-6 text-primary" />
                      </div>
                      <h3 className="text-lg font-medium mb-2">{capability.title}</h3>
                      <p className="text-sm text-muted-foreground">{capability.description}</p>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      <div>
        <h2 className="text-2xl font-semibold mb-6">Limitations</h2>
        <Card className="bg-card/50 border-primary/10">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-orange-500/20 grid place-items-center flex-shrink-0">
                <AlertTriangle className="w-5 h-5 text-orange-500" />
              </div>
              <div>
                <h3 className="text-lg font-medium mb-2">Known Limitations</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  While this AI persona is powerful, it's important to be aware of its limitations:
                </p>
                <ul className="space-y-2">
                  {persona.limitations.map((limitation, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <span className="h-5 w-5 flex-shrink-0 text-primary mt-0.5">•</span>
                      <span className="text-sm">{limitation}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div>
        <h2 className="text-2xl font-semibold mb-6">Best Practices</h2>
        <Card className="bg-card/50 border-primary/10">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-green-500/20 grid place-items-center flex-shrink-0">
                <CheckCircle className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <h3 className="text-lg font-medium mb-2">Get the Most Out of This Persona</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Follow these best practices to maximize your experience:
                </p>
                <div className="space-y-6">
                  <div>
                    <h4 className="font-medium mb-2">Be Specific in Your Requests</h4>
                    <p className="text-sm text-muted-foreground">
                      Provide clear, detailed instructions to get the most accurate and relevant responses.
                    </p>
                  </div>
                  <Separator />
                  <div>
                    <h4 className="font-medium mb-2">Provide Context</h4>
                    <p className="text-sm text-muted-foreground">
                      Include relevant background information to help the persona understand your needs better.
                    </p>
                  </div>
                  <Separator />
                  <div>
                    <h4 className="font-medium mb-2">Iterate and Refine</h4>
                    <p className="text-sm text-muted-foreground">
                      If you don't get the desired response initially, refine your query or provide feedback.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PersonaDetails;
