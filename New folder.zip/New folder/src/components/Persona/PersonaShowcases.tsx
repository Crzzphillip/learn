
import { useState, useEffect } from "react";
import { 
  User, 
  Calendar, 
  Copy, 
  ExternalLink, 
  ThumbsUp, 
  MessageSquare, 
  Code, 
  FileText, 
  Image as ImageIcon,
  Book
} from "lucide-react";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { personaService } from "@/services/personaService";
import { PersonaShowcase as PersonaShowcaseType } from "@/data/personaData";

interface PersonaShowcasesProps {
  personaId: string;
}

const PersonaShowcases = ({ personaId }: PersonaShowcasesProps) => {
  const [activeFilter, setActiveFilter] = useState("all");
  const [showcases, setShowcases] = useState<PersonaShowcaseType[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchShowcases = async () => {
      setLoading(true);
      const data = await personaService.getPersonaShowcases(personaId);
      setShowcases(data);
      setLoading(false);
    };

    fetchShowcases();
  }, [personaId]);

  const filteredShowcases = activeFilter === "all" 
    ? showcases 
    : showcases.filter(showcase => showcase.type === activeFilter);

  const handleCopyShowcase = async (id: string) => {
    await personaService.copyShowcase(id);
  };

  const renderPreview = (showcase: PersonaShowcaseType) => {
    switch (showcase.type) {
      case "code":
        return (
          <div className="bg-black/30 rounded-md p-4 overflow-auto max-h-96">
            <pre className="text-sm text-gray-300 font-mono">
              <code>{showcase.preview}</code>
            </pre>
          </div>
        );
      case "text":
        return (
          <div className="bg-black/30 rounded-md p-4 overflow-auto max-h-96">
            <div className="prose prose-sm prose-invert max-w-none">
              <pre className="text-sm text-gray-300 whitespace-pre-wrap font-mono">
                {showcase.preview}
              </pre>
            </div>
          </div>
        );
      case "image":
        return (
          <div className="rounded-md overflow-hidden bg-black/20">
            <img 
              src={showcase.preview} 
              alt={showcase.title} 
              className="w-full h-auto object-cover"
            />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-semibold">Community Showcases</h2>
        <Tabs 
          defaultValue="all" 
          value={activeFilter} 
          onValueChange={setActiveFilter}
          className="w-auto"
        >
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="code" className="flex items-center gap-1">
              <Code className="w-3.5 h-3.5" /> Code
            </TabsTrigger>
            <TabsTrigger value="text" className="flex items-center gap-1">
              <FileText className="w-3.5 h-3.5" /> Text
            </TabsTrigger>
            <TabsTrigger value="image" className="flex items-center gap-1">
              <ImageIcon className="w-3.5 h-3.5" /> Visuals
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-40">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      ) : (
        <div className="space-y-6">
          {filteredShowcases.length > 0 ? (
            filteredShowcases.map((showcase) => (
              <Card key={showcase.id} className="bg-card/50 border-primary/10">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4 mb-6">
                    <Avatar className="h-10 w-10 border border-primary/10">
                      <AvatarImage src={showcase.userAvatar} alt={showcase.user} />
                      <AvatarFallback>
                        <User className="h-5 w-5" />
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium">{showcase.user}</h4>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Calendar className="w-3.5 h-3.5 mr-1" />
                          {showcase.date}
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap gap-2 mt-1">
                        {showcase.type === "code" && (
                          <Badge variant="outline" className="bg-blue-500/10 text-blue-400 border-blue-500/20">
                            <Code className="w-3 h-3 mr-1" /> Code
                          </Badge>
                        )}
                        {showcase.type === "text" && (
                          <Badge variant="outline" className="bg-green-500/10 text-green-400 border-green-500/20">
                            <Book className="w-3 h-3 mr-1" /> Text
                          </Badge>
                        )}
                        {showcase.type === "image" && (
                          <Badge variant="outline" className="bg-purple-500/10 text-purple-400 border-purple-500/20">
                            <ImageIcon className="w-3 h-3 mr-1" /> Visual
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <h3 className="text-xl font-semibold mb-2">{showcase.title}</h3>
                  <p className="text-muted-foreground mb-4">{showcase.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {showcase.tags.map((tag: string) => (
                      <Badge key={tag} variant="secondary" className="bg-primary/10 border-none text-sm">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  {renderPreview(showcase)}
                </CardContent>
                
                <CardFooter className="border-t border-primary/10 py-3 px-6 flex items-center justify-between bg-black/10">
                  <div className="flex items-center gap-4">
                    <button className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors">
                      <ThumbsUp className="h-3.5 w-3.5" />
                      {showcase.likes}
                    </button>
                    <button className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors">
                      <MessageSquare className="h-3.5 w-3.5" />
                      {showcase.comments} comments
                    </button>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="gap-1" 
                      onClick={() => handleCopyShowcase(showcase.id)}
                    >
                      <Copy className="w-3.5 h-3.5" />
                      Remix
                    </Button>
                    <Button variant="outline" size="sm" className="gap-1">
                      <ExternalLink className="w-3.5 h-3.5" />
                      View Full
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))
          ) : (
            <Card className="bg-card/50 border-primary/10">
              <CardContent className="py-12 text-center">
                <p className="text-muted-foreground">No showcases found matching the selected filter.</p>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
};

export default PersonaShowcases;
