import { useState, useEffect } from "react";
import { User, Briefcase, ThumbsUp, MessageSquare, PlusCircle, HelpCircle, LightbulbIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { personaService } from "@/services/personaService";
import { PersonaUseCase } from "@/data/personaData";

interface PersonaUseCasesProps {
  personaId: string;
}

const PersonaUseCases = ({ personaId }: PersonaUseCasesProps) => {
  const [openDialog, setOpenDialog] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [industry, setIndustry] = useState("");
  const [results, setResults] = useState("");
  const [useCases, setUseCases] = useState<PersonaUseCase[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUseCases = async () => {
      setLoading(true);
      const data = await personaService.getPersonaUseCases(personaId);
      setUseCases(data);
      setLoading(false);
    };

    fetchUseCases();
  }, [personaId]);

  const handleSubmitUseCase = async () => {
    if (!title || !description || !industry || !results) {
      toast.error("Please fill all fields");
      return;
    }

    const useCaseData: Partial<PersonaUseCase> = {
      title,
      description,
      industry,
      results
    };

    const success = await personaService.submitUseCase(personaId, useCaseData);

    if (success) {
      setOpenDialog(false);
      
      setTitle("");
      setDescription("");
      setIndustry("");
      setResults("");
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-semibold">Success Stories</h2>
        <div className="flex items-center gap-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon">
                  <HelpCircle className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p className="max-w-xs">Share how you've used this AI persona in your workflow and the results you achieved.</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <Dialog open={openDialog} onOpenChange={setOpenDialog}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <PlusCircle className="w-4 h-4" />
                Share Your Story
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[550px]">
              <DialogHeader>
                <DialogTitle>Share Your Success Story</DialogTitle>
                <DialogDescription>
                  Tell the community how you've used this AI persona to achieve results.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="title" className="text-right">
                    Title
                  </Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="col-span-3"
                    placeholder="E.g., Content Creation Acceleration"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="industry" className="text-right">
                    Industry
                  </Label>
                  <Input
                    id="industry"
                    value={industry}
                    onChange={(e) => setIndustry(e.target.value)}
                    className="col-span-3"
                    placeholder="E.g., Marketing, Education, Healthcare"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="description" className="text-right">
                    Description
                  </Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="col-span-3"
                    placeholder="How did you use this AI persona?"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="results" className="text-right">
                    Results
                  </Label>
                  <Textarea
                    id="results"
                    value={results}
                    onChange={(e) => setResults(e.target.value)}
                    className="col-span-3"
                    placeholder="What outcomes or benefits did you achieve?"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" onClick={handleSubmitUseCase}>
                  Submit Story
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="bg-primary/5 border border-primary/10 rounded-lg p-4 mb-6">
        <div className="flex items-start gap-3">
          <div className="bg-primary/10 rounded-full p-2 mt-1">
            <LightbulbIcon className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h3 className="font-medium mb-1">Looking for inspiration?</h3>
            <p className="text-sm text-muted-foreground">
              Browse success stories below to see how others have leveraged this AI persona in their workflows. 
              Consider similar applications in your own projects and share your results!
            </p>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-40">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {useCases.map((useCase) => (
            <Card key={useCase.id} className="bg-card/50 border-primary/10 hover:border-primary/30 transition-colors">
              <CardContent className="p-0">
                <div className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <Avatar className="h-12 w-12 border-2 border-primary/20">
                      <AvatarImage src={useCase.userAvatar} alt={useCase.user} />
                      <AvatarFallback>
                        <User className="h-6 w-6 text-muted-foreground" />
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold">{useCase.user}</h3>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Briefcase className="w-3.5 h-3.5" />
                        <Badge variant="outline" className="bg-primary/5 text-xs font-normal">
                          {useCase.industry}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  <h4 className="text-lg font-medium mb-2">{useCase.title}</h4>
                  <p className="text-sm text-muted-foreground mb-4">{useCase.description}</p>
                  
                  <div className="border-t pt-4">
                    <div className="flex items-center gap-1 text-sm font-medium text-primary">
                      Results:
                    </div>
                    <p className="text-sm mt-1">{useCase.results}</p>
                  </div>
                </div>
                
                <div className="bg-muted/30 px-6 py-3 flex items-center justify-between text-xs text-muted-foreground">
                  <span>{useCase.date}</span>
                  <div className="flex items-center gap-4">
                    <button className="flex items-center gap-1 hover:text-primary transition-colors">
                      <ThumbsUp className="h-3.5 w-3.5" />
                      {useCase.likes || 0}
                    </button>
                    <button className="flex items-center gap-1 hover:text-primary transition-colors">
                      <MessageSquare className="h-3.5 w-3.5" />
                      Comment
                    </button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default PersonaUseCases;
