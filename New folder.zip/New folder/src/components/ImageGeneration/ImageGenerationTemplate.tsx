
import { Image, Palette, Wand, Sparkles } from "lucide-react";
import { SpaceTemplate, SpaceType } from "@/types/space";

export const getDefaultImageGenerationTemplate = (): SpaceTemplate => {
  return {
    title: "Image Generation Space",
    description: "Create, customize, and share AI-generated images with advanced models and tools.",
    type: "image-generation" as SpaceType,
    gradient: "from-[#D946EF] to-[#8B5CF6]",
    icon: Image,
    primaryColor: "#D946EF",
    secondaryColor: "#8B5CF6",
    accentColor: "#E5DEFF",
    features: [
      {
        id: "ai-models",
        title: "AI Model Listings & Discovery",
        description: "Browse and use different image-generation models",
        icon: Palette,
        category: "discovery",
        isAvailable: true
      },
      {
        id: "image-generation",
        title: "Image Generation Features",
        description: "Generate images from text, sketches, or reference images",
        icon: Image,
        category: "creation",
        isAvailable: true
      },
      {
        id: "model-customization",
        title: "AI Model Customization",
        description: "Fine-tune and train models on custom datasets",
        icon: Wand,
        category: "customization",
        isAvailable: true
      },
      {
        id: "style-customization",
        title: "Style Customization",
        description: "Modify outputs with prompts, weights, or control settings",
        icon: Sparkles,
        category: "editing",
        isAvailable: true
      }
    ],
    widgets: [
      {
        id: "image-preview",
        title: "Image Preview",
        type: "preview",
        size: "large",
        priority: 1
      },
      {
        id: "model-marketplace",
        title: "Model Marketplace",
        type: "marketplace",
        size: "medium",
        priority: 2
      },
      {
        id: "generation-history",
        title: "Generation History",
        type: "activity",
        size: "medium",
        priority: 3
      },
      {
        id: "control-panel",
        title: "Control Panel",
        type: "control-panel",
        size: "full",
        priority: 4
      }
    ]
  };
};

export default getDefaultImageGenerationTemplate;
