
import { Image, Wand, Sparkles, Lock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SpaceFeature } from "@/types/space";

interface ImageGenerationFeaturesProps {
  features: SpaceFeature[];
}

const ImageGenerationFeatures = ({ features }: ImageGenerationFeaturesProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
      {features.map((feature) => (
        <Card key={feature.id} className="bg-black/20 border border-white/10 hover:border-purple-500/30 hover:bg-black/30 transition-all duration-300">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <feature.icon className="w-5 h-5 text-purple-400" />
                {feature.title}
              </span>
              {!feature.isAvailable && (
                <Lock className="w-4 h-4 text-white/40" />
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-white/70 mb-4">{feature.description}</p>
            <Button 
              variant={feature.isAvailable ? "default" : "outline"} 
              className={feature.isAvailable ? "bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 w-full" : "w-full"}
              disabled={!feature.isAvailable}
            >
              {feature.isAvailable ? "Access Feature" : "Coming Soon"}
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default ImageGenerationFeatures;
