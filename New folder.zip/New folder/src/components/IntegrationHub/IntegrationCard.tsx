
import { IntegrationItem } from '@/data/integrationHubData';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useState } from 'react';
import { CheckCircle, XCircle, Info } from 'lucide-react';

interface IntegrationCardProps {
  integration: IntegrationItem;
  onConnect: (id: string) => void;
  onDisconnect: (id: string) => void;
}

const IntegrationCard = ({ integration, onConnect, onDisconnect }: IntegrationCardProps) => {
  const [isConnecting, setIsConnecting] = useState(false);
  
  const handleConnect = () => {
    setIsConnecting(true);
    setTimeout(() => {
      onConnect(integration.id);
      setIsConnecting(false);
    }, 1500);
  };
  
  const handleDisconnect = () => {
    onDisconnect(integration.id);
  };
  
  const getStatusBadge = () => {
    switch(integration.status) {
      case 'active':
        return <Badge className="bg-green-500">Active</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-500">Pending</Badge>;
      case 'inactive':
        return <Badge className="bg-gray-500">Inactive</Badge>;
      default:
        return null;
    }
  };
  
  return (
    <div className="border rounded-lg p-5 bg-card">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-12 h-12 rounded-lg overflow-hidden bg-muted grid place-items-center">
          {integration.imageUrl ? (
            <img src={integration.imageUrl} alt={integration.name} className="w-full h-full object-cover" />
          ) : (
            <Info className="w-6 h-6 text-muted-foreground" />
          )}
        </div>
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <h3 className="font-medium text-lg">{integration.name}</h3>
            {getStatusBadge()}
          </div>
          <p className="text-sm text-muted-foreground">{integration.description}</p>
        </div>
      </div>
      
      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">
          {integration.connectionCount > 0 
            ? `${integration.connectionCount} active connection${integration.connectionCount > 1 ? 's' : ''}` 
            : 'No active connections'}
        </div>
        <div className="flex gap-2">
          {integration.status === 'active' ? (
            <Button variant="outline" size="sm" className="gap-1" onClick={handleDisconnect}>
              <XCircle className="w-4 h-4" />
              Disconnect
            </Button>
          ) : (
            <Button size="sm" className="gap-1" onClick={handleConnect} disabled={isConnecting}>
              <CheckCircle className="w-4 h-4" />
              {isConnecting ? 'Connecting...' : 'Connect'}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default IntegrationCard;
