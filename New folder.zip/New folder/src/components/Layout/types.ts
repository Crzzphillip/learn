
import { LucideIcon } from "lucide-react";

export interface NavItem {
  id: string;
  label: string;
  icon: LucideIcon;
  path: string;
  badge?: string;
}

export interface AIAssistant {
  id: string;
  name: string;
  description: string;
  icon: LucideIcon;
  gradient: string;
}

export interface SearchHistoryItem {
  id: number;
  query: string;
  timestamp: string;
}
