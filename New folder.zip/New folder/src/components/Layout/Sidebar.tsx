import { useState } from "react";
import { useLocation, useParams, Link } from "react-router-dom";
import {
  Home, ChevronLeft, ChevronRight, Bot, GitBranch,
  AppWindow, Users, ChevronDown, Book, Bell, Settings,
  SquareUser, ListChecks, StickyNote
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { NAV_ITEMS } from "./constants";
import { SearchButton } from "./components/SearchButton";
import { NavigationSheet } from "./components/NavigationSheet";
import { WorkspaceButton } from "./components/WorkspaceButton";
import { WorkspaceTabs } from "./components/WorkspaceTabs";
import { ThemeToggle } from "@/components/Theme/ThemeToggle";
import { spaceTemplates } from "@/config/spaceTemplates";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

const Sidebar = () => {
  const location = useLocation();
  const { spaceId } = useParams();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(location.pathname.includes('/space/'));
  const [isMySpaceOpen, setIsMySpaceOpen] = useState(false);
  const [isCommunityOpen, setIsCommunityOpen] = useState(false);
  const isInSpace = location.pathname.startsWith('/space/');

  // Get current space template and icon
  const getCurrentSpaceTemplate = () => {
    if (!spaceId) return null;
    return spaceTemplates[spaceId] || null;
  };

  const spaceTemplate = getCurrentSpaceTemplate();

  // Get dynamic nav items based on the current space
  const getSpaceNavItems = () => {
    if (!spaceTemplate) {
      return [
        {
          label: "Overview",
          icon: Home,
          path: `/space/${spaceId}`
        },
        {
          label: "Agents",
          icon: Bot,
          path: `/space/${spaceId}/agents`
        },
        {
          label: "Workflows",
          icon: GitBranch,
          path: `/space/${spaceId}/workflows`
        },
        {
          label: "Apps",
          icon: AppWindow,
          path: `/space/${spaceId}/apps`
        }
      ];
    }

    // With space template, we can customize the nav items
    return [
      {
        label: "Overview",
        icon: Home,
        path: `/space/${spaceId}`
      },
      {
        label: "Agents",
        icon: Bot,
        path: `/space/${spaceId}/agents`
      },
      {
        label: "Workflows",
        icon: GitBranch,
        path: `/space/${spaceId}/workflows`
      },
      {
        label: "Apps",
        icon: AppWindow,
        path: `/space/${spaceId}/apps`
      },
      {
        label: "Community",
        icon: Users,
        path: `/community/${spaceId}`
      }
    ];
  };

  const spaceNavItems = getSpaceNavItems();

  // My Space sub-items
  const mySpaceItems = [
    {
      label: "My Library",
      icon: ListChecks,
      path: "/library"
    },
    {
      label: "Notifications",
      icon: Bell,
      path: "/notifications"
    },
    {
      label: "Settings",
      icon: Settings,
      path: "/settings"
    }
  ];

  const communityItems = [
    {
      label: "Overview",
      icon: Home,
      path: "/community",
    },
    {
      label: "Blogs",
      icon: Book,
      path: "/blog",
    },
    {
      label: "Showcases",
      icon: StickyNote,
      path: "/showcases",
    },
  ];


  return (
    <aside className={`${isCollapsed ? 'w-[80px]' : 'w-[280px]'} h-screen bg-black/20 backdrop-blur-xl border-r border-white/5 transition-all duration-300`}>
      <div className="flex flex-col h-full p-4">
        <div className={`flex items-center gap-3 px-2 mb-8 ${isCollapsed ? 'justify-center' : ''}`}>
          <div className="w-10 h-10 bg-gradient-to-br from-primary/20 to-primary/10 rounded-xl grid place-items-center">
            <Home className="w-5 h-5 text-primary" />
          </div>
          {!isCollapsed && (
            <span className="text-xl font-semibold bg-gradient-to-br from-white to-white/70 bg-clip-text text-transparent">
              AI Nexus
            </span>
          )}
        </div>

        <div className="space-y-2 mb-8">
          <SearchButton 
            isCollapsed={isCollapsed}
            isSearchOpen={isSearchOpen}
            setIsSearchOpen={setIsSearchOpen}
          />

          {location.pathname.includes('/') && (
            <NavigationSheet
              isCollapsed={isCollapsed}
              isInSpace={isInSpace}
              spaceNavItems={spaceNavItems}
              currentPath={location.pathname}
            />
          )}
        </div>

        <nav className="flex-1">
          <div className="space-y-1 mb-8">
            {/* Regular nav items */}
            {NAV_ITEMS.map((item) => {
              // Render the My Space collapsible section after the Blog item
              if (item.id === "community") {
                return (
                  <div key={"community"} className="space-y-1">
                    {/* Community collapsible section */}
                    <Collapsible
                      open={isCommunityOpen}
                      onOpenChange={setIsCommunityOpen}
                      className={`w-full rounded-xl transition-all duration-200 ${
                        isCollapsed ? "" : "hover:bg-white/5"
                      }`}
                    >
                      <CollapsibleTrigger asChild>
                        <div
                          className={`flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200 cursor-pointer ${
                            isCollapsed ? "justify-center" : ""
                          } ${
                            communityItems.some((item) =>
                              location.pathname.startsWith(item.path)
                            )
                              ? "bg-primary/20 text-primary"
                              : "text-white/60 hover:text-white"
                          }`}
                        >
                          <Users className="w-5 h-5" />
                          {!isCollapsed && (
                            <>
                              <span>Community</span>
                              <ChevronDown
                                className={`w-4 h-4 ml-auto transition-transform ${
                                  isCommunityOpen ? "rotate-180" : ""
                                }`}
                              />
                            </>
                          )}
                        </div>
                      </CollapsibleTrigger>
                      {!isCollapsed && (
                        <CollapsibleContent className="space-y-1 mt-1 pl-4">
                          {communityItems.map((item) => (
                            <Link
                              key={item.label}
                              to={item.path}
                              className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-all duration-200 ${
                                location.pathname === item.path
                                  ? "bg-primary/10 text-primary"
                                  : "hover:bg-white/5 text-white/60 hover:text-white"
                              }`}
                            >
                              <item.icon className="w-4 h-4" />
                              <span>{item.label}</span>
                            </Link>
                          ))}
                        </CollapsibleContent>
                      )}
                    </Collapsible>

                    {/* My Space collapsible section */}




                    <Collapsible
                      key={item.id}


                      open={isMySpaceOpen}
                      onOpenChange={setIsMySpaceOpen}
                      className={`w-full rounded-xl transition-all duration-200 ${
                        isCollapsed ? '' : 'hover:bg-white/5'
                      }`}
                    >
                      <CollapsibleTrigger asChild>
                        <div
                          className={`flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200 cursor-pointer ${
                            isCollapsed ? 'justify-center' : ''
                          } ${
                            mySpaceItems.some(item => location.pathname === item.path)
                              ? "bg-primary/20 text-primary" 
                              : "text-white/60 hover:text-white"
                          }`}
                        >
                          <SquareUser className="w-5 h-5" />
                          {!isCollapsed && (
                            <>
                              <span>My Space</span>
                              <ChevronDown className={`w-4 h-4 ml-auto transition-transform ${isMySpaceOpen ? 'rotate-180' : ''}`} />
                            </>
                          )}
                        </div>
                      </CollapsibleTrigger>
                      {!isCollapsed && (
                        <CollapsibleContent className="space-y-1 mt-1 pl-4">
                          {mySpaceItems.map((item) => (
                            <Link
                              key={item.label}
                              to={item.path}
                              className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-all duration-200 ${
                                location.pathname === item.path 
                                  ? "bg-primary/10 text-primary" 
                                  : "hover:bg-white/5 text-white/60 hover:text-white"
                              }`}
                            >
                              <item.icon className="w-4 h-4" />
                              <span>{item.label}</span>
                            </Link>
                          ))}
                        </CollapsibleContent>
                      )}
                    </Collapsible>
                  </div>

                );
              }

              
              // Render other nav items normally
              return (
                <Link
                  key={item.id}
                  to={item.path}
                  className={`flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200 group ${
                    isCollapsed ? 'justify-center' : ''
                  } ${
                    location.pathname === item.path 
                      ? "bg-primary/20 text-primary" 
                      : "hover:bg-white/5 text-white/60 hover:text-white"
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  {!isCollapsed && (
                    <>
                      <span>{item.label}</span>
                      {item.badge && (
                        <span className="ml-auto px-2 py-0.5 text-xs bg-white/10 rounded-full">
                          {item.badge}
                        </span>
                      )}
                    </>
                  )}
                </Link>
              );
            })}
          </div>
        </nav>

        <div className="pt-6 border-t border-white/5">
          <WorkspaceTabs isCollapsed={isCollapsed} />
        </div>

        <div className="flex items-center justify-between mt-4">
          <ThemeToggle />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <ChevronLeft className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
