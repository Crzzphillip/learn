
import { LucideIcon } from "lucide-react";

export interface RecentSpace {
  id: string;
  name: string;
  gradient: string;
}

export interface RecentItem {
  id: string;
  name: string;
  type: 'agent' | 'app' | 'workflow';
  icon: LucideIcon;
}

export interface SpaceNavItem {
  label: string;
  icon: LucideIcon;
  path: string;
}

export interface WorkspaceButtonProps {
  icon: React.ReactNode;
  name: string;
  badge?: string | number;
  isCollapsed: boolean;
  workspaceId?: string;
}

export type WorkspaceTabType = 'workspaces' | 'spaces' | 'agents' | 'workflows';

export interface WorkspaceTabItem {
  id: WorkspaceTabType;
  label: string;
}
