
import { Bot, GitBranch, AppWindow, Home } from "lucide-react";
import { RecentSpace, RecentItem } from "../types/sidebar";

export const RECENT_SPACES: RecentSpace[] = [
  { id: 'space-1', name: 'Development Hub', gradient: 'from-blue-500/20 to-cyan-500/20' },
  { id: 'space-2', name: 'Creative Studio', gradient: 'from-purple-500/20 to-pink-500/20' },
  { id: 'space-3', name: 'Content Lab', gradient: 'from-green-500/20 to-emerald-500/20' }
];

export const RECENT_ITEMS: RecentItem[] = [
  { id: 'item-1', name: 'Code Assistant', type: 'agent', icon: Bot },
  { id: 'item-2', name: 'Blog Writer', type: 'agent', icon: Bot },
  { id: 'item-3', name: 'Image Editor', type: 'app', icon: AppWindow },
  { id: 'item-4', name: 'Content Pipeline', type: 'workflow', icon: GitBranch },
  { id: 'item-5', name: 'SEO Optimizer', type: 'app', icon: AppWindow }
];
