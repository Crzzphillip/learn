
import { Link } from "react-router-dom";
import { Settings, Users, LayoutGrid, Wrench, Rocket } from "lucide-react";
import { SpaceNavItem } from "../types/sidebar";
import { Separator } from "@/components/ui/separator";
import { ActivityItem } from "./ActivityPreview";
import { spaceRecentActivity } from "./data/recentActivity";
import { Button } from "@/components/ui/button";
import { useParams } from "react-router-dom";

interface SpaceNavigationProps {
  spaceNavItems: SpaceNavItem[];
  currentPath: string;
}

export const SpaceNavigation = ({ spaceNavItems, currentPath }: SpaceNavigationProps) => {
  const { spaceId } = useParams();
  
  return (
    <div className="py-6 space-y-8">
      <div>
        <h2 className="text-xl font-semibold mb-4">Space Navigation</h2>
        <div className="grid grid-cols-2 gap-4">
          {spaceNavItems.map((item, index) => {
            const isActive = currentPath === item.path;
            return (
              <Link
                key={index}
                to={item.path}
                className={`p-4 rounded-lg flex items-center gap-3 transition-colors
                  ${isActive 
                    ? 'bg-white/10 text-white' 
                    : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10'
                  }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </Link>
            );
          })}
          
          <Link
            to={`/space/${spaceId}/workspaces`}
            className="p-4 rounded-lg flex items-center gap-3 transition-colors
              bg-white/5 text-white/60 hover:text-white hover:bg-white/10"
          >
            <LayoutGrid className="w-5 h-5" />
            <span className="font-medium">Workspaces</span>
          </Link>
          
          <Link
            to={`/space/${spaceId}/tools`}
            className={`p-4 rounded-lg flex items-center gap-3 transition-colors
              ${currentPath === `/space/${spaceId}/tools` 
                ? 'bg-white/10 text-white' 
                : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10'
              }`}
          >
            <Wrench className="w-5 h-5" />
            <span className="font-medium">Tools</span>
          </Link>
        </div>
      </div>

      <div>
        <h3 className="text-xl font-semibold mb-4">Community Access</h3>
        <div className="bg-white/5 rounded-lg p-6">
          <p className="text-white/60 mb-4">
            Join the community space to collaborate with other members, participate in discussions, and share resources.
          </p>
          <Link to={`/community/${spaceId}`}>
            <Button className="w-full gap-2 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700">
              <Users className="w-4 h-4" />
              Enter Community Space
            </Button>
          </Link>
        </div>
      </div>

      <div>
        <h3 className="text-xl font-semibold mb-4">Space Management</h3>
        <div className="bg-white/5 rounded-lg p-6">
          <p className="text-white/60 mb-4">
            Manage your space settings, members, and configurations.
          </p>
          <Button variant="outline" className="w-full gap-2 bg-white/5 hover:bg-white/10">
            <Settings className="w-4 h-4" />
            Manage Settings
          </Button>
        </div>
      </div>

      <Separator className="bg-white/10" />

      <div>
        <h3 className="text-lg font-medium text-white/60 mb-4">Recent Activity in This Space</h3>
        <div className="grid grid-cols-2 gap-4">
          {spaceRecentActivity.map((item) => (
            <ActivityItem key={item.id} {...item} />
          ))}
        </div>
      </div>
    </div>
  );
};
