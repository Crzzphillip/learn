
import { ArrowUpRight, Clock, LucideIcon } from "lucide-react";
import { Link } from "react-router-dom";

interface ActivityItemProps {
  id: string;
  title: string;
  timestamp: string;
  icon: LucideIcon;
  description?: string;
  gradient?: string;
}

export const ActivityItem = ({ title, timestamp, icon: Icon, description, gradient }: ActivityItemProps) => (
  <div className="p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer group h-full">
    <div className="flex items-start gap-3">
      <div className={`w-8 h-8 rounded-lg ${gradient || 'bg-white/10'} grid place-items-center flex-shrink-0`}>
        <Icon className="w-4 h-4" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between">
          <span className="font-medium">{title}</span>
          <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>
        {description && (
          <p className="text-sm text-white/40 truncate">{description}</p>
        )}
        <div className="flex items-center gap-2 mt-1">
          <Clock className="w-3 h-3 text-white/40" />
          <span className="text-xs text-white/40">{timestamp}</span>
        </div>
      </div>
    </div>
  </div>
);

interface QuickAccessItemProps {
  id: string;
  name: string;
  type: string;
  icon: LucideIcon;
  gradient?: string;
}

export const QuickAccessItem = ({ name, type, icon: Icon, gradient }: QuickAccessItemProps) => (
  <Link
    to="#"
    className="px-4 py-3 rounded-lg flex items-center gap-3 text-sm transition-colors hover:bg-white/5 group h-full"
  >
    <div className={`w-8 h-8 rounded-lg ${gradient || 'bg-white/5'} grid place-items-center`}>
      <Icon className="w-4 h-4" />
    </div>
    <div className="flex-1">
      <span>{name}</span>
      <span className="ml-2 text-xs text-white/40 capitalize">· {type}</span>
    </div>
    <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
  </Link>
);
