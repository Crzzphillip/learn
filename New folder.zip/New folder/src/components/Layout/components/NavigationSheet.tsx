
import { AppWindow, ArrowUpRight, Home, Bitcoin, Image } from "lucide-react";
import { Link, useLocation, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { RECENT_SPACES, RECENT_ITEMS } from "../constants/sidebarData";
import { SpaceNavItem } from "../types/sidebar";
import { SpaceNavigation } from "./SpaceNavigation";
import { ActivityItem, QuickAccessItem } from "./ActivityPreview";
import { recentActivity } from "./data/recentActivity";
import SpaceNavigationDialog from "@/components/Space/SpaceNavigationDialog";
import { useState, useEffect } from "react";
import { spaceTemplates } from "@/config/spaceTemplates";

interface NavigationSheetProps {
  isCollapsed: boolean;
  isInSpace: boolean;
  spaceNavItems: SpaceNavItem[];
  currentPath: string;
}

export const NavigationSheet = ({
  isCollapsed,
  isInSpace,
  spaceNavItems,
  currentPath
}: NavigationSheetProps) => {
  const location = useLocation();
  const { spaceId } = useParams();
  const isExplorePage = location.pathname.startsWith('/explore');
  const isSpaceRoot = /^\/space\/[^/]+$/.test(location.pathname);
  const [isSpaceDialogOpen, setIsSpaceDialogOpen] = useState(false);
  const [isGlowing, setIsGlowing] = useState(isSpaceRoot);

  useEffect(() => {
    setIsGlowing(isSpaceRoot);
  }, [isSpaceRoot]);

  // Get current space template and icon
  const getSpaceIcon = () => {
    if (!spaceId) return AppWindow;
    
    const template = spaceTemplates[spaceId];
    if (!template) return AppWindow;
    
    return template.icon;
  };

  const SpaceIcon = getSpaceIcon();
  
  // Get space name
  const getSpaceName = () => {
    if (!spaceId) return 'Space';
    
    const template = spaceTemplates[spaceId];
    if (!template) return 'Space';
    
    // Get a short name based on the title
    const words = template.title.split(' ');
    return words.length > 1 && words[1] !== 'Space' ? words[0] : template.title;
  };
  
  const spaceName = getSpaceName();
  
  // If we're in a space, use the dialog instead of the sheet
  if (isInSpace && spaceId) {
    return (
      <>
        <Button 
          variant="ghost" 
          className={`w-full ${isCollapsed ? 'justify-center' : 'justify-start'} 
            ${isInSpace ? 'bg-white/10 text-white' : 'text-white/60 hover:text-white hover:bg-white/5'}
            ${isGlowing ? 'ring-2 ring-primary animate-pulse transition-all duration-1000' : ''}
            ${isSpaceRoot ? 'ring-2 ring-primary/20' : ''}
          `}
          onClick={() => {
            setIsSpaceDialogOpen(true);
            setIsGlowing(false);
          }}
        >
          <SpaceIcon className="w-5 h-5" />
          {!isCollapsed && (
            <span className="flex items-center gap-2">
              {spaceName} Navigation
              {isSpaceRoot && (
                <span className="px-1.5 py-0.5 rounded-full bg-primary/20 text-primary text-xs">
                  Active
                </span>
              )}
            </span>
          )}
        </Button>
        
        <SpaceNavigationDialog
          open={isSpaceDialogOpen}
          onOpenChange={setIsSpaceDialogOpen}
          spaceNavItems={spaceNavItems}
          currentPath={currentPath}
          spaceId={spaceId}
        />
      </>
    );
  }

  // Original sheet for non-space pages
  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button 
          variant="ghost" 
          className={`w-full ${isCollapsed ? 'justify-center' : 'justify-start'} 
            ${isInSpace ? 'bg-white/10 text-white' : 'text-white/60 hover:text-white hover:bg-white/5'}
            ${isSpaceRoot ? 'ring-2 ring-primary/20' : ''}
          `}
        >
          <AppWindow className="w-5 h-5" />
          {!isCollapsed && (
            <span className="flex items-center gap-2">
              Space Navigation
              {isSpaceRoot && (
                <span className="px-1.5 py-0.5 rounded-full bg-primary/20 text-primary text-xs">
                  Active
                </span>
              )}
            </span>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent 
        side="right" 
        className="w-[900px] max-w-3xl bg-black/80 backdrop-blur-xl border-white/10"
      >
        <ScrollArea className="h-full pr-4">
          {isInSpace ? (
            <SpaceNavigation spaceNavItems={spaceNavItems} currentPath={currentPath} />
          ) : (
            <div className="py-6">
              {isExplorePage ? (
                <div className="space-y-8">
                  <div>
                    <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
                    <div className="grid grid-cols-2 gap-4">
                      {recentActivity.map(activity => (
                        <ActivityItem key={activity.id} {...activity} />
                      ))}
                    </div>
                  </div>

                  <Separator className="bg-white/10" />

                  <div>
                    <h2 className="text-xl font-semibold mb-4">Quick Access</h2>
                    <div className="grid grid-cols-2 gap-4">
                      {RECENT_ITEMS.map(item => (
                        <QuickAccessItem key={item.id} {...item} />
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div>
                  <h2 className="text-xl font-semibold mb-4">Recent Spaces</h2>
                  <div className="grid grid-cols-2 gap-4">
                    {RECENT_SPACES.map(space => (
                      <Link
                        key={space.id}
                        to={`/space/${space.id}`}
                        className="p-4 rounded-lg bg-white/5 flex items-center gap-3 transition-colors hover:bg-white/10 group h-full"
                      >
                        <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${space.gradient} grid place-items-center`}>
                          <Home className="w-5 h-5" />
                        </div>
                        <span className="flex-1 font-medium">{space.name}</span>
                        <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
};
