
import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { workspaceTabsService } from "@/services/workspaceTabsService";
import { WorkspaceTabType, WorkspaceTabItem } from "../types/sidebar";
import { WorkspaceButton } from "./WorkspaceButton";

interface WorkspaceTabsProps {
  isCollapsed: boolean;
}

const TABS: WorkspaceTabItem[] = [
  { id: "workspaces", label: "Workspaces" },
  { id: "spaces", label: "Spaces" },
  { id: "agents", label: "Agents" },
  { id: "workflows", label: "Workflows" }
];

export const WorkspaceTabs: React.FC<WorkspaceTabsProps> = ({ isCollapsed }) => {
  const [activeTab, setActiveTab] = useState<WorkspaceTabType>("workspaces");
  const [recentSpaces, setRecentSpaces] = useState([]);
  const [recentAgents, setRecentAgents] = useState([]);
  const [recentWorkflows, setRecentWorkflows] = useState([]);
  const [recentApps, setRecentApps] = useState([]);
  const tabsContainerRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    // Fetch data for each tab
    setRecentSpaces(workspaceTabsService.getRecentSpaces());
    setRecentAgents(workspaceTabsService.getRecentAgents());
    setRecentWorkflows(workspaceTabsService.getRecentWorkflows());
    setRecentApps(workspaceTabsService.getRecentApps());
  }, []);

  const scrollTabs = (direction: 'left' | 'right') => {
    if (tabsContainerRef.current) {
      const scrollAmount = 80; // Adjust as needed
      const currentScroll = tabsContainerRef.current.scrollLeft;
      tabsContainerRef.current.scrollTo({
        left: direction === 'left' ? currentScroll - scrollAmount : currentScroll + scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  // Only render the tabs if sidebar is not collapsed
  if (isCollapsed) {
    return <span className="px-2 text-sm font-medium text-white/40 mb-3 block">WS</span>;
  }

  return (
    <div className="space-y-3">
      {/* Tabs container with navigation buttons */}
      <div className="relative flex items-center">
        <button 
          onClick={() => scrollTabs('left')}
          className="absolute left-0 z-20 w-5 h-5 flex items-center justify-center rounded-full bg-black/30 text-white/60 hover:text-white/80 hover:bg-black/40 backdrop-blur-sm"
        >
          <ChevronLeft className="w-3 h-3" />
        </button>
        
        <div className="overflow-x-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] pb-1 px-5" ref={tabsContainerRef}>
          <div className="flex gap-1 relative">
            <div className="flex whitespace-nowrap bg-black/30 backdrop-blur-sm rounded-lg p-1">
              {TABS.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`relative px-3 py-1 text-xs font-medium rounded-md transition-colors z-10
                    ${activeTab === tab.id ? 'text-white' : 'text-white/60 hover:text-white/80'}`}
                >
                  {activeTab === tab.id && (
                    <motion.div
                      layoutId="tab-highlight"
                      className="absolute inset-0 bg-white/10 rounded-md -z-10"
                      transition={{ type: "spring", duration: 0.5 }}
                    />
                  )}
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        <button 
          onClick={() => scrollTabs('right')}
          className="absolute right-0 z-20 w-5 h-5 flex items-center justify-center rounded-full bg-black/30 text-white/60 hover:text-white/80 hover:bg-black/40 backdrop-blur-sm"
        >
          <ChevronRight className="w-3 h-3" />
        </button>
      </div>

      {/* Content for the active tab - with custom scrollbar */}
      <div className="max-h-[120px] overflow-y-auto pr-1 hover:pr-0 transition-all duration-200 
                      [&::-webkit-scrollbar]:w-1.5 
                      [&::-webkit-scrollbar-track]:rounded-full 
                      [&::-webkit-scrollbar-track]:bg-transparent
                      [&::-webkit-scrollbar-thumb]:rounded-full
                      [&::-webkit-scrollbar-thumb]:bg-gray-800/50
                      [&::-webkit-scrollbar-thumb:hover]:bg-gray-700/50">
        {activeTab === "workspaces" && (
          <div className="space-y-1">
            <WorkspaceButton
              icon={<div className="w-5 h-5 rounded bg-gradient-to-br from-purple-500/20 to-blue-500/20 flex-shrink-0" />}
              name="Blaze's Workspace"
              isCollapsed={isCollapsed}
              workspaceId="blaze-workspace"
            />
            <WorkspaceButton
              icon={<div className="w-5 h-5 rounded bg-gradient-to-br from-emerald-500/20 to-teal-500/20 flex-shrink-0" />}
              name="Prod workspace"
              badge="12"
              isCollapsed={isCollapsed}
              workspaceId="prodigies-workspace"
            />
             <WorkspaceButton
              icon={<div className="w-5 h-5 rounded bg-gradient-to-br from-emerald-500/20 to-teal-500/20 flex-shrink-0" />}
              name="leonardo canvas"
              badge="12"
              isCollapsed={isCollapsed}
              workspaceId="canvas-1"
            />
          </div>
        )}

        {activeTab === "spaces" && (
          <div className="space-y-1">
            {recentSpaces.map((space) => (
              <Link 
                key={space.id}
                to={`/space/${space.id}`}
                className="flex items-center gap-3 px-4 py-2.5 rounded-xl hover:bg-white/5 transition-colors text-white/60 hover:text-white"
              >
                <div className={`w-5 h-5 rounded bg-gradient-to-br ${space.gradient} flex-shrink-0`} />
                <span>{space.name}</span>
              </Link>
            ))}
          </div>
        )}

        {activeTab === "agents" && (
          <div className="space-y-1">
            {recentAgents.map((agent) => (
              <Link 
                key={agent.id}
                to={`/agent/${agent.id}`}
                className="flex items-center gap-3 px-4 py-2.5 rounded-xl hover:bg-white/5 transition-colors text-white/60 hover:text-white"
              >
                <agent.icon className="w-5 h-5 text-primary/70" />
                <span>{agent.name}</span>
              </Link>
            ))}
          </div>
        )}

        {activeTab === "workflows" && (
          <div className="space-y-1">
            {recentWorkflows.map((workflow) => (
              <Link 
                key={workflow.id}
                to={`/workflow/${workflow.id}`}
                className="flex items-center gap-3 px-4 py-2.5 rounded-xl hover:bg-white/5 transition-colors text-white/60 hover:text-white"
              >
                <workflow.icon className="w-5 h-5 text-primary/70" />
                <span>{workflow.name}</span>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
