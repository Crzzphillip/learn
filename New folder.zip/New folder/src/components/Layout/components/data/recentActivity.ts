
import { Bot, GitBranch, AppWindow, Home, Clock } from "lucide-react";

// Mock recent activity data for the current space
export const spaceRecentActivity = [
  {
    id: '1',
    type: 'agent',
    title: 'Code Assistant',
    timestamp: '1 hour ago',
    icon: Bot,
    description: 'Used the code assistant to refactor components'
  },
  {
    id: '2',
    type: 'workflow',
    title: 'Blog Pipeline',
    timestamp: '3 hours ago',
    icon: GitBranch,
    description: 'Updated the content workflow'
  },
  {
    id: '3',
    type: 'app',
    title: 'Content Editor',
    timestamp: '5 hours ago',
    icon: AppWindow,
    description: 'Created a new draft'
  }
];

// Mock recent activity data - in a real app, this would come from an API/state
export const recentActivity = [
  {
    id: '1',
    type: 'workflow',
    title: 'Content Pipeline',
    timestamp: '2 hours ago',
    icon: Clock
  },
  {
    id: '2',
    type: 'app',
    title: 'Blog Generator',
    timestamp: '3 hours ago',
    icon: AppWindow
  },
  {
    id: '3',
    type: 'space',
    title: 'Development Hub',
    timestamp: '5 hours ago',
    icon: Home
  }
];
