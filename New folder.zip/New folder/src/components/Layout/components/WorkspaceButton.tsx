
import { useNavigate } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import { WorkspaceButtonProps } from "../types/sidebar";

export const WorkspaceButton = ({ icon, name, badge, isCollapsed, workspaceId = "default" }: WorkspaceButtonProps) => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(`/workspace/${workspaceId}/run`);
  };

  return (
    <button 
      className={`w-full px-4 py-2.5 rounded-xl hover:bg-white/5 transition-colors flex items-center gap-3 text-white/60 hover:text-white ${
        isCollapsed ? 'justify-center' : ''
      }`}
      onClick={handleClick}
    >
      {icon}
      {!isCollapsed && (
        <>
          <span>{name}</span>
          {badge ? (
            <span className="ml-auto px-2 py-0.5 text-xs bg-white/10 rounded-full">{badge}</span>
          ) : (
            <ChevronRight className="w-4 h-4 ml-auto opacity-40" />
          )}
        </>
      )}
    </button>
  );
};
