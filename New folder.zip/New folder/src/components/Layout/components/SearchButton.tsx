
import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { SearchDialog } from "../SearchDialog";
import { NAV_ITEMS, AI_ASSISTANTS } from "../constants";

interface SearchButtonProps {
  isCollapsed: boolean;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
}

export const SearchButton = ({ isCollapsed, isSearchOpen, setIsSearchOpen }: SearchButtonProps) => {
  return (
    <Dialog open={isSearchOpen} onOpenChange={setIsSearchOpen}>
      {isCollapsed ? (
        <Button
          variant="ghost"
          size="icon"
          className="w-full h-10 flex justify-center items-center"
          onClick={() => setIsSearchOpen(true)}
        >
          <Search className="w-5 h-5" />
        </Button>
      ) : (
        <button 
          className="w-full px-4 py-2.5 text-sm bg-white/5 rounded-xl border border-white/5 hover:bg-white/10 transition-colors text-white/60 flex items-center gap-2"
          onClick={() => setIsSearchOpen(true)}
        >
          <Search className="w-4 h-4" />
          <span>Search or jump to...</span>
          <kbd className="ml-auto text-xs bg-white/10 px-2 py-0.5 rounded">⌘K</kbd>
        </button>
      )}
      <SearchDialog 
        open={isSearchOpen} 
        onOpenChange={setIsSearchOpen}
        navItems={NAV_ITEMS}
        aiAssistants={AI_ASSISTANTS}
      />
    </Dialog>
  );
};
