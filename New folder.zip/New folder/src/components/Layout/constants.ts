
import { Home, Library, Users, Settings, Globe, Code, Palette, MessageSquare, Newspaper } from "lucide-react";
import { AIAssistant, NavItem } from "./types";

export const NAV_ITEMS: NavItem[] = [
  { id: "home", label: "Home", icon: Home, path: "/home" },
  { id: "explore", label: "Explore", icon: Globe, path: "/explore" },
  { id: "create", label: "Create", icon: Code, path: "/create" },
  { id: "community", label: "Community", icon: Users, path: "/community" },
];

export const AI_ASSISTANTS: AIAssistant[] = [
  {
    id: "code-assistant",
    name: "Code Assistant",
    description: "Your AI programming partner",
    icon: Code,
    gradient: "from-blue-500/20 to-cyan-500/20"
  },
  {
    id: "creative",
    name: "Creative AI",
    description: "Design and creative tasks",
    icon: Palette,
    gradient: "from-purple-500/20 to-pink-500/20"
  },
  {
    id: "chat",
    name: "Chat Assistant",
    description: "Natural conversation AI",
    icon: MessageSquare,
    gradient: "from-green-500/20 to-emerald-500/20"
  }
];
