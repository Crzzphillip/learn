
import { Clock, Search } from "lucide-react";
import { Link } from "react-router-dom";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useState } from "react";
import { AIAssistant, NavItem, SearchHistoryItem } from "./types";

interface SearchDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  navItems: NavItem[];
  aiAssistants: AIAssistant[];
}

const searchHistory: SearchHistoryItem[] = [
  { id: 1, query: "code generation", timestamp: "2 days ago" },
  { id: 2, query: "image processing", timestamp: "3 days ago" },
  { id: 3, query: "chatbot templates", timestamp: "1 week ago" },
  { id: 4, query: "workflow automation", timestamp: "2 weeks ago" },
];

export function SearchDialog({ open, onOpenChange, navItems, aiAssistants }: SearchDialogProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredHistory = searchQuery
    ? searchHistory.filter(item => 
        item.query.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : searchHistory;

  return (
    <DialogContent className="sm:max-w-[640px] bg-black/95 backdrop-blur-xl border-white/10">
      <DialogTitle className="text-lg font-semibold mb-4">Search</DialogTitle>
      <div className="flex items-center gap-2 mb-2">
        <Search className="w-5 h-5 text-white/60" />
        <input
          type="text"
          placeholder="Search or jump to..."
          className="flex-1 bg-transparent border-none text-white/90 placeholder:text-white/40 focus:outline-none"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          autoFocus
        />
        <kbd className="text-xs bg-white/10 px-2 py-1 rounded">ESC</kbd>
      </div>

      {searchQuery && filteredHistory.length > 0 && (
        <div className="mb-4 border-b border-white/10 pb-4">
          <div className="flex items-center gap-2 text-sm text-white/40 mb-2">
            <Clock className="w-4 h-4" />
            <span>Recent searches</span>
          </div>
          <div className="space-y-1">
            {filteredHistory.map((item) => (
              <button
                key={item.id}
                className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5 transition-colors flex items-center gap-3 group"
                onClick={() => setSearchQuery(item.query)}
              >
                <Search className="w-4 h-4 text-white/40" />
                <span className="flex-1">{item.query}</span>
                <span className="text-xs text-white/40">{item.timestamp}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      <ScrollArea className="h-[400px] -mx-6 px-6">
        <div className="space-y-6">
          <div>
            <h4 className="text-sm font-medium text-white/40 mb-3">Jump to</h4>
            <div className="flex flex-wrap gap-2">
              {navItems.map((item) => (
                <Link
                  key={item.id}
                  to={item.path}
                  className="px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 transition-colors text-white/80 hover:text-white flex items-center gap-2 text-sm"
                  onClick={() => onOpenChange(false)}
                >
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium text-white/40 mb-3">AI Assistants</h4>
            <div className="grid grid-cols-2 gap-3">
              {aiAssistants.map((assistant) => (
                <button
                  key={assistant.id}
                  className={`p-4 rounded-xl bg-gradient-to-br ${assistant.gradient} hover:bg-opacity-30 transition-all duration-300 group text-left`}
                  onClick={() => {
                    onOpenChange(false);
                    const fluxAssistant = document.querySelector('[data-testid="flux-assistant"]') as HTMLElement;
                    if (fluxAssistant) {
                      fluxAssistant.style.display = 'block';
                    }
                  }}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-white/10 grid place-items-center">
                      <assistant.icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">{assistant.name}</h3>
                      <p className="text-sm text-white/60">{assistant.description}</p>
                    </div>
                  </div>
                  <div className="h-0.5 w-0 group-hover:w-full bg-gradient-to-r from-white/20 to-transparent mt-3 transition-all duration-300" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </ScrollArea>
    </DialogContent>
  );
}
