
import { useState, useEffect, useRef } from 'react';
import { Bot, X, Minus, Send, Code, Image, Paperclip } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from '@/hooks/use-toast';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  status?: 'typing' | 'complete';
  messageType?: 'text' | 'code' | 'action';
}

export interface FluxAssistantProps {
  onSendMessage?: (message: string) => void;
  initialMessages?: Message[];
}

const FluxAssistant = ({ onSendMessage, initialMessages = [] }: FluxAssistantProps) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isVisible, setIsVisible] = useState(true);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: message,
      timestamp: new Date(),
      messageType: 'text'
    };

    setMessages(prev => [...prev, userMessage]);
    setMessage('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: "I'm here to help you build and customize your workflow. What would you like to do?",
        timestamp: new Date(),
        messageType: 'text'
      };
      setMessages(prev => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 1000);

    // Call the onSendMessage prop if provided
    if (onSendMessage) {
      onSendMessage(message);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  // Toggle chat visibility
  const toggleChat = () => {
    setIsExpanded(!isExpanded);
    if (!isExpanded && messages.length === 0) {
      // Set a welcome message when opening empty chat
      const welcomeMessage: Message = {
        id: Date.now().toString(),
        type: 'assistant',
        content: "Hello! I'm Flux, your workflow assistant. How can I help you today?",
        timestamp: new Date(),
        messageType: 'text'
      };
      setMessages([welcomeMessage]);
    }
  };

  // Close flux assistant
  const closeAssistant = () => {
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <>
      {/* Glassmorphic overlay that appears when expanded */}
      {isExpanded && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-40">
          {/* Messages are displayed directly on the glassmorphic background */}
          <div className="fixed inset-0 z-40 flex flex-col justify-end items-center pb-24 pointer-events-none">
            <div className="w-[85%] max-w-3xl pointer-events-auto">
              <ScrollArea className="h-[400px] pr-4 transparent">
                <div className="space-y-4 p-4">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex gap-3 ${
                        msg.type === 'user' ? 'flex-row-reverse' : ''
                      }`}
                    >
                      <div
                        className={`w-8 h-8 rounded-lg grid place-items-center ${
                          msg.type === 'user'
                            ? 'bg-primary/20'
                            : 'bg-emerald-500/20'
                        }`}
                      >
                        {msg.type === 'user' ? (
                          'U'
                        ) : (
                          <Bot className="w-4 h-4 text-emerald-500" />
                        )}
                      </div>
                      <div
                        className={`flex-1 rounded-lg p-3 text-sm ${
                          msg.type === 'user'
                            ? 'bg-primary/10 backdrop-blur-sm ml-12 text-white'
                            : 'bg-white/10 backdrop-blur-sm mr-12 text-white'
                        }`}
                      >
                        {msg.content}
                      </div>
                    </div>
                  ))}
                  {isTyping && (
                    <div className="flex gap-3">
                      <div className="w-8 h-8 rounded-lg bg-emerald-500/20 grid place-items-center">
                        <Bot className="w-4 h-4 text-emerald-500" />
                      </div>
                      <div className="flex-1 rounded-lg p-3 text-sm bg-white/10 backdrop-blur-sm mr-12 text-white">
                        Typing...
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </ScrollArea>
            </div>
          </div>
        </div>
      )}
    
      <div 
        className={`fixed z-50 transition-all duration-300 ${
          isExpanded 
            ? 'bottom-0 left-1/2 -translate-x-1/2 w-[85%] max-w-3xl mb-4' 
            : 'bottom-4 right-4'
        }`}
      >
        <div className={`bg-background/95 backdrop-blur-xl rounded-xl border shadow-lg ${
          !isExpanded ? 'p-1 flex items-center gap-1' : ''
        }`}>
          {isExpanded ? (
            <>
              <div className="flex items-center gap-3 p-4 border-b">
                <div className="w-10 h-10 rounded-full bg-emerald-500/10 grid place-items-center">
                  <Bot className="w-5 h-5 text-emerald-500" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold">Flux</h3>
                  <p className="text-xs text-muted-foreground">Workflow Assistant</p>
                </div>
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={toggleChat}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 hover:bg-destructive/90 hover:text-destructive-foreground"
                    onClick={closeAssistant}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="p-4">
                <div className="flex gap-2">
                  <div className="flex items-center gap-1">
                    <Button type="button" variant="ghost" size="icon" className="h-8 w-8">
                      <Code className="h-4 w-4" />
                    </Button>
                    <Button type="button" variant="ghost" size="icon" className="h-8 w-8">
                      <Image className="h-4 w-4" />
                    </Button>
                    <Button type="button" variant="ghost" size="icon" className="h-8 w-8">
                      <Paperclip className="h-4 w-4" />
                    </Button>
                  </div>
                  <Textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Message Flux..."
                    className="min-h-[40px] flex-1 resize-none"
                    rows={1}
                  />
                  <Button
                    type="submit"
                    disabled={!message.trim() || isTyping}
                    size="icon"
                    className="h-10 w-10"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </form>
            </>
          ) : (
            <>
              <div className="w-8 h-8 rounded-full bg-emerald-500/10 grid place-items-center">
                <Bot className="w-4 h-4 text-emerald-500" />
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={toggleChat}
              >
                <Minus className="h-3 w-3" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 hover:bg-destructive/90 hover:text-destructive-foreground"
                onClick={closeAssistant}
              >
                <X className="h-3 w-3" />
              </Button>
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default FluxAssistant;
