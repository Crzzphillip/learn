
import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';
import { Play } from 'lucide-react';

const TriggerNode = ({ data }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-4 min-w-[200px]">
      <Handle type="source" position={Position.Bottom} />
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-green-500/10 grid place-items-center">
          <Play className="w-5 h-5 text-green-500" />
        </div>
        <div>
          <h3 className="font-medium">{data.label}</h3>
          <p className="text-xs text-muted-foreground">Trigger Event</p>
        </div>
      </div>
    </div>
  );
};

export default memo(TriggerNode);
