
import { useState, useEffect, useCallback } from 'react';
import {
  ReactFlow,
  MiniMap,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  addEdge,
  Panel,
  BackgroundVariant,
  NodeChange,
  EdgeChange,
  Connection,
  Edge,
  Node,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { Button } from '@/components/ui/button';
import { 
  Play, 
  Pause, 
  SkipForward, 
  RefreshCw, 
  Settings, 
  Save, 
  Download, 
  Share, 
  Eye, 
  EyeOff 
} from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';

interface WorkflowViewProps {
  workflowId: string;
}

// Define the node type to match what we're using
type WorkflowNode = Node & {
  className: string;
  data: {
    label: string;
    status?: string;
  };
};

// Define the edge type to match what we're using
type WorkflowEdge = Edge & {
  animated: boolean;
};

const WorkflowView = ({ workflowId }: WorkflowViewProps) => {
  // Sample nodes and edges for demonstration
  const initialNodes: WorkflowNode[] = [
    {
      id: 'trigger',
      type: 'input',
      data: { label: 'Workflow Trigger' },
      position: { x: 250, y: 25 },
      className: 'bg-primary/10 border-primary/30',
    },
    {
      id: 'content-ideas',
      data: { label: 'Generate Content Ideas', status: 'waiting' },
      position: { x: 250, y: 125 },
      className: 'bg-gray-800/80 border-gray-600',
    },
    {
      id: 'first-draft',
      data: { label: 'Create First Draft', status: 'waiting' },
      position: { x: 250, y: 225 },
      className: 'bg-gray-800/80 border-gray-600',
    },
    {
      id: 'generate-images',
      data: { label: 'Generate Images', status: 'waiting' },
      position: { x: 250, y: 325 },
      className: 'bg-gray-800/80 border-gray-600',
    },
    {
      id: 'finalize',
      type: 'output',
      data: { label: 'Review and Finalize', status: 'waiting' },
      position: { x: 250, y: 425 },
      className: 'bg-gray-800/80 border-gray-600',
    },
  ];

  const initialEdges: WorkflowEdge[] = [
    { id: 'e1-2', source: 'trigger', target: 'content-ideas', animated: false },
    { id: 'e2-3', source: 'content-ideas', target: 'first-draft', animated: false },
    { id: 'e3-4', source: 'first-draft', target: 'generate-images', animated: false },
    { id: 'e4-5', source: 'generate-images', target: 'finalize', animated: false },
  ];

  const [nodes, setNodes, onNodesChange] = useNodesState<WorkflowNode>(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState<WorkflowEdge>(initialEdges);
  const [isRunning, setIsRunning] = useState(false);
  const [currentNodeIndex, setCurrentNodeIndex] = useState(-1);
  const [showMinimap, setShowMinimap] = useState(true);
  const [showControls, setShowControls] = useState(true);
  const [isDirty, setIsDirty] = useState(false);

  // Handle edge connections
  const onConnect = useCallback((params: Connection) => {
    setEdges((eds) => addEdge({ ...params, animated: false } as WorkflowEdge, eds));
    setIsDirty(true);
  }, [setEdges]);

  // Handle node changes - this is where we need to fix the type issue
  const handleNodesChange = useCallback((changes: NodeChange[]) => {
    // Cast the changes to the correct type
    onNodesChange(changes as NodeChange<WorkflowNode>[]);
    setIsDirty(true);
  }, [onNodesChange]);

  // Handle edge changes
  const handleEdgesChange = useCallback((changes: EdgeChange[]) => {
    onEdgesChange(changes as EdgeChange<WorkflowEdge>[]);
    setIsDirty(true);
  }, [onEdgesChange]);

  // Simulate workflow execution
  useEffect(() => {
    if (!isRunning) return;

    const nodeIds = nodes
      .filter(node => node.id !== 'trigger')
      .map(node => node.id);
    
    if (currentNodeIndex >= nodeIds.length) {
      setIsRunning(false);
      toast.success("Workflow completed successfully!");
      return;
    }

    const timer = setTimeout(() => {
      const currentId = nodeIds[currentNodeIndex];
      
      // Update node status
      setNodes(nds => 
        nds.map(node => {
          if (node.id === currentId) {
            return {
              ...node,
              data: { ...node.data, status: 'running' },
              className: 'bg-yellow-500/20 border-yellow-500'
            };
          }
          return node;
        })
      );

      // Update edge animation
      if (currentNodeIndex > 0) {
        const prevId = nodeIds[currentNodeIndex - 1];
        const edgeId = `e${nodes.findIndex(n => n.id === prevId)}-${nodes.findIndex(n => n.id === currentId)}`;
        
        setEdges(eds => 
          eds.map(edge => {
            if (edge.source === prevId && edge.target === currentId) {
              return { ...edge, animated: true };
            }
            return edge;
          })
        );
      }

      // After a delay, complete the node
      const completionTimer = setTimeout(() => {
        setNodes(nds => 
          nds.map(node => {
            if (node.id === currentId) {
              return {
                ...node,
                data: { ...node.data, status: 'completed' },
                className: 'bg-green-500/20 border-green-500'
              };
            }
            return node;
          })
        );
        
        setCurrentNodeIndex(prev => prev + 1);
      }, 2000);

      return () => clearTimeout(completionTimer);
    }, 1000);

    return () => clearTimeout(timer);
  }, [isRunning, currentNodeIndex, nodes, setNodes, edges, setEdges]);

  const handleRunWorkflow = () => {
    if (isRunning) {
      setIsRunning(false);
      toast.info("Workflow paused");
    } else {
      // Reset node states
      setNodes(nds => 
        nds.map(node => {
          if (node.id === 'trigger') {
            return {
              ...node,
              className: 'bg-primary/10 border-primary/30'
            };
          }
          return {
            ...node,
            data: { ...node.data, status: 'waiting' },
            className: 'bg-gray-800/80 border-gray-600'
          };
        })
      );
      
      // Reset edge animations
      setEdges(eds => 
        eds.map(edge => ({
          ...edge,
          animated: false
        }))
      );
      
      setCurrentNodeIndex(0);
      setIsRunning(true);
      toast.info("Workflow started");
    }
  };

  const handleNextStep = () => {
    if (!isRunning) {
      setIsRunning(true);
      toast.info("Advancing workflow step");
    } else {
      setCurrentNodeIndex(prev => Math.min(prev + 1, nodes.length - 2));
      toast.info("Advancing to next step");
    }
  };

  const handleReset = () => {
    setIsRunning(false);
    setCurrentNodeIndex(-1);
    
    // Reset node states
    setNodes(nds => 
      nds.map(node => {
        if (node.id === 'trigger') {
          return {
            ...node,
            className: 'bg-primary/10 border-primary/30'
          };
        }
        return {
          ...node,
          data: { ...node.data, status: 'waiting' },
          className: 'bg-gray-800/80 border-gray-600'
        };
      })
    );
    
    // Reset edge animations
    setEdges(eds => 
      eds.map(edge => ({
        ...edge,
        animated: false
      }))
    );

    toast.success("Workflow reset");
  };

  const handleSaveWorkflow = () => {
    // In a real application, this would save to a backend
    toast.success("Workflow saved successfully");
    setIsDirty(false);
  };

  const handleExportWorkflow = () => {
    const flowData = {
      nodes,
      edges,
      workflowId,
      metadata: {
        exportTime: new Date().toISOString(),
        name: "Content Creation Suite",
      }
    };
    
    // Create a downloadable JSON file
    const dataStr = JSON.stringify(flowData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `workflow-${workflowId}-${new Date().toISOString()}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    toast.success("Workflow exported");
  };

  const handleShareWorkflow = () => {
    // In a real application, this would generate a shareable link
    navigator.clipboard.writeText(`https://example.com/workflow/${workflowId}`);
    toast.success("Shareable link copied to clipboard");
  };

  return (
    <div className="w-full h-[90vh] overflow-hidden">
      <TooltipProvider>
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={handleNodesChange}
          onEdgesChange={handleEdgesChange}
          onConnect={onConnect}
          fitView
          attributionPosition="bottom-right"
          className="bg-transparent"
        >
          {showControls && (
            <Controls className="bg-black/40 border border-white/10 rounded-md" />
          )}
          
          {showMinimap && (
            <MiniMap 
              nodeColor="#555" 
              maskColor="rgba(0, 0, 0, 0.1)"
              className="bg-black/40 border border-white/10 rounded-md"
            />
          )}
          
          <Background color="#aaa" gap={16} variant={BackgroundVariant.Dots} className="opacity-5" />
          
          <Panel position="top-left" className="bg-black/50 backdrop-blur-md p-2 rounded-lg border border-white/10">
            <div className="flex items-center gap-2 flex-wrap">
              <Tooltip delayDuration={300}>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={handleRunWorkflow}
                    className="text-white/80 hover:text-white"
                  >
                    {isRunning ? <Pause className="w-4 h-4 mr-1" /> : <Play className="w-4 h-4 mr-1" />}
                    {isRunning ? 'Pause' : 'Run'}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{isRunning ? 'Pause workflow execution' : 'Run workflow'}</p>
                </TooltipContent>
              </Tooltip>
              
              <Tooltip delayDuration={300}>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={handleNextStep}
                    disabled={currentNodeIndex >= nodes.length - 2}
                    className="text-white/80 hover:text-white disabled:opacity-40"
                  >
                    <SkipForward className="w-4 h-4 mr-1" />
                    Next Step
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Advance to the next step</p>
                </TooltipContent>
              </Tooltip>
              
              <Tooltip delayDuration={300}>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={handleReset}
                    className="text-white/80 hover:text-white"
                  >
                    <RefreshCw className="w-4 h-4 mr-1" />
                    Reset
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Reset workflow to initial state</p>
                </TooltipContent>
              </Tooltip>

              <Separator orientation="vertical" className="h-6 mx-1 bg-white/10" />
              
              <Tooltip delayDuration={300}>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={handleSaveWorkflow}
                    disabled={!isDirty}
                    className={`${isDirty ? 'text-primary hover:text-primary/80' : 'text-white/40'}`}
                  >
                    <Save className="w-4 h-4 mr-1" />
                    Save
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Save workflow changes</p>
                </TooltipContent>
              </Tooltip>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="text-white/80 hover:text-white"
                  >
                    <Settings className="w-4 h-4 mr-1" />
                    Options
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-black/90 border-white/10 text-white">
                  <DropdownMenuLabel>Workflow Settings</DropdownMenuLabel>
                  <DropdownMenuSeparator className="bg-white/10" />
                  <DropdownMenuItem onClick={() => setShowMinimap(!showMinimap)} className="flex items-center gap-2">
                    {showMinimap ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    {showMinimap ? "Hide Minimap" : "Show Minimap"}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setShowControls(!showControls)} className="flex items-center gap-2">
                    {showControls ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    {showControls ? "Hide Controls" : "Show Controls"}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator className="bg-white/10" />
                  <DropdownMenuItem onClick={handleExportWorkflow} className="flex items-center gap-2">
                    <Download className="w-4 h-4" />
                    Export Workflow
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleShareWorkflow} className="flex items-center gap-2">
                    <Share className="w-4 h-4" />
                    Share Workflow
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </Panel>
          
          <Panel position="bottom-center" className="bg-black/30 backdrop-blur-sm py-1 px-3 rounded-full border border-white/5">
            <div className="flex items-center gap-4 text-xs text-white/60">
              {!isRunning ? (
                <span>Ready to run</span>
              ) : (
                <span>Running: Step {currentNodeIndex + 1} of {nodes.length - 1}</span>
              )}
              <span>•</span>
              <span>{isDirty ? "Unsaved changes" : "All changes saved"}</span>
            </div>
          </Panel>
        </ReactFlow>
      </TooltipProvider>
    </div>
  );
};

export default WorkflowView;
