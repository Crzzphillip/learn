
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ChevronLeft, ChevronRight, Play, Save, Code, Image, RefreshCw } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';

interface NodeViewProps {
  workflowId: string;
}

const NodeView = ({ workflowId }: NodeViewProps) => {
  const [currentNodeIndex, setCurrentNodeIndex] = useState(0);
  const [inputValues, setInputValues] = useState<Record<number, string>>({
    0: '',
    1: '',
    2: '',
    3: ''
  });
  const [outputValues, setOutputValues] = useState<Record<number, string>>({});
  const [isRunning, setIsRunning] = useState<Record<number, boolean>>({});
  const [completedNodes, setCompletedNodes] = useState<Record<number, boolean>>({});

  // Sample nodes for demonstration
  const nodes = [
    {
      id: 'content-ideas',
      name: 'Generate Content Ideas',
      description: 'Generate creative content ideas based on the input topic',
      inputLabel: 'Enter a topic or theme',
      placeholder: 'E.g., Sustainable living, Future of work, etc.',
      outputs: ['list of ideas', 'topic analysis'],
      icon: <Code className="w-5 h-5" />
    },
    {
      id: 'first-draft',
      name: 'Create First Draft',
      description: 'Create a first draft based on the selected content idea',
      inputLabel: 'Select a content idea to develop',
      placeholder: 'Enter one of the generated ideas or write your own',
      outputs: ['draft content', 'structure overview'],
      icon: <Code className="w-5 h-5" />
    },
    {
      id: 'generate-images',
      name: 'Generate Images',
      description: 'Generate supporting images for the content',
      inputLabel: 'Describe the images you need',
      placeholder: 'E.g., A modern workspace with people collaborating',
      outputs: ['image links', 'image descriptions'],
      icon: <Image className="w-5 h-5" />
    },
    {
      id: 'finalize',
      name: 'Review and Finalize',
      description: 'Review and finalize the content with generated images',
      inputLabel: 'Provide any final adjustments',
      placeholder: 'E.g., Make the tone more professional, add a conclusion',
      outputs: ['final content', 'publication-ready assets'],
      icon: <Code className="w-5 h-5" />
    }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputValues({
      ...inputValues,
      [currentNodeIndex]: e.target.value
    });
  };

  const handleRunNode = () => {
    if (!inputValues[currentNodeIndex]?.trim()) return;
    
    setIsRunning({
      ...isRunning,
      [currentNodeIndex]: true
    });
    
    // Simulate processing time
    setTimeout(() => {
      const sampleOutputs = [
        `Generated content ideas based on "${inputValues[currentNodeIndex]}":\n\n1. 10 ways to implement ${inputValues[currentNodeIndex]} in daily life\n2. The future of ${inputValues[currentNodeIndex]}: Trends and predictions\n3. How ${inputValues[currentNodeIndex]} is changing the industry\n4. A beginner's guide to ${inputValues[currentNodeIndex]}\n5. Case studies: Success stories in ${inputValues[currentNodeIndex]}`,
        
        `First draft for "${inputValues[currentNodeIndex]}":\n\n# ${inputValues[currentNodeIndex]}\n\n## Introduction\nIn recent years, ${inputValues[currentNodeIndex]} has become increasingly important in our society. This article explores the key aspects and implications.\n\n## Main Points\n- History and evolution\n- Current practices\n- Future directions\n\n## Conclusion\nBy understanding ${inputValues[currentNodeIndex]}, we can better prepare for future challenges.`,
        
        `Generated image descriptions for "${inputValues[currentNodeIndex]}":\n\n1. A vibrant illustration showing ${inputValues[currentNodeIndex]} in action\n2. Infographic highlighting key statistics about ${inputValues[currentNodeIndex]}\n3. Portrait of industry leaders in the field of ${inputValues[currentNodeIndex]}\n\nImage URLs would be provided here in a real implementation.`,
        
        `Finalized content for "${inputValues[currentNodeIndex]}":\n\nThe article has been refined with your suggestions. All images have been integrated, formatting has been standardized, and SEO optimization has been applied. The content is now ready for publication or further distribution.`
      ];
      
      setOutputValues({
        ...outputValues,
        [currentNodeIndex]: sampleOutputs[currentNodeIndex]
      });
      
      setIsRunning({
        ...isRunning,
        [currentNodeIndex]: false
      });
      
      setCompletedNodes({
        ...completedNodes,
        [currentNodeIndex]: true
      });
    }, 2000);
  };

  const handlePrevNode = () => {
    setCurrentNodeIndex(prev => Math.max(0, prev - 1));
  };

  const handleNextNode = () => {
    if (currentNodeIndex < nodes.length - 1) {
      // If the current node is completed or we want to allow skipping
      setCurrentNodeIndex(prev => prev + 1);
      
      // Pre-populate next node with current node's output
      if (completedNodes[currentNodeIndex] && !inputValues[currentNodeIndex + 1]) {
        // This would be a simplified version in a real implementation
        // You'd want to extract relevant parts of the output
        setInputValues(prev => ({
          ...prev,
          [currentNodeIndex + 1]: `Based on previous step: "${outputValues[currentNodeIndex]?.split('\n')[0]}"`
        }));
      }
    }
  };

  const currentNode = nodes[currentNodeIndex];

  return (
    <div className="w-full h-[85vh] flex flex-col rounded-xl overflow-hidden border border-white/10 bg-black/20 backdrop-blur-sm">
      {/* Node navigation header */}
      <div className="p-4 border-b border-white/10 bg-black/40 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary/20 grid place-items-center">
            {currentNode.icon}
          </div>
          <div>
            <h3 className="font-medium text-base">{currentNode.name}</h3>
            <p className="text-xs text-white/60">{currentNodeIndex + 1} of {nodes.length}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handlePrevNode}
            disabled={currentNodeIndex === 0}
            className="h-8 w-8 p-0 rounded-full disabled:opacity-40"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          
          <div className="flex">
            {nodes.map((_, index) => (
              <div 
                key={index}
                className={`w-6 h-1 mx-0.5 rounded-full ${
                  completedNodes[index] 
                    ? 'bg-primary' 
                    : index === currentNodeIndex
                    ? 'bg-white/40' 
                    : 'bg-white/10'
                }`}
              />
            ))}
          </div>
          
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleNextNode}
            disabled={currentNodeIndex === nodes.length - 1}
            className="h-8 w-8 p-0 rounded-full disabled:opacity-40"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      {/* Node content */}
      <ScrollArea className="flex-1 overflow-auto p-4">
        <div className="max-w-2xl mx-auto space-y-6">
          <div>
            <h2 className="text-lg font-medium mb-2">{currentNode.name}</h2>
            <p className="text-white/60 text-sm">{currentNode.description}</p>
          </div>
          
          <Tabs defaultValue="input" className="w-full">
            <TabsList className="grid grid-cols-2 mb-4">
              <TabsTrigger value="input">Input</TabsTrigger>
              <TabsTrigger value="output" disabled={!completedNodes[currentNodeIndex]}>
                Output
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="input" className="space-y-4">
              <div>
                <label className="block text-sm text-white/80 mb-2">
                  {currentNode.inputLabel}
                </label>
                <Textarea
                  placeholder={currentNode.placeholder}
                  className="min-h-[120px] bg-black/30 border-white/10 resize-none"
                  value={inputValues[currentNodeIndex] || ''}
                  onChange={handleInputChange}
                />
              </div>
              
              <div className="flex items-center justify-between pt-2">
                <div>
                  <span className="text-xs text-white/60">
                    {completedNodes[currentNodeIndex] ? 'Node completed' : 'Ready to execute'}
                  </span>
                </div>
                
                <div className="flex gap-2">
                  {completedNodes[currentNodeIndex] && (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => {
                        setCompletedNodes({
                          ...completedNodes, 
                          [currentNodeIndex]: false
                        });
                        setOutputValues({
                          ...outputValues,
                          [currentNodeIndex]: ''
                        });
                      }}
                      className="text-white/80 border-white/20"
                    >
                      <RefreshCw className="h-4 w-4 mr-1" />
                      Reset
                    </Button>
                  )}
                  
                  <Button 
                    onClick={handleRunNode}
                    disabled={isRunning[currentNodeIndex] || !inputValues[currentNodeIndex]?.trim()}
                    className="bg-primary hover:bg-primary/90"
                  >
                    {isRunning[currentNodeIndex] ? (
                      <>Running...</>
                    ) : completedNodes[currentNodeIndex] ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-1" />
                        Run Again
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-1" />
                        Run Node
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="output" className="space-y-4">
              <div className="p-4 bg-black/40 rounded-md border border-white/10 min-h-[200px] whitespace-pre-wrap">
                {outputValues[currentNodeIndex] || 'No output yet'}
              </div>
              
              <div className="flex justify-end gap-2">
                <Button variant="outline" size="sm" className="text-white/80 border-white/20">
                  <Save className="h-4 w-4 mr-1" />
                  Save Output
                </Button>
                
                <Button 
                  variant="default" 
                  onClick={handleNextNode} 
                  disabled={currentNodeIndex === nodes.length - 1}
                >
                  <ChevronRight className="h-4 w-4 mr-1" />
                  Next Node
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </ScrollArea>
    </div>
  );
};

export default NodeView;
