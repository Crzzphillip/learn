
import { Save, Share, Play, Settings, Code, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';

const WorkflowToolbar = () => {
  return (
    <div className="border-b bg-background/95 backdrop-blur-sm">
      <div className="container py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-semibold">New Workflow</h1>
            <Button variant="outline" size="sm" className="gap-2">
              <Settings className="w-4 h-4" />
              Settings
            </Button>
            <Button variant="outline" size="sm" className="gap-2">
              <Code className="w-4 h-4" />
              Code View
            </Button>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-2">
              <Users className="w-4 h-4" />
              Collaborate
            </Button>
            <Button variant="outline" size="sm" className="gap-2">
              <Save className="w-4 h-4" />
              Save
            </Button>
            <Button variant="outline" size="sm" className="gap-2">
              <Share className="w-4 h-4" />
              Share
            </Button>
            <Button size="sm" className="gap-2">
              <Play className="w-4 h-4" />
              Run Workflow
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorkflowToolbar;
