
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Activity, Zap, Clock, AlertTriangle } from "lucide-react";

interface WorkflowStatsProps {
  workflow: any;
}

const executionData = [
  { name: "Successful", value: 68, color: "#10b981" },
  { name: "Failed", value: 12, color: "#ef4444" },
  { name: "Pending", value: 20, color: "#6366f1" }
];

const WorkflowStats = ({ workflow }: WorkflowStatsProps) => {
  return (
    <Card className="glass-panel border-primary/10">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Workflow Performance</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <div className="space-y-6 h-full">
              <div className="p-4 rounded-lg bg-secondary/10">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-5 h-5 text-amber-400" />
                  <span className="text-sm font-medium">Efficiency Score</span>
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold">{workflow?.efficiency || "85"}</span>
                  <span className="text-sm text-muted-foreground">/100</span>
                </div>
                <Progress value={85} className="h-2 mt-2" />
              </div>
              
              <div className="p-4 rounded-lg bg-secondary/10">
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="w-5 h-5 text-blue-400" />
                  <span className="text-sm font-medium">Executions Today</span>
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold">{workflow?.executions || "124"}</span>
                  <span className="text-xs text-green-400">↑ 8% from yesterday</span>
                </div>
              </div>
              
              <div className="p-4 rounded-lg bg-secondary/10">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-5 h-5 text-purple-400" />
                  <span className="text-sm font-medium">Avg. Execution Time</span>
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold">{workflow?.avgTime || "1.2s"}</span>
                  <span className="text-xs text-green-400">↓ 0.3s improvement</span>
                </div>
              </div>
              
              <div className="p-4 rounded-lg bg-secondary/10">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-5 h-5 text-amber-400" />
                  <span className="text-sm font-medium">Error Rate</span>
                </div>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold">{workflow?.errorRate || "3.2%"}</span>
                  <span className="text-xs text-green-400">↓ 1.4% improvement</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col">
            <h3 className="text-sm font-medium mb-2">Execution Results</h3>
            <div className="flex-1 flex items-center justify-center">
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={executionData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                  >
                    {executionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value) => [`${value}%`, 'Proportion']}
                    contentStyle={{ 
                      backgroundColor: 'rgba(0, 0, 0, 0.8)', 
                      border: '1px solid rgba(255, 255, 255, 0.2)',
                      borderRadius: '6px' 
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center gap-6 mt-2">
              {executionData.map((entry, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: entry.color }}
                  />
                  <span className="text-xs text-muted-foreground">{entry.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default WorkflowStats;
