
import React from "react";
import { SpaceFeature } from "@/types/space";

interface LeonardoFeaturesProps {
  features: SpaceFeature[];
}

const LeonardoFeatures = ({ features }: LeonardoFeaturesProps) => {
  return (
    <div className="mt-8 mb-12">
      <h2 className="text-2xl font-semibold mb-6">Leonardo.AI Features</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {features.map((feature) => {
          const Icon = feature.icon;
          return (
            <div 
              key={feature.id}
              className="p-6 rounded-xl bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20 shadow-sm border border-purple-100 dark:border-purple-900/30"
            >
              <div className="flex items-start">
                <div className="p-3 rounded-lg bg-white shadow-sm dark:bg-black/20 mr-4">
                  <Icon className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                </div>
                <div>
                  <h3 className="text-lg font-medium mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default LeonardoFeatures;
