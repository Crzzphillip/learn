
import { Wand, Image, Palette, Brush, Layers, Layout, BookOpen, Sparkles, FileImage, PenTool } from "lucide-react";
import { SpaceTemplate, SpaceType } from "@/types/space";

export const getLeonardoAiTemplate = (): SpaceTemplate => {
  return {
    title: "Leonardo.AI Space",
    description: "AI-powered platform for creative image generation, manipulation, and design workflows.",
    type: "leonardo" as SpaceType,
    gradient: "from-purple-500/20 to-indigo-500/20",
    icon: Wand,
    primaryColor: "#8B5CF6",
    secondaryColor: "#4F46E5",
    accentColor: "#A78BFA",
    features: [
      {
        id: "image-generation",
        title: "Image Generation",
        description: "Generate high-quality images from text descriptions",
        icon: Image,
        category: "creation",
        isAvailable: true
      },
      {
        id: "style-transfer",
        title: "Style Transfer",
        description: "Apply artistic styles to existing images",
        icon: Palette,
        category: "editing",
        isAvailable: true
      },
      {
        id: "creative-workflows",
        title: "Creative Workflows",
        description: "Automate creative processes with AI-powered workflows",
        icon: Layers,
        category: "workflow",
        isAvailable: true
      },
      {
        id: "design-tools",
        title: "Design Tools",
        description: "AI-enhanced tools for visual design",
        icon: PenTool,
        category: "tools",
        isAvailable: true
      }
    ],
    widgets: [
      {
        id: "generation-dashboard",
        title: "Generation Dashboard",
        type: "control-panel",
        size: "large",
        priority: 1
      },
      {
        id: "style-library",
        title: "Style Library",
        type: "marketplace",
        size: "medium",
        priority: 2
      },
      {
        id: "recent-creations",
        title: "Recent Creations",
        type: "preview",
        size: "full",
        priority: 3
      },
      {
        id: "model-explorer",
        title: "Model Explorer",
        type: "marketplace",
        size: "medium",
        priority: 4
      }
    ]
  };
};

export default getLeonardoAiTemplate;
