
import { Factory, Truck, BarChart4, Cog, Gauge } from "lucide-react";
import { SpaceTemplate, SpaceType } from "@/types/space";

export const getManufacturingSpaceTemplate = (): SpaceTemplate => {
  return {
    title: "Manufacturing Space",
    description: "AI-powered platform for optimizing production, supply chain management, and predictive maintenance.",
    type: "manufacturing" as SpaceType,
    gradient: "from-[#374151] to-[#4B5563]",
    icon: Factory,
    primaryColor: "#4B5563",
    secondaryColor: "#374151",
    accentColor: "#6B7280",
    features: [
      {
        id: "predictive-maintenance",
        title: "Predictive Maintenance",
        description: "AI-driven equipment monitoring and maintenance scheduling",
        icon: Cog,
        category: "maintenance",
        isAvailable: true
      },
      {
        id: "supply-chain-optimization",
        title: "Supply Chain Optimization",
        description: "End-to-end supply chain visibility and optimization",
        icon: Truck,
        category: "supply-chain",
        isAvailable: true
      },
      {
        id: "production-efficiency",
        title: "Production Efficiency",
        description: "Real-time production monitoring and optimization",
        icon: Gauge,
        category: "production",
        isAvailable: true
      },
      {
        id: "quality-control",
        title: "Quality Control",
        description: "AI-powered quality assurance and defect detection",
        icon: BarChart4,
        category: "quality",
        isAvailable: true
      }
    ],
    widgets: [
      {
        id: "production-dashboard",
        title: "Production Dashboard",
        type: "chart",
        size: "large",
        priority: 1
      },
      {
        id: "maintenance-schedule",
        title: "Maintenance Schedule",
        type: "calendar",
        size: "medium",
        priority: 2
      },
      {
        id: "supply-chain-monitor",
        title: "Supply Chain Monitor",
        type: "stats",
        size: "medium",
        priority: 3
      },
      {
        id: "factory-overview",
        title: "Factory Overview",
        type: "dashboard",
        size: "full",
        priority: 4
      }
    ]
  };
};

export default getManufacturingSpaceTemplate;
