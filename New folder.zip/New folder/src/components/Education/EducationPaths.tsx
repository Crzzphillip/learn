
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LearningPath } from "@/types/space";

interface EducationPathsProps {
  learningPaths: LearningPath[];
}

const EducationPaths = ({ learningPaths }: EducationPathsProps) => {
  const getLevelColor = (level: 'beginner' | 'intermediate' | 'advanced') => {
    switch (level) {
      case 'beginner':
        return "bg-green-500/20 text-green-500";
      case 'intermediate':
        return "bg-blue-500/20 text-blue-500";
      case 'advanced':
        return "bg-purple-500/20 text-purple-500";
      default:
        return "bg-blue-500/20 text-blue-500";
    }
  };

  return (
    <div className="mb-8">
      <h2 className="text-2xl font-bold mb-6">Learning Paths</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {learningPaths.map((path) => (
          <Card key={path.id} className="bg-black/20 border border-white/10 hover:border-blue-500/30 hover:bg-black/30 transition-all duration-300">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="flex items-center gap-2">
                  <path.icon className="w-5 h-5 text-blue-400" />
                  {path.title}
                </CardTitle>
                <Badge variant="outline" className={`${getLevelColor(path.level)}`}>
                  {path.level}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-white/70 mb-2">{path.description}</p>
              <div className="flex justify-between text-xs text-white/50 mb-4">
                <span>{path.modules} modules</span>
                <span>{path.duration}</span>
              </div>
              <Button 
                className="bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-600 hover:to-cyan-700 w-full"
              >
                Explore Path
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default EducationPaths;
