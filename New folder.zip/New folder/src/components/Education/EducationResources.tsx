
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { EducationalResource } from "@/types/space";

interface EducationResourcesProps {
  resources: EducationalResource[];
}

const EducationResources = ({ resources }: EducationResourcesProps) => {
  const getTypeColor = (type: string) => {
    switch (type) {
      case 'video':
        return "bg-red-500/20 text-red-500";
      case 'article':
        return "bg-blue-500/20 text-blue-500";
      case 'tutorial':
        return "bg-green-500/20 text-green-500";
      case 'course':
        return "bg-purple-500/20 text-purple-500";
      case 'documentation':
        return "bg-amber-500/20 text-amber-500";
      default:
        return "bg-blue-500/20 text-blue-500";
    }
  };

  return (
    <div className="mb-8">
      <h2 className="text-2xl font-bold mb-6">Educational Resources</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {resources.map((resource) => (
          <Card key={resource.id} className="bg-black/20 border border-white/10 hover:border-blue-500/30 hover:bg-black/30 transition-all duration-300">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <resource.icon className="w-5 h-5 text-blue-400" />
                  {resource.title}
                </CardTitle>
                <Badge variant="outline" className={`${getTypeColor(resource.type)}`}>
                  {resource.type}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between text-xs text-white/70 mb-2">
                <span>By {resource.author}</span>
                <span>{resource.duration}</span>
              </div>
              <div className="mt-4 text-right">
                <a href="#" className="text-blue-400 hover:text-blue-300 transition-colors text-sm">
                  Access Resource →
                </a>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default EducationResources;
