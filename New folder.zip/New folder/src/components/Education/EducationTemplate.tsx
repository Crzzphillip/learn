
import { BookOpen, GraduationCap, Video, FileText, PenTool } from "lucide-react";
import { SpaceTemplate, SpaceType } from "@/types/space";

export const getDefaultEducationTemplate = (): SpaceTemplate => {
  return {
    title: "Education Space",
    description: "Interactive learning environment with courses, tutorials, and community-driven education.",
    type: "education" as SpaceType,
    gradient: "from-[#06B6D4] to-[#3B82F6]",
    icon: GraduationCap,
    primaryColor: "#06B6D4",
    secondaryColor: "#3B82F6",
    accentColor: "#93C5FD",
    features: [
      {
        id: "interactive-courses",
        title: "Interactive Courses",
        description: "Engage with interactive courses with hands-on exercises",
        icon: BookOpen,
        category: "learning",
        isAvailable: true
      },
      {
        id: "video-tutorials",
        title: "Video Tutorials",
        description: "Watch step-by-step video tutorials on various topics",
        icon: Video,
        category: "tutorials",
        isAvailable: true
      },
      {
        id: "practice-exercises",
        title: "Practice Exercises",
        description: "Reinforce learning with practical coding exercises",
        icon: PenTool,
        category: "practice",
        isAvailable: true
      },
      {
        id: "certification",
        title: "Certification Programs",
        description: "Earn certificates for completed courses and tracks",
        icon: FileText,
        category: "credentials",
        isAvailable: true
      }
    ],
    widgets: [
      {
        id: "learning-dashboard",
        title: "Learning Dashboard",
        type: "dashboard",
        size: "large",
        priority: 1
      },
      {
        id: "course-progress",
        title: "Course Progress",
        type: "stats",
        size: "medium",
        priority: 2
      },
      {
        id: "recommended-courses",
        title: "Recommended For You",
        type: "marketplace",
        size: "medium",
        priority: 3
      },
      {
        id: "code-playground",
        title: "Code Playground",
        type: "editor",
        size: "full",
        priority: 4
      }
    ],
    learningPaths: [
      {
        id: "web-development",
        title: "Web Development",
        description: "Learn frontend and backend web development",
        modules: 12,
        duration: "8 weeks",
        level: "beginner",
        icon: BookOpen
      },
      {
        id: "data-science",
        title: "Data Science & AI",
        description: "Master data analysis and machine learning",
        modules: 10,
        duration: "10 weeks",
        level: "intermediate",
        icon: BookOpen
      },
      {
        id: "mobile-development",
        title: "Mobile App Development",
        description: "Build iOS and Android applications",
        modules: 8,
        duration: "6 weeks",
        level: "intermediate",
        icon: BookOpen
      }
    ],
    resources: [
      {
        id: "intro-programming",
        title: "Introduction to Programming",
        type: "video",
        author: "Dr. Alan Smith",
        duration: "45 min",
        icon: Video
      },
      {
        id: "react-foundations",
        title: "React Foundations",
        type: "course",
        author: "Sarah Johnson",
        duration: "3 hours",
        icon: BookOpen
      },
      {
        id: "python-data-analysis",
        title: "Data Analysis with Python",
        type: "tutorial",
        author: "Michael Chen",
        duration: "2 hours",
        icon: FileText
      }
    ]
  };
};

export default getDefaultEducationTemplate;
