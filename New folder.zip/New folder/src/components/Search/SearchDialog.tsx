
import { useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Search, Code, Palette, MessageSquare, Brain, Workflow, Layout, Globe, Bot, Command as CommandIcon } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { categories } from "@/data/exploreData";

interface SearchResult {
  id: string;
  title: string;
  description: string;
  category: string;
  icon: any;
  path: string;
}

type CommandType = "space" | "agent" | "app" | "workflow" | "chat" | "none";

const searchResults: SearchResult[] = [
  {
    id: "1",
    title: "CodeCraft AI",
    description: "Expert coding assistant for developers",
    category: "Agents",
    icon: Code,
    path: "/space/codecraft"
  },
  {
    id: "2",
    title: "Design System",
    description: "AI-powered design workflow",
    category: "Workflows",
    icon: Workflow,
    path: "/workflow/design"
  },
  {
    id: "3",
    title: "Content Studio",
    description: "Create and edit content with AI",
    category: "Apps",
    icon: Layout,
    path: "/apps/studio"
  },
  {
    id: "4",
    title: "Global Chat",
    description: "Chat with the community",
    category: "Spaces",
    icon: Globe,
    path: "/spaces/chat"
  }
];

export function SearchDialog({ open, setOpen }: { open: boolean; setOpen: (open: boolean) => void }) {
  const navigate = useNavigate();
  const [activeCommand, setActiveCommand] = useState<CommandType>("none");
  const [searchQuery, setSearchQuery] = useState("");
  const [chatMessages, setChatMessages] = useState<{ role: "user" | "assistant"; content: string }[]>([]);

  const handleSearch = (value: string) => {
    setSearchQuery(value);
    
    if (value.startsWith("/")) {
      const command = value.split(" ")[0].slice(1) as CommandType;
      setActiveCommand(command);
    } else {
      setActiveCommand("chat");
    }
  };

  const renderCommandView = () => {
    switch (activeCommand) {
      case "space":
        return (
          <div className="grid grid-cols-2 gap-4 p-4">
            {categories.map((category) => (
              <div
                key={category.id}
                className="group relative overflow-hidden rounded-xl cursor-pointer"
                onClick={() => {
                  navigate(`/space/${category.id}`);
                  setOpen(false);
                }}
              >
                <div className={`p-6 bg-gradient-to-br ${category.gradient}`}>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-lg bg-white/10 grid place-items-center">
                      <category.icon className="w-5 h-5" />
                    </div>
                    <h3 className="font-medium">{category.title}</h3>
                  </div>
                  <p className="text-sm text-white/60">{category.description}</p>
                </div>
              </div>
            ))}
          </div>
        );

      case "agent":
        return (
          <div className="grid grid-cols-2 gap-4 p-4">
            {categories.flatMap(category => category.spaces)
              .filter(space => space.category === "Development")
              .map(agent => (
                <div
                  key={agent.id}
                  className="p-6 rounded-xl bg-gradient-to-br from-purple-500/20 to-blue-500/20 cursor-pointer"
                  onClick={() => {
                    navigate(`/space/${agent.id}`);
                    setOpen(false);
                  }}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-lg bg-white/10 grid place-items-center">
                      <Bot className="w-5 h-5" />
                    </div>
                    <h3 className="font-medium">{agent.title}</h3>
                  </div>
                  <p className="text-sm text-white/60">{agent.description}</p>
                </div>
              ))}
          </div>
        );

      case "chat":
        return (
          <div className="flex flex-col h-[400px]">
            <div className="flex-1 overflow-auto p-4 space-y-4">
              {chatMessages.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-lg ${
                      message.role === "user"
                        ? "bg-primary/20 text-primary-foreground"
                        : "bg-muted"
                    }`}
                  >
                    {message.content}
                  </div>
                </div>
              ))}
            </div>
            <div className="p-4 border-t border-white/10">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (searchQuery.trim()) {
                    setChatMessages([
                      ...chatMessages,
                      { role: "user", content: searchQuery },
                      { role: "assistant", content: "I'm here to help you navigate. What would you like to know?" }
                    ]);
                    setSearchQuery("");
                  }
                }}
              >
                <CommandInput
                  value={searchQuery}
                  onValueChange={handleSearch}
                  placeholder="Ask me anything..."
                  className="border-none bg-transparent"
                />
              </form>
            </div>
          </div>
        );

      default:
        return (
          <Command className="bg-transparent">
            <CommandInput
              value={searchQuery}
              onValueChange={handleSearch}
              placeholder="Type / for commands or start typing to chat..."
              className="h-12 bg-secondary/20 border-white/5"
            />
            <CommandList className="max-h-[400px] overflow-auto">
              <CommandEmpty>No results found.</CommandEmpty>
              <CommandGroup heading="Commands">
                <CommandItem className="flex items-center gap-2 p-2">
                  <CommandIcon className="w-4 h-4" />
                  <span className="font-mono">/space</span>
                  <span className="text-muted-foreground">Browse AI spaces</span>
                </CommandItem>
                <CommandItem className="flex items-center gap-2 p-2">
                  <CommandIcon className="w-4 h-4" />
                  <span className="font-mono">/agent</span>
                  <span className="text-muted-foreground">Find AI agents</span>
                </CommandItem>
                <CommandItem className="flex items-center gap-2 p-2">
                  <CommandIcon className="w-4 h-4" />
                  <span className="font-mono">/app</span>
                  <span className="text-muted-foreground">Discover apps</span>
                </CommandItem>
                <CommandItem className="flex items-center gap-2 p-2">
                  <CommandIcon className="w-4 h-4" />
                  <span className="font-mono">/workflow</span>
                  <span className="text-muted-foreground">Explore workflows</span>
                </CommandItem>
              </CommandGroup>
            </CommandList>
          </Command>
        );
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-[640px] bg-background/40 backdrop-blur-2xl border-white/10">
        {renderCommandView()}
      </DialogContent>
    </Dialog>
  );
};
