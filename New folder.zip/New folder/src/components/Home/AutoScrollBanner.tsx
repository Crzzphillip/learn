
import { useEffect, useState } from "react";
import { ArrowRight } from "lucide-react";
import { Carousel, CarouselContent, CarouselItem } from "@/components/ui/carousel";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

const bannerImages = [
  "/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png",
  "/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png",
  "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png",
  "/lovable-uploads/02aed6e2-2911-4e2d-a6c7-36e8e7d361b5.png",
  "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png",
];

const AutoScrollBanner = () => {
  const [api, setApi] = useState<any>(null);
  const [current, setCurrent] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    if (!api) return;

    const interval = setInterval(() => {
      api.scrollNext();
    }, 5000);

    return () => clearInterval(interval);
  }, [api]);

  return (
    <div className="container py-8">
      <div className="relative h-[300px] overflow-hidden rounded-3xl bg-black">
        <div className="absolute inset-0 bg-gradient-to-b from-background/40 to-background pointer-events-none" />
        <Carousel
          opts={{
            align: "start",
            loop: true,
          }}
          setApi={setApi}
          className="h-full"
        >
          <CarouselContent className="h-full">
            {bannerImages.map((image, index) => (
              <CarouselItem key={index} className="h-full">
                <div className="relative w-full h-full">
                  <img
                    src={image}
                    alt={`Banner ${index + 1}`}
                    className="w-full h-full object-cover transition-opacity duration-500 opacity-40"
                  />
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-black/80 to-black" />
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
        </Carousel>
        
        <div className="absolute inset-0 flex items-center pointer-events-none">
          <div className="container">
            <div className="max-w-2xl space-y-6">
              <div>
                <h1 className="text-4xl font-bold mb-3 leading-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-white/80">
                  Discover AI-Powered Solutions
                </h1>
                <p className="text-lg text-white/80">
                  Join our community of innovators and explore cutting-edge AI tools and spaces designed to transform your workflow
                </p>
              </div>
              <div className="flex gap-4 pointer-events-auto">
                <Button 
                  size="lg" 
                  className="text-base px-6 bg-primary hover:bg-primary/90"
                  onClick={() => navigate('/explore/spaces')}
                >
                  Start Exploring
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="text-base px-6 bg-white/10 hover:bg-white/20 backdrop-blur-sm"
                  onClick={() => navigate('/blog')}
                >
                  Learn More
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AutoScrollBanner;
