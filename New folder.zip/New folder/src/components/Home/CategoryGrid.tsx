
import { Code, Palette, MessageSquare } from "lucide-react";
import { useNavigate } from "react-router-dom";

const CategoryGrid = () => {
  const navigate = useNavigate();

  const categories = [
    {
      id: "development",
      label: "Development",
      icon: Code,
      description: "Coding assistants and development tools powered by AI",
      count: 12
    },
    {
      id: "creative",
      label: "Creative",
      icon: Palette,
      description: "Design, art, and content creation with AI assistance",
      count: 8
    },
    {
      id: "communication",
      label: "Communication",
      icon: MessageSquare,
      description: "Advanced chat and conversation AI specialists",
      count: 15
    }
  ];

  const handleCategoryClick = (category: string) => {
    navigate(`/explore/spaces?category=${encodeURIComponent(category.toLowerCase())}`);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-semibold mb-2">Browse by Category</h2>
          <p className="text-muted-foreground">Find the perfect AI space for your needs</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {categories.map((category) => (
          <div 
            key={category.id}
            onClick={() => handleCategoryClick(category.label)}
            className="glass-panel rounded-xl p-6 cursor-pointer hover:scale-[1.02] transition-all duration-300"
          >
            <div className="w-12 h-12 rounded-xl bg-secondary/50 grid place-items-center mb-4">
              <category.icon className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-semibold mb-2">{category.label}</h3>
            <p className="text-sm text-muted-foreground mb-4">{category.description}</p>
            <span className="text-primary hover:underline text-sm">{category.count} Spaces Available →</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategoryGrid;
