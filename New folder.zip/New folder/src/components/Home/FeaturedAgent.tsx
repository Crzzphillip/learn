
import { Star, Users, ArrowRight } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useNavigate } from "react-router-dom";

interface FeaturedAgentProps {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  category: string;
  rating: string;
}

const FeaturedAgent = ({ id, title, description, icon: Icon, category, rating }: FeaturedAgentProps) => {
  const navigate = useNavigate();

  return (
    <Dialog>
      <DialogTrigger asChild>
        <div className="relative group cursor-pointer">
          <div className="relative h-[320px] rounded-xl overflow-hidden">
            <img 
              src="/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png" 
              alt={title} 
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent" />
            <div className="absolute inset-0 backdrop-blur-[2px] glass-panel opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </div>
          
          <div className="absolute inset-0 p-6 flex flex-col justify-end">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-xl grid place-items-center">
                <Icon className="w-6 h-6" />
              </div>
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/10 backdrop-blur-sm">
                <Star className="w-4 h-4 fill-primary text-primary" />
                <span className="text-sm font-medium">{rating}</span>
              </div>
            </div>
            
            <h3 className="text-lg font-semibold mb-2">{title}</h3>
            <p className="text-sm text-white/80 mb-4 line-clamp-2">{description}</p>
            <div className="flex items-center justify-between">
              <span className="text-xs px-2.5 py-1 rounded-full bg-white/10 backdrop-blur-sm">
                {category}
              </span>
              <span className="text-sm text-primary hover:underline group-hover:translate-x-1 transition-transform duration-300">
                Try Now →
              </span>
            </div>
          </div>
        </div>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            AI Space specialized in {category}
          </DialogDescription>
        </DialogHeader>
        <div className="py-6">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-16 h-16 rounded-xl bg-secondary/50 grid place-items-center flex-shrink-0">
              <Icon className="w-8 h-8" />
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-1">{title}</h4>
              <div className="flex items-center gap-4 mb-2">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-primary text-primary" />
                  <span className="text-sm">{rating}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Users className="w-4 h-4" />
                  <span className="text-sm">2.4k users</span>
                </div>
              </div>
              <span className="text-xs px-2.5 py-1 rounded-full bg-secondary/50">{category}</span>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <h5 className="text-sm font-medium mb-2">Description</h5>
              <p className="text-sm text-muted-foreground">{description}</p>
            </div>
            
            <div>
              <h5 className="text-sm font-medium mb-2">Features</h5>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Advanced AI algorithms</li>
                <li>• Real-time assistance</li>
                <li>• Seamless integration</li>
                <li>• Custom workflows</li>
              </ul>
            </div>
          </div>
        </div>
        <DialogFooter>
          <button 
            onClick={() => navigate(`/space/${id}`)}
            className="w-full inline-flex items-center justify-center px-4 py-2.5 rounded-lg font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
          >
            Continue to Space
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default FeaturedAgent;
