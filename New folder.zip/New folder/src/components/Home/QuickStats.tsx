
import { Users, Zap, Sparkles } from "lucide-react";

const QuickStats = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
      <div className="glass-panel rounded-xl p-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-primary/20 grid place-items-center">
            <Users className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-1">12.5k+</h3>
            <p className="text-muted-foreground">Active Users</p>
          </div>
        </div>
      </div>
      <div className="glass-panel rounded-xl p-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-primary/20 grid place-items-center">
            <Zap className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-1">250k+</h3>
            <p className="text-muted-foreground">Tasks Completed</p>
          </div>
        </div>
      </div>
      <div className="glass-panel rounded-xl p-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-primary/20 grid place-items-center">
            <Sparkles className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-1">98%</h3>
            <p className="text-muted-foreground">Satisfaction Rate</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuickStats;
