
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Minus, ArrowUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface Collaborator {
  id: string;
  name: string;
  color: string;
  position: { x: number; y: number };
}

interface CollaborativeCanvasProps {
  title?: string;
  imageUrl?: string;
  imageAlt?: string;
  imageDescription?: string;
  collaborators?: Collaborator[];
}

const CollaborativeCanvas = ({
  title = "LUMINESCENT FLOWERS",
  imageUrl = "/lovable-uploads/b10f9492-8ed2-429e-bbbc-5e323d052dc2.png",
  imageAlt = "Luminescent flowers with glowing effect",
  imageDescription = "Two intertwined stylized flowers against a black background. The petals have a gradient of colors, including blue, orange, and purple, creating a glowing effect.",
  collaborators = [
    { id: "1", name: "Bogdan", color: "bg-green-500", position: { x: 25, y: 30 } },
    { id: "2", name: "Nima", color: "bg-teal-500", position: { x: 75, y: 5 } },
    { id: "3", name: "Paul", color: "bg-orange-500", position: { x: 85, y: 60 } },
    { id: "4", name: "Francisco", color: "bg-purple-500", position: { x: 30, y: 90 } }
  ]
}: CollaborativeCanvasProps) => {
  const [zoom, setZoom] = useState(4);

  return (
    <div className="w-full p-4 bg-black text-white min-h-[600px] relative">
      <div className="container mx-auto">
        <div className="relative w-full h-[600px] flex items-center justify-center">
          {/* Collaborator cursors */}
          {collaborators.map((collaborator) => (
            <div
              key={collaborator.id}
              className="absolute z-20"
              style={{ 
                left: `${collaborator.position.x}%`, 
                top: `${collaborator.position.y}%`
              }}
            >
              <div className="flex items-center gap-1">
                <div className={`w-3 h-3 rotate-45 ${collaborator.color}`}></div>
                <Badge className={`${collaborator.color} text-black font-medium`}>
                  {collaborator.name}
                </Badge>
              </div>
            </div>
          ))}

          {/* Canvas content */}
          <div className="max-w-lg mx-auto z-10">
            <h3 className="text-sm text-center mb-2 tracking-widest uppercase">
              {title}
            </h3>
            
            <Card className="bg-black border border-gray-800 rounded-lg overflow-hidden">
              <div className="relative">
                <img 
                  src={imageUrl} 
                  alt={imageAlt}
                  className="w-full object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 p-3 bg-black/80 text-xs text-gray-300">
                  {imageDescription}
                </div>
                
                {/* Zoom controls */}
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex flex-col gap-2 bg-black/50 backdrop-blur-sm rounded-md p-1">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 rounded-md hover:bg-white/10"
                    onClick={() => setZoom(Math.min(zoom + 1, 10))}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                  <div className="text-center text-xs py-1">{zoom}</div>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 rounded-md hover:bg-white/10"
                    onClick={() => setZoom(Math.max(zoom - 1, 1))}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <div className="border-t border-gray-700 my-1"></div>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 rounded-md hover:bg-white/10"
                  >
                    <ArrowUp className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CollaborativeCanvas;
