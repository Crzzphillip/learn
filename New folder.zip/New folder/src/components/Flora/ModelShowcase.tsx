
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { AIModel, modelsService } from "@/services/modelsService";

interface ModelShowcaseProps {
  title?: string;
  description?: string;
  models?: AIModel[]; // Add the models prop as optional
}

const ModelShowcase = ({ 
  title = "AI is complicated. We made it simple.", 
  description = "We curate the best text, image, and video models.\nYou bring your idea to life.",
  models: initialModels // Accept the models prop
}: ModelShowcaseProps) => {
  const [models, setModels] = useState<AIModel[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchModels = async () => {
      try {
        setLoading(true);
        // If initial models are provided, use them; otherwise fetch from service
        if (initialModels && initialModels.length > 0) {
          setModels(initialModels);
          setLoading(false);
        } else {
          const data = await modelsService.getAllModels();
          setModels(data);
        }
      } catch (error) {
        console.error("Failed to fetch models:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchModels();
  }, [initialModels]);

  return (
    <div className="w-full px-2 py-8 bg-black text-white">
      <div className="container mx-auto">
        <h2 className="text-4xl font-bold mb-3">{title}</h2>
        <p className="text-xl mb-12 text-gray-300 whitespace-pre-line">{description}</p>
        
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            {[...Array(4)].map((_, index) => (
              <Card 
                key={`skeleton-${index}`}
                className="overflow-hidden border-0 rounded-xl bg-gradient-to-br from-gray-900 to-black p-6 flex items-center justify-center h-32 relative animate-pulse"
              />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            {models.map((model) => (
              <Card 
                key={model.id}
                className={`overflow-hidden border-0 rounded-xl bg-gradient-to-br ${model.background || 'from-gray-900 to-black'} p-6 flex items-center justify-center h-32 relative transition-transform hover:scale-[1.02]`}
              >
                <div className="text-center">
                  <img 
                    src={model.logo} 
                    alt={model.name} 
                    className="h-10 mx-auto mb-2" 
                  />
                  <h3 className="text-white text-xl font-bold">{model.name}</h3>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ModelShowcase;
