
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Carousel, CarouselContent, CarouselItem } from "@/components/ui/carousel";
import { useEffect, useState } from "react";
import { Workflow, workflowsService } from "@/services/workflowsService";

interface WorkflowGalleryProps {
  title?: string;
  description?: string;
  workflows?: Workflow[]; // Add workflows prop as optional
}

const WorkflowGallery = ({
  title = "Find your Flow.",
  description = "Explore the Community to find a workflow that fits your needs.",
  workflows: initialWorkflows // Accept the workflows prop
}: WorkflowGalleryProps) => {
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchWorkflows = async () => {
      try {
        setLoading(true);
        // If initial workflows are provided, use them; otherwise fetch from service
        if (initialWorkflows && initialWorkflows.length > 0) {
          setWorkflows(initialWorkflows);
          setLoading(false);
        } else {
          const data = await workflowsService.getAllWorkflows();
          setWorkflows(data);
        }
      } catch (error) {
        console.error("Failed to fetch workflows:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchWorkflows();
  }, [initialWorkflows]);

  return (
    <div className="w-full bg-black text-white py-10">
      <div className="container mx-auto">
        <h2 className="text-4xl font-bold mb-3">{title}</h2>
        <p className="text-xl mb-6 text-gray-300">{description}</p>

        <Button variant="outline" className="mb-12 border-white/20 hover:bg-white/10 transition-colors">
          Explore Community
        </Button>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[...Array(4)].map((_, index) => (
              <Card key={`skeleton-${index}`} className="bg-black border-0 overflow-hidden rounded-xl h-80 relative group animate-pulse">
                <div className="absolute inset-0 bg-gradient-to-t from-black to-gray-800 opacity-70"></div>
              </Card>
            ))}
          </div>
        ) : (
          <Carousel
            opts={{
              align: "start",
              loop: true,
            }}
            className="w-full"
          >
            <CarouselContent className="-ml-2 md:-ml-4">
              {workflows.map((workflow) => (
                <CarouselItem key={workflow.id} className="pl-2 md:pl-4 md:basis-1/2 lg:basis-1/4">
                  <Card className="bg-black border-0 overflow-hidden rounded-xl h-80 relative group cursor-pointer">
                    <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-70 z-10"></div>
                    <img 
                      src={workflow.imageUrl} 
                      alt={workflow.title}
                      className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    <div className="absolute bottom-0 left-0 right-0 p-4 z-20">
                      <h3 className="text-lg font-medium line-clamp-1">{workflow.title}</h3>
                      <p className="text-sm text-gray-300 mt-1 line-clamp-2">{workflow.description}</p>
                    </div>
                  </Card>
                </CarouselItem>
              ))}
            </CarouselContent>
          </Carousel>
        )}
      </div>
    </div>
  );
};

export default WorkflowGallery;
