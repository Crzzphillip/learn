
import { Wand, Layers, Star, Rocket, Image, Palette, FileVideo, Tv, Users, Box } from "lucide-react";
import { SpaceTemplate, SpaceType } from "@/types/space";

export const getFloraCreativeTemplate = (): SpaceTemplate => {
  return {
    title: "FLORA Creative Space",
    description: "The space between imagination and execution is here",
    type: "flora" as SpaceType,
    gradient: "from-[#9b87f5] to-[#D946EF]",
    icon: Wand,
    primaryColor: "#9b87f5",
    secondaryColor: "#D946EF",
    accentColor: "#E5DEFF",
    features: [
      {
        id: "creative-control",
        title: "Professional Creative Control",
        description: "Tools built for professionals who need real control, iteration, and collaboration",
        icon: Palette,
        category: "core",
        isAvailable: true
      },
      {
        id: "workflow-system",
        title: "Creative Workflow System",
        description: "Codify your process and scale creativity effortlessly",
        icon: Layers,
        category: "process",
        isAvailable: true
      },
      {
        id: "fluid-creativity",
        title: "Fluid Creative Experience",
        description: "Intuitive system bringing together the best AI models",
        icon: Wand,
        category: "experience",
        isAvailable: true
      },
      {
        id: "scale-creativity",
        title: "Scale Creative Output",
        description: "Do 100X more creative work with rapid iteration and variation",
        icon: Rocket,
        category: "scaling",
        isAvailable: true
      }
    ],
    widgets: [
      {
        id: "model-showcase",
        title: "AI Model Showcase",
        type: "marketplace",
        size: "full",
        priority: 1
      },
      {
        id: "collaborative-canvas",
        title: "Collaborative Canvas",
        type: "preview",
        size: "large",
        priority: 2
      },
      {
        id: "workflow-gallery",
        title: "Workflow Gallery",
        type: "dashboard",
        size: "full",
        priority: 3
      },
      {
        id: "creative-history",
        title: "Creation History",
        type: "activity",
        size: "medium",
        priority: 4
      },
      {
        id: "control-panel",
        title: "Creative Control Panel",
        type: "control-panel",
        size: "medium",
        priority: 5
      }
    ],
    specializations: [
      {
        id: "video-generation",
        title: "Video Generation",
        description: "Transform static content into dynamic videos with advanced AI models",
        icon: FileVideo,
        gradient: "from-orange-600 to-red-600"
      },
      {
        id: "image-creation",
        title: "Image Creation",
        description: "Create stunning visuals with the latest image generation models",
        icon: Image,
        gradient: "from-blue-600 to-indigo-600"
      },
      {
        id: "3d-modeling",
        title: "3D Generation",
        description: "Generate 3D models and environments from simple text prompts",
        icon: Box,
        gradient: "from-green-600 to-emerald-600"
      },
      {
        id: "collaborative-design",
        title: "Collaborative Design",
        description: "Work together in real-time on creative projects",
        icon: Users,
        gradient: "from-purple-600 to-pink-600"
      }
    ],
    tools: [
      {
        id: "runway-integration",
        title: "Runway Integration",
        description: "Generate high-quality videos from images with advanced AI models",
        icon: Tv,
        category: "video-generation",
        difficulty: "intermediate",
        isAvailable: true
      },
      {
        id: "luma-integration",
        title: "Luma Integration",
        description: "Create realistic 3D assets and animations with advanced AI",
        icon: Box,
        category: "3d-generation",
        difficulty: "advanced",
        isAvailable: true
      },
      {
        id: "creative-multiplier",
        title: "Creative Multiplier",
        description: "Scale your creative work with controlled variations and iterations",
        icon: Rocket,
        category: "scaling",
        difficulty: "beginner",
        isAvailable: true
      },
      {
        id: "design-studio",
        title: "AI Design Studio",
        description: "Professional-grade design tools with AI assistance and control",
        icon: Palette,
        category: "design",
        difficulty: "intermediate",
        isAvailable: true
      }
    ]
  };
};

export default getFloraCreativeTemplate;
