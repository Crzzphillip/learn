
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SpaceFeature } from "@/types/space";
import ModelShowcase from "./ModelShowcase";
import CollaborativeCanvas from "./CollaborativeCanvas";
import WorkflowGallery from "./WorkflowGallery";
import { Wand, Layers, Star, Rocket, Image } from "lucide-react";
import { useEffect, useState } from "react";
import { AIModel, modelsService } from "@/services/modelsService";
import { Workflow, workflowsService } from "@/services/workflowsService";

interface FloraFeaturesProps {
  features: SpaceFeature[];
}

const FloraFeatures = ({ features }: FloraFeaturesProps) => {
  const [aiModels, setAiModels] = useState<AIModel[]>([]);
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [modelsData, workflowsData] = await Promise.all([
          modelsService.getAllModels(),
          workflowsService.getAllWorkflows()
        ]);
        setAiModels(modelsData);
        setWorkflows(workflowsData);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="mt-8 mb-6 space-y-12">
      <div>
        <h2 className="text-2xl font-semibold mb-4">FLORA Creative Platform</h2>
        <p className="text-muted-foreground mb-6 max-w-3xl">
          We built FLORA with top agencies, studios, and digital creators to solve the biggest pain points in creative work.
          The space between imagination and execution is here.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {features.map((feature) => (
            <Card key={feature.id} className="border border-primary/10 bg-card/50 backdrop-blur-sm">
              <CardHeader className="pb-2">
                <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center mb-2">
                  <feature.icon className="w-5 h-5 text-primary" />
                </div>
                <CardTitle className="text-lg">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Model Showcase with models passed as prop */}
      <ModelShowcase models={aiModels} />
      <CollaborativeCanvas />
      {/* WorkflowGallery with workflows passed as prop */}
      <WorkflowGallery workflows={workflows} />
    </div>
  );
};

export default FloraFeatures;
