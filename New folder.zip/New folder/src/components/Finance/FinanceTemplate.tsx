
import { TrendingUp, DollarSign, LineChart, BarChart4, Briefcase } from "lucide-react";
import { SpaceTemplate, SpaceType } from "@/types/space";

export const getFinanceSpaceTemplate = (): SpaceTemplate => {
  return {
    title: "Finance Space",
    description: "Advanced AI platform for financial analysis, market insights, and regulatory compliance.",
    type: "finance" as SpaceType,
    gradient: "from-[#0F766E] to-[#0E7490]",
    icon: DollarSign,
    primaryColor: "#0E7490",
    secondaryColor: "#0F766E",
    accentColor: "#14B8A6",
    features: [
      {
        id: "market-analysis",
        title: "Market Analysis & Insights",
        description: "Real-time market data and AI-powered predictive analytics",
        icon: LineChart,
        category: "analytics",
        isAvailable: true
      },
      {
        id: "portfolio-management",
        title: "Portfolio Management",
        description: "AI-driven investment strategies and portfolio optimization",
        icon: Briefcase,
        category: "management",
        isAvailable: true
      },
      {
        id: "regulatory-compliance",
        title: "Regulatory Compliance",
        description: "Stay compliant with financial regulations across global markets",
        icon: BarChart4,
        category: "compliance",
        isAvailable: true
      },
      {
        id: "trading-automation",
        title: "Trading Automation",
        description: "Automated trading strategies with risk management",
        icon: TrendingUp,
        category: "trading",
        isAvailable: true
      }
    ],
    widgets: [
      {
        id: "market-dashboard",
        title: "Market Dashboard",
        type: "chart",
        size: "large",
        priority: 1
      },
      {
        id: "portfolio-performance",
        title: "Portfolio Performance",
        type: "chart",
        size: "medium",
        priority: 2
      },
      {
        id: "regulatory-updates",
        title: "Regulatory Updates",
        type: "activity",
        size: "medium",
        priority: 3
      },
      {
        id: "financial-overview",
        title: "Financial Overview",
        type: "stats",
        size: "full",
        priority: 4
      }
    ]
  };
};

export default getFinanceSpaceTemplate;
