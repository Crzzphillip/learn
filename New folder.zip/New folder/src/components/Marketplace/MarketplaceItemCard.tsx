
import { MarketplaceItem } from '@/data/marketplaceData';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';
import { useState } from 'react';
import { Download, Star, ShoppingCart, Wrench } from 'lucide-react';

interface MarketplaceItemCardProps {
  item: MarketplaceItem;
  onPurchase: (id: string) => void;
  onDownload: (id: string) => void;
}

const MarketplaceItemCard = ({ item, onPurchase, onDownload }: MarketplaceItemCardProps) => {
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  
  const handlePurchase = () => {
    setIsPurchasing(true);
    setTimeout(() => {
      onPurchase(item.id);
      setIsPurchasing(false);
    }, 1500);
  };
  
  const handleDownload = () => {
    setIsDownloading(true);
    setTimeout(() => {
      onDownload(item.id);
      setIsDownloading(false);
    }, 2000);
  };
  
  const getCategoryIcon = () => {
    switch(item.category) {
      case 'agent': return <Bot className="w-5 h-5" />;
      case 'workflow': return <GitBranch className="w-5 h-5" />;
      case 'tool': return <Wrench className="w-5 h-5" />;
      case 'template': return <LayoutTemplate className="w-5 h-5" />;
      case 'app': return <AppWindow className="w-5 h-5" />;
      default: return null;
    }
  };
  
  // Add imports for icons that aren't already in the imports
  const Bot = ({ className }: { className: string }) => <span className={className}>🤖</span>;
  const GitBranch = ({ className }: { className: string }) => <span className={className}>⑂</span>;
  const LayoutTemplate = ({ className }: { className: string }) => <span className={className}>📄</span>;
  const AppWindow = ({ className }: { className: string }) => <span className={className}>🖥️</span>;
  
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className="relative h-40 bg-muted">
        {item.imageUrl ? (
          <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full grid place-items-center bg-gradient-to-br from-primary/20 to-secondary/20">
            {getCategoryIcon()}
          </div>
        )}
        <Badge className="absolute top-2 right-2 text-xs">{item.category}</Badge>
      </div>
      <CardContent className="p-5">
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-medium text-lg">{item.name}</h3>
          <div className="flex items-center gap-1 text-amber-500">
            <Star className="w-4 h-4 fill-amber-500" />
            <span className="text-sm">{item.rating}</span>
          </div>
        </div>
        
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{item.description}</p>
        
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full overflow-hidden">
              <img src={item.author.avatar} alt={item.author.name} className="w-full h-full object-cover" />
            </div>
            <span className="text-sm">{item.author.name}</span>
          </div>
          <span className="font-medium">{item.price} credits</span>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="flex-1 gap-1" onClick={handleDownload} disabled={isDownloading}>
            <Download className="w-4 h-4" />
            {isDownloading ? 'Downloading...' : 'Download'}
          </Button>
          <Button size="sm" className="flex-1 gap-1" onClick={handlePurchase} disabled={isPurchasing}>
            <ShoppingCart className="w-4 h-4" />
            {isPurchasing ? 'Processing...' : 'Purchase'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default MarketplaceItemCard;
