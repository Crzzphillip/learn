
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronRight, FileText, Video, Bookmark, Book, Link as LinkIcon, Download, Plus, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';

interface WorkspaceResourcesProps {
  workspace: any;
}

// Sample resources data - in a real app, this would come from the workspace data
const resources = [
  {
    id: 'res-1',
    title: 'E-commerce Setup Guide',
    description: 'Step-by-step guide for setting up your online store',
    type: 'document',
    tags: ['guide', 'setup'],
    lastUpdated: '2023-10-10',
    author: 'Alex Chen',
  },
  {
    id: 'res-2',
    title: 'Marketing Strategy Template',
    description: 'Template for creating your marketing strategy',
    type: 'document',
    tags: ['template', 'marketing'],
    lastUpdated: '2023-10-08',
    author: 'Sarah Johnson',
  },
  {
    id: 'res-3',
    title: 'Product Photography Tips',
    description: 'Learn how to take professional product photos',
    type: 'video',
    tags: ['tips', 'photography'],
    duration: '15:23',
    lastUpdated: '2023-09-28',
    author: 'Michael Brown',
  },
  {
    id: 'res-4',
    title: 'Customer Acquisition Strategies',
    description: 'Effective strategies for acquiring new customers',
    type: 'article',
    tags: ['strategy', 'marketing'],
    lastUpdated: '2023-10-05',
    author: 'Emma Wilson',
  },
  {
    id: 'res-5',
    title: 'Shopify Integration Guide',
    description: 'How to integrate your store with Shopify',
    type: 'document',
    tags: ['guide', 'integration'],
    lastUpdated: '2023-10-12',
    author: 'Alex Chen',
  },
  {
    id: 'res-6',
    title: 'Sales Pitch Deck',
    description: 'Template for creating sales presentations',
    type: 'presentation',
    tags: ['template', 'sales'],
    lastUpdated: '2023-09-20',
    author: 'Sarah Johnson',
  },
];

// Sample learning paths - in a real app, this would come from the workspace data
const learningPaths = [
  {
    id: 'lp-1',
    title: 'E-commerce Fundamentals',
    description: 'Learn the basics of running an online store',
    modules: 5,
    progress: 60,
    level: 'Beginner',
  },
  {
    id: 'lp-2',
    title: 'Advanced Marketing Techniques',
    description: 'Master advanced marketing strategies for e-commerce',
    modules: 8,
    progress: 25,
    level: 'Advanced',
  },
  {
    id: 'lp-3',
    title: 'Customer Service Excellence',
    description: 'Provide outstanding customer service for your online business',
    modules: 4,
    progress: 0,
    level: 'Intermediate',
  },
];

// Sample bookmarks - in a real app, this would come from the workspace data
const bookmarks = [
  {
    id: 'bm-1',
    title: 'Top 10 E-commerce Trends for 2023',
    url: 'https://example.com/trends',
    savedOn: '2023-10-08',
  },
  {
    id: 'bm-2',
    title: 'How to Optimize Product Pages for Conversion',
    url: 'https://example.com/optimize',
    savedOn: '2023-10-05',
  },
  {
    id: 'bm-3',
    title: 'Email Marketing Best Practices',
    url: 'https://example.com/email',
    savedOn: '2023-09-28',
  },
];

const WorkspaceResources = ({ workspace }: WorkspaceResourcesProps) => {
  const getResourceIcon = (type: string) => {
    switch (type) {
      case 'document':
        return <FileText className="w-5 h-5 text-blue-500" />;
      case 'video':
        return <Video className="w-5 h-5 text-red-500" />;
      case 'article':
        return <Book className="w-5 h-5 text-green-500" />;
      case 'presentation':
        return <Bookmark className="w-5 h-5 text-amber-500" />;
      default:
        return <ChevronRight className="w-5 h-5" />;
    }
  };
  
  return (
    <ScrollArea className="h-full w-full">
      <div className="container py-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">Workspace Resources</h1>
          <div className="flex items-center gap-3">
            <div className="relative w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search resources..."
                className="pl-8"
              />
            </div>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Add Resource
            </Button>
          </div>
        </div>
        
        <Tabs defaultValue="all">
          <TabsList>
            <TabsTrigger value="all">All Resources</TabsTrigger>
            <TabsTrigger value="learningPaths">Learning Paths</TabsTrigger>
            <TabsTrigger value="documents">Documents</TabsTrigger>
            <TabsTrigger value="bookmarks">Bookmarks</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {resources.map((resource) => (
                <Card key={resource.id} className="overflow-hidden hover:bg-muted/50 transition-colors">
                  <CardContent className="p-0">
                    <div className="p-6">
                      <div className="flex items-start gap-3 mb-2">
                        <div className="w-10 h-10 rounded-md flex items-center justify-center bg-muted">
                          {getResourceIcon(resource.type)}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{resource.title}</h3>
                          <p className="text-sm text-muted-foreground mt-1">{resource.description}</p>
                          <div className="flex items-center gap-2 mt-2">
                            {resource.tags.map((tag: string) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="mt-4 pt-4 border-t flex items-center justify-between text-xs text-muted-foreground">
                        <span>Last updated: {resource.lastUpdated}</span>
                        <span>By: {resource.author}</span>
                      </div>
                    </div>
                    <div className="bg-muted/30 p-2 flex justify-end border-t">
                      <Button variant="ghost" size="sm" className="gap-1">
                        Open <ChevronRight className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="learningPaths" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {learningPaths.map((path) => (
                <Card key={path.id} className="overflow-hidden hover:bg-muted/50 transition-colors">
                  <CardContent className="p-0">
                    <div className="p-6">
                      <div className="flex items-start gap-3 mb-2">
                        <div className="w-10 h-10 rounded-md flex items-center justify-center bg-purple-500/10">
                          <Book className="w-5 h-5 text-purple-500" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{path.title}</h3>
                          <p className="text-sm text-muted-foreground mt-1">{path.description}</p>
                          <div className="flex items-center justify-between mt-3">
                            <Badge variant="outline">
                              {path.level}
                            </Badge>
                            <span className="text-sm">{path.modules} modules</span>
                          </div>
                          <div className="w-full bg-muted h-1.5 rounded-full mt-3">
                            <div 
                              className="bg-purple-500 h-1.5 rounded-full" 
                              style={{ width: `${path.progress}%` }}
                            ></div>
                          </div>
                          <div className="mt-1 text-xs text-right">
                            {path.progress > 0 ? `${path.progress}% complete` : 'Not started'}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="bg-muted/30 p-2 flex justify-end border-t">
                      <Button variant="ghost" size="sm" className="gap-1">
                        {path.progress > 0 ? 'Continue' : 'Start Learning'} <ChevronRight className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="documents" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {resources.filter(r => r.type === 'document' || r.type === 'presentation').map((resource) => (
                <Card key={resource.id} className="overflow-hidden hover:bg-muted/50 transition-colors">
                  <CardContent className="p-0">
                    <div className="p-6">
                      <div className="flex items-start gap-3 mb-2">
                        <div className="w-10 h-10 rounded-md flex items-center justify-center bg-muted">
                          {getResourceIcon(resource.type)}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{resource.title}</h3>
                          <p className="text-sm text-muted-foreground mt-1">{resource.description}</p>
                          <div className="flex items-center gap-2 mt-2">
                            {resource.tags.map((tag: string) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="mt-4 pt-4 border-t flex items-center justify-between text-xs text-muted-foreground">
                        <span>Last updated: {resource.lastUpdated}</span>
                        <span>By: {resource.author}</span>
                      </div>
                    </div>
                    <div className="bg-muted/30 p-2 flex justify-end border-t">
                      <Button variant="ghost" size="sm" className="gap-1 mr-2">
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm" className="gap-1">
                        Open <ChevronRight className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="bookmarks" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Saved Links</CardTitle>
                <CardDescription>Bookmarked resources relevant to this workspace</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {bookmarks.map((bookmark) => (
                    <div key={bookmark.id} className="flex items-start p-3 rounded-lg hover:bg-muted">
                      <div className="w-8 h-8 rounded-md bg-blue-500/10 flex items-center justify-center mr-3">
                        <LinkIcon className="w-4 h-4 text-blue-500" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">{bookmark.title}</h4>
                        <a href={bookmark.url} className="text-sm text-blue-500 hover:underline" target="_blank" rel="noopener noreferrer">
                          {bookmark.url}
                        </a>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Saved on {bookmark.savedOn}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </ScrollArea>
  );
};

export default WorkspaceResources;
