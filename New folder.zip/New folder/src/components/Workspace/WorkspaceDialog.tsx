import { X, Globe, Users, MessageSquare, Webhook, Wrench, Puzzle, Layers, Github } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';

interface WorkspaceDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function WorkspaceDialog({ open, onOpenChange }: WorkspaceDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl w-full h-[90vh] overflow-hidden p-0 gap-0 bg-black/80 backdrop-blur-xl border border-white/20 rounded-xl">
        <div className="flex h-full">
          {/* Left sidebar */}
          <div className="w-64 border-r border-white/10 flex flex-col">
            <DialogHeader className="p-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 grid place-items-center">
                  <Globe className="h-5 w-5 text-white" />
                </div>
                <div>
                  <DialogTitle className="text-white">Workspace</DialogTitle>
                  <p className="text-xs text-white/60">Community Hub</p>
                </div>
              </div>
            </DialogHeader>
            
            <ScrollArea className="flex-1">
              <div className="p-3 space-y-6">
                <div>
                  <h3 className="text-xs font-medium text-white/40 mb-3 px-3">MAIN</h3>
                  <div className="space-y-1">
                    <Button variant="ghost" className="w-full justify-start text-white/70 hover:text-white">
                      <Globe className="mr-2 h-4 w-4" />
                      Overview
                    </Button>
                    <Button variant="ghost" className="w-full justify-start text-white/70 hover:text-white">
                      <Users className="mr-2 h-4 w-4" />
                      Members
                    </Button>
                    <Button variant="ghost" className="w-full justify-start text-white/70 hover:text-white">
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Discussions
                    </Button>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-xs font-medium text-white/40 mb-3 px-3">RESOURCES</h3>
                  <div className="space-y-1">
                    <Button variant="ghost" className="w-full justify-start text-white/70 hover:text-white">
                      <Webhook className="mr-2 h-4 w-4" />
                      Integrations
                    </Button>
                    <Button variant="ghost" className="w-full justify-start text-white/70 hover:text-white">
                      <Wrench className="mr-2 h-4 w-4" />
                      Tools
                    </Button>
                    <Button variant="ghost" className="w-full justify-start text-white/70 hover:text-white">
                      <Puzzle className="mr-2 h-4 w-4" />
                      Extensions
                    </Button>
                    <Button variant="ghost" className="w-full justify-start text-white/70 hover:text-white bg-white/10">
                      <Layers className="mr-2 h-4 w-4" />
                      Templates
                    </Button>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-xs font-medium text-white/40 mb-3 px-3">CONNECTED</h3>
                  <div className="space-y-1">
                    <Button variant="ghost" className="w-full justify-start text-white/70 hover:text-white">
                      <Github className="mr-2 h-4 w-4" />
                      GitHub
                    </Button>
                  </div>
                </div>
              </div>
            </ScrollArea>
            
            <div className="p-4 border-t border-white/10">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="https://github.com/shadcn.png" />
                    <AvatarFallback>U</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium text-white">User</p>
                    <p className="text-xs text-white/60">Admin</p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
          
          {/* Main content */}
          <div className="flex-1 flex flex-col min-h-0">
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <div className="flex-1">
                <Input 
                  placeholder="Search workspace..." 
                  className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0 bg-white/5 text-white placeholder:text-white/40"
                />
              </div>
              <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)} className="ml-2 text-white/70 hover:text-white">
                <X className="h-5 w-5" />
              </Button>
            </div>
            
            <Tabs defaultValue="hub" className="flex-1 flex flex-col min-h-0">
              <div className="px-4 py-2 border-b border-white/10">
                <TabsList className="bg-white/5 p-1">
                  <TabsTrigger value="hub" className="text-white data-[state=active]:bg-white/10">Hub</TabsTrigger>
                  <TabsTrigger value="chat" className="text-white data-[state=active]:bg-white/10">Chat</TabsTrigger>
                  <TabsTrigger value="tools" className="text-white data-[state=active]:bg-white/10">Tools</TabsTrigger>
                  <TabsTrigger value="integrations" className="text-white data-[state=active]:bg-white/10">Integrations</TabsTrigger>
                </TabsList>
              </div>
              
              <TabsContent value="hub" className="flex-1 p-4 overflow-auto space-y-6 m-0">
                <Card className="bg-white/5 border-white/10 text-white">
                  <CardHeader>
                    <CardTitle>Welcome to Workspace Hub</CardTitle>
                    <CardDescription className="text-white/60">Connect with your team and access resources</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-4">
                        <h3 className="text-sm font-medium">Recent Activities</h3>
                        
                        <div className="space-y-3">
                          <div className="flex items-start gap-3">
                            <Avatar className="h-8 w-8">
                              <AvatarImage src="https://github.com/shadcn.png" />
                              <AvatarFallback>JD</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="text-sm"><span className="font-medium">John Doe</span> updated the workflow</p>
                              <p className="text-xs text-white/60">2 hours ago</p>
                            </div>
                          </div>
                          
                          <div className="flex items-start gap-3">
                            <Avatar className="h-8 w-8">
                              <AvatarImage src="https://github.com/shadcn.png" />
                              <AvatarFallback>AS</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="text-sm"><span className="font-medium">Alice Smith</span> added new tools</p>
                              <p className="text-xs text-white/60">Yesterday</p>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <h3 className="text-sm font-medium">Resources</h3>
                        
                        <div className="space-y-3">
                          <Button variant="outline" className="w-full justify-start border-white/10 hover:bg-white/10 text-white">
                            <Webhook className="mr-2 h-4 w-4" />
                            Connect APIs
                          </Button>
                          
                          <Button variant="outline" className="w-full justify-start border-white/10 hover:bg-white/10 text-white">
                            <Wrench className="mr-2 h-4 w-4" />
                            Add Custom Tools
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="bg-white/5 border-white/10 text-white">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Team</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex -space-x-2">
                        <Avatar className="h-8 w-8 border-2 border-background">
                          <AvatarImage src="https://github.com/shadcn.png" />
                          <AvatarFallback>JD</AvatarFallback>
                        </Avatar>
                        <Avatar className="h-8 w-8 border-2 border-background">
                          <AvatarImage src="https://github.com/shadcn.png" />
                          <AvatarFallback>AS</AvatarFallback>
                        </Avatar>
                        <Avatar className="h-8 w-8 border-2 border-background">
                          <AvatarImage src="https://github.com/shadcn.png" />
                          <AvatarFallback>JC</AvatarFallback>
                        </Avatar>
                        <div className="h-8 w-8 rounded-full border-2 border-background bg-white/20 grid place-items-center">
                          <span className="text-xs">+2</span>
                        </div>
                      </div>
                      <Button variant="ghost" className="w-full mt-3 text-sm text-white/70 hover:text-white">View All</Button>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-white/5 border-white/10 text-white">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Templates</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <Badge className="bg-purple-500/20 text-purple-300 hover:bg-purple-500/30">Workflow</Badge>
                        <Badge className="bg-blue-500/20 text-blue-300 hover:bg-blue-500/30">App</Badge>
                        <Badge className="bg-green-500/20 text-green-300 hover:bg-green-500/30">Dashboard</Badge>
                      </div>
                      <Button variant="ghost" className="w-full mt-3 text-sm text-white/70 hover:text-white">Browse All</Button>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-white/5 border-white/10 text-white">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base">Quick Stats</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-white/70">Workflows</span>
                          <span>12</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-white/70">Apps</span>
                          <span>5</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-white/70">Tools</span>
                          <span>18</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="chat" className="flex-1 p-4 overflow-auto m-0">
                <Card className="bg-white/5 border-white/10 text-white h-full flex flex-col">
                  <CardContent className="flex-1 p-4">
                    <div className="text-center text-white/60 h-full flex flex-col items-center justify-center">
                      <MessageSquare className="h-12 w-12 mb-4 opacity-40" />
                      <p>Team chat feature coming soon.</p>
                      <p className="text-sm">Communicate with your team in real-time.</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="tools" className="flex-1 p-4 overflow-auto m-0">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <Card key={i} className="bg-white/5 border-white/10 text-white">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-base">Tool {i + 1}</CardTitle>
                          <Badge variant="outline" className="border-white/10">New</Badge>
                        </div>
                        <CardDescription className="text-white/60">Description for Tool {i + 1}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Button variant="outline" className="w-full border-white/10 hover:bg-white/10 text-white">
                          Add to Workspace
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="integrations" className="flex-1 p-4 overflow-auto m-0">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <Card key={i} className="bg-white/5 border-white/10 text-white">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-base">Integration {i + 1}</CardTitle>
                          {i % 2 === 0 && (
                            <Badge className="bg-green-500/20 text-green-300">Connected</Badge>
                          )}
                        </div>
                        <CardDescription className="text-white/60">Description for Integration {i + 1}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Button variant={i % 2 === 0 ? "destructive" : "outline"} className="w-full border-white/10 hover:bg-white/10 text-white">
                          {i % 2 === 0 ? "Disconnect" : "Connect"}
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
