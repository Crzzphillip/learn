
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Users,
  MessageSquare,
  GitCommit,
  Calendar,
  Star,
  BarChart3
} from "lucide-react";
import { Workspace } from "@/services/workspaceService";

interface CollaborationStatsProps {
  workspace: Workspace;
}

const CollaborationStats = ({ workspace }: CollaborationStatsProps) => {
  // Safely handle the case where workspace might be undefined
  if (!workspace) {
    return null;
  }

  // Calculate team activity score (0-100)
  const teamActivityScore = 72;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Collaboration Stats</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Team Activity Score */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-medium">Team Activity Score</h3>
            <span className="text-xl font-bold">{teamActivityScore}</span>
          </div>
          <Progress value={teamActivityScore} className="h-2" />
          <div className="text-xs text-muted-foreground">
            Based on team contributions, response time, and overall engagement
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-2">
              <div className="bg-primary/20 p-2 rounded-full">
                <Users className="w-4 h-4 text-primary" />
              </div>
              <div>
                <div className="text-sm font-medium">Active Members</div>
                <div className="text-xl font-bold">
                  {workspace.activeCollaborators ? workspace.activeCollaborators.length : 1}
                </div>
              </div>
            </div>
          </div>

          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-2">
              <div className="bg-blue-500/20 p-2 rounded-full">
                <MessageSquare className="w-4 h-4 text-blue-500" />
              </div>
              <div>
                <div className="text-sm font-medium">Comments</div>
                <div className="text-xl font-bold">24</div>
              </div>
            </div>
          </div>

          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-2">
              <div className="bg-green-500/20 p-2 rounded-full">
                <GitCommit className="w-4 h-4 text-green-500" />
              </div>
              <div>
                <div className="text-sm font-medium">Commits</div>
                <div className="text-xl font-bold">47</div>
              </div>
            </div>
          </div>

          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-2">
              <div className="bg-amber-500/20 p-2 rounded-full">
                <Calendar className="w-4 h-4 text-amber-500" />
              </div>
              <div>
                <div className="text-sm font-medium">Days Active</div>
                <div className="text-xl font-bold">18</div>
              </div>
            </div>
          </div>
        </div>

        {/* Top Contributors */}
        <div className="space-y-2">
          <h3 className="text-sm font-medium">Top Contributors</h3>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Avatar>
                  <AvatarImage src={
                    workspace.creator ? workspace.creator.avatar : "https://i.pravatar.cc/150?u=default"
                  } />
                  <AvatarFallback>
                    {workspace.creator ? workspace.creator.name.charAt(0) : "U"}
                  </AvatarFallback>
                </Avatar>
                <div className="text-sm font-medium">
                  {workspace.creator ? workspace.creator.name : "Unknown User"}
                </div>
              </div>
              <div className="flex items-center gap-1 text-sm text-amber-500">
                <Star className="w-4 h-4 fill-amber-500" />
                <span>23 pts</span>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Avatar>
                  <AvatarImage src="https://i.pravatar.cc/150?u=jamie" />
                  <AvatarFallback>J</AvatarFallback>
                </Avatar>
                <div className="text-sm font-medium">Jamie Rivera</div>
              </div>
              <div className="flex items-center gap-1 text-sm text-amber-500">
                <Star className="w-4 h-4 fill-amber-500" />
                <span>19 pts</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default CollaborationStats;
