
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, PaperclipIcon, Smile } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageItem } from "@/services/collaborationService";

interface TeamChatProps {
  messagesData: MessageItem[];
  formatTimeAgo: (timestamp: string) => string;
}

const TeamChat = ({ messagesData, formatTimeAgo }: TeamChatProps) => {
  return (
    <Card className="h-[500px] flex flex-col">
      <CardHeader className="px-4 py-3 border-b">
        <CardTitle>Team Chat</CardTitle>
      </CardHeader>
      
      <CardContent className="flex-1 overflow-hidden p-0">
        <ScrollArea className="h-[370px] p-4">
          <div className="space-y-4">
            {messagesData.map((message) => (
              <div key={message.id} className="flex gap-3">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={message.user.avatar} />
                  <AvatarFallback>{message.user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">{message.user.name}</span>
                    <span className="text-xs text-muted-foreground">
                      {formatTimeAgo(message.timestamp)}
                    </span>
                  </div>
                  <div className="mt-1 text-sm">
                    {message.content}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
      
      <CardFooter className="p-4 border-t">
        <div className="flex w-full items-center gap-2">
          <Button variant="outline" size="icon" className="shrink-0">
            <PaperclipIcon className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" className="shrink-0">
            <Smile className="h-4 w-4" />
          </Button>
          <Input placeholder="Type a message..." className="flex-1" />
          <Button size="sm" className="shrink-0">
            <Send className="h-4 w-4 mr-2" />
            Send
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default TeamChat;
