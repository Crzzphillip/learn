
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserPlus } from "lucide-react";
import { useState } from "react";

const InviteMembersDialog = () => {
  const [emails, setEmails] = useState<string[]>(['']);
  const [open, setOpen] = useState(false);
  const [selectedRole, setSelectedRole] = useState("editor");

  const addEmailField = () => {
    setEmails([...emails, '']);
  };

  const updateEmail = (index: number, value: string) => {
    const updatedEmails = [...emails];
    updatedEmails[index] = value;
    setEmails(updatedEmails);
  };

  const handleInvite = () => {
    // Filter out empty emails
    const validEmails = emails.filter(email => email.trim() !== '');
    console.log('Inviting members:', validEmails, 'with role:', selectedRole);
    
    // Close dialog and reset form
    setOpen(false);
    setEmails(['']);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <UserPlus className="mr-2 h-4 w-4" />
          Invite Members
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Invite Team Members</DialogTitle>
          <DialogDescription>
            Add teammates to collaborate on this workspace.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          {emails.map((email, index) => (
            <div key={index} className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor={`email-${index}`} className="text-right">
                Email {index + 1}
              </Label>
              <Input
                id={`email-${index}`}
                value={email}
                onChange={(e) => updateEmail(index, e.target.value)}
                placeholder="colleague@company.com"
                className="col-span-3"
              />
            </div>
          ))}
          
          <div className="grid grid-cols-4 items-center gap-4">
            <div className="text-right">
              <Button 
                type="button" 
                variant="ghost" 
                size="sm" 
                onClick={addEmailField}
              >
                + Add
              </Button>
            </div>
            <div className="col-span-3">
              <Select value={selectedRole} onValueChange={setSelectedRole}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="editor">Editor</SelectItem>
                  <SelectItem value="viewer">Viewer</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" onClick={handleInvite}>Invite Members</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default InviteMembersDialog;
