
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Filter, Search, MoreVertical, EyeOff, Clock, Lock } from "lucide-react";
import { Workspace } from "@/services/workspaceService";
import { PendingInvite, getTeamMembers } from "@/services/collaborationService";

interface TeamMembersProps {
  workspace: Workspace;
  pendingInvites: PendingInvite[];
  formatTimeAgo: (timestamp: string) => string;
}

const TeamMembers = ({ workspace, pendingInvites, formatTimeAgo }: TeamMembersProps) => {
  // Get team members using our service
  const teamMembers = getTeamMembers(workspace);
  
  return (
    <Card className="md:col-span-2">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Team Members</CardTitle>
            <CardDescription>
              {teamMembers.length} members in this workspace
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="h-8 gap-1">
              <Filter className="w-3.5 h-3.5" />
              Filter
            </Button>
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search members..."
                className="pl-8 h-8 w-48"
              />
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Owner - should always be at least one team member (the owner) */}
          {teamMembers.length > 0 && teamMembers.filter(member => member.role === 'owner').map(owner => (
            <div key={owner.id} className="flex items-center justify-between border-b pb-4">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={owner.avatar} />
                  <AvatarFallback>{owner.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-medium">{owner.name}</div>
                  <div className="text-sm text-muted-foreground flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5" />
                    Workspace Owner
                  </div>
                </div>
              </div>
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                Owner
              </Badge>
            </div>
          ))}
          
          {/* Collaborators - other team members that aren't owners */}
          {teamMembers.filter(member => member.role !== 'owner').map((collaborator) => (
            <div key={collaborator.id} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={collaborator.avatar} />
                  <AvatarFallback>{collaborator.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-medium">{collaborator.name}</div>
                  <div className="text-sm text-muted-foreground">
                    {collaborator.role === 'editor' ? 'Can edit content' : 'View only access'}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className={
                  collaborator.role === 'editor' 
                    ? "bg-blue-500/10 text-blue-500 border-blue-500/20"
                    : "bg-amber-500/10 text-amber-500 border-amber-500/20"
                }>
                  {collaborator.role === 'editor' ? 'Editor' : 'Viewer'}
                </Badge>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
          
          {/* Pending Invites */}
          {pendingInvites.length > 0 && (
            <div className="mt-6">
              <h3 className="text-sm font-medium text-muted-foreground mb-3">Pending Invites</h3>
              {pendingInvites.map((invite) => (
                <div key={invite.id} className="flex items-center justify-between py-2">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-muted flex items-center justify-center">
                      <EyeOff className="w-4 h-4 text-muted-foreground" />
                    </div>
                    <div>
                      <div className="font-medium">{invite.email}</div>
                      <div className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        Invited {formatTimeAgo(invite.invited)}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="bg-muted text-muted-foreground">
                      Pending
                    </Badge>
                    <Button variant="ghost" size="sm" className="h-8">
                      Resend
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default TeamMembers;
