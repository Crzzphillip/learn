
// Sample activity data - in a real app, this would come from the workspace data
export const activityData = [
  {
    id: 'act-1',
    user: {
      id: 'user-1',
      name: 'Alex Chen',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alex'
    },
    action: 'modified',
    item: 'Customer Support Agent',
    itemType: 'agent',
    timestamp: '2023-10-18T14:35:00Z',
  },
  {
    id: 'act-2',
    user: {
      id: 'user-2',
      name: 'Sarah Johnson',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah'
    },
    action: 'added',
    item: 'Lead Generation Workflow',
    itemType: 'workflow',
    timestamp: '2023-10-18T11:20:00Z',
  },
  {
    id: 'act-3',
    user: {
      id: 'user-3',
      name: 'Michael Brown',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Michael'
    },
    action: 'commented on',
    item: 'Marketing Strategy Template',
    itemType: 'document',
    comment: 'We should update this for the Q4 campaign.',
    timestamp: '2023-10-17T16:45:00Z',
  },
  {
    id: 'act-4',
    user: {
      id: 'user-1',
      name: 'Alex Chen',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alex'
    },
    action: 'created',
    item: 'Analytics Dashboard',
    itemType: 'app',
    timestamp: '2023-10-17T10:15:00Z',
  },
  {
    id: 'act-5',
    user: {
      id: 'user-2',
      name: 'Sarah Johnson',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah'
    },
    action: 'updated',
    item: 'E-commerce Setup Guide',
    itemType: 'document',
    timestamp: '2023-10-16T15:30:00Z',
  },
];

// Sample messages data - in a real app, this would come from the workspace chat system
export const messagesData = [
  {
    id: 'msg-1',
    user: {
      id: 'user-1',
      name: 'Alex Chen',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alex'
    },
    content: "I've updated the customer support agent with new responses. Can someone test it?",
    timestamp: '2023-10-18T14:40:00Z',
  },
  {
    id: 'msg-2',
    user: {
      id: 'user-2',
      name: 'Sarah Johnson',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah'
    },
    content: 'I can test it this afternoon. Also, the lead generation workflow is ready for review.',
    timestamp: '2023-10-18T14:45:00Z',
  },
  {
    id: 'msg-3',
    user: {
      id: 'user-3',
      name: 'Michael Brown',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Michael'
    },
    content: 'Great work! I noticed the analytics dashboard is showing some interesting trends with the new traffic sources.',
    timestamp: '2023-10-18T15:00:00Z',
  },
  {
    id: 'msg-4',
    user: {
      id: 'user-1',
      name: 'Alex Chen',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alex'
    },
    content: 'Yes, I was just looking at that. The conversion rate from social media is higher than expected.',
    timestamp: '2023-10-18T15:05:00Z',
  },
];

// Sample pending invites - in a real app, this would come from the workspace data
export const pendingInvites = [
  {
    id: 'inv-1',
    email: 'emma.wilson@example.com',
    role: 'editor',
    invited: '2023-10-17T09:30:00Z',
    status: 'pending',
  },
  {
    id: 'inv-2',
    email: 'david.miller@example.com',
    role: 'viewer',
    invited: '2023-10-18T11:15:00Z',
    status: 'pending',
  },
];

// Utility function for formatting timestamps
export const formatTimeAgo = (timestamp: string) => {
  const now = new Date();
  const time = new Date(timestamp);
  const diff = now.getTime() - time.getTime();
  
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) return `${days}d ago`;
  if (hours > 0) return `${hours}h ago`;
  if (minutes > 0) return `${minutes}m ago`;
  return 'Just now';
};
