
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Save, 
  Monitor, 
  Palette, 
  Code, 
  Share, 
  Users, 
  Settings 
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import TeamManagement from './TeamManagement';
import SharedSettings from './SharedSettings';

export type SessionMode = 'developer' | 'creative' | 'business';
export type WorkspaceData = {
  id: string;
  name: string;
  mode: SessionMode;
  nodes: any[];
  edges: any[];
  lastModified: Date;
  collaborators?: number;
};

const WorkspaceManager = () => {
  const [currentMode, setCurrentMode] = useState<SessionMode>('developer');
  const [isCollaborating, setIsCollaborating] = useState(true);
  const [activeCollaborators, setActiveCollaborators] = useState(3);
  const { toast } = useToast();

  const handleModeChange = (mode: SessionMode) => {
    setCurrentMode(mode);
    toast({
      title: 'Mode Changed',
      description: `Switched to ${mode} mode`,
    });
  };

  const handleSaveWorkspace = () => {
    // TODO: Implement workspace saving
    toast({
      title: 'Workspace Saved',
      description: 'Your workspace has been saved successfully',
    });
  };

  const toggleCollaboration = () => {
    setIsCollaborating(!isCollaborating);
    toast({
      title: isCollaborating ? 'Collaboration Disabled' : 'Collaboration Enabled',
      description: isCollaborating 
        ? 'You are now working in private mode' 
        : 'Other team members can now see and edit this workspace',
    });
  };

  return (
    <div className="fixed top-4 right-4 z-50 bg-background/95 backdrop-blur-sm p-4 rounded-lg shadow-lg">
      <div className="flex items-center gap-4">
        <Select value={currentMode} onValueChange={handleModeChange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select mode" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="developer">
              <div className="flex items-center gap-2">
                <Code className="w-4 h-4" />
                Developer Mode
              </div>
            </SelectItem>
            <SelectItem value="creative">
              <div className="flex items-center gap-2">
                <Palette className="w-4 h-4" />
                Creative Mode
              </div>
            </SelectItem>
            <SelectItem value="business">
              <div className="flex items-center gap-2">
                <Monitor className="w-4 h-4" />
                Business Mode
              </div>
            </SelectItem>
          </SelectContent>
        </Select>
        
        <Button variant="outline" size="sm" onClick={handleSaveWorkspace} className="gap-2">
          <Save className="w-4 h-4" />
          Save Workspace
        </Button>

        <Dialog>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm" className="gap-2">
              <Users className="w-4 h-4" />
              <span>Collaboration</span>
              {isCollaborating && (
                <Badge variant="secondary" className="ml-1 h-5 px-1.5 bg-green-500/20 text-green-500 hover:bg-green-500/20">
                  {activeCollaborators}
                </Badge>
              )}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Workspace Collaboration</DialogTitle>
              <DialogDescription>
                Manage team members and collaboration settings
              </DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="team">
              <TabsList className="grid grid-cols-2 w-full">
                <TabsTrigger value="team" className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Team Members
                </TabsTrigger>
                <TabsTrigger value="settings" className="flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  Shared Settings
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="team" className="mt-4">
                <TeamManagement workspaceId="ws-1" workspaceName="AI Content Generator" />
              </TabsContent>
              
              <TabsContent value="settings" className="mt-4">
                <SharedSettings workspaceId="ws-1" workspaceName="AI Content Generator" />
              </TabsContent>
            </Tabs>
            
            <div className="flex justify-between mt-4">
              <Button 
                variant={isCollaborating ? "destructive" : "default"} 
                onClick={toggleCollaboration}
                className="gap-2"
              >
                {isCollaborating ? (
                  <>
                    <Share className="w-4 h-4" />
                    Disable Collaboration
                  </>
                ) : (
                  <>
                    <Share className="w-4 h-4" />
                    Enable Collaboration
                  </>
                )}
              </Button>
              
              <Button variant="outline" className="gap-2">
                <Share className="w-4 h-4" />
                Create Share Link
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default WorkspaceManager;
