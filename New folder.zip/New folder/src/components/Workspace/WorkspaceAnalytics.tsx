import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { Calendar, ChevronDown, Download, RefreshCw } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { getWorkspaceAnalytics } from '@/services/workspaceAnalyticsService';
import { Workspace } from '@/services/workspaceService';

interface WorkspaceAnalyticsProps {
  workspace: Workspace;
}

// Sample data
const performanceData = [
  { name: 'Mon', leads: 12, conversions: 4, revenue: 420 },
  { name: 'Tue', leads: 19, conversions: 7, revenue: 780 },
  { name: 'Wed', leads: 15, conversions: 5, revenue: 550 },
  { name: 'Thu', leads: 22, conversions: 9, revenue: 990 },
  { name: 'Fri', leads: 28, conversions: 11, revenue: 1250 },
  { name: 'Sat', leads: 16, conversions: 6, revenue: 680 },
  { name: 'Sun', leads: 15, conversions: 5, revenue: 560 },
];

const channelData = [
  { name: 'Social Media', value: 35 },
  { name: 'Search', value: 25 },
  { name: 'Direct', value: 20 },
  { name: 'Email', value: 15 },
  { name: 'Referral', value: 5 },
];

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

const productData = [
  { name: 'Product A', sales: 120, revenue: 1800 },
  { name: 'Product B', sales: 90, revenue: 1350 },
  { name: 'Product C', sales: 70, revenue: 980 },
  { name: 'Product D', sales: 50, revenue: 750 },
  { name: 'Product E', sales: 30, revenue: 450 },
];

const WorkspaceAnalytics = ({ workspace }: WorkspaceAnalyticsProps) => {
  // Get analytics data using the service - this will now always return valid data
  const analytics = getWorkspaceAnalytics(workspace);
  
  return (
    <ScrollArea className="h-full w-full">
      <div className="container py-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">Analytics Dashboard</h1>
          <div className="flex items-center gap-3">
            <Select defaultValue="7days">
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Time period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="yesterday">Yesterday</SelectItem>
                <SelectItem value="7days">Last 7 days</SelectItem>
                <SelectItem value="30days">Last 30 days</SelectItem>
                <SelectItem value="90days">Last 90 days</SelectItem>
                <SelectItem value="custom">Custom range</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" className="gap-2">
              <RefreshCw className="w-4 h-4" />
              Refresh
            </Button>
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              Export
            </Button>
          </div>
        </div>
        
        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col">
                <span className="text-muted-foreground text-sm">Total Leads</span>
                <div className="flex items-end justify-between mt-2">
                  <span className="text-3xl font-semibold">{analytics.leads}</span>
                  <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                    {analytics.growth}
                  </Badge>
                </div>
                <span className="text-xs text-muted-foreground mt-2">Compared to previous period</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col">
                <span className="text-muted-foreground text-sm">Conversions</span>
                <div className="flex items-end justify-between mt-2">
                  <span className="text-3xl font-semibold">{analytics.conversions}</span>
                  <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                    +12%
                  </Badge>
                </div>
                <span className="text-xs text-muted-foreground mt-2">Compared to previous period</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col">
                <span className="text-muted-foreground text-sm">Revenue</span>
                <div className="flex items-end justify-between mt-2">
                  <span className="text-3xl font-semibold">{analytics.revenue}</span>
                  <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                    +18%
                  </Badge>
                </div>
                <span className="text-xs text-muted-foreground mt-2">Compared to previous period</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col">
                <span className="text-muted-foreground text-sm">Conversion Rate</span>
                <div className="flex items-end justify-between mt-2">
                  <span className="text-3xl font-semibold">
                    {Math.round(analytics.conversions / analytics.leads * 100)}%
                  </span>
                  <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                    +5%
                  </Badge>
                </div>
                <span className="text-xs text-muted-foreground mt-2">Compared to previous period</span>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Main Charts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Performance Overview</CardTitle>
              <CardDescription>Daily leads, conversions, and revenue</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={performanceData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Legend />
                    <Line yAxisId="left" type="monotone" dataKey="leads" stroke="#8884d8" activeDot={{ r: 8 }} />
                    <Line yAxisId="left" type="monotone" dataKey="conversions" stroke="#82ca9d" />
                    <Line yAxisId="right" type="monotone" dataKey="revenue" stroke="#ffc658" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Lead Sources</CardTitle>
              <CardDescription>Distribution of leads by channel</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={channelData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {channelData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Product Performance */}
        <Card>
          <CardHeader>
            <CardTitle>Product Performance</CardTitle>
            <CardDescription>Sales and revenue by product</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={productData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Bar yAxisId="left" dataKey="sales" fill="#8884d8" name="Sales (units)" />
                  <Bar yAxisId="right" dataKey="revenue" fill="#82ca9d" name="Revenue ($)" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        {/* Analytics Details Tabs */}
        <Tabs defaultValue="performance">
          <TabsList>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="customers">Customers</TabsTrigger>
            <TabsTrigger value="marketing">Marketing</TabsTrigger>
            <TabsTrigger value="inventory">Inventory</TabsTrigger>
          </TabsList>
          
          <TabsContent value="performance" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance Metrics</CardTitle>
                <CardDescription>Detailed analysis of business performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-medium mb-2">Traffic Overview</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Total Visitors</span>
                          <span className="font-medium">3,582</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">New Visitors</span>
                          <span className="font-medium">2,825 (78.9%)</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Returning Visitors</span>
                          <span className="font-medium">757 (21.1%)</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Bounce Rate</span>
                          <span className="font-medium">42.3%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Avg. Session Duration</span>
                          <span className="font-medium">3m 27s</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium mb-2">Sales Overview</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Total Orders</span>
                          <span className="font-medium">147</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Average Order Value</span>
                          <span className="font-medium">$85.60</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Total Sales</span>
                          <span className="font-medium">$12,580</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Refund Rate</span>
                          <span className="font-medium">3.2%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Processing Orders</span>
                          <span className="font-medium">12</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="customers" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Customer Insights</CardTitle>
                <CardDescription>Understanding your customer base</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-medium mb-2">Demographics</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Age Group (18-24)</span>
                          <span className="font-medium">28%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Age Group (25-34)</span>
                          <span className="font-medium">42%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Age Group (35-44)</span>
                          <span className="font-medium">18%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Age Group (45+)</span>
                          <span className="font-medium">12%</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium mb-2">Customer Loyalty</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">New Customers</span>
                          <span className="font-medium">85</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Returning Customers</span>
                          <span className="font-medium">62</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Customer Retention Rate</span>
                          <span className="font-medium">42.2%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Repeat Purchase Rate</span>
                          <span className="font-medium">27.5%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="marketing" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Marketing Effectiveness</CardTitle>
                <CardDescription>Analysis of marketing campaigns and channels</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-medium mb-2">Channel Performance</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Social Media CTR</span>
                          <span className="font-medium">3.2%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Email Open Rate</span>
                          <span className="font-medium">28.5%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Email Click Rate</span>
                          <span className="font-medium">4.7%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Search Conversion Rate</span>
                          <span className="font-medium">5.8%</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium mb-2">Campaign Results</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Summer Sale Campaign</span>
                          <span className="font-medium">$4,250 (ROI: 320%)</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">New Product Launch</span>
                          <span className="font-medium">$3,180 (ROI: 225%)</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Holiday Promotion</span>
                          <span className="font-medium">$5,120 (ROI: 410%)</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Loyalty Program</span>
                          <span className="font-medium">$1,870 (ROI: 150%)</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="inventory" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Inventory Status</CardTitle>
                <CardDescription>Overview of current inventory and stock levels</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-medium mb-2">Inventory Summary</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Total Products</span>
                          <span className="font-medium">128</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">In Stock Products</span>
                          <span className="font-medium">112</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Low Stock Products</span>
                          <span className="font-medium">9</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Out of Stock Products</span>
                          <span className="font-medium">7</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium mb-2">Inventory Value</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Total Inventory Value</span>
                          <span className="font-medium">$87,580</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Average Product Value</span>
                          <span className="font-medium">$684.22</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Inventory Turnover Rate</span>
                          <span className="font-medium">4.2x</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Days of Supply</span>
                          <span className="font-medium">48 days</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </ScrollArea>
  );
};

export default WorkspaceAnalytics;
