
import { Workspace } from "@/services/workspaceService";

export interface WorkspaceFlowProps {
  workspace: Workspace;
}

const WorkspaceFlow = ({ workspace }: WorkspaceFlowProps) => {
  return (
    <div className="bg-card rounded-lg border shadow-sm p-6">
      <h2 className="text-xl font-semibold mb-4">Workspace Flow</h2>
      <div className="flex items-center justify-center h-[500px] text-muted-foreground">
        Flow visualization for {workspace.title} coming soon
      </div>
    </div>
  );
};

export default WorkspaceFlow;
