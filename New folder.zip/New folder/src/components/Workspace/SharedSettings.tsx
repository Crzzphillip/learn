
import { useState } from 'react';
import { Settings, Lock, Eye, Share2, Palette, FileCode, History } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";

interface SharedSettingsProps {
  workspaceId: string;
  workspaceName: string;
}

interface SettingItem {
  id: string;
  label: string;
  description: string;
  icon: React.ElementType;
  type: 'toggle' | 'select' | 'input' | 'radio';
  options?: string[];
  value: any;
}

const SharedSettings = ({ workspaceId, workspaceName }: SharedSettingsProps) => {
  const { toast } = useToast();
  
  const [settings, setSettings] = useState<SettingItem[]>([
    {
      id: 'visibility',
      label: 'Workspace Visibility',
      description: 'Control who can see this workspace',
      icon: Eye,
      type: 'select',
      options: ['Team only', 'Public within organization', 'Public'],
      value: 'Team only'
    },
    {
      id: 'autoSave',
      label: 'Auto-save',
      description: 'Automatically save changes to workspace',
      icon: History,
      type: 'toggle',
      value: true
    },
    {
      id: 'saveInterval',
      label: 'Auto-save Interval',
      description: 'How often to automatically save changes',
      icon: History,
      type: 'select',
      options: ['30 seconds', '1 minute', '5 minutes', '10 minutes'],
      value: '5 minutes'
    },
    {
      id: 'shareLinks',
      label: 'Share Links',
      description: 'Allow team members to create share links',
      icon: Share2,
      type: 'toggle',
      value: true
    },
    {
      id: 'lockEditing',
      label: 'Lock Editing',
      description: 'Prevent further changes to this workspace',
      icon: Lock,
      type: 'toggle',
      value: false
    },
    {
      id: 'theme',
      label: 'Workspace Theme',
      description: 'Customize the appearance of this workspace',
      icon: Palette,
      type: 'radio',
      options: ['Default', 'Custom'],
      value: 'Default'
    },
    {
      id: 'customThemeColor',
      label: 'Theme Color',
      description: 'Custom color for this workspace',
      icon: Palette,
      type: 'input',
      value: '#3b82f6'
    },
    {
      id: 'customCSS',
      label: 'Custom CSS',
      description: 'Add custom CSS to the workspace',
      icon: FileCode,
      type: 'toggle',
      value: false
    }
  ]);

  const updateSetting = (id: string, value: any) => {
    setSettings(prev => prev.map(item => 
      item.id === id ? { ...item, value } : item
    ));
    
    toast({
      title: "Setting updated",
      description: `The setting "${id}" has been updated.`,
    });
  };

  const renderSettingControl = (setting: SettingItem) => {
    switch (setting.type) {
      case 'toggle':
        return (
          <Switch 
            checked={setting.value} 
            onCheckedChange={(checked) => updateSetting(setting.id, checked)} 
          />
        );
      
      case 'select':
        return (
          <Select 
            value={setting.value} 
            onValueChange={(value) => updateSetting(setting.id, value)}
          >
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Select option" />
            </SelectTrigger>
            <SelectContent>
              {setting.options?.map(option => (
                <SelectItem key={option} value={option}>{option}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        );
      
      case 'input':
        return (
          <Input 
            type="text" 
            value={setting.value} 
            onChange={(e) => updateSetting(setting.id, e.target.value)}
            className="w-40"
          />
        );
      
      case 'radio':
        return (
          <RadioGroup 
            value={setting.value} 
            onValueChange={(value) => updateSetting(setting.id, value)}
            className="flex items-center gap-4"
          >
            {setting.options?.map(option => (
              <div key={option} className="flex items-center space-x-2">
                <RadioGroupItem value={option} id={`${setting.id}-${option}`} />
                <Label htmlFor={`${setting.id}-${option}`}>{option}</Label>
              </div>
            ))}
          </RadioGroup>
        );
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="w-5 h-5" />
          Shared Workspace Settings
        </CardTitle>
        <CardDescription>
          Manage settings for "{workspaceName}" workspace
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {settings.map((setting, index) => (
          <div key={setting.id}>
            <div className="flex items-center justify-between py-2">
              <div className="flex items-start gap-3">
                <setting.icon className="w-5 h-5 mt-0.5 text-muted-foreground" />
                <div>
                  <h3 className="text-sm font-medium">{setting.label}</h3>
                  <p className="text-xs text-muted-foreground">{setting.description}</p>
                </div>
              </div>
              {renderSettingControl(setting)}
            </div>
            {index < settings.length - 1 && <Separator className="my-2" />}
          </div>
        ))}
      </CardContent>
      <CardFooter className="border-t pt-4">
        <Button variant="outline" className="ml-auto">Reset to Defaults</Button>
      </CardFooter>
    </Card>
  );
};

export default SharedSettings;
