import { useState } from 'react';
import { AppWindow, GitBranch, Bot, Wrench, BookTemplate, HelpCircle, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface SidebarIconsProps {
  className?: string;
}

export function SidebarIcons({ className = '' }: SidebarIconsProps) {
  const [activeIcon, setActiveIcon] = useState<string | null>(null);
  
  const icons = [
    { id: 'apps', icon: AppWindow, label: 'Apps' },
    { id: 'workflows', icon: GitBranch, label: 'Workflows' },
    { id: 'agents', icon: Bot, label: 'Agents' },
    { id: 'tools', icon: Wrench, label: 'Tools' },
    { id: 'templates', icon: BookTemplate, label: 'Templates' },
  ];
  
  return (
    <TooltipProvider delayDuration={300}>
      <div className={`flex flex-col items-center gap-2 py-4 ${className}`}>
        {icons.map((item) => (
          <Tooltip key={item.id}>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className={`rounded-full h-10 w-10 ${activeIcon === item.id 
                  ? 'bg-primary/20 text-primary' 
                  : 'text-white/60 hover:text-white hover:bg-white/10'}`}
                onClick={() => setActiveIcon(item.id)}
              >
                <item.icon className="h-5 w-5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="right">
              <p>{item.label}</p>
            </TooltipContent>
          </Tooltip>
        ))}
        
        <div className="w-8 my-2 border-t border-white/10"></div>
        
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full h-10 w-10 text-white/60 hover:text-white hover:bg-white/10"
            >
              <Plus className="h-5 w-5" />
            </Button>
          </TooltipTrigger>
          <TooltipContent side="right">
            <p>Add New</p>
          </TooltipContent>
        </Tooltip>
        
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full h-10 w-10 text-white/60 hover:text-white hover:bg-white/10"
            >
              <HelpCircle className="h-5 w-5" />
            </Button>
          </TooltipTrigger>
          <TooltipContent side="right">
            <p>Help & Support</p>
          </TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}
