
import { useState } from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { AlertTriangle, Save, Trash2, Lock, Bell, Globe, Upload, Download } from 'lucide-react';
import { Workspace } from '@/services/workspaceService';
import { useToast } from '@/components/ui/use-toast';
import { 
  getWorkspaceSavedStates,
  getWorkspaceSettings,
  updateWorkspaceSettings,
  resetWorkspaceSettingsToDefault,
  WorkspaceSettings as WorkspaceSettingsType
} from '@/services/workspaceSettingsService';

interface WorkspaceSettingsProps {
  workspace: Workspace;
}

const WorkspaceSettings = ({ workspace }: WorkspaceSettingsProps) => {
  const { toast } = useToast();
  
  // Get saved states and settings from our service
  const savedStates = getWorkspaceSavedStates(workspace);
  const [settings, setSettings] = useState<WorkspaceSettingsType>(getWorkspaceSettings(workspace));

  // Handle setting updates
  const handleSettingUpdate = (settingId: keyof WorkspaceSettingsType, value: any) => {
    setSettings(prev => ({ ...prev, [settingId]: value }));
    
    // In a real implementation, this would update the settings on the backend
    updateWorkspaceSettings(workspace?.id || 'unknown', settingId, value)
      .then(() => {
        toast({
          title: "Setting updated",
          description: `The setting "${settingId}" has been updated.`,
        });
      })
      .catch(error => {
        toast({
          title: "Error updating setting",
          description: "An error occurred while updating the setting.",
          variant: "destructive",
        });
        console.error("Error updating setting:", error);
      });
  };
  
  // Handle reset to defaults
  const handleResetToDefaults = () => {
    resetWorkspaceSettingsToDefault(workspace?.id || 'unknown')
      .then((defaultSettings) => {
        setSettings(defaultSettings);
        toast({
          title: "Settings reset",
          description: "All settings have been reset to their default values.",
        });
      })
      .catch(error => {
        toast({
          title: "Error resetting settings",
          description: "An error occurred while resetting settings.",
          variant: "destructive",
        });
        console.error("Error resetting settings:", error);
      });
  };

  return (
    <ScrollArea className="h-full w-full">
      <div className="container py-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">Workspace Settings</h1>
          <Button className="gap-2">
            <Save className="w-4 h-4" />
            Save Changes
          </Button>
        </div>
        
        <Tabs defaultValue="general">
          <TabsList>
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="permissions">Permissions</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="export">Export & Backup</TabsTrigger>
            <TabsTrigger value="danger">Danger Zone</TabsTrigger>
          </TabsList>
          
          <TabsContent value="general" className="mt-6 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Workspace Details</CardTitle>
                <CardDescription>Update your workspace's basic information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="workspace-name">Workspace Name</Label>
                  <Input id="workspace-name" defaultValue={workspace?.name || workspace?.title || 'My Workspace'} />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="workspace-description">Description</Label>
                  <Textarea 
                    id="workspace-description" 
                    defaultValue={workspace?.description || ''}
                    placeholder="Describe what this workspace is for"
                    className="min-h-24"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="workspace-type">Type</Label>
                  <Select defaultValue={workspace?.templateType || 'custom'}>
                    <SelectTrigger id="workspace-type">
                      <SelectValue placeholder="Select a workspace type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="e-commerce">E-commerce</SelectItem>
                      <SelectItem value="marketing">Marketing</SelectItem>
                      <SelectItem value="sales">Sales</SelectItem>
                      <SelectItem value="productivity">Productivity</SelectItem>
                      <SelectItem value="development">Development</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="workspace-icon">Icon</Label>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br from-indigo-500/20 to-purple-500/20 text-2xl">
                      {workspace?.templateIcon || '🚀'}
                    </div>
                    <Button variant="outline" size="sm">
                      <Upload className="w-4 h-4 mr-2" />
                      Change Icon
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Visibility & Access</CardTitle>
                <CardDescription>Control who can see and join your workspace</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Public Workspace</Label>
                    <p className="text-sm text-muted-foreground">
                      Allow anyone to discover this workspace
                    </p>
                  </div>
                  <Switch 
                    checked={settings.visibility === 'Public'}
                    onCheckedChange={(checked) => 
                      handleSettingUpdate('visibility', checked ? 'Public' : 'Team only')
                    }
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Show in Template Gallery</Label>
                    <p className="text-sm text-muted-foreground">
                      Make this workspace available as a template
                    </p>
                  </div>
                  <Switch
                    checked={workspace?.template || false}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Join Requests</Label>
                    <p className="text-sm text-muted-foreground">
                      Require approval for new members
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="permissions" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Permission Settings</CardTitle>
                <CardDescription>Manage access controls for workspace members</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center gap-4">
                      <Lock className="w-5 h-5 text-muted-foreground" />
                      <div>
                        <h3 className="font-medium">Permission Presets</h3>
                        <p className="text-sm text-muted-foreground">
                          Choose a preset or customize individual permissions
                        </p>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-4">
                      <Button variant="outline" className="justify-start h-auto py-3">
                        <div className="text-left">
                          <div className="font-medium">Private</div>
                          <div className="text-xs text-muted-foreground">
                            Only invited members can access
                          </div>
                        </div>
                      </Button>
                      <Button variant="outline" className="justify-start h-auto py-3">
                        <div className="text-left">
                          <div className="font-medium">Team</div>
                          <div className="text-xs text-muted-foreground">
                            All team members can access
                          </div>
                        </div>
                      </Button>
                      <Button variant="outline" className="justify-start h-auto py-3">
                        <div className="text-left">
                          <div className="font-medium">Public</div>
                          <div className="text-xs text-muted-foreground">
                            Anyone can view, members can edit
                          </div>
                        </div>
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="font-medium">Component Permissions</h3>
                    <p className="text-sm text-muted-foreground">
                      Control who can access specific parts of your workspace
                    </p>
                    
                    <div className="border rounded-lg divide-y">
                      <div className="p-4 flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">Agents</h4>
                          <p className="text-sm text-muted-foreground">
                            Control who can view and modify agents
                          </p>
                        </div>
                        <Select defaultValue="members">
                          <SelectTrigger className="w-40">
                            <SelectValue placeholder="Select permissions" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="owner">Owner Only</SelectItem>
                            <SelectItem value="editors">Editors</SelectItem>
                            <SelectItem value="members">All Members</SelectItem>
                            <SelectItem value="public">Public</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="p-4 flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">Workflows</h4>
                          <p className="text-sm text-muted-foreground">
                            Control who can view and modify workflows
                          </p>
                        </div>
                        <Select defaultValue="editors">
                          <SelectTrigger className="w-40">
                            <SelectValue placeholder="Select permissions" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="owner">Owner Only</SelectItem>
                            <SelectItem value="editors">Editors</SelectItem>
                            <SelectItem value="members">All Members</SelectItem>
                            <SelectItem value="public">Public</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="p-4 flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">Resources</h4>
                          <p className="text-sm text-muted-foreground">
                            Control who can view and modify resources
                          </p>
                        </div>
                        <Select defaultValue="members">
                          <SelectTrigger className="w-40">
                            <SelectValue placeholder="Select permissions" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="owner">Owner Only</SelectItem>
                            <SelectItem value="editors">Editors</SelectItem>
                            <SelectItem value="members">All Members</SelectItem>
                            <SelectItem value="public">Public</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="p-4 flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">Analytics</h4>
                          <p className="text-sm text-muted-foreground">
                            Control who can view analytics
                          </p>
                        </div>
                        <Select defaultValue="owner">
                          <SelectTrigger className="w-40">
                            <SelectValue placeholder="Select permissions" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="owner">Owner Only</SelectItem>
                            <SelectItem value="editors">Editors</SelectItem>
                            <SelectItem value="members">All Members</SelectItem>
                            <SelectItem value="public">Public</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="notifications" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Notification Settings</CardTitle>
                <CardDescription>Control when you receive notifications about this workspace</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Workflow Completions</Label>
                      <p className="text-sm text-muted-foreground">
                        Get notified when workflows complete
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">New Members</Label>
                      <p className="text-sm text-muted-foreground">
                        Get notified when someone joins the workspace
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Member Comments</Label>
                      <p className="text-sm text-muted-foreground">
                        Get notified when members leave comments
                      </p>
                    </div>
                    <Switch />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Resource Updates</Label>
                      <p className="text-sm text-muted-foreground">
                        Get notified when resources are updated
                      </p>
                    </div>
                    <Switch />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Weekly Summary</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive a weekly summary of workspace activity
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="export" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Export & Backup</CardTitle>
                <CardDescription>Export your workspace data or create backups</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <h3 className="font-medium">Export Workspace</h3>
                  <p className="text-sm text-muted-foreground">
                    Export your workspace to different formats
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-3">
                    <Button variant="outline" className="justify-start h-auto py-3">
                      <div className="text-left flex items-center gap-3">
                        <Download className="w-4 h-4" />
                        <div>
                          <div className="font-medium">JSON</div>
                          <div className="text-xs text-muted-foreground">
                            Raw data export
                          </div>
                        </div>
                      </div>
                    </Button>
                    <Button variant="outline" className="justify-start h-auto py-3">
                      <div className="text-left flex items-center gap-3">
                        <Download className="w-4 h-4" />
                        <div>
                          <div className="font-medium">PDF</div>
                          <div className="text-xs text-muted-foreground">
                            Documentation format
                          </div>
                        </div>
                      </div>
                    </Button>
                    <Button variant="outline" className="justify-start h-auto py-3">
                      <div className="text-left flex items-center gap-3">
                        <Download className="w-4 h-4" />
                        <div>
                          <div className="font-medium">ZIP</div>
                          <div className="text-xs text-muted-foreground">
                            Complete archive
                          </div>
                        </div>
                      </div>
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">Backup History</h3>
                  <p className="text-sm text-muted-foreground">
                    View and restore from previous backups
                  </p>
                  
                  <div className="border rounded-lg divide-y mt-3">
                    {savedStates && savedStates.length > 0 ? (
                      savedStates.map((state) => (
                        <div key={state.id} className="p-4 flex items-center justify-between">
                          <div>
                            <h4 className="font-medium">{state.title}</h4>
                            <p className="text-sm text-muted-foreground">
                              {state.description}
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {new Date(state.timestamp).toLocaleString()}
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">Restore</Button>
                            <Button variant="outline" size="sm">Download</Button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="p-4 text-center text-muted-foreground">
                        No backups available yet.
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">Create Backup</h3>
                  <p className="text-sm text-muted-foreground">
                    Save the current state of your workspace
                  </p>
                  
                  <div className="flex mt-3 gap-4">
                    <div className="flex-1">
                      <Input placeholder="Backup name" />
                    </div>
                    <Button>Create Backup</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="danger" className="mt-6">
            <Card className="border-red-200 dark:border-red-800">
              <CardHeader>
                <CardTitle className="text-red-500 flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5" />
                  Danger Zone
                </CardTitle>
                <CardDescription>
                  Irreversible actions that affect your workspace
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="border border-red-200 dark:border-red-800 rounded-lg p-4 space-y-3">
                  <div>
                    <h3 className="font-medium">Reset Workspace</h3>
                    <p className="text-sm text-muted-foreground">
                      Reset this workspace to its initial state. All custom configurations will be lost.
                    </p>
                  </div>
                  <Button variant="outline" className="text-red-500 border-red-200 dark:border-red-800">
                    Reset Workspace
                  </Button>
                </div>
                
                <div className="border border-red-200 dark:border-red-800 rounded-lg p-4 space-y-3">
                  <div>
                    <h3 className="font-medium">Transfer Ownership</h3>
                    <p className="text-sm text-muted-foreground">
                      Transfer ownership of this workspace to another user.
                    </p>
                  </div>
                  <Button variant="outline" className="border-red-200 dark:border-red-800">
                    Transfer Ownership
                  </Button>
                </div>
                
                <div className="border border-red-200 dark:border-red-800 rounded-lg p-4 space-y-3">
                  <div>
                    <h3 className="font-medium">Delete Workspace</h3>
                    <p className="text-sm text-muted-foreground">
                      Permanently delete this workspace and all its data. This action cannot be undone.
                    </p>
                  </div>
                  <Button variant="destructive">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete Workspace
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </ScrollArea>
  );
};

export default WorkspaceSettings;
