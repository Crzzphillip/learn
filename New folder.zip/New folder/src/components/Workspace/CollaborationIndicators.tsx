
import { useState, useEffect } from 'react';
import { CollaborativeAvatar } from './CollaborativeAvatar';
import { User } from "@/types/user";
import { Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';

interface CollaborationIndicatorsProps {
  workspaceId: string;
}

// Sample data for demonstration
const SAMPLE_COLLABORATORS: (User & { 
  isActive: boolean; 
  lastSeen?: Date;
  position?: { x: number; y: number } | null;
  currentActivity?: string;
})[] = [
  {
    id: '1',
    name: 'Alex Rivera',
    email: 'alex@example.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alex',
    isActive: true,
    position: { x: 250, y: 120 },
    currentActivity: 'Editing Agent node'
  },
  {
    id: '2',
    name: 'Morgan Freeman',
    email: 'morgan@example.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Morgan',
    isActive: true,
    position: { x: 450, y: 320 },
    currentActivity: 'Adding new connection'
  },
  {
    id: '3',
    name: 'Emma Wilson',
    email: 'emma@example.com', 
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Emma',
    isActive: true,
    position: null,
    currentActivity: 'Viewing workspace'
  },
  {
    id: '4',
    name: 'Mike Patel',
    email: 'mike@example.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mike',
    isActive: false,
    lastSeen: new Date(Date.now() - 25 * 60000)
  }
];

// Simulate cursor movement for active users
const simulateMovement = (collaborators: typeof SAMPLE_COLLABORATORS) => {
  return collaborators.map(user => {
    if (user.isActive && user.position) {
      return {
        ...user,
        position: {
          x: user.position.x + (Math.random() * 10 - 5),
          y: user.position.y + (Math.random() * 10 - 5)
        }
      };
    }
    return user;
  });
};

const CollaborationIndicators = ({ workspaceId }: CollaborationIndicatorsProps) => {
  const [collaborators, setCollaborators] = useState(SAMPLE_COLLABORATORS);
  const activeUsers = collaborators.filter(u => u.isActive).length;
  
  useEffect(() => {
    // Simulate real-time cursor movement
    const interval = setInterval(() => {
      setCollaborators(prev => simulateMovement(prev));
    }, 2000);
    
    return () => clearInterval(interval);
  }, []);
  
  return (
    <>
      {/* Cursor indicators for each active user */}
      {collaborators.map(user => (
        user.isActive && user.position && (
          <CollaborativeAvatar
            key={user.id}
            user={user}
            isActive={user.isActive}
            lastSeen={user.lastSeen}
            position={user.position}
            size="sm"
          />
        )
      ))}
      
      {/* Collaboration panel trigger */}
      <div className="fixed bottom-4 left-4 z-50">
        <Sheet>
          <SheetTrigger asChild>
            <Button className="rounded-full h-12 px-4" variant="default">
              <Users className="h-5 w-5 mr-2" />
              <span>{activeUsers} online</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-80 sm:w-96">
            <SheetHeader>
              <SheetTitle>Current Collaborators</SheetTitle>
              <SheetDescription>
                See who's currently viewing or editing this workspace
              </SheetDescription>
            </SheetHeader>
            <div className="mt-6 space-y-6">
              <div>
                <h3 className="text-sm font-medium mb-3">Active Now ({activeUsers})</h3>
                <div className="space-y-3">
                  {collaborators
                    .filter(user => user.isActive)
                    .map(user => (
                      <div key={user.id} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <CollaborativeAvatar
                            user={user}
                            isActive={true}
                          />
                          <div>
                            <p className="text-sm font-medium">{user.name}</p>
                            <p className="text-xs text-muted-foreground">{user.currentActivity || 'Active'}</p>
                          </div>
                        </div>
                        <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                          Online
                        </Badge>
                      </div>
                    ))}
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium mb-3">Recently Active</h3>
                <div className="space-y-3">
                  {collaborators
                    .filter(user => !user.isActive)
                    .map(user => (
                      <div key={user.id} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <CollaborativeAvatar
                            user={user}
                            isActive={false}
                            lastSeen={user.lastSeen}
                          />
                          <div>
                            <p className="text-sm font-medium">{user.name}</p>
                            <p className="text-xs text-muted-foreground">
                              Last seen: {user.lastSeen ? new Date(user.lastSeen).toLocaleTimeString() : 'Unknown'}
                            </p>
                          </div>
                        </div>
                        <Badge variant="outline" className="bg-background text-muted-foreground">
                          Offline
                        </Badge>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </>
  );
};

export default CollaborationIndicators;
