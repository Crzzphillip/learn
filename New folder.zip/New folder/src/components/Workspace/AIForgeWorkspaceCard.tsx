
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { BrainCircuit, Code, LayoutDashboard, Rocket, Terminal, Workflow } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

export const AIForgeWorkspaceCard = () => {
  const navigate = useNavigate();

  const handleNavigateToAIForgeWorkspace = () => {
    toast.success("Opening AIForge workspace...", {
      description: "Your AI-powered development environment is ready"
    });
    
    // Navigate directly to the AIForge workspace
    navigate("/workspace/aiforge");
  };

  return (
    <Card className="hover:shadow-md transition-shadow border-2 border-primary/20 bg-primary/5 overflow-hidden">
      <div className="absolute top-0 right-0">
        <Badge variant="default" className="m-2">
          Featured
        </Badge>
      </div>
      
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-lg bg-primary/20 grid place-items-center">
            <BrainCircuit className="text-primary w-6 h-6" />
          </div>
          <div>
            <CardTitle className="flex items-center gap-1">
              AIForge Workspace
            </CardTitle>
            <CardDescription>AI-Powered App Development Platform</CardDescription>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <p className="text-sm">
          Transform ideas into reality with AI-driven development. AIForge combines AI agents and workflows to streamline web app creation.
        </p>
        
        <div className="grid grid-cols-2 gap-2">
          <div className="flex items-center gap-2 p-2 rounded-md bg-black/5">
            <Code className="w-4 h-4 text-blue-500" />
            <span className="text-xs">Code Generation</span>
          </div>
          <div className="flex items-center gap-2 p-2 rounded-md bg-black/5">
            <LayoutDashboard className="w-4 h-4 text-green-500" />
            <span className="text-xs">Visual UI Editor</span>
          </div>
          <div className="flex items-center gap-2 p-2 rounded-md bg-black/5">
            <Workflow className="w-4 h-4 text-purple-500" />
            <span className="text-xs">AI Workflows</span>
          </div>
          <div className="flex items-center gap-2 p-2 rounded-md bg-black/5">
            <Rocket className="w-4 h-4 text-orange-500" />
            <span className="text-xs">One-Click Deploy</span>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <Badge variant="outline" className="bg-black/5">
            13 AI agents
          </Badge>
          <Badge variant="outline" className="bg-black/5">
            8 workflows
          </Badge>
          <Badge variant="outline" className="bg-black/5">
            4 app templates
          </Badge>
        </div>
      </CardContent>
      
      <CardFooter className="pt-2 border-t">
        <Button 
          className="w-full"
          onClick={handleNavigateToAIForgeWorkspace}
        >
          <Terminal className="w-4 h-4 mr-2" />
          Open AIForge Workspace
        </Button>
      </CardFooter>
    </Card>
  );
};
