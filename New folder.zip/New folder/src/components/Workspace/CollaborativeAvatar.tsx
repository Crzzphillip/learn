
import { useState } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { User } from "@/types/user";

interface CollaborativeAvatarProps {
  user: User;
  isActive?: boolean;
  lastSeen?: Date;
  position?: { x: number; y: number };
  size?: 'sm' | 'md' | 'lg';
}

export const CollaborativeAvatar = ({
  user,
  isActive = false,
  lastSeen,
  position,
  size = 'md',
}: CollaborativeAvatarProps) => {
  const [showTooltip, setShowTooltip] = useState(false);
  
  const sizeClass = {
    sm: 'h-6 w-6',
    md: 'h-8 w-8',
    lg: 'h-10 w-10',
  }[size];
  
  const formatLastSeen = (date?: Date) => {
    if (!date) return 'unknown';
    
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    
    if (minutes < 1) return 'just now';
    if (minutes === 1) return '1 minute ago';
    if (minutes < 60) return `${minutes} minutes ago`;
    
    const hours = Math.floor(minutes / 60);
    if (hours === 1) return '1 hour ago';
    if (hours < 24) return `${hours} hours ago`;
    
    return date.toLocaleDateString();
  };
  
  return (
    <TooltipProvider>
      <Tooltip open={showTooltip}>
        <TooltipTrigger asChild>
          <div 
            className="relative"
            onMouseEnter={() => setShowTooltip(true)}
            onMouseLeave={() => setShowTooltip(false)}
            style={position ? { position: 'absolute', left: `${position.x}px`, top: `${position.y}px` } : undefined}
          >
            <Avatar className={`${sizeClass} border-2 ${isActive ? 'border-green-500' : 'border-background'}`}>
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
            </Avatar>
            {isActive && (
              <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full bg-green-500 ring-1 ring-background"></span>
            )}
          </div>
        </TooltipTrigger>
        <TooltipContent side="bottom">
          <div className="text-xs">
            <p className="font-medium">{user.name}</p>
            <p className="text-muted-foreground">{isActive ? 'Currently active' : `Last seen: ${formatLastSeen(lastSeen)}`}</p>
            {position && <p className="text-muted-foreground">Viewing workflow canvas</p>}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default CollaborativeAvatar;
