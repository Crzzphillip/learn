
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Activity, MessageCircle } from 'lucide-react';

// Import our new components
import TeamMembers from './CollaborationComponents/TeamMembers';
import CollaborationStats from './CollaborationComponents/CollaborationStats';
import ActivityLog from './CollaborationComponents/ActivityLog';
import TeamChat from './CollaborationComponents/TeamChat';
import InviteMembersDialog from './CollaborationComponents/InviteMembersDialog';

// Import our new service and utilities
import { 
  getActivityData, 
  getMessagesData, 
  getPendingInvites, 
  formatTimeAgo 
} from '@/services/collaborationService';
import { Workspace } from '@/services/workspaceService';

interface WorkspaceCollaborationProps {
  workspace: Workspace;
}

const WorkspaceCollaboration = ({ workspace }: WorkspaceCollaborationProps) => {
  // Get data from our service
  const activityData = getActivityData();
  const messagesData = getMessagesData();
  const pendingInvites = getPendingInvites();
  
  return (
    <ScrollArea className="h-full w-full">
      <div className="container py-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">Team & Collaboration</h1>
          <InviteMembersDialog />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Team Members */}
          <TeamMembers 
            workspace={workspace} 
            pendingInvites={pendingInvites} 
            formatTimeAgo={formatTimeAgo} 
          />
          
          {/* Quick Stats */}
          <CollaborationStats workspace={workspace} />
        </div>
        
        <Tabs defaultValue="activity">
          <TabsList>
            <TabsTrigger value="activity" className="flex items-center gap-2">
              <Activity className="w-4 h-4" />
              Activity
            </TabsTrigger>
            <TabsTrigger value="messages" className="flex items-center gap-2">
              <MessageCircle className="w-4 h-4" />
              Messages
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="activity" className="mt-6">
            <ActivityLog 
              activityData={activityData}
              formatTimeAgo={formatTimeAgo}
            />
          </TabsContent>
          
          <TabsContent value="messages" className="mt-6">
            <TeamChat 
              messagesData={messagesData}
              formatTimeAgo={formatTimeAgo}
            />
          </TabsContent>
        </Tabs>
      </div>
    </ScrollArea>
  );
};

export default WorkspaceCollaboration;
