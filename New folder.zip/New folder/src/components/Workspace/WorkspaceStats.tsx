
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ResponsiveContainer, AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from "recharts";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Activity, Users, Files, Clock } from "lucide-react";
import { useState } from "react";

interface WorkspaceStatsProps {
  workspace: any;
}

const usageData = [
  { date: "Mon", files: 12, users: 5, time: 3.2 },
  { date: "Tue", files: 18, users: 7, time: 4.5 },
  { date: "Wed", files: 25, users: 9, time: 5.1 },
  { date: "Thu", files: 20, users: 8, time: 4.8 },
  { date: "Fri", files: 28, users: 12, time: 6.2 },
  { date: "Sat", files: 15, users: 4, time: 2.5 },
  { date: "Sun", files: 10, users: 3, time: 1.8 }
];

const activityData = [
  { hour: "00:00", activity: 5 },
  { hour: "04:00", activity: 2 },
  { hour: "08:00", activity: 12 },
  { hour: "12:00", activity: 25 },
  { hour: "16:00", activity: 30 },
  { hour: "20:00", activity: 15 }
];

const WorkspaceStats = ({ workspace }: WorkspaceStatsProps) => {
  const [activeTab, setActiveTab] = useState("usage");

  return (
    <Card className="glass-panel border-primary/10">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Workspace Analytics</CardTitle>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Activity className="w-4 h-4" />
            <span>Last updated: Today, 10:45 AM</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="p-4 rounded-lg bg-secondary/10">
            <div className="flex items-center gap-2 mb-2">
              <Users className="w-5 h-5 text-blue-400" />
              <span className="text-sm font-medium">Active Users</span>
            </div>
            <div className="text-2xl font-bold">{workspace?.activeUsers || 12}</div>
            <div className="text-xs text-green-400">↑ 15% this week</div>
          </div>
          
          <div className="p-4 rounded-lg bg-secondary/10">
            <div className="flex items-center gap-2 mb-2">
              <Files className="w-5 h-5 text-purple-400" />
              <span className="text-sm font-medium">Files Created</span>
            </div>
            <div className="text-2xl font-bold">{workspace?.filesCreated || 128}</div>
            <div className="text-xs text-green-400">↑ 8% this week</div>
          </div>
          
          <div className="p-4 rounded-lg bg-secondary/10">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-5 h-5 text-amber-400" />
              <span className="text-sm font-medium">Avg. Session</span>
            </div>
            <div className="text-2xl font-bold">{workspace?.avgSession || "45m"}</div>
            <div className="text-xs text-green-400">↑ 12% this week</div>
          </div>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="usage">Usage Metrics</TabsTrigger>
            <TabsTrigger value="activity">Activity Timeline</TabsTrigger>
          </TabsList>
          
          <TabsContent value="usage" className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={usageData} margin={{ top: 10, right: 30, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="date" stroke="rgba(255,255,255,0.5)" />
                <YAxis stroke="rgba(255,255,255,0.5)" />
                <Tooltip
                  contentStyle={{ backgroundColor: 'rgba(0,0,0,0.8)', border: '1px solid rgba(255,255,255,0.2)' }}
                />
                <Legend />
                <Bar dataKey="files" name="Files Created" fill="#8884d8" />
                <Bar dataKey="users" name="Active Users" fill="#82ca9d" />
                <Bar dataKey="time" name="Hours Spent" fill="#ffc658" />
              </BarChart>
            </ResponsiveContainer>
          </TabsContent>
          
          <TabsContent value="activity" className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={activityData} margin={{ top: 10, right: 30, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="hour" stroke="rgba(255,255,255,0.5)" />
                <YAxis stroke="rgba(255,255,255,0.5)" />
                <Tooltip
                  contentStyle={{ backgroundColor: 'rgba(0,0,0,0.8)', border: '1px solid rgba(255,255,255,0.2)' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="activity" 
                  name="Activity Level" 
                  stroke="#8884d8" 
                  fill="rgba(136, 132, 216, 0.3)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default WorkspaceStats;
