import { useState } from 'react';
import { PlusCircle, Users, UserPlus, Mail, X, Crown } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useToast } from "@/components/ui/use-toast";
import { User } from "@/types/user";

interface TeamManagementProps {
  workspaceId: string;
  workspaceName: string;
}

type role = 'Owner' | 'Admin' | 'Editor' | 'Viewer';

interface TeamMember extends Omit<User, 'role'> {
  role: role;
  isActive?: boolean;
  lastSeen?: Date;
}

const SAMPLE_TEAM_MEMBERS: TeamMember[] = [
  {
    id: '1',
    name: 'Alex Rivera',
    email: 'alex@example.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alex',
    role: 'Owner',
    isActive: true,
    lastSeen: new Date()
  },
  {
    id: '2',
    name: 'Morgan Freeman',
    email: 'morgan@example.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Morgan',
    role: 'Admin',
    isActive: false,
    lastSeen: new Date(Date.now() - 30 * 60000)
  },
  {
    id: '3',
    name: 'Emma Wilson',
    email: 'emma@example.com', 
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Emma',
    role: 'Editor',
    isActive: true,
    lastSeen: new Date()
  },
  {
    id: '4',
    name: 'Mike Patel',
    email: 'mike@example.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mike',
    role: 'Viewer',
    isActive: false,
    lastSeen: new Date(Date.now() - 2 * 24 * 60 * 60000)
  }
];

const TeamManagement = ({ workspaceId, workspaceName }: TeamManagementProps) => {
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>(SAMPLE_TEAM_MEMBERS);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<role>('Editor');
  const { toast } = useToast();

  const handleInvite = () => {
    if (!inviteEmail.trim() || !inviteEmail.includes('@')) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Invitation sent",
      description: `An invitation has been sent to ${inviteEmail}`,
    });
    
    setInviteEmail('');
  };

  const updateMemberRole = (userId: string, role: role) => {
    setTeamMembers(members => 
      members.map(member => 
        member.id === userId ? { ...member, role } : member
      )
    );
    
    toast({
      title: "Role updated",
      description: `Team member's role has been updated to ${role}`,
    });
  };

  const removeMember = (userId: string) => {
    setTeamMembers(members => members.filter(member => member.id !== userId));
    
    toast({
      title: "Member removed",
      description: "Team member has been removed from workspace",
    });
  };

  const getRoleBadgeVariant = (role: role) => {
    switch (role) {
      case 'Owner': return 'default';
      case 'Admin': return 'outline';
      case 'Editor': return 'secondary';
      case 'Viewer': return 'destructive';
      default: return 'secondary';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="w-5 h-5" />
          Team Management
        </CardTitle>
        <CardDescription>
          Manage team members for "{workspaceName}" workspace
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-sm font-medium">Team Members</h3>
          <div className="space-y-2">
            {teamMembers.map((member) => (
              <div key={member.id} className="flex items-center justify-between p-3 rounded-md bg-card/50">
                <div className="flex items-center gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={member.avatar} alt={member.name} />
                    <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium">{member.name}</p>
                      {member.role === 'Owner' && (
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Crown className="h-3.5 w-3.5 text-amber-500" />
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="text-xs">Workspace Owner</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      )}
                      {member.isActive && (
                        <span className="h-2 w-2 rounded-full bg-green-500" />
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">{member.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={getRoleBadgeVariant(member.role)} className="capitalize">
                    {member.role}
                  </Badge>
                  
                  {member.id !== '1' && (
                    <>
                      <Select 
                        value={member.role} 
                        onValueChange={(value) => updateMemberRole(member.id, value as role)}
                      >
                        <SelectTrigger className="h-8 w-24">
                          <SelectValue placeholder="Select role" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Admin">Admin</SelectItem>
                          <SelectItem value="Editor">Editor</SelectItem>
                          <SelectItem value="Viewer">Viewer</SelectItem>
                        </SelectContent>
                      </Select>
                      
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => removeMember(member.id)}
                        className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="space-y-4">
          <h3 className="text-sm font-medium">Invite Team Members</h3>
          <div className="flex items-center gap-2">
            <div className="relative flex-grow">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Email address"
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={inviteRole} onValueChange={(value) => setInviteRole(value as role)}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Admin">Admin</SelectItem>
                <SelectItem value="Editor">Editor</SelectItem>
                <SelectItem value="Viewer">Viewer</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={handleInvite} className="gap-2">
              <UserPlus className="h-4 w-4" />
              Invite
            </Button>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between border-t pt-4">
        <p className="text-xs text-muted-foreground">
          All team members will have access based on their assigned roles
        </p>
        <Button variant="outline" size="sm" className="gap-2">
          <PlusCircle className="h-4 w-4" />
          Bulk Invite
        </Button>
      </CardFooter>
    </Card>
  );
};

export default TeamManagement;
