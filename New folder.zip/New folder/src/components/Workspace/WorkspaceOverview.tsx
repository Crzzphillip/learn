import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { ChevronRight, Download, ExternalLink, Lock, Zap, Bot, Layers, Calendar, Globe, Smartphone, Monitor, Chrome, Share, Plus } from 'lucide-react';
import { Line, Bar, Pie } from 'recharts';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { getWorkspaceAnalytics, getPerformanceData } from '@/services/workspaceAnalyticsService';
import { Workspace } from '@/services/workspaceService';

interface WorkspaceOverviewProps {
  workspace: Workspace;
  onEditWorkspace?: () => void;
  onCreateApp?: () => void;
  onExportWorkspace?: (type: string) => void;
  onPublishTemplate?: () => void;
}

const WorkspaceOverview = ({
  workspace,
  onEditWorkspace,
  onCreateApp,
  onExportWorkspace,
  onPublishTemplate
}: WorkspaceOverviewProps) => {
  const [exportDialogOpen, setExportDialogOpen] = useState(false);
  const [publishDialogOpen, setPublishDialogOpen] = useState(false);
  
  // Get analytics data using the service - this will now always return valid data
  const analytics = getWorkspaceAnalytics(workspace);
  
  // Get performance data for charts
  const performanceData = getPerformanceData(workspace);
  
  // Safely access workspace properties with defaults
  const components = workspace?.components || [];
  const team = workspace?.team || [];
  const integrations = workspace?.integrations || [];
  const exportOptions = workspace?.exportOptions || [];
  
  const getComponentIcon = (type: string) => {
    switch (type) {
      case 'agent':
        return <Bot className="w-5 h-5 text-primary" />;
      case 'workflow':
        return <Zap className="w-5 h-5 text-blue-500" />;
      case 'app':
        return <Layers className="w-5 h-5 text-green-500" />;
      case 'tool':
        return <Zap className="w-5 h-5 text-amber-500" />;
      default:
        return <ChevronRight className="w-5 h-5" />;
    }
  };
  
  return (
    <ScrollArea className="h-full w-full">
      <div className="container py-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Workspace Quick Stats */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-medium">Performance Overview</CardTitle>
              <CardDescription>Last 7 days metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <span className="text-sm text-muted-foreground">Leads</span>
                  <p className="text-2xl font-semibold">{analytics.leads}</p>
                  <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                    {analytics.growth}
                  </Badge>
                </div>
                <div className="space-y-1">
                  <span className="text-sm text-muted-foreground">Conversions</span>
                  <p className="text-2xl font-semibold">{analytics.conversions}</p>
                  <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                    +12%
                  </Badge>
                </div>
                <div className="space-y-1">
                  <span className="text-sm text-muted-foreground">Revenue</span>
                  <p className="text-2xl font-semibold">{analytics.revenue}</p>
                  <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                    +18%
                  </Badge>
                </div>
                <div className="space-y-1">
                  <span className="text-sm text-muted-foreground">Last Updated</span>
                  <p className="text-sm font-medium">{new Date(analytics.lastUpdated).toLocaleDateString()}</p>
                  <span className="text-xs text-muted-foreground">
                    {new Date(analytics.lastUpdated).toLocaleTimeString()}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Team/Collaboration */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-medium">Team</CardTitle>
              <CardDescription>Workspace collaborators</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {workspace?.owner && (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8 border border-border">
                        <AvatarImage src={workspace.owner.avatar} />
                        <AvatarFallback>{workspace.owner.name?.charAt(0) || '?'}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">{workspace.owner.name}</p>
                        <p className="text-xs text-muted-foreground">Owner</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                      Owner
                    </Badge>
                  </div>
                )}
                
                {team.map((collaborator: any, index: number) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8 border border-border">
                        <AvatarImage src={collaborator.avatar} />
                        <AvatarFallback>{collaborator.name?.charAt(0) || '?'}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">{collaborator.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {collaborator.role === 'editor' ? 'Can edit' : 'View only'}
                        </p>
                      </div>
                    </div>
                    <Badge variant="outline" className={
                      collaborator.role === 'editor' 
                        ? "bg-blue-500/10 text-blue-500 border-blue-500/20"
                        : "bg-amber-500/10 text-amber-500 border-amber-500/20"
                    }>
                      {collaborator.role === 'editor' ? 'Editor' : 'Viewer'}
                    </Badge>
                  </div>
                ))}
                
                <Button variant="outline" size="sm" className="w-full gap-2">
                  <Lock className="w-4 h-4" />
                  Manage Access
                </Button>
              </div>
            </CardContent>
          </Card>
          
          {/* Integrations */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-medium">Integrations</CardTitle>
              <CardDescription>Connected services</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {integrations.map((integration: any, index: number) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-md bg-muted flex items-center justify-center">
                        <span className="text-lg">{integration.icon}</span>
                      </div>
                      <div>
                        <p className="text-sm font-medium">{integration.name}</p>
                        <p className="text-xs text-muted-foreground capitalize">{integration.status}</p>
                      </div>
                    </div>
                    <Badge variant={integration.status === 'connected' ? "outline" : "secondary"} className={
                      integration.status === 'connected' 
                        ? "bg-green-500/10 text-green-500 border-green-500/20"
                        : "bg-amber-500/10 text-amber-500 border-amber-500/20"
                    }>
                      {integration.status === 'connected' ? 'Connected' : 'Pending'}
                    </Badge>
                  </div>
                ))}
                
                <Button variant="outline" size="sm" className="w-full gap-2">
                  <Plus className="w-4 h-4" />
                  Add Integration
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Components Grid - Showing all workspace components */}
        <Card>
          <CardHeader>
            <CardTitle>Workspace Components</CardTitle>
            <CardDescription>All agents, workflows, apps, and tools in this workspace</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all">
              <TabsList className="mb-4">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="agents">Agents</TabsTrigger>
                <TabsTrigger value="workflows">Workflows</TabsTrigger>
                <TabsTrigger value="apps">Apps</TabsTrigger>
                <TabsTrigger value="tools">Tools</TabsTrigger>
              </TabsList>
              
              <TabsContent value="all" className="m-0">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {components.map((component: any) => (
                    <Card key={component.id} className="overflow-hidden bg-muted/30">
                      <CardContent className="p-0">
                        <div className="p-4">
                          <div className="flex items-start gap-3 mb-2">
                            <div className={`w-10 h-10 rounded-md flex items-center justify-center ${
                              component.type === 'agent' 
                                ? 'bg-primary/10'
                                : component.type === 'workflow' 
                                  ? 'bg-blue-500/10'
                                  : component.type === 'app'
                                    ? 'bg-green-500/10'
                                    : 'bg-amber-500/10'
                            }`}>
                              {getComponentIcon(component.type)}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-start justify-between">
                                <h3 className="font-medium text-base">{component.name}</h3>
                                <Badge variant="outline" className="capitalize text-xs">
                                  {component.type}
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mt-1">{component.description}</p>
                            </div>
                          </div>
                        </div>
                        <div className="border-t bg-muted/30 p-2 flex justify-end">
                          <Button variant="ghost" size="sm">
                            Open <ChevronRight className="ml-1 w-4 h-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="agents" className="m-0">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {components.filter((c: any) => c.type === 'agent').map((component: any) => (
                    <Card key={component.id} className="overflow-hidden bg-muted/30">
                      <CardContent className="p-0">
                        <div className="p-4">
                          <div className="flex items-start gap-3 mb-2">
                            <div className="w-10 h-10 rounded-md flex items-center justify-center bg-primary/10">
                              <Bot className="w-5 h-5 text-primary" />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-start justify-between">
                                <h3 className="font-medium text-base">{component.name}</h3>
                                <Badge variant="outline" className="capitalize text-xs">
                                  {component.type}
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mt-1">{component.description}</p>
                            </div>
                          </div>
                        </div>
                        <div className="border-t bg-muted/30 p-2 flex justify-end">
                          <Button variant="ghost" size="sm">
                            Open <ChevronRight className="ml-1 w-4 h-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              {/* Similar TabsContent for workflows, apps, and tools */}
              <TabsContent value="workflows" className="m-0">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {components.filter((c: any) => c.type === 'workflow').map((component: any) => (
                    <Card key={component.id} className="overflow-hidden bg-muted/30">
                      <CardContent className="p-0">
                        <div className="p-4">
                          <div className="flex items-start gap-3 mb-2">
                            <div className="w-10 h-10 rounded-md flex items-center justify-center bg-blue-500/10">
                              <Zap className="w-5 h-5 text-blue-500" />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-start justify-between">
                                <h3 className="font-medium text-base">{component.name}</h3>
                                <Badge variant="outline" className="capitalize text-xs">
                                  {component.type}
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mt-1">{component.description}</p>
                            </div>
                          </div>
                        </div>
                        <div className="border-t bg-muted/30 p-2 flex justify-end">
                          <Button variant="ghost" size="sm">
                            Open <ChevronRight className="ml-1 w-4 h-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="apps" className="m-0">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {components.filter((c: any) => c.type === 'app').map((component: any) => (
                    <Card key={component.id} className="overflow-hidden bg-muted/30">
                      <CardContent className="p-0">
                        <div className="p-4">
                          <div className="flex items-start gap-3 mb-2">
                            <div className="w-10 h-10 rounded-md flex items-center justify-center bg-green-500/10">
                              <Layers className="w-5 h-5 text-green-500" />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-start justify-between">
                                <h3 className="font-medium text-base">{component.name}</h3>
                                <Badge variant="outline" className="capitalize text-xs">
                                  {component.type}
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mt-1">{component.description}</p>
                            </div>
                          </div>
                        </div>
                        <div className="border-t bg-muted/30 p-2 flex justify-end">
                          <Button variant="ghost" size="sm">
                            Open <ChevronRight className="ml-1 w-4 h-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="tools" className="m-0">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {components.filter((c: any) => c.type === 'tool').map((component: any) => (
                    <Card key={component.id} className="overflow-hidden bg-muted/30">
                      <CardContent className="p-0">
                        <div className="p-4">
                          <div className="flex items-start gap-3 mb-2">
                            <div className="w-10 h-10 rounded-md flex items-center justify-center bg-amber-500/10">
                              <Zap className="w-5 h-5 text-amber-500" />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-start justify-between">
                                <h3 className="font-medium text-base">{component.name}</h3>
                                <Badge variant="outline" className="capitalize text-xs">
                                  {component.type}
                                </Badge>
                              </div>
                              <p className="text-sm text-muted-foreground mt-1">{component.description}</p>
                            </div>
                          </div>
                        </div>
                        <div className="border-t bg-muted/30 p-2 flex justify-end">
                          <Button variant="ghost" size="sm">
                            Open <ChevronRight className="ml-1 w-4 h-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        
        {/* Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Export Workspace Button */}
          <Dialog open={exportDialogOpen} onOpenChange={setExportDialogOpen}>
            <DialogTrigger asChild>
              <Card className="cursor-pointer hover:bg-muted/50 transition-colors">
                <CardContent className="p-6 flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-md bg-blue-500/10 flex items-center justify-center">
                      <Download className="w-6 h-6 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="font-medium">Export Workspace</h3>
                      <p className="text-sm text-muted-foreground">Create apps from this workspace</p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground" />
                </CardContent>
              </Card>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Export Workspace</DialogTitle>
                <DialogDescription>
                  Turn this workspace into a standalone application.
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4 py-4">
                {exportOptions.map((option: any) => (
                  <Button 
                    key={option.id}
                    variant="outline" 
                    className="h-auto py-6 flex flex-col items-center gap-2"
                    onClick={() => {
                      onExportWorkspace(option.type);
                      setExportDialogOpen(false);
                    }}
                  >
                    <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
                      {option.icon}
                    </div>
                    <span>{option.name}</span>
                  </Button>
                ))}
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setExportDialogOpen(false)}>Cancel</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          {/* Share Workspace Button */}
          <Card className="cursor-pointer hover:bg-muted/50 transition-colors" onClick={() => window.open('/')}>
            <CardContent className="p-6 flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-md bg-green-500/10 flex items-center justify-center">
                  <Share className="w-6 h-6 text-green-500" />
                </div>
                <div>
                  <h3 className="font-medium">Share Workspace</h3>
                  <p className="text-sm text-muted-foreground">Collaborate with others</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </CardContent>
          </Card>
          
          {/* Publish as Template Button */}
          <Dialog open={publishDialogOpen} onOpenChange={setPublishDialogOpen}>
            <DialogTrigger asChild>
              <Card className="cursor-pointer hover:bg-muted/50 transition-colors">
                <CardContent className="p-6 flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-md bg-purple-500/10 flex items-center justify-center">
                      <ExternalLink className="w-6 h-6 text-purple-500" />
                    </div>
                    <div>
                      <h3 className="font-medium">Publish as Template</h3>
                      <p className="text-sm text-muted-foreground">Share with the community</p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground" />
                </CardContent>
              </Card>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Publish as Template</DialogTitle>
                <DialogDescription>
                  Make this workspace available as a template for others to use.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="rounded-lg bg-muted p-4">
                  <h4 className="font-medium mb-2 flex items-center gap-2">
                    <Zap className="w-4 h-4" />
                    Benefits of Publishing
                  </h4>
                  <ul className="text-sm text-muted-foreground space-y-2">
                    <li>• Help others with similar needs</li>
                    <li>• Earn credits when others use your template</li>
                    <li>• Build your reputation in the community</li>
                    <li>• Get feedback to improve your workspace</li>
                  </ul>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setPublishDialogOpen(false)}>Cancel</Button>
                <Button 
                  onClick={() => {
                    onPublishTemplate();
                    setPublishDialogOpen(false);
                  }}
                >
                  Publish Template
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </ScrollArea>
  );
};

export default WorkspaceOverview;
