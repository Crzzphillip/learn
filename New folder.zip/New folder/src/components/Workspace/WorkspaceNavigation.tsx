
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, BarChart, Settings, MessageSquare, GitFork } from "lucide-react";

interface WorkspaceNavigationProps {
  workspaceId: string;
  activeTab: string;
  onChange: (value: string) => void;
  isAIForgeWorkspace?: boolean;
}

const WorkspaceNavigation = ({ 
  workspaceId, 
  activeTab, 
  onChange,
  isAIForgeWorkspace = false 
}: WorkspaceNavigationProps) => {
  return (
    <Tabs 
      defaultValue={activeTab} 
      value={activeTab}
      onValueChange={onChange}
      className="w-full"
    >
      <TabsList className="grid grid-cols-7 h-auto bg-transparent border p-1 rounded-lg overflow-auto scrollbar-none">
        <TabsTrigger
          value="overview"
          className="data-[state=active]:bg-primary/10 data-[state=active]:text-primary rounded-md py-2"
        >
          Overview
        </TabsTrigger>
        <TabsTrigger
          value="flow"
          className="data-[state=active]:bg-primary/10 data-[state=active]:text-primary rounded-md py-2"
        >
          Flow
        </TabsTrigger>
        <TabsTrigger
          value="chat"
          className="data-[state=active]:bg-primary/10 data-[state=active]:text-primary rounded-md py-2"
        >
          <MessageSquare className="w-4 h-4 mr-2" />
          Chat
        </TabsTrigger>
        <TabsTrigger
          value="resources"
          className="data-[state=active]:bg-primary/10 data-[state=active]:text-primary rounded-md py-2"
        >
          Resources
        </TabsTrigger>
        <TabsTrigger
          value="analytics"
          className="data-[state=active]:bg-primary/10 data-[state=active]:text-primary rounded-md py-2"
        >
          <BarChart className="w-4 h-4 mr-2" />
          Analytics
        </TabsTrigger>
        <TabsTrigger
          value="collaboration"
          className="data-[state=active]:bg-primary/10 data-[state=active]:text-primary rounded-md py-2"
        >
          <Users className="w-4 h-4 mr-2" />
          Team
        </TabsTrigger>
        <TabsTrigger
          value="settings"
          className="data-[state=active]:bg-primary/10 data-[state=active]:text-primary rounded-md py-2"
        >
          <Settings className="w-4 h-4 mr-2" />
          Settings
        </TabsTrigger>
      </TabsList>
    </Tabs>
  );
};

export default WorkspaceNavigation;
