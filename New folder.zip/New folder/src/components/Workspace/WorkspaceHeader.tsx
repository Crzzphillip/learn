
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Layers, PenSquare, Share, Play } from "lucide-react";
import { toast } from "sonner";
import BackToSpace from "@/components/Space/BackToSpace";
import { useNavigate, useParams } from "react-router-dom";

interface WorkspaceHeaderProps {
  workspaceData: {
    name: string;
    description: string;
    templateType: string;
    templateIcon: string;
    id: string;
  };
  onEditWorkspace: () => void;
  onCreateApp: () => void;
  onShareWorkspace: () => void;
  isAIForgeWorkspace?: boolean;
}

const WorkspaceHeader = ({ 
  workspaceData, 
  onEditWorkspace, 
  onCreateApp, 
  onShareWorkspace,
  isAIForgeWorkspace = false
}: WorkspaceHeaderProps) => {
  const navigate = useNavigate();
  const { spaceId } = useParams();

  const handleStartSession = () => {
    navigate(`/workspace/${workspaceData.id}/run`);
    toast.success("Starting AIForge session...", {
      description: "Your development environment is being prepared"
    });
  };

  return (
    <div className="border-b bg-background/95 backdrop-blur-sm">
      <div className="container py-4">
        <BackToSpace spaceId={spaceId || ""} />
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br from-indigo-500/20 to-purple-500/20 text-2xl">
              {workspaceData.templateIcon}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-semibold">{workspaceData.name}</h1>
                <Badge variant="outline" className="text-xs bg-indigo-500/10 text-indigo-500 border-indigo-500/20">
                  {workspaceData.templateType}
                </Badge>
              </div>
              <p className="text-muted-foreground text-sm">{workspaceData.description}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isAIForgeWorkspace && (
              <Button 
                variant="default" 
                size="sm" 
                className="gap-2 bg-green-600 hover:bg-green-700 text-white"
                onClick={handleStartSession}
              >
                <Play className="w-4 h-4" />
                Start Session
              </Button>
            )}
            <Button 
              variant="outline" 
              size="sm" 
              className="gap-2"
              onClick={onShareWorkspace}
            >
              <Share className="w-4 h-4" />
              Share
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="gap-2"
              onClick={onCreateApp}
            >
              <Layers className="w-4 h-4" />
              Create App
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="gap-2"
              onClick={onEditWorkspace}
            >
              <PenSquare className="w-4 h-4" />
              Edit
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorkspaceHeader;
