
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { 
  Users, 
  Clock, 
  ScrollText, 
  CheckCircle2, 
  XCircle, 
  MoreHorizontal,
  CalendarClock,
  UserPlus,
  ChevronDown
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

interface Collaborator {
  id: string;
  name: string;
  avatar: string;
  status: "online" | "offline" | "away";
}

interface VersionChange {
  id: string;
  title: string;
  author: string;
  timestamp: string;
  type: "addition" | "modification" | "removal";
}

interface ApprovalItem {
  id: string;
  title: string;
  description: string;
  requester: Collaborator;
  reviewers: Collaborator[];
  status: "pending" | "approved" | "rejected";
  deadline: string;
}

const collaborators: Collaborator[] = [
  {
    id: "user-1",
    name: "Alex Johnson",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alex",
    status: "online"
  },
  {
    id: "user-2",
    name: "Sarah Chen",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah",
    status: "online"
  },
  {
    id: "user-3",
    name: "Michael Torres",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Michael",
    status: "away"
  },
  {
    id: "user-4",
    name: "Emma Wilson",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Emma",
    status: "offline"
  }
];

const versionChanges: VersionChange[] = [
  {
    id: "change-1",
    title: "Updated frontend components",
    author: "Sarah Chen",
    timestamp: "2 hours ago",
    type: "modification"
  },
  {
    id: "change-2",
    title: "Added new API endpoints",
    author: "Michael Torres",
    timestamp: "Yesterday",
    type: "addition"
  },
  {
    id: "change-3",
    title: "Removed deprecated code",
    author: "Alex Johnson",
    timestamp: "2 days ago",
    type: "removal"
  }
];

const approvalItems: ApprovalItem[] = [
  {
    id: "approval-1",
    title: "Frontend Design Updates",
    description: "Approval needed for UI component library changes",
    requester: collaborators[1],
    reviewers: [collaborators[0], collaborators[3]],
    status: "pending",
    deadline: "Tomorrow, 5:00 PM"
  },
  {
    id: "approval-2",
    title: "Database Schema Changes",
    description: "New table structure for user analytics",
    requester: collaborators[2],
    reviewers: [collaborators[0], collaborators[1]],
    status: "approved",
    deadline: "Completed"
  },
  {
    id: "approval-3",
    title: "Production Deployment",
    description: "Release v2.5 to production environment",
    requester: collaborators[0],
    reviewers: [collaborators[1], collaborators[2], collaborators[3]],
    status: "rejected",
    deadline: "Expired"
  }
];

interface CollaborationZonesProps {
  className?: string;
  primaryColor?: string;
}

const CollaborationZones = ({ className = "", primaryColor = "#7E69AB" }: CollaborationZonesProps) => {
  const [activeTab, setActiveTab] = useState("workshops");

  const getStatusColor = (status: string) => {
    switch(status) {
      case "online": return "bg-emerald-500";
      case "away": return "bg-amber-500";
      case "offline": return "bg-slate-400";
      default: return "bg-slate-400";
    }
  };

  const getChangeTypeColor = (type: string) => {
    switch(type) {
      case "addition": return "text-emerald-400";
      case "modification": return "text-blue-400";
      case "removal": return "text-rose-400";
      default: return "text-white/70";
    }
  };

  const getChangeTypeIcon = (type: string) => {
    switch(type) {
      case "addition": return "+";
      case "modification": return "⟳";
      case "removal": return "−";
      default: return "";
    }
  };

  const getApprovalStatusColor = (status: string) => {
    switch(status) {
      case "pending": return "bg-amber-500/20 text-amber-400";
      case "approved": return "bg-emerald-500/20 text-emerald-400";
      case "rejected": return "bg-rose-500/20 text-rose-400";
      default: return "bg-slate-500/20 text-slate-400";
    }
  };

  return (
    <Card className={`bg-black/20 border-white/10 backdrop-blur-md ${className}`}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-medium text-white/90">Collaboration Zones</CardTitle>
          <Button 
            variant="outline" 
            size="sm" 
            className="gap-1 bg-primary/10 border-primary/20 hover:bg-primary/20"
            style={{ borderColor: `${primaryColor}20` }}
          >
            <UserPlus className="h-3 w-3" />
            Invite
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 mb-4 bg-black/30">
            <TabsTrigger 
              value="workshops"
              className="data-[state=active]:bg-primary/20"
              style={{ 
                ["--tw-bg-opacity" as any]: "1",
                backgroundColor: `rgb(${parseInt(primaryColor.slice(1, 3), 16)} ${parseInt(primaryColor.slice(3, 5), 16)} ${parseInt(primaryColor.slice(5, 7), 16)} / 0.2)`
              }}
            >
              <Users className="h-4 w-4 mr-2" />
              Workshops
            </TabsTrigger>
            <TabsTrigger 
              value="versions" 
              className="data-[state=active]:bg-primary/20"
              style={{ 
                ["--tw-bg-opacity" as any]: "1",
                backgroundColor: `rgb(${parseInt(primaryColor.slice(1, 3), 16)} ${parseInt(primaryColor.slice(3, 5), 16)} ${parseInt(primaryColor.slice(5, 7), 16)} / 0.2)`
              }}
            >
              <ScrollText className="h-4 w-4 mr-2" />
              Version Scrolls
            </TabsTrigger>
            <TabsTrigger 
              value="councils" 
              className="data-[state=active]:bg-primary/20"
              style={{ 
                ["--tw-bg-opacity" as any]: "1",
                backgroundColor: `rgb(${parseInt(primaryColor.slice(1, 3), 16)} ${parseInt(primaryColor.slice(3, 5), 16)} ${parseInt(primaryColor.slice(5, 7), 16)} / 0.2)`
              }}
            >
              <CheckCircle2 className="h-4 w-4 mr-2" />
              Council Chambers
            </TabsTrigger>
          </TabsList>

          <TabsContent value="workshops">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-medium text-white/90">Live Collaborators</h3>
                <Button variant="ghost" size="sm" className="h-7 text-xs">
                  Schedule Workshop
                  <CalendarClock className="h-3 w-3 ml-1" />
                </Button>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                {collaborators.map((user) => (
                  <div 
                    key={user.id}
                    className="flex items-center p-2 rounded-lg bg-black/20 border border-white/5"
                  >
                    <div className="relative mr-3">
                      <Avatar className="h-8 w-8 border border-white/10">
                        <AvatarImage src={user.avatar} alt={user.name} />
                        <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span 
                        className={`absolute bottom-0 right-0 h-2 w-2 rounded-full ${getStatusColor(user.status)}`}
                      />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-white/90">{user.name}</p>
                      <p className="text-xs text-white/60 capitalize">{user.status}</p>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="rounded-lg bg-black/40 border border-white/5 p-4 mt-4">
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-sm font-medium text-white/90">Current Workshop Session</h3>
                  <div className="flex items-center gap-1">
                    <span className="animate-pulse h-2 w-2 rounded-full bg-emerald-500" />
                    <span className="text-xs text-emerald-400">Live</span>
                  </div>
                </div>
                
                <div className="bg-black/40 rounded p-3 border border-white/5">
                  <h4 className="text-sm font-medium text-white/90 mb-2">Frontend Development</h4>
                  <div className="flex items-center gap-2 mb-3">
                    <Clock className="h-3 w-3 text-white/60" />
                    <span className="text-xs text-white/60">Started 45 minutes ago</span>
                  </div>
                  
                  <div className="flex -space-x-2 mb-2">
                    {collaborators.slice(0, 3).map((user) => (
                      <Avatar key={user.id} className="h-6 w-6 border border-black/40">
                        <AvatarImage src={user.avatar} alt={user.name} />
                        <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                    ))}
                    <div className="h-6 w-6 rounded-full bg-primary/20 text-primary flex items-center justify-center text-xs">
                      +{collaborators.length - 3}
                    </div>
                  </div>
                  
                  <Button variant="outline" size="sm" className="w-full mt-2 bg-white/5 hover:bg-white/10">
                    Join Workshop
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="versions">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-medium text-white/90">Recent Changes</h3>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="gap-1 h-7 text-xs">
                      All Changes
                      <ChevronDown className="h-3 w-3" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-black/90 border-white/10">
                    <DropdownMenuItem>All Changes</DropdownMenuItem>
                    <DropdownMenuItem>Additions</DropdownMenuItem>
                    <DropdownMenuItem>Modifications</DropdownMenuItem>
                    <DropdownMenuItem>Removals</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              
              <div className="space-y-2">
                {versionChanges.map((change) => (
                  <div
                    key={change.id}
                    className="flex items-center p-3 rounded-lg bg-black/20 border border-white/5"
                  >
                    <div className={`w-6 h-6 rounded-full ${getChangeTypeColor(change.type)} bg-white/5 flex items-center justify-center mr-3 font-bold text-lg`}>
                      {getChangeTypeIcon(change.type)}
                    </div>
                    <div className="flex-grow min-w-0">
                      <div className="flex items-center">
                        <p className="text-sm font-medium text-white/90 truncate">{change.title}</p>
                      </div>
                      <div className="flex items-center text-xs text-white/60">
                        <span>{change.author}</span>
                        <span className="mx-1">•</span>
                        <span>{change.timestamp}</span>
                      </div>
                    </div>
                    <div className="ml-2 flex">
                      <Button variant="ghost" size="icon" className="h-7 w-7 rounded-full hover:bg-white/5">
                        <ScrollText className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
              
              <Button variant="outline" size="sm" className="w-full mt-2 bg-white/5 hover:bg-white/10">
                View All Changes
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="councils">
            <div className="space-y-4">
              <h3 className="text-sm font-medium text-white/90">Approval Workflows</h3>
              
              <div className="space-y-3">
                {approvalItems.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 rounded-lg bg-black/20 border border-white/5"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="text-sm font-medium text-white/90">{item.title}</h4>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${getApprovalStatusColor(item.status)}`}>
                        {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                      </span>
                    </div>
                    
                    <p className="text-xs text-white/70 mb-3">{item.description}</p>
                    
                    <div className="flex justify-between items-center mb-2">
                      <div className="flex items-center">
                        <Avatar className="h-6 w-6 mr-2">
                          <AvatarImage src={item.requester.avatar} alt={item.requester.name} />
                          <AvatarFallback>{item.requester.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <span className="text-xs text-white/60">Requested by {item.requester.name}</span>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        <CalendarClock className="h-3 w-3 text-white/60" />
                        <span className="text-xs text-white/60">{item.deadline}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between mt-3">
                      <div className="flex -space-x-2">
                        {item.reviewers.map((reviewer) => (
                          <Avatar key={reviewer.id} className="h-6 w-6 border border-black/40">
                            <AvatarImage src={reviewer.avatar} alt={reviewer.name} />
                            <AvatarFallback>{reviewer.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                        ))}
                      </div>
                      
                      {item.status === "pending" && (
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" className="h-7 bg-rose-500/10 border-rose-500/30 hover:bg-rose-500/20 text-rose-400">
                            <XCircle className="h-3 w-3 mr-1" />
                            Reject
                          </Button>
                          <Button variant="outline" size="sm" className="h-7 bg-emerald-500/10 border-emerald-500/30 hover:bg-emerald-500/20 text-emerald-400">
                            <CheckCircle2 className="h-3 w-3 mr-1" />
                            Approve
                          </Button>
                        </div>
                      )}
                      
                      {(item.status === "approved" || item.status === "rejected") && (
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default CollaborationZones;
