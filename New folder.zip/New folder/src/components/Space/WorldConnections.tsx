
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Network, CircleUser, Globe, Link as LinkIcon, Briefcase, Building, Shield, MapPin } from "lucide-react";
import { motion } from "framer-motion";

interface Connection {
  id: string;
  name: string;
  type: "person" | "company" | "organization" | "team" | "space";
  location: string;
  industry: string;
  status: "active" | "pending" | "inactive";
  relationship: "collaborator" | "client" | "partner" | "competitor";
}

const connections: Connection[] = [
  {
    id: "conn-1",
    name: "TechForward Labs",
    type: "company",
    location: "San Francisco, CA",
    industry: "AI Research",
    status: "active",
    relationship: "partner"
  },
  {
    id: "conn-2",
    name: "Digital Horizons",
    type: "organization",
    location: "London, UK",
    industry: "Technology",
    status: "active",
    relationship: "collaborator"
  },
  {
    id: "conn-3",
    name: "Quantum Innovators",
    type: "team",
    location: "Berlin, Germany",
    industry: "Quantum Computing",
    status: "pending",
    relationship: "client"
  },
  {
    id: "conn-4",
    name: "VisionAI Space",
    type: "space",
    location: "Tokyo, Japan",
    industry: "Computer Vision",
    status: "active",
    relationship: "collaborator"
  }
];

interface WorldConnectionsProps {
  className?: string;
  primaryColor?: string;
}

const WorldConnections = ({ className = "", primaryColor = "#7E69AB" }: WorldConnectionsProps) => {
  const [activeConnection, setActiveConnection] = useState<Connection | null>(null);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "person": return <CircleUser className="h-4 w-4" />;
      case "company": return <Building className="h-4 w-4" />;
      case "organization": return <Briefcase className="h-4 w-4" />;
      case "team": return <Shield className="h-4 w-4" />;
      case "space": return <Globe className="h-4 w-4" />;
      default: return <CircleUser className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-emerald-400";
      case "pending": return "bg-amber-400";
      case "inactive": return "bg-slate-400";
      default: return "bg-slate-400";
    }
  };

  const getRelationshipColor = (relationship: string) => {
    switch (relationship) {
      case "collaborator": return primaryColor;
      case "client": return "#3B82F6";
      case "partner": return "#10B981";
      case "competitor": return "#F43F5E";
      default: return "#94A3B8";
    }
  };

  return (
    <Card className={`bg-black/20 border-white/10 backdrop-blur-md ${className}`}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2 text-lg font-medium text-white/90">
            <div className="w-6 h-6 rounded-full flex items-center justify-center"
                 style={{ backgroundColor: `${primaryColor}30` }}>
              <Network className="h-4 w-4" style={{ color: primaryColor }} />
            </div>
            World Connections
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-4">
          <div className="relative h-[180px] rounded-lg overflow-hidden mb-2">
            <div className="absolute inset-0 opacity-70 bg-black/40">
              <img
                src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072&auto=format&fit=crop"
                alt="World Map"
                className="w-full h-full object-cover opacity-50"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent" />

            {/* Connection dots */}
            {connections.map((conn) => {
              // Simple pseudo-positioning for demo
              const left = Math.random() * 80 + 10; // 10-90%
              const top = Math.random() * 80 + 10; // 10-90%
              
              return (
                <motion.div
                  key={conn.id}
                  className="absolute w-3 h-3 cursor-pointer"
                  style={{ 
                    left: `${left}%`, 
                    top: `${top}%`,
                  }}
                  initial={{ scale: 0.8 }}
                  animate={{ 
                    scale: activeConnection?.id === conn.id ? 1.3 : 1,
                    backgroundColor: getRelationshipColor(conn.relationship)
                  }}
                  whileHover={{ scale: 1.5 }}
                  transition={{ type: "spring", stiffness: 200, damping: 10 }}
                  onClick={() => setActiveConnection(conn === activeConnection ? null : conn)}
                >
                  <span className="absolute inset-0 rounded-full animate-ping opacity-75"
                        style={{ backgroundColor: getRelationshipColor(conn.relationship) }} />
                  <span className="absolute inset-0 rounded-full"
                        style={{ backgroundColor: getRelationshipColor(conn.relationship) }} />
                </motion.div>
              );
            })}
            
            {/* Active connection info */}
            {activeConnection && (
              <div className="absolute bottom-2 left-2 right-2 p-2 bg-black/60 backdrop-blur-sm rounded-md border border-white/10">
                <div className="flex items-center gap-2">
                  <div className="p-1 rounded-full"
                       style={{ backgroundColor: getRelationshipColor(activeConnection.relationship) }}>
                    {getTypeIcon(activeConnection.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-medium truncate">{activeConnection.name}</h4>
                    <div className="flex items-center text-xs text-white/60">
                      <MapPin className="h-3 w-3 mr-1" />
                      <span className="truncate">{activeConnection.location}</span>
                    </div>
                  </div>
                  <div className={`h-2 w-2 rounded-full ${getStatusColor(activeConnection.status)}`} />
                </div>
              </div>
            )}
          </div>
          
          <div className="grid grid-cols-2 gap-2">
            {connections.map((conn) => (
              <button
                key={conn.id}
                className={`flex items-center p-2 rounded-lg border transition-all text-left ${
                  activeConnection?.id === conn.id ? 'bg-black/40 border-white/20' : 'bg-black/20 border-white/5'
                }`}
                onClick={() => setActiveConnection(conn === activeConnection ? null : conn)}
              >
                <div className="mr-2 p-1 rounded-full"
                     style={{ backgroundColor: `${getRelationshipColor(conn.relationship)}40` }}>
                  {getTypeIcon(conn.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">{conn.name}</p>
                  <p className="text-xs text-white/60 truncate">{conn.industry}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default WorldConnections;
