
import React from "react";

const LoadingState = () => {
  return (
    <div className="space-y-6">
      <div className="h-40 bg-card/30 rounded-xl animate-pulse" />
      <div className="h-96 bg-card/30 rounded-xl animate-pulse" />
    </div>
  );
};

export default LoadingState;
