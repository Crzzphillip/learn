
import { Button } from "@/components/ui/button";
import StandaloneAppCard from "./StandaloneAppCard";
import { LucideIcon, Bot, Zap, Layout, Code, FileText, Database, MessageSquare } from "lucide-react";

interface StandaloneApp {
  id?: string;
  title: string;
  description: string;
  icon: LucideIcon;
  credits: string;
  locked: boolean;
  image: string;
  sourceType: 'agent' | 'workflow' | 'workspace';
  source?: {
    id: string;
    name: string;
  };
}

interface StandaloneAppsSectionProps {
  apps: StandaloneApp[];
  title?: string;
}

const StandaloneAppsSection = ({ apps, title = "Standalone Apps" }: StandaloneAppsSectionProps) => {
  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-semibold">{title}</h2>
        <Button variant="outline">View All</Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {apps.map((app, index) => (
          <StandaloneAppCard key={app.id || index} {...app} />
        ))}
      </div>
    </div>
  );
};

// Sample apps for demonstration
export const sampleStandaloneApps: StandaloneApp[] = [
  {
    id: "app-1",
    title: "Component Crafter",
    description: "Generate UI components from text descriptions with simple chat interface",
    icon: Code,
    credits: "15",
    locked: false,
    image: "",
    sourceType: "agent",
    source: {
      id: "agent-123",
      name: "UI Builder Agent"
    }
  },
  {
    id: "app-2",
    title: "Campaign Genie",
    description: "Generate marketing content, social posts, and ads from product descriptions",
    icon: MessageSquare,
    credits: "20",
    locked: false,
    image: "",
    sourceType: "workflow",
    source: {
      id: "workflow-456",
      name: "Marketing Workflow"
    }
  },
  {
    id: "app-3",
    title: "Film Factory",
    description: "Complete video production assistant for scripting, editing and rendering",
    icon: FileText,
    credits: "40",
    locked: true,
    image: "",
    sourceType: "workspace",
    source: {
      id: "workspace-789",
      name: "Video Production"
    }
  }
];

export default StandaloneAppsSection;
