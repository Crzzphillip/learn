
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { GitBranch, Copy } from "lucide-react";
import CreditBadge from "./CreditBadge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface WorkflowCardProps {
  id?: string;
  title: string;
  description: string;
  agents?: string[];
  credits: string;
  locked: boolean;
  image: string;
  author?: {
    name: string;
    avatar: string;
    role?: string;
  };
  usageStats?: {
    runs?: string;
    copies?: string;
    rating?: string;
  };
  tags?: string[];
  onOpen?: () => void; // Added this prop to match usage in WorkflowsSection
}

const WorkflowCard = ({
  id,
  title,
  description,
  agents = [],
  credits,
  locked,
  image,
  author,
  usageStats,
  tags = [],
  onOpen
}: WorkflowCardProps) => {
  const navigate = useNavigate();

  const handleRunWorkflow = () => {
    if (!locked && id) {
      if (onOpen) {
        // Use the provided onOpen handler if available
        onOpen();
      } else {
        navigate(`/workflow/${id}`);
      }
    }
  };

  const handleCopyWorkflow = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Copy workflow functionality would go here
    console.log("Copying workflow:", id);
  };

  return (
    <Card className="group hover:border-primary/30 transition-all duration-300 overflow-hidden bg-black/20 border-white/10 backdrop-blur-sm">
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent z-10" />
        <img 
          src={image} 
          alt={title} 
          className="w-full h-40 object-cover opacity-70 group-hover:opacity-90 transition-opacity duration-500"
        />
        <div className="absolute top-3 right-3 z-20">
          <CreditBadge credits={credits} locked={locked} />
        </div>
        
        {tags && tags.length > 0 && (
          <div className="absolute top-3 left-3 z-20 flex gap-2">
            {tags.map((tag, index) => (
              <Badge key={index} variant="secondary" className="bg-black/60 backdrop-blur-md text-white border-none">
                {tag}
              </Badge>
            ))}
          </div>
        )}
      </div>
      
      <CardHeader className="relative z-20 -mt-10 pb-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500/30 to-violet-500/30 flex items-center justify-center backdrop-blur-xl">
            <GitBranch className="w-5 h-5" />
          </div>
          <h3 className="font-semibold">{title}</h3>
        </div>
      </CardHeader>
      
      <CardContent>
        <p className="text-sm text-white/70 mb-4 line-clamp-3">{description}</p>
        
        {agents && agents.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-4">
            {agents.map((agent, index) => (
              <Badge key={index} variant="outline" className="bg-black/40 text-xs">
                {agent}
              </Badge>
            ))}
          </div>
        )}
        
        {author && (
          <div className="flex items-center mb-4">
            <Avatar className="h-6 w-6 mr-2">
              <AvatarImage src={author.avatar} />
              <AvatarFallback>{author.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <span className="text-xs text-white/60">
              {author.name} • {author.role || "Contributor"}
            </span>
          </div>
        )}
        
        {usageStats && (
          <div className="flex items-center justify-between text-xs text-white/60 mb-4">
            {usageStats.runs && <span>{usageStats.runs} runs</span>}
            <span>•</span>
            {usageStats.copies && (
              <div className="flex items-center">
                <Copy className="w-3 h-3 mr-1" />
                {usageStats.copies}
              </div>
            )}
            <span>•</span>
            {usageStats.rating && <span>{usageStats.rating} ★</span>}
          </div>
        )}
        
        <div className="pt-2 flex gap-2">
          <Button 
            className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700"
            disabled={locked}
            onClick={handleRunWorkflow}
          >
            {locked ? "Unlock" : "Run"}
          </Button>
          <Button 
            variant="outline" 
            className="bg-black/20 border-white/20"
            onClick={handleCopyWorkflow}
          >
            <Copy className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default WorkflowCard;
