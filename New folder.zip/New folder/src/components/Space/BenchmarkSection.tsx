
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Benchmark } from '@/types/explore';
import { benchmarkService } from '@/services/benchmarkService';
import BenchmarkSummary from '../Benchmarks/BenchmarkSummary';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

interface BenchmarkSectionProps {
  spaceId: string;
  primaryColor?: string;
}

const BenchmarkSection = ({ spaceId, primaryColor = "#7E69AB" }: BenchmarkSectionProps) => {
  const [benchmarks, setBenchmarks] = useState<Benchmark[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchBenchmarks = async () => {
      try {
        setIsLoading(true);
        const data = await benchmarkService.getSpaceBenchmarks(spaceId);
        setBenchmarks(data);
      } catch (error) {
        console.error("Error fetching space benchmarks:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchBenchmarks();
  }, [spaceId]);

  // Group benchmarks by category
  const benchmarksByCategory: Record<string, Benchmark[]> = {};
  benchmarks.forEach(benchmark => {
    if (!benchmarksByCategory[benchmark.category]) {
      benchmarksByCategory[benchmark.category] = [];
    }
    benchmarksByCategory[benchmark.category].push(benchmark);
  });

  if (isLoading) {
    return (
      <Card className="bg-black/20 border-white/10 backdrop-blur-sm">
        <CardHeader>
          <CardTitle>Performance Benchmarks</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            <div className="h-12 bg-white/10 rounded-md"></div>
            <div className="h-12 bg-white/10 rounded-md"></div>
            <div className="h-12 bg-white/10 rounded-md"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (benchmarks.length === 0) {
    return null;
  }

  return (
    <Card className="bg-black/20 border-white/10 backdrop-blur-sm">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle>Performance Benchmarks</CardTitle>
        <Link to={`/space/${spaceId}/benchmarks`}>
          <Button 
            variant="ghost" 
            size="sm"
            className="text-xs gap-1"
            style={{ color: primaryColor }}
          >
            View All <ArrowRight className="h-3 w-3" />
          </Button>
        </Link>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Object.entries(benchmarksByCategory).slice(0, 4).map(([category, benchmarks]) => (
            <Card key={category} className="bg-black/30 border-white/5">
              <CardHeader className="py-3 px-4">
                <h3 className="text-sm font-medium capitalize">{category} Benchmarks</h3>
              </CardHeader>
              <CardContent className="py-3 px-4">
                {benchmarks.slice(0, 2).map(benchmark => (
                  <div key={benchmark.id} className="mb-3 last:mb-0">
                    <div className="flex justify-between items-center mb-1.5">
                      <span className="text-sm">{benchmark.name}</span>
                      <span className="font-medium">{benchmark.score}/{benchmark.maxScore}</span>
                    </div>
                    <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <div 
                        className="h-full rounded-full"
                        style={{ 
                          width: `${(benchmark.score / benchmark.maxScore) * 100}%`,
                          backgroundColor: primaryColor 
                        }}
                      ></div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default BenchmarkSection;
