
import { ReactNode } from "react";
import Sidebar from "@/components/Layout/Sidebar";
import SpaceBanner from "@/components/Space/SpaceBanner";
import { SpaceStat, SpaceTemplate } from "@/types/space";

interface SpaceLayoutProps {
  children: ReactNode;
  stats: SpaceStat[];
  template: SpaceTemplate;
  trendData?: {
    title: string;
    change: string;
    description: string;
    isUp: boolean;
    gradient: string;
  }[];
  fullWidth?: boolean;
}

const SpaceLayout = ({ children, stats, template, trendData, fullWidth }: SpaceLayoutProps) => {
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-auto">
          {!fullWidth && <SpaceBanner stats={stats} template={template} trendData={trendData} />}
          <div className={fullWidth ? "h-full" : "py-6 relative"}>
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default SpaceLayout;
