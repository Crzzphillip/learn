
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { SpaceCredits } from "@/types/space";
import { ArrowUpRight, CreditCard, LineChart, Zap } from "lucide-react";

interface SpaceCreditsManagerProps {
  credits: SpaceCredits;
  onPurchaseCredits: () => void;
  onUpgradeSubscription: () => void;
}

const SpaceCreditsManager = ({
  credits,
  onPurchaseCredits,
  onUpgradeSubscription,
}: SpaceCreditsManagerProps) => {
  const totalUsage = Object.values(credits.usage).reduce((a, b) => a + b, 0);
  const usagePercentage = (totalUsage / credits.balance) * 100;

  return (
    <div className="space-y-6 p-6 bg-card rounded-lg border">
      <div className="space-y-2">
        <h3 className="text-lg font-semibold">Credits & Subscription</h3>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-primary" />
            <span>{credits.balance} credits available</span>
          </div>
          <Button variant="outline" size="sm" onClick={onPurchaseCredits}>
            Purchase Credits
          </Button>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Credits Usage</span>
          <span>{usagePercentage.toFixed(1)}%</span>
        </div>
        <Progress value={usagePercentage} className="h-2" />
      </div>

      <div className="grid grid-cols-2 gap-4">
        {Object.entries(credits.usage).map(([type, amount]) => (
          <div key={type} className="p-3 bg-muted rounded-lg">
            <div className="text-sm font-medium capitalize">{type}</div>
            <div className="text-2xl font-bold">{amount}</div>
          </div>
        ))}
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CreditCard className="w-4 h-4" />
            <span className="font-medium capitalize">
              {credits.subscriptionTier} Plan
            </span>
          </div>
          <Button variant="outline" size="sm" onClick={onUpgradeSubscription}>
            Upgrade
          </Button>
        </div>
      </div>

      {credits.earnings > 0 && (
        <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
          <div className="space-y-1">
            <div className="text-sm font-medium">Community Earnings</div>
            <div className="text-2xl font-bold">${credits.earnings}</div>
          </div>
          <Button variant="ghost" size="icon">
            <ArrowUpRight className="w-5 h-5" />
          </Button>
        </div>
      )}
    </div>
  );
};

export default SpaceCreditsManager;
