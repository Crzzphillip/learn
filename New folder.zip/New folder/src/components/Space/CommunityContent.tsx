
import { useState, useEffect } from "react";
import { Separator } from "@/components/ui/separator";
import CommunityContentReview, { ContentReviewItem } from "@/components/Space/CommunityContentReview";
import { dummyDatabase } from "@/services/dummyDatabase";

interface CommunityContentProps {
  reviewItems?: ContentReviewItem[];
  onApprove?: (id: string) => void;
  onReject?: (id: string) => void;
}

const CommunityContent = ({ reviewItems: initialItems, onApprove, onReject }: CommunityContentProps) => {
  const [items, setItems] = useState<ContentReviewItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchReviewItems = async () => {
      try {
        setIsLoading(true);
        // If initial items were provided, use them, otherwise fetch from the database
        if (initialItems) {
          setItems(initialItems);
        } else {
          // Map the database items to match our ContentReviewItem interface
          const fetchedItems = await dummyDatabase.getReviewItems();
          const formattedItems = fetchedItems.map(item => ({
            ...item,
            description: item.content, // Use content as description
            submittedAt: item.timestamp, // Use timestamp as submittedAt
          })) as ContentReviewItem[];
          
          setItems(formattedItems);
        }
      } catch (error) {
        console.error("Error fetching review items:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchReviewItems();
  }, [initialItems]);

  const handleApprove = async (id: string) => {
    try {
      await dummyDatabase.approveContent(id);
      // If custom handler is provided, use it
      if (onApprove) {
        onApprove(id);
      }
      // Refresh the list
      const updatedItems = await dummyDatabase.getReviewItems();
      const formattedItems = updatedItems.map(item => ({
        ...item,
        description: item.content,
        submittedAt: item.timestamp,
      })) as ContentReviewItem[];
      setItems(formattedItems);
    } catch (error) {
      console.error("Error approving content:", error);
    }
  };

  const handleReject = async (id: string) => {
    try {
      await dummyDatabase.rejectContent(id);
      // If custom handler is provided, use it
      if (onReject) {
        onReject(id);
      }
      // Refresh the list
      const updatedItems = await dummyDatabase.getReviewItems();
      const formattedItems = updatedItems.map(item => ({
        ...item,
        description: item.content,
        submittedAt: item.timestamp,
      })) as ContentReviewItem[];
      setItems(formattedItems);
    } catch (error) {
      console.error("Error rejecting content:", error);
    }
  };

  return (
    <>
      <Separator />
      {isLoading ? (
        <div className="my-6 space-y-4">
          {[1, 2].map((i) => (
            <div key={i} className="bg-card rounded-xl p-6 animate-pulse h-40" />
          ))}
        </div>
      ) : (
        <CommunityContentReview 
          items={items} 
          onApprove={handleApprove} 
          onReject={handleReject} 
        />
      )}
      <Separator />
    </>
  );
};

export default CommunityContent;
