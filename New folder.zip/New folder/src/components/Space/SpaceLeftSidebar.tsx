
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  ChevronDown, ChevronRight, X, Plus, 
  Server, Globe, Database, Code, FileText, 
  Layout, Image, Layers, Folder, 
  Wrench, Bot, GitBranch, Settings,
  Users, Package, LinkIcon, ShoppingBag, Shield,
  LayoutDashboard, FolderOpen, FileBox, 
  Clock, Brush, Edit, Terminal
} from "lucide-react";
import { Link, useLocation, useParams } from "react-router-dom";
import { cn } from "@/lib/utils";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ActivityItem } from "@/components/Layout/components/ActivityPreview";
import { getSpaceRecentActivity } from "@/services/spaceActivityService";

interface SpaceLeftSidebarProps {
  onClose?: () => void;
  className?: string;
}

interface SidebarItemProps {
  label: string;
  icon: React.ReactNode;
  children?: React.ReactNode;
  expanded?: boolean;
  onToggle?: () => void;
  path?: string;
  level?: number;
  variant?: "default" | "colored";
}

const SidebarItem = ({ 
  label, 
  icon, 
  children, 
  expanded = false, 
  onToggle,
  path,
  level = 0,
  variant = "default"
}: SidebarItemProps) => {
  const location = useLocation();
  const isActive = path && location.pathname === path;
  const padding = `pl-${Math.min(level * 3 + 2, 8)}`;

  const getIconColor = () => {
    if (variant === "colored") {
      const colors = [
        "#8B5CF6", // purple
        "#EC4899", // pink
        "#F97316", // orange
        "#0EA5E9", // blue
        "#22C55E", // green
        "#EF4444", // red
        "#F59E0B", // amber
        "#06B6D4", // cyan
      ];
      
      // Use the label to determine a consistent color
      const index = label.charCodeAt(0) % colors.length;
      return colors[index];
    }
    
    return isActive ? "var(--primary)" : "currentColor";
  };

  if (children) {
    return (
      <div className="sidebar-item">
        <div 
          className={cn(
            "flex items-center gap-2 py-1.5 px-2 rounded-sm text-sm cursor-pointer text-gray-300 hover:text-white hover:bg-white/5",
            isActive && "bg-primary/10 text-primary",
            "group"
          )}
          onClick={onToggle}
        >
          {expanded ? 
            <ChevronDown className="h-3.5 w-3.5 text-gray-400" /> : 
            <ChevronRight className="h-3.5 w-3.5 text-gray-400" />
          }
          {React.isValidElement(icon) && React.cloneElement(icon as React.ReactElement, { 
            style: { color: getIconColor() } 
          })}
          <span className="flex-1 truncate">{label}</span>
          {level === 0 && <Plus className="h-3.5 w-3.5 text-gray-400 opacity-0 group-hover:opacity-100" />}
        </div>
        {expanded && (
          <div className={`${level > 0 ? padding : ''}`}>
            {children}
          </div>
        )}
      </div>
    );
  }

  if (path) {
    return (
      <Link to={path}>
        <div 
          className={cn(
            `flex items-center gap-2 py-1.5 px-2 ${padding} rounded-sm text-sm cursor-pointer text-gray-300 hover:text-white hover:bg-white/5`,
            isActive && "bg-primary/10 text-primary"
          )}
        >
          {React.isValidElement(icon) && React.cloneElement(icon as React.ReactElement, { 
            style: { color: getIconColor() } 
          })}
          <span className="flex-1 truncate">{label}</span>
        </div>
      </Link>
    );
  }

  return (
    <div 
      className={cn(
        `flex items-center gap-2 py-1.5 px-2 ${padding} rounded-sm text-sm cursor-pointer text-gray-300 hover:text-white hover:bg-white/5`
      )}
    >
      {React.isValidElement(icon) && React.cloneElement(icon as React.ReactElement, { 
        style: { color: getIconColor() } 
      })}
      <span className="flex-1 truncate">{label}</span>
    </div>
  );
};

const SpaceLeftSidebar = ({ onClose, className }: SpaceLeftSidebarProps) => {
  const { spaceId } = useParams();
  const location = useLocation();
  const [activeTab, setActiveTab] = useState("pages");
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    spacePages: true,
    codeBuilder: true,
    pageBuilder: false,
  });

  const recentActivities = getSpaceRecentActivity(spaceId || "");

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  // Determine space type based on spaceId or path
  const getSpaceType = () => {
    if (spaceId?.includes("flora") || location.pathname.includes("/flora")) {
      return "creative";
    } else if (spaceId?.includes("codecraft") || location.pathname.includes("/codecraft")) {
      return "development";
    } else {
      return "general";
    }
  };

  const spaceType = getSpaceType();

  const renderSpaceTools = () => {
    switch (spaceType) {
      case "creative":
        return (
          <div className="space-y-3">
            <h3 className="text-xs text-gray-500 font-medium px-2">CREATIVE TOOLS</h3>
            <SidebarItem 
              label="Canvas Editor" 
              icon={<Brush className="h-4 w-4" />}
              path={`/space/${spaceId}/canvas`}
              variant="colored"
            />
            <SidebarItem 
              label="Image Generator" 
              icon={<Image className="h-4 w-4" />}
              path={`/space/${spaceId}/image-generator`}
              variant="colored"
            />
            <SidebarItem 
              label="Design Tools" 
              icon={<Layers className="h-4 w-4" />}
              path={`/space/${spaceId}/design`}
              variant="colored"
            />
          </div>
        );
      case "development":
        return (
          <div className="space-y-3">
            <h3 className="text-xs text-gray-500 font-medium px-2">DEVELOPMENT TOOLS</h3>
            <SidebarItem 
              label="Code Editor" 
              icon={<Code className="h-4 w-4" />}
              path={`/space/${spaceId}/code-editor`}
              variant="colored"
            />
            <SidebarItem 
              label="Terminal" 
              icon={<Terminal className="h-4 w-4" />}
              path={`/space/${spaceId}/terminal`}
              variant="colored"
            />
            <SidebarItem 
              label="Database Manager" 
              icon={<Database className="h-4 w-4" />}
              path={`/space/${spaceId}/database`}
              variant="colored"
            />
          </div>
        );
      default:
        return (
          <div className="space-y-3">
            <h3 className="text-xs text-gray-500 font-medium px-2">GENERAL TOOLS</h3>
            <SidebarItem 
              label="Document Editor" 
              icon={<Edit className="h-4 w-4" />}
              path={`/space/${spaceId}/editor`}
              variant="colored"
            />
            <SidebarItem 
              label="Flow Designer" 
              icon={<GitBranch className="h-4 w-4" />}
              path={`/space/${spaceId}/flow`}
              variant="colored"
            />
          </div>
        );
    }
  };

  return (
    <div className={cn(
      "w-64 h-full bg-black/80 backdrop-blur-lg border-r border-white/5 overflow-hidden",
      className
    )}>
      {onClose && (
        <div className="flex justify-end p-2">
          <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}

      <div className="px-2 py-3">
        <Tabs defaultValue="pages" className="border-b border-white/10 pb-3 mb-3">
          <TabsList className="w-full grid grid-cols-3 bg-white/5 p-1">
            <TabsTrigger 
              value="pages" 
              onClick={() => setActiveTab("pages")}
              className="text-xs text-white/80"
            >
              Pages
            </TabsTrigger>
            <TabsTrigger 
              value="recents" 
              onClick={() => setActiveTab("recents")}
              className="text-xs text-white/80"
            >
              Recents
            </TabsTrigger>
            <TabsTrigger 
              value="tools" 
              onClick={() => setActiveTab("tools")}
              className="text-xs text-white/80"
            >
              Tools
            </TabsTrigger>
          </TabsList>

          <ScrollArea className="h-[calc(100vh-80px)] pr-2 space-y-6 mt-2">
            <TabsContent value="pages" className="m-0">
              <SidebarItem 
                label="SPACE PAGES" 
                icon={<Folder className="h-4 w-4 text-gray-400" />}
                expanded={expandedSections.spacePages}
                onToggle={() => toggleSection('spacePages')}
                variant="colored"
              >
                <SidebarItem 
                  label="Overview" 
                  icon={<LayoutDashboard className="h-4 w-4" />}
                  path={`/space/${spaceId}`}
                  variant="colored"
                />
                <SidebarItem 
                  label="Agents" 
                  icon={<Bot className="h-4 w-4" />}
                  path={`/space/${spaceId}/agents`}
                  variant="colored"
                />
                <SidebarItem 
                  label="Workflows" 
                  icon={<GitBranch className="h-4 w-4" />}
                  path={`/space/${spaceId}/workflows`}
                  variant="colored"
                />
                <SidebarItem 
                  label="Apps" 
                  icon={<Package className="h-4 w-4" />}
                  path={`/space/${spaceId}/apps`}
                  variant="colored"
                />
                <SidebarItem 
                  label="Tools" 
                  icon={<Wrench className="h-4 w-4" />}
                  path={`/space/${spaceId}/tools`}
                  variant="colored"
                />
                <SidebarItem 
                  label="Resources" 
                  icon={<FileBox className="h-4 w-4" />}
                  path={`/space/${spaceId}/resources`}
                  variant="colored"
                />
                <SidebarItem 
                  label="Workspaces" 
                  icon={<FolderOpen className="h-4 w-4" />}
                  path={`/space/${spaceId}/workspaces`}
                  variant="colored"
                />
                <SidebarItem 
                  label="Integrations" 
                  icon={<LinkIcon className="h-4 w-4" />}
                  path={`/space/${spaceId}/integrations`}
                  variant="colored"
                />
                <SidebarItem 
                  label="MCP Server" 
                  icon={<Server className="h-4 w-4" />}
                  path={`/space/${spaceId}/mcpserver`}
                  variant="colored"
                />
                <SidebarItem 
                  label="Marketplace" 
                  icon={<ShoppingBag className="h-4 w-4" />}
                  path={`/space/${spaceId}/marketplace`}
                  variant="colored"
                />
                <SidebarItem 
                  label="Security" 
                  icon={<Shield className="h-4 w-4" />}
                  path={`/space/${spaceId}/security`}
                  variant="colored"
                />
                <SidebarItem 
                  label="Community" 
                  icon={<Users className="h-4 w-4" />}
                  path={`/community/${spaceId}`}
                  variant="colored"
                />
                <SidebarItem 
                  label="Settings" 
                  icon={<Settings className="h-4 w-4" />}
                  path={`/space/${spaceId}/settings`}
                  variant="colored"
                />
              </SidebarItem>

              <SidebarItem 
                label="CODE BUILDER" 
                icon={<Code className="h-4 w-4 text-gray-400" />}
                expanded={expandedSections.codeBuilder}
                onToggle={() => toggleSection('codeBuilder')}
                variant="colored"
              >
                <SidebarItem 
                  label="Hello World.co" 
                  icon={<Folder className="h-4 w-4 text-gray-400" />}
                  expanded={true}
                  level={1}
                  variant="colored"
                >
                  <SidebarItem 
                    label="Server" 
                    icon={<Server className="h-4 w-4 text-gray-400" />}
                    path={`/space/${spaceId}/mcpserver`}
                    level={2}
                    variant="colored"
                  />
                  <SidebarItem 
                    label="Html" 
                    icon={<FileText className="h-4 w-4 text-gray-400" />}
                    level={2}
                    variant="colored"
                  />
                  <SidebarItem 
                    label="Database" 
                    icon={<Database className="h-4 w-4 text-gray-400" />}
                    level={2}
                    variant="colored"
                  />
                </SidebarItem>
              </SidebarItem>

              <SidebarItem 
                label="PAGE BUILDER" 
                icon={<Layout className="h-4 w-4 text-gray-400" />}
                expanded={expandedSections.pageBuilder}
                onToggle={() => toggleSection('pageBuilder')}
                variant="colored"
              >
                <SidebarItem 
                  label="About Us" 
                  icon={<Layers className="h-4 w-4 text-gray-400" />}
                  path={`/space/${spaceId}/about`}
                  level={1}
                  variant="colored"
                />
                <SidebarItem 
                  label="Partners" 
                  icon={<Layers className="h-4 w-4 text-gray-400" />}
                  path={`/space/${spaceId}/partners`}
                  level={1}
                  variant="colored"
                />
                <SidebarItem 
                  label="Product" 
                  icon={<Layers className="h-4 w-4 text-gray-400" />}
                  path={`/space/${spaceId}/products`}
                  level={1}
                  variant="colored"
                />
                <SidebarItem 
                  label="Footer" 
                  icon={<Layers className="h-4 w-4 text-gray-400" />}
                  path={`/space/${spaceId}/footer`}
                  level={1}
                  variant="colored"
                />
              </SidebarItem>
            </TabsContent>

            <TabsContent value="recents" className="m-0">
              <div className="space-y-3">
                <h3 className="text-xs text-gray-500 font-medium px-2 mt-2">RECENT ACTIVITY</h3>
                <div className="space-y-2">
                  {recentActivities.map((activity) => (
                    <ActivityItem
                      key={activity.id}
                      id={activity.id}
                      title={activity.title}
                      timestamp={activity.timestamp}
                      icon={activity.icon}
                      description={activity.description}
                      gradient="bg-white/10"
                    />
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="tools" className="m-0">
              {renderSpaceTools()}
            </TabsContent>
          </ScrollArea>
        </Tabs>
      </div>
    </div>
  );
};

export default SpaceLeftSidebar;
