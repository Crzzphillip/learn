
import { motion } from "framer-motion";
import { ArrowUp, TrendingUp } from "lucide-react";

interface TrendCardProps {
  title: string;
  category: string;
  growth: string;
  period: string;
  color: string;
}

const TrendCard = ({ title, category, growth, period, color }: TrendCardProps) => {
  return (
    <motion.div
      className="glass-panel rounded-xl p-5 min-w-[280px] mr-4"
      whileHover={{ scale: 1.02, transition: { duration: 0.2 } }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0, transition: { duration: 0.5 } }}
    >
      <div className="flex items-center justify-between mb-4">
        <div className={`w-10 h-10 rounded-xl bg-${color}/20 grid place-items-center`}>
          <TrendingUp className={`w-5 h-5 text-${color}`} />
        </div>
        <span className="text-xs px-2 py-1 rounded-full bg-white/10">
          {category}
        </span>
      </div>
      <h3 className="font-semibold text-lg mb-4">{title}</h3>
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1 text-green-500">
          <ArrowUp className="w-4 h-4" />
          <span className="font-medium">{growth}</span>
        </div>
        <span className="text-xs text-muted-foreground">in the last {period}</span>
      </div>
    </motion.div>
  );
};

export default TrendCard;
