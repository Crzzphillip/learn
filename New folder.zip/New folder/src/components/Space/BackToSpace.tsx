
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

interface BackToSpaceProps {
  spaceId: string;
}

const BackToSpace = ({ spaceId }: BackToSpaceProps) => {
  return (
    <div className="mb-6">
      <Link to={`/space/${spaceId}`}>
        <Button variant="ghost" size="sm" className="gap-1 text-muted-foreground">
          <ArrowLeft className="h-4 w-4" />
          Back to Space
        </Button>
      </Link>
    </div>
  );
};

export default BackToSpace;
