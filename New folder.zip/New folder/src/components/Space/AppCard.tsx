
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LucideIcon } from "lucide-react";
import CreditBadge from "./CreditBadge";

interface AppCardProps {
  id?: string;
  title: string;
  description: string;
  icon: LucideIcon;
  credits: string;
  locked: boolean;
  image: string;
  primaryColor?: string;
}

const AppCard = ({
  id,
  title,
  description,
  icon: Icon,
  credits,
  locked,
  image,
  primaryColor = "#7E69AB"
}: AppCardProps) => {
  const navigate = useNavigate();

  const handleLaunchApp = () => {
    if (!locked && id) {
      navigate(`/app/${id}`);
    }
  };

  return (
    <Card className="group hover:border-primary/30 transition-all duration-300 bg-black/20 border-white/10 backdrop-blur-sm">
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent z-10" />
        <img 
          src={image} 
          alt={title} 
          className="w-full h-32 object-cover opacity-70 group-hover:opacity-90 transition-opacity duration-500"
        />
        <div className="absolute top-3 right-3 z-20">
          <CreditBadge credits={credits} locked={locked} />
        </div>
      </div>
      
      <CardHeader className="relative z-20 -mt-8 pb-0">
        <div className="flex items-center gap-3">
          <div 
            className="w-10 h-10 rounded-lg flex items-center justify-center backdrop-blur-xl"
            style={{ 
              background: `linear-gradient(to bottom right, ${primaryColor}30, ${primaryColor}20)` 
            }}
          >
            <Icon className="w-5 h-5" />
          </div>
          <h3 className="font-semibold">{title}</h3>
        </div>
      </CardHeader>
      
      <CardContent>
        <p className="text-sm text-white/70 mb-4 line-clamp-3">{description}</p>
        
        <div className="pt-2">
          <Button 
            className="w-full"
            style={{
              background: `linear-gradient(to right, ${primaryColor}, ${primaryColor}DD)`,
              color: "white"
            }}
            disabled={locked}
            onClick={handleLaunchApp}
          >
            {locked ? "Unlock App" : "Launch App"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default AppCard;
