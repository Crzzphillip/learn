
import { useState, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface TypewriterCardProps {
  title: string;
  description: string;
  examples: string[];
  icon: React.ReactNode;
  className?: string;
  primaryColor?: string;
}

const TypewriterCard = ({
  title,
  description,
  examples,
  icon,
  className,
  primaryColor = "#7E69AB"
}: TypewriterCardProps) => {
  const [isHovered, setIsHovered] = useState(false);
  const [currentExampleIndex, setCurrentExampleIndex] = useState(0);
  const [displayedText, setDisplayedText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const typingTimerRef = useRef<NodeJS.Timeout | null>(null);
  const pauseTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Effect to handle the typewriter animation
  useEffect(() => {
    if (!isHovered) {
      // Reset when not hovered
      setDisplayedText("");
      setIsTyping(false);

      // Clear any existing timers
      if (typingTimerRef.current) clearInterval(typingTimerRef.current);
      if (pauseTimerRef.current) clearTimeout(pauseTimerRef.current);
      return;
    }

    // Start typing animation when hovered
    const currentExample = examples[currentExampleIndex];
    let charIndex = 0;
    setIsTyping(true);

    // Clear any existing typing timer
    if (typingTimerRef.current) clearInterval(typingTimerRef.current);

    // Set up typing animation
    typingTimerRef.current = setInterval(() => {
      if (charIndex <= currentExample.length) {
        setDisplayedText(currentExample.substring(0, charIndex));
        charIndex++;
      } else {
        // Finished typing current example
        setIsTyping(false);
        clearInterval(typingTimerRef.current!);

        // Set up pause before starting next example
        pauseTimerRef.current = setTimeout(() => {
          // Move to next example after pause
          setCurrentExampleIndex(prevIndex => prevIndex === examples.length - 1 ? 0 : prevIndex + 1);
        }, 2000); // 2 second pause before next example
      }
    }, 50); // 50ms between each character for typing effect

    // Cleanup
    return () => {
      if (typingTimerRef.current) clearInterval(typingTimerRef.current);
      if (pauseTimerRef.current) clearTimeout(pauseTimerRef.current);
    };
  }, [isHovered, currentExampleIndex, examples]);

  return (
    <Card 
      className={cn(
        "h-full transition-all duration-300 backdrop-blur-sm border border-white/10 bg-black/20 overflow-hidden",
        "hover:border-primary/40 hover:shadow-lg hover:shadow-primary/5",
        className
      )}
      style={{
        borderColor: isHovered ? `${primaryColor}40` : 'rgba(255, 255, 255, 0.1)',
        boxShadow: isHovered ? `0 4px 20px ${primaryColor}15` : 'none'
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="p-3 h-full flex flex-col">
        {!isHovered ? (
          // Default view - show icon, title and description
          <>
            <div className="flex items-center gap-3 mb-3">
              <div 
                className="w-10 h-10 rounded-lg flex items-center justify-center" 
                style={{
                  background: `linear-gradient(to bottom right, ${primaryColor}40, ${primaryColor}20)`
                }}
              >
                {icon}
              </div>
              <h3 className="font-semibold text-base">{title}</h3>
            </div>
            
            <p className="text-sm text-white/70 mb-4">
              {description}
            </p>
          </>
        ) : (
          // Hovered view - show typing animation
          <div className="flex items-center justify-center h-full">
            <div 
              className="text-sm font-mono max-w-[90%]"
              style={{ color: `${primaryColor}` }}
            >
              {displayedText}
              {isTyping && <span className="animate-pulse">|</span>}
            </div>
          </div>
        )}
      </div>
    </Card>
  );
};

export default TypewriterCard;
