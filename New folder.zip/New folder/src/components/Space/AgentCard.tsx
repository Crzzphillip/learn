
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LucideIcon } from "lucide-react";
import CreditBadge from "./CreditBadge";

interface AgentCardProps {
  id?: string;
  title: string;
  description: string;
  icon: LucideIcon;
  category: string;
  rating: string;
  credits: string;
  locked: boolean;
  personas?: string[];
  image: string;
  primaryColor?: string;
}

const AgentCard = ({
  id,
  title,
  description,
  icon: Icon,
  category,
  rating,
  credits,
  locked,
  personas = [],
  image,
  primaryColor = "#7E69AB"
}: AgentCardProps) => {
  const navigate = useNavigate();

  const handleUseAgent = () => {
    if (!locked && id) {
      navigate(`/agent/${id}`);
    }
  };

  return (
    <Card className="group hover:border-primary/30 transition-all duration-300 overflow-hidden bg-black/20 border-white/10 backdrop-blur-sm">
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent z-10" />
        <img 
          src={image} 
          alt={title} 
          className="w-full h-32 object-cover opacity-70 group-hover:opacity-90 transition-opacity duration-500"
        />
        <div className="absolute top-3 right-3 z-20">
          <CreditBadge credits={credits} locked={locked} />
        </div>
      </div>
      
      <CardHeader className="relative z-20 -mt-8 pb-0">
        <div className="flex items-center gap-3 mb-2">
          <div 
            className="w-10 h-10 rounded-lg flex items-center justify-center backdrop-blur-xl"
            style={{ 
              background: `linear-gradient(to bottom right, ${primaryColor}30, ${primaryColor}20)` 
            }}
          >
            <Icon className="w-5 h-5" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold">{title}</h3>
            <div className="flex items-center text-xs space-x-2 text-white/60">
              <span>{category}</span>
              <span>•</span>
              <span className="flex items-center">
                {rating} ★
              </span>
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <p className="text-sm text-white/70 mb-4 line-clamp-3">{description}</p>
        
        {personas.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-4">
            {personas.map((persona, index) => (
              <Badge key={index} variant="outline" className="bg-black/40 text-xs">
                {persona}
              </Badge>
            ))}
          </div>
        )}
        
        <div className="pt-2">
          <Button 
            className="w-full"
            style={{
              background: `linear-gradient(to right, ${primaryColor}, ${primaryColor}DD)`,
              color: "white"
            }}
            disabled={locked}
            onClick={handleUseAgent}
          >
            {locked ? "Unlock Agent" : "Use Agent"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default AgentCard;
