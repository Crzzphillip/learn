
import { Copy, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import WorkflowCard from "./WorkflowCard";
import { useNavigate, useParams } from "react-router-dom";
import { Workflow } from "@/types/explore";

interface FeaturedWorkflowsSectionProps {
  workflows: Workflow[];
}

const FeaturedWorkflowsSection = ({
  workflows = []
}: FeaturedWorkflowsSectionProps) => {
  const navigate = useNavigate();
  const { spaceId } = useParams();
  
  // Ensure workflows is always an array
  const safeWorkflows = Array.isArray(workflows) ? workflows : [];
  
  const handleBrowseAll = () => {
    navigate(`/space/${spaceId}/workspaces`);
  };
  
  return (
    <div className="mb-12">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-semibold mb-2">Featured Workflows</h2>
          <p className="text-muted-foreground">Popular workflow templates created by the community</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Copy className="w-4 h-4 mr-2" />
            Share Workflow
          </Button>
          <Button variant="default" size="sm" onClick={handleBrowseAll}>
            <Eye className="w-4 h-4 mr-2" />
            Browse All
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {safeWorkflows.map((workflow, index) => (
          <WorkflowCard 
            key={workflow.id || index}
            id={workflow.id}
            title={workflow.title}
            description={workflow.description}
            agents={workflow.agents}
            credits={workflow.credits}
            locked={workflow.locked}
            image={workflow.image}
            author={workflow.author}
            usageStats={workflow.usageStats}
            tags={workflow.tags}
          />
        ))}
      </div>
    </div>
  );
};

export default FeaturedWorkflowsSection;
