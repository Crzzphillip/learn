
import { useRef } from "react";
import { ChevronLeft, ChevronRight, Wrench } from "lucide-react";
import { Button } from "@/components/ui/button";
import SpaceStatsPanel from "@/components/Space/SpaceStatsPanel";
import ForesightOrbs from "@/components/Space/ForesightOrbs";
import CollaborationZones from "@/components/Space/CollaborationZones";
import WorldConnections from "@/components/Space/WorldConnections";
import WorldTestingGrounds from "@/components/Space/WorldTestingGrounds";
import { SpaceStat } from "@/types/space";

interface AnalyticsScrollableProps {
  stats: SpaceStat[];
  primaryColor: string;
}

const AnalyticsScrollable = ({ stats, primaryColor }: AnalyticsScrollableProps) => {
  const analyticsScrollRef = useRef<HTMLDivElement>(null);

  const scrollAnalyticsLeft = () => {
    if (analyticsScrollRef.current) {
      analyticsScrollRef.current.scrollBy({
        left: -300,
        behavior: "smooth"
      });
    }
  };

  const scrollAnalyticsRight = () => {
    if (analyticsScrollRef.current) {
      analyticsScrollRef.current.scrollBy({
        left: 300,
        behavior: "smooth"
      });
    }
  };

  return (
    <div className="relative mb-8">
      <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <Wrench className="w-5 h-5" style={{ color: primaryColor }} />
        Space Stats
      </h3>
      
      <div className="absolute left-0 top-1/2 -translate-y-1/2 z-10">
        <Button
          size="icon"
          variant="secondary"
          className="rounded-full w-10 h-10 bg-background/80 backdrop-blur-sm"
          onClick={scrollAnalyticsLeft}
        >
          <ChevronLeft className="w-5 h-5" />
        </Button>
      </div>
      
      <div 
        ref={analyticsScrollRef}
        className="flex overflow-x-auto space-x-4 pb-4 scrollbar-hide"
        style={{ 
          scrollBehavior: 'smooth',
          msOverflowStyle: 'none',
          scrollbarWidth: 'none'
        }}
      >
        <div className="min-w-[400px] max-w-[500px]">
          <SpaceStatsPanel stats={stats} className="h-full" primaryColor={primaryColor} />
        </div>
        
        <div className="min-w-[400px] max-w-[500px]">
          <ForesightOrbs className="h-full" primaryColor={primaryColor} />
        </div>
        <div className="min-w-[400px] max-w-[500px]">
          <CollaborationZones primaryColor={primaryColor} />
        </div>
        <div className="min-w-[400px] max-w-[500px]">
          <WorldConnections primaryColor={primaryColor} />
        </div>
        <div className="min-w-[400px] max-w-[500px]">
          <WorldTestingGrounds primaryColor={primaryColor} />
        </div>
      </div>
      
      <div className="absolute right-0 top-1/2 -translate-y-1/2 z-10">
        <Button
          size="icon"
          variant="secondary"
          className="rounded-full w-10 h-10 bg-background/80 backdrop-blur-sm"
          onClick={scrollAnalyticsRight}
        >
          <ChevronRight className="w-5 h-5" />
        </Button>
      </div>
      
      <style>
        {`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        `}
      </style>
    </div>
  );
};

export default AnalyticsScrollable;
