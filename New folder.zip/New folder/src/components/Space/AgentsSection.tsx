
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import AgentCard from "./AgentCard";
import { LucideIcon } from "lucide-react";

interface Agent {
  id?: string;
  title: string;
  description: string;
  icon: LucideIcon;
  category: string;
  rating: string;
  credits: string;
  locked: boolean;
  personas?: string[];
  image: string;
}

interface AgentsSectionProps {
  agents: Agent[];
  primaryColor?: string;
}

const AgentsSection = ({ agents, primaryColor = "#7E69AB" }: AgentsSectionProps) => {
  const navigate = useNavigate();
  const { spaceId } = useParams();

  const handleViewAll = () => {
    if (spaceId) {
      navigate(`/space/${spaceId}/agents`);
    }
  };

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-semibold">AI Agents</h2>
        <Button 
          variant="outline" 
          onClick={handleViewAll}
          style={{ 
            borderColor: `${primaryColor}30`
          }}
          className="hover:border-primary/50"
        >
          View All
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {agents.map((agent, index) => (
          <AgentCard 
            key={agent.id || index} 
            {...agent} 
            primaryColor={primaryColor}
          />
        ))}
      </div>
    </div>
  );
};

export default AgentsSection;
