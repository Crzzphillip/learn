
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import AgentCard from "./AgentCard";
import { LucideIcon } from "lucide-react";

interface Resource {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  category: string;
  rating: string;
  credits: string;
  locked: boolean;
  type: string;
  image: string;
}

interface ResourcesSectionProps {
  resources: Resource[];
}

const ResourcesSection = ({ resources }: ResourcesSectionProps) => {
  const navigate = useNavigate();
  const { spaceId } = useParams();

  const handleViewAll = () => {
    if (spaceId) {
      navigate(`/space/${spaceId}/resources`);
    }
  };

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-semibold">Learning Resources</h2>
        <Button variant="outline" onClick={handleViewAll}>View All</Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {resources.map((resource) => (
          <AgentCard 
            key={resource.id}
            {...resource}
            personas={[resource.type]}
          />
        ))}
      </div>
    </div>
  );
};

export default ResourcesSection;
