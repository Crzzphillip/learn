
import { useNavigate, useParams } from "react-router-dom";
import { ChevronRight, ChevronLeft } from "lucide-react";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";
import { getSpaceNavPages } from "@/services/spaceNavService";

interface NavPageProps {
  name: string;
  path: string;
  description: string;
  color: string;
}

interface SpaceNavProps {
  primaryColor: string;
  accentColor: string;
  activeIndex: number;
  setActiveIndex: (index: number) => void;
  api: any;
}

const SpaceNav = ({ primaryColor, accentColor, activeIndex, setActiveIndex, api }: SpaceNavProps) => {
  const navigate = useNavigate();
  const { spaceId } = useParams();
  
  // Get space pages from service instead of hardcoding
  const spacePages = getSpaceNavPages(primaryColor, accentColor);

  const handlePageCardClick = (path: string) => {
    if (path === 'community'){
      navigate(`/community/${spaceId}`);
    } else{
      navigate(`/space/${spaceId}/${path}`);
  }
  };

  useEffect(() => {
    if (!api || spacePages.length <= 3) return;
    
    const interval = setInterval(() => {
      api.scrollNext();
    }, 4000);
    
    return () => clearInterval(interval);
  }, [api, spacePages]);

  return (
    <div className="relative px-8">
      <Carousel
        setApi={api}
        opts={{
          align: "center",
          loop: true,
          containScroll: false,
        }}
        className="w-full"
      >
        <CarouselContent>
          {spacePages.map((page, index) => (
            <CarouselItem 
              key={index} 
              className="sm:basis-1/3 md:basis-1/5 lg:basis-1/5 transition-all duration-300"
              onClick={() => handlePageCardClick(page.path)}
            >
              <Card 
                className={cn(
                  "min-w-[200px] rounded-2xl p-4 cursor-pointer bg-black/20 backdrop-blur-sm border-white/10 hover:border-white/30 transition-all duration-300",
                  activeIndex === index 
                    ? "scale-110 shadow-lg z-10" 
                    : "scale-90 opacity-80"
                )}
              >
                <h3 className="font-semibold mb-2">{page.name}</h3>
                <p className="text-xs text-white/70 mb-3">{page.description}</p>
              </Card>
            </CarouselItem>
          ))}
        </CarouselContent>
        <CarouselPrevious className="absolute -left-4 top-1/2 -translate-y-1/2 bg-black/40 backdrop-blur-md border-white/10 hover:bg-black/60" />
        <CarouselNext className="absolute -right-4 top-1/2 -translate-y-1/2 bg-black/40 backdrop-blur-md border-white/10 hover:bg-black/60" />
      </Carousel>
    </div>
  );
};

export default SpaceNav;
