
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { ArrowUpRight, BarChart2, Clock, CreditCard, LineChart as LineChartIcon, Users, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SpaceStat } from "@/types/space";
import StatCard from "./StatCard";

interface SpaceStatsPanelProps {
  stats: SpaceStat[];
  className?: string;
  primaryColor?: string;
}

const performanceData = [
  { name: "Jan", value: 400 },
  { name: "Feb", value: 300 },
  { name: "Mar", value: 600 },
  { name: "Apr", value: 800 },
  { name: "May", value: 500 },
  { name: "Jun", value: 900 },
  { name: "Jul", value: 1100 }
];

const usageData = [
  { name: "Agents", usage: 65 },
  { name: "Workflows", usage: 45 },
  { name: "Apps", usage: 30 },
  { name: "Tools", usage: 20 },
  { name: "Resources", usage: 15 }
];

const roiData = [
  { name: "Q1", cost: 500, gain: 850 },
  { name: "Q2", cost: 600, gain: 1200 },
  { name: "Q3", cost: 800, gain: 1600 },
  { name: "Q4", cost: 1000, gain: 2400 }
];

const SpaceStatsPanel = ({ stats, className = "", primaryColor = "#7E69AB" }: SpaceStatsPanelProps) => {
  const [activeTab, setActiveTab] = useState("performance");

  return (
    <Card className={`bg-black/20 border-white/10 backdrop-blur-md ${className}`}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-medium text-white/90">Space Statistics</CardTitle>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-white/60 hover:text-white hover:bg-white/10">
            <ArrowUpRight className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex flex-wrap gap-2 mt-2">
          {stats.map((stat, index) => (
            <StatCard key={index} icon={stat.icon} label={stat.label} value={stat.value} />
          ))}
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 mb-4 bg-black/30">
            <TabsTrigger 
              value="performance" 
              className="data-[state=active]:bg-primary/20"
              style={{ 
                ["--tw-bg-opacity" as any]: 0.2, 
                ["--tw-bg-color" as any]: primaryColor 
              }}
            >
              <LineChartIcon className="h-4 w-4 mr-2" />
              Performance
            </TabsTrigger>
            <TabsTrigger 
              value="usage" 
              className="data-[state=active]:bg-primary/20"
              style={{ 
                ["--tw-bg-opacity" as any]: 0.2, 
                ["--tw-bg-color" as any]: primaryColor 
              }}
            >
              <BarChart2 className="h-4 w-4 mr-2" />
              Usage
            </TabsTrigger>
            <TabsTrigger 
              value="roi" 
              className="data-[state=active]:bg-primary/20"
              style={{ 
                ["--tw-bg-opacity" as any]: 0.2, 
                ["--tw-bg-color" as any]: primaryColor 
              }}
            >
              <Zap className="h-4 w-4 mr-2" />
              ROI
            </TabsTrigger>
          </TabsList>

          <TabsContent value="performance" className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
                <XAxis dataKey="name" stroke="#ffffff60" />
                <YAxis stroke="#ffffff60" />
                <Tooltip
                  contentStyle={{ background: "rgba(0,0,0,0.8)", border: "1px solid rgba(255,255,255,0.1)" }}
                  labelStyle={{ color: "rgba(255,255,255,0.8)" }}
                />
                <Line type="monotone" dataKey="value" stroke={primaryColor} strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </TabsContent>
          
          <TabsContent value="usage" className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={usageData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
                <XAxis dataKey="name" stroke="#ffffff60" />
                <YAxis stroke="#ffffff60" />
                <Tooltip
                  contentStyle={{ background: "rgba(0,0,0,0.8)", border: "1px solid rgba(255,255,255,0.1)" }}
                  labelStyle={{ color: "rgba(255,255,255,0.8)" }}
                />
                <Bar dataKey="usage" fill={primaryColor} />
              </BarChart>
            </ResponsiveContainer>
          </TabsContent>
          
          <TabsContent value="roi" className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={roiData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff20" />
                <XAxis dataKey="name" stroke="#ffffff60" />
                <YAxis stroke="#ffffff60" />
                <Tooltip
                  contentStyle={{ background: "rgba(0,0,0,0.8)", border: "1px solid rgba(255,255,255,0.1)" }}
                  labelStyle={{ color: "rgba(255,255,255,0.8)" }}
                />
                <Bar dataKey="cost" fill="#ff4d4f" name="Cost" />
                <Bar dataKey="gain" fill={primaryColor} name="Gain" />
              </BarChart>
            </ResponsiveContainer>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default SpaceStatsPanel;
