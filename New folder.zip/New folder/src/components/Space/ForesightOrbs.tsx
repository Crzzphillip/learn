
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Eye, Lightbulb, TrendingUp, X, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";

interface Suggestion {
  id: string;
  title: string;
  description: string;
  potentialImprovement: string;
  category: "workflow" | "performance" | "usage" | "cost";
  priority: "high" | "medium" | "low";
}

const suggestionsData: Suggestion[] = [
  {
    id: "sug-1",
    title: "Optimize Ad Workflow",
    description: "Your ad workflow could be optimized to reach more viewers",
    potentialImprovement: "20% increase in audience reach",
    category: "workflow",
    priority: "high"
  },
  {
    id: "sug-2",
    title: "Reduce Resource Usage",
    description: "Several workflows are using more credits than necessary",
    potentialImprovement: "15% reduction in credit usage",
    category: "cost",
    priority: "medium"
  },
  {
    id: "sug-3",
    title: "Enhance Code Reviews",
    description: "Adding automated code reviews could improve code quality",
    potentialImprovement: "30% fewer bugs in production",
    category: "performance",
    priority: "high"
  },
  {
    id: "sug-4",
    title: "Consolidate Similar Tools",
    description: "You're using 3 tools with overlapping functionality",
    potentialImprovement: "10% cost savings",
    category: "cost",
    priority: "low"
  }
];

interface ForesightOrbsProps {
  className?: string;
  primaryColor?: string;
}

const ForesightOrbs = ({ className = "", primaryColor = "#7E69AB" }: ForesightOrbsProps) => {
  const [suggestions, setSuggestions] = useState<Suggestion[]>(suggestionsData);
  const [activeIndex, setActiveIndex] = useState(0);

  const dismissSuggestion = (id: string) => {
    setSuggestions(suggestions.filter(s => s.id !== id));
  };

  const renderPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "text-rose-400";
      case "medium": return "text-amber-400";
      case "low": return "text-emerald-400";
      default: return "text-blue-400";
    }
  };

  const renderCategoryIcon = (category: string) => {
    switch (category) {
      case "workflow": return <Lightbulb className="h-4 w-4" />;
      case "performance": return <TrendingUp className="h-4 w-4" />;
      default: return <Eye className="h-4 w-4" />;
    }
  };

  if (suggestions.length === 0) {
    return null;
  }

  const currentSuggestion = suggestions[activeIndex];

  return (
    <Card className={`bg-black/20 border-white/10 backdrop-blur-md ${className}`}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2 text-lg font-medium text-white/90">
            <div className="w-6 h-6 rounded-full flex items-center justify-center" 
                 style={{ backgroundColor: `${primaryColor}30` }}>
              <Eye className="h-4 w-4" style={{ color: primaryColor }} />
            </div>
            Foresight Predictions
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="relative">
          <motion.div
            key={currentSuggestion.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="p-4 rounded-lg border"
            style={{ 
              backgroundImage: `linear-gradient(to bottom right, ${primaryColor}10, ${primaryColor}05)`,
              borderColor: `${primaryColor}20`
            }}
          >
            <div className="absolute top-2 right-2 flex space-x-1">
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-6 w-6 rounded-full bg-black/20 hover:bg-black/40"
                onClick={() => dismissSuggestion(currentSuggestion.id)}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
            
            <div className="flex items-start mb-3">
              <div className="p-2 rounded-full mr-3" 
                   style={{ backgroundColor: `${primaryColor}20` }}>
                {renderCategoryIcon(currentSuggestion.category)}
              </div>
              <div>
                <h3 className="font-medium text-white/90">{currentSuggestion.title}</h3>
                <p className={`text-xs ${renderPriorityColor(currentSuggestion.priority)}`}>
                  {currentSuggestion.priority.charAt(0).toUpperCase() + currentSuggestion.priority.slice(1)} Priority
                </p>
              </div>
            </div>
            
            <p className="text-sm text-white/70 mb-3">{currentSuggestion.description}</p>
            
            <div className="bg-black/20 rounded-md p-3 mb-3">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-emerald-400" />
                <span className="text-sm font-medium text-emerald-400">Potential Improvement:</span>
              </div>
              <p className="text-sm text-white/80 ml-6">{currentSuggestion.potentialImprovement}</p>
            </div>
            
            <div className="flex justify-between items-center">
              <div className="flex space-x-1">
                {suggestions.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveIndex(idx)}
                    className={`w-2 h-2 rounded-full ${idx === activeIndex ? 'bg-primary' : 'bg-white/20'}`}
                    style={idx === activeIndex ? { backgroundColor: primaryColor } : {}}
                  />
                ))}
              </div>
              
              <Button size="sm" variant="outline" className="gap-1 text-xs h-8 hover:bg-white/10"
                      style={{ 
                        backgroundColor: `${primaryColor}10`, 
                        borderColor: `${primaryColor}30`,
                        color: "white"
                      }}>
                Implement Now
                <ChevronRight className="h-3 w-3" />
              </Button>
            </div>
          </motion.div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ForesightOrbs;
