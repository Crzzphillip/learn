
import { motion } from "framer-motion";
import { Workflow } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface FeaturedWorkflowCardProps {
  id: string;
  title: string;
  description: string;
  tags: string[];
  author: {
    name: string;
    avatar: string;
  };
  stats: {
    runs: string;
    rating: string;
  };
}

const FeaturedWorkflowCard = ({ id, title, description, tags, author, stats }: FeaturedWorkflowCardProps) => {
  const navigate = useNavigate();

  return (
    <motion.div
      className="glass-panel rounded-xl p-5 cursor-pointer min-w-[350px] mr-4"
      whileHover={{ scale: 1.02, transition: { duration: 0.2 } }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0, transition: { duration: 0.5 } }}
      onClick={() => navigate(`/workflow/${id}`)}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="w-10 h-10 rounded-xl bg-primary/20 grid place-items-center">
          <Workflow className="w-5 h-5 text-primary" />
        </div>
        <div className="text-xs text-muted-foreground">by {author.name}</div>
      </div>
      <h3 className="font-semibold text-lg mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{description}</p>
      <div className="flex flex-wrap gap-2 mb-4">
        {tags.map((tag, index) => (
          <span key={index} className="text-xs px-2 py-1 rounded-full bg-white/10">
            {tag}
          </span>
        ))}
      </div>
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <div>{stats.runs} runs</div>
        <div className="px-2 py-1 rounded-full bg-white/10">★ {stats.rating}</div>
      </div>
    </motion.div>
  );
};

export default FeaturedWorkflowCard;
