
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface FeaturedAgentCardProps {
  id: string;
  name: string;
  avatar: string;
  category: string;
  description: string;
  stats: {
    interactions: string;
    rating: string;
  };
}

const FeaturedAgentCard = ({ id, name, avatar, category, description, stats }: FeaturedAgentCardProps) => {
  const navigate = useNavigate();

  return (
    <motion.div
      className="glass-panel rounded-xl p-5 cursor-pointer min-w-[320px] mr-4"
      whileHover={{ scale: 1.02, transition: { duration: 0.2 } }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0, transition: { duration: 0.5 } }}
      onClick={() => navigate(`/agent/${id}`)}
    >
      <div className="flex items-start gap-4 mb-4">
        <Avatar className="w-12 h-12 rounded-xl">
          <AvatarImage src={avatar} alt={name} />
          <AvatarFallback>{name[0]}</AvatarFallback>
        </Avatar>
        <div>
          <h3 className="font-semibold text-lg">{name}</h3>
          <span className="text-xs px-2 py-1 rounded-full bg-primary/20 text-primary">
            {category}
          </span>
        </div>
      </div>
      <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{description}</p>
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <div>{stats.interactions} interactions</div>
        <div className="px-2 py-1 rounded-full bg-white/10">★ {stats.rating}</div>
      </div>
    </motion.div>
  );
};

export default FeaturedAgentCard;
