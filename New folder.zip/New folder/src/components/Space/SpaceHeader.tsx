
import { Button } from "@/components/ui/button";
import { CreditCard, Settings, Grid3X3 } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import { SpaceTemplate } from "@/types/space";

interface SpaceHeaderProps {
  template: SpaceTemplate;
}

const SpaceManagementSidebar = () => {
  const { spaceId } = useParams();
  const navigate = useNavigate();
  
  const handleManageSpace = () => {
    navigate(`/space/${spaceId}/manage`);
  };

  const handleViewAllContent = () => {
    navigate(`/space/${spaceId}/allin`);
  };

  return (
    <div className="flex items-center gap-3">
      <Button variant="outline" className="gap-2" onClick={handleViewAllContent}>
        <Grid3X3 className="w-4 h-4" />
        All Content
      </Button>
      <Button variant="outline" className="gap-2" onClick={handleManageSpace}>
        <Settings className="w-4 h-4" />
        Manage Space
      </Button>
    </div>
  );
};

const SpaceHeader = ({ template }: SpaceHeaderProps) => {
  return (
    <div className="flex items-start gap-6">
      <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/10 grid place-items-center backdrop-blur-xl`}>
        <template.icon className="w-10 h-10" style={{ color: template.primaryColor }} />
      </div>
      <div className="flex-1">
        <h1 className="text-4xl font-semibold tracking-tight mb-3">{template.title}</h1>
        <p className="text-xl text-muted-foreground max-w-2xl">{template.description}</p>
      </div>
      <div className="flex items-center gap-3">
        <Button variant="outline" className="gap-2">
          <CreditCard className="w-4 h-4" />
          Subscribe
        </Button>
        <SpaceManagementSidebar />
      </div>
    </div>
  );
};

export default SpaceHeader;
