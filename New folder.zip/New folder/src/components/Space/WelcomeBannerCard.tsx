
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardTitle } from "@/components/ui/card";
import { useNavigate, useParams } from "react-router-dom";
import InfiniteCardSlider from "@/components/Space/InfiniteCardSlider";
import { ThemeContent, ThemeStyles } from "@/utils/spaceThemeUtils";
import { ExternalLink } from "lucide-react";

interface WelcomeBannerCardProps {
  themeContent: ThemeContent;
  styles: ThemeStyles;
}

const WelcomeBannerCard = ({ themeContent, styles }: WelcomeBannerCardProps) => {
  const navigate = useNavigate();
  const { spaceId } = useParams();
  const [isHovering, setIsHovering] = useState(false);

  const handleExploreAll = () => {
    navigate(`/space/${spaceId}/allin`);
  };

  return (
    <div 
      className="mb-8 relative" 
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      <Card className={`${styles.cardBg} backdrop-blur-sm transition-all duration-300`}>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
            <div>
              <CardTitle className={`text-2xl mb-2 ${styles.heading}`}>{themeContent.title}</CardTitle>
              <CardDescription className="text-white/70">{themeContent.description}</CardDescription>
            </div>
            <Button className={`${styles.buttonGradient}`}>
              Explore All Tools
            </Button>
          </div>
          
          <div className="mt-6">
            <InfiniteCardSlider 
              featuredAgents={themeContent.featuredAgents}
              featuredWorkflows={themeContent.featuredWorkflows}
              trends={themeContent.trends}
            />
          </div>
        </CardContent>
      </Card>

      {/* Explore All Glass Card that appears on hover */}
      <div 
        className={`absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300 ${
          isHovering ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'
        }`}
      >
        <Card 
          className="bg-black/40 backdrop-blur-xl border border-white/10 p-3 cursor-pointer hover:bg-black/50 transition-all duration-300 group"
          onClick={handleExploreAll}
        >
          <CardContent className="p-4 flex flex-col items-center gap-2">
            <div className="w-12 h-12 rounded-full flex items-center justify-center bg-gradient-to-br from-primary/30 to-primary/10 group-hover:from-primary/40 group-hover:to-primary/20 transition-all duration-300">
              <ExternalLink className="w-6 h-6 text-primary" />
            </div>
            <span className="text-lg font-medium text-white">Explore All</span>
            <span className="text-xs text-white/60">View complete gallery</span>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default WelcomeBannerCard;
