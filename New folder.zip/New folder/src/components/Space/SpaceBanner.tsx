
import { useState, useEffect } from "react";
import { SpaceStat, SpaceTemplate } from "@/types/space";
import SpaceHeader from "./SpaceHeader";
import SpaceNav from "./SpaceNav";

interface SpaceBannerProps {
  stats: SpaceStat[];
  template: SpaceTemplate;
  trendData?: {
    title: string;
    change: string;
    description: string;
    isUp: boolean;
    gradient: string;
  }[];
}

const SpaceBanner = ({ stats, template, trendData = [] }: SpaceBannerProps) => {
  const [api, setApi] = useState<any>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  
  useEffect(() => {
    if (!api) return;
    
    const onSelect = () => {
      setActiveIndex(api.selectedScrollSnap());
    };
    
    api.on("select", onSelect);
    
    return () => {
      api.off("select", onSelect);
    };
  }, [api]);

  return (
    <div className="relative h-[400px]">
      <div className={`absolute inset-0 bg-gradient-to-br ${template.gradient}`} />
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-background/80 to-background" />
      
      <div className="absolute bottom-0 left-0 right-0">
        <div className="container py-8">
          <SpaceHeader template={template} />

          <div className="relative mt-8">
            <SpaceNav 
              primaryColor={template.primaryColor}
              accentColor={template.accentColor}
              activeIndex={activeIndex}
              setActiveIndex={setActiveIndex}
              api={api}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default SpaceBanner;
