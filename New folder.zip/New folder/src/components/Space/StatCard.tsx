
import { useEffect, useState } from "react";
import { motion } from "framer-motion";

interface StatCardProps {
  icon: React.ComponentType<any>;
  label: string;
  value: string;
}

const StatCard = ({ icon: Icon, label, value }: StatCardProps) => {
  return (
    <div className="flex items-center gap-3 p-2 rounded-lg bg-background/30 hover:bg-background/50 transition-colors">
      <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center text-primary">
        <Icon className="w-4 h-4" />
      </div>
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm font-semibold">{value}</p>
      </div>
    </div>
  );
};

export default StatCard;
