
import { useState } from "react";
import { X, LayoutGrid, GitBranch, Bot, Settings, Users, Palette, MessageSquare, Zap, Laptop, Code, FileText, Boxes, ArrowRight } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { SpaceNavigation } from "@/components/Layout/components/SpaceNavigation";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { SpaceNavItem } from "@/components/Layout/types/sidebar";
import InfiniteCardSlider from "./InfiniteCardSlider";
import { useNavigate } from "react-router-dom";
import { getFeaturedWorkflows } from "@/data/spaceData";

interface SpaceNavigationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  spaceNavItems: SpaceNavItem[];
  currentPath: string;
  spaceId: string;
}

interface AIRealm {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  gradient: string;
  tools: number;
  agents: number;
}

const SpaceNavigationDialog = ({
  open,
  onOpenChange,
  spaceNavItems,
  currentPath,
  spaceId
}: SpaceNavigationDialogProps) => {
  const navigate = useNavigate();
  const featuredWorkflows = getFeaturedWorkflows();
  const [selectedRealmId, setSelectedRealmId] = useState<string | null>(null);
  
  const aiRealms: AIRealm[] = [
    {
      id: "development",
      title: "Frontend Development",
      description: "UI/UX design, component libraries, and frontend frameworks",
      icon: Code,
      gradient: "from-blue-500/10 to-indigo-500/10",
      tools: 24,
      agents: 16
    },
    {
      id: "creative",
      title: "Creative Art",
      description: "Digital artwork, illustrations, and creative design",
      icon: Palette,
      gradient: "from-pink-500/10 to-purple-500/10",
      tools: 18,
      agents: 12
    },
    {
      id: "marketing",
      title: "Marketing",
      description: "Content creation, analytics, and campaign management",
      icon: MessageSquare,
      gradient: "from-orange-500/10 to-amber-500/10",
      tools: 21,
      agents: 14
    },
    {
      id: "productivity",
      title: "Productivity",
      description: "Task management, automation, and workflow optimization",
      icon: Zap,
      gradient: "from-emerald-500/10 to-teal-500/10",
      tools: 19,
      agents: 13
    },
    {
      id: "backend",
      title: "Backend Development",
      description: "APIs, databases, and server infrastructure",
      icon: Laptop,
      gradient: "from-cyan-500/10 to-blue-500/10",
      tools: 26,
      agents: 15
    }
  ];
  
  const selectedRealm = selectedRealmId ? aiRealms.find(realm => realm.id === selectedRealmId) : null;
  
  const trendingWorkspaces = [{
    title: "Frontend Development Kit",
    description: "Modern UI components with code generation",
    icon: LayoutGrid,
    stats: {
      usedBy: "423 users",
      rating: "4.9 ★"
    },
    gradient: "from-blue-500/10 to-indigo-500/10"
  }, {
    title: "Workflow Automation",
    description: "Connect and automate your development tools",
    icon: GitBranch,
    stats: {
      usedBy: "287 users",
      rating: "4.7 ★"
    },
    gradient: "from-emerald-500/10 to-teal-500/10"
  }, {
    title: "AI Agent Toolkit",
    description: "Build and deploy AI agents for development",
    icon: Bot,
    stats: {
      usedBy: "195 users",
      rating: "4.8 ★"
    },
    gradient: "from-purple-500/10 to-violet-500/10"
  }];
  
  const trendingWorkflows = [{
    title: "React Component Generator",
    description: "Generate React components from descriptions",
    icon: LayoutGrid,
    stats: {
      runs: "1.4k",
      copies: "345"
    },
    gradient: "from-sky-500/10 to-blue-500/10"
  }, {
    title: "CI/CD Pipeline Builder",
    description: "Automated CI/CD setup for your projects",
    icon: GitBranch,
    stats: {
      runs: "983",
      copies: "219"
    },
    gradient: "from-amber-500/10 to-orange-500/10"
  }];
  
  const trends = [{
    title: "TypeScript Usage",
    change: "+24%",
    description: "TypeScript adoption has increased in this space",
    isUp: true,
    gradient: "from-green-500/10 to-emerald-500/10"
  }, {
    title: "Testing Coverage",
    change: "+15%",
    description: "More projects now include comprehensive tests",
    isUp: true,
    gradient: "from-blue-500/10 to-indigo-500/10"
  }];

  const quickNavActions = [
    {
      title: "Agents",
      icon: Bot,
      path: `/space/${spaceId}/agents`,
      gradient: "from-purple-500/10 to-indigo-500/10"
    },
    {
      title: "Workflows",
      icon: GitBranch,
      path: `/space/${spaceId}/workflows`,
      gradient: "from-emerald-500/10 to-teal-500/10"
    },
    {
      title: "Workspaces",
      icon: Laptop,
      path: `/space/${spaceId}/workspaces`,
      gradient: "from-sky-500/10 to-blue-500/10"
    },
    {
      title: "Apps",
      icon: LayoutGrid,
      path: `/space/${spaceId}/apps`,
      gradient: "from-amber-500/10 to-orange-500/10"
    },
    {
      title: "Resources",
      icon: FileText,
      path: `/space/${spaceId}/resources`,
      gradient: "from-rose-500/10 to-pink-500/10"
    },
    {
      title: "Tools",
      icon: Boxes,
      path: `/space/${spaceId}/tools`,
      gradient: "from-cyan-500/10 to-blue-500/10"
    },
    {
      title: "Community",
      icon: Users,
      path: `/community/${spaceId}`,
      gradient: "from-violet-500/10 to-purple-500/10"
    },
    {
      title: "Settings",
      icon: Settings,
      path: `/space/${spaceId}/settings`,
      gradient: "from-slate-500/10 to-gray-500/10"
    }
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-none w-[90vw] max-h-[90vh] mx-auto p-0 rounded-xl border border-primary/10 overflow-hidden bg-[rgba(0,0,0,.98)]">
        <div className="w-full h-full overflow-y-auto">
          <div className="sticky top-0 z-10 flex items-center justify-between p-4 backdrop-blur-md bg-black/40 border-b border-white/10">
            <h2 className="text-2xl font-bold">Specialized AI Realms</h2>
            <Button variant="ghost" size="icon" className="rounded-full hover:bg-white/10" onClick={() => onOpenChange(false)}>
              <X className="h-5 w-5" />
            </Button>
          </div>
          
          <div className="flex h-[calc(90vh-4rem)]">
            {/* Quick Action Side Navigation */}
            <div className="w-[220px] min-w-[220px] h-full border-r border-white/10 p-3 space-y-2 hidden md:block">
              <div className="mb-4">
                <h3 className="text-sm font-medium text-white/70 px-2 mb-2">Quick Navigation</h3>
                <div className="space-y-1.5">
                  {quickNavActions.map((action, index) => (
                    <Button 
                      key={index}
                      variant="ghost" 
                      className="w-full justify-start text-sm font-normal hover:bg-white/10"
                      onClick={() => {
                        navigate(action.path);
                        onOpenChange(false);
                      }}
                    >
                      <div className={`w-7 h-7 rounded-md bg-gradient-to-br ${action.gradient} flex items-center justify-center mr-2`}>
                        <action.icon className="w-4 h-4" />
                      </div>
                      {action.title}
                    </Button>
                  ))}
                </div>
              </div>
              
              <div className="mt-auto pt-4 border-t border-white/10">
                <Button 
                  variant="outline" 
                  className="w-full text-xs justify-between bg-transparent border-white/20 hover:bg-white/10"
                  onClick={() => {
                    navigate(`/space/${spaceId}`);
                    onOpenChange(false);
                  }}
                >
                  <span>Go to Space</span>
                  <ArrowRight className="w-3.5 h-3.5 ml-1" />
                </Button>
              </div>
            </div>
            
            {/* Main Content */}
            <div className="flex-1 p-4 overflow-y-auto pb-8">
              {!selectedRealm ? (
                <>
                  <div className="mb-8">
                    <h3 className="text-xl font-semibold mb-4">Domain-Specific Hubs</h3>
                    <p className="text-white/60 mb-4">Each realm offers curated agents, workflows, and tools with distinct themes.</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {aiRealms.map((realm) => (
                        <Card 
                          key={realm.id}
                          className={`bg-card/50 border border-primary/10 hover:border-primary/30 cursor-pointer transition-all duration-300`}
                          onClick={() => setSelectedRealmId(realm.id)}
                        >
                          <CardHeader>
                            <div className="flex items-center gap-3">
                              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${realm.gradient} flex items-center justify-center`}>
                                <realm.icon className="w-6 h-6" />
                              </div>
                              <div>
                                <CardTitle>{realm.title}</CardTitle>
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <CardDescription className="text-white/70 mb-4">{realm.description}</CardDescription>
                            <div className="flex items-center justify-between text-sm">
                              <span>{realm.tools} Tools</span>
                              <span>{realm.agents} Agents</span>
                              <span className="text-primary">Explore →</span>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                      <Card className="bg-card/50 border border-primary/10 border-dashed hover:border-primary/30 cursor-pointer transition-all duration-300">
                        <CardHeader>
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center">
                              <Settings className="w-6 h-6" />
                            </div>
                            <div>
                              <CardTitle>Create Custom Realm</CardTitle>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <CardDescription className="text-white/70 mb-4">Build your own specialized environment with custom tools and agents</CardDescription>
                          <div className="text-sm text-primary">
                            Get Started →
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                  
                  <div className="mb-8">
                    <h3 className="text-xl font-semibold mb-4">Cross-World Synergy</h3>
                    <Card className="bg-card/50 border border-primary/10">
                      <CardContent className="pt-6">
                        <p className="text-white/70 mb-4">Combine capabilities across realms for holistic projects</p>
                        <div className="mx-4">
                          <InfiniteCardSlider featuredAgents={trendingWorkspaces} featuredWorkflows={trendingWorkflows} trends={trends} />
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-center gap-3 mb-6">
                    <Button variant="ghost" onClick={() => setSelectedRealmId(null)} className="gap-2">
                      <X className="h-4 w-4" />
                      <span>Back to Realms</span>
                    </Button>
                    <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${selectedRealm.gradient} flex items-center justify-center`}>
                      <selectedRealm.icon className="w-4 h-4" />
                    </div>
                    <h3 className="text-xl font-semibold">{selectedRealm.title} Realm</h3>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                    <div className="md:col-span-8">
                      <Card className="bg-card/50 border border-primary/10">
                        <CardHeader>
                          <CardTitle>Tools & Capabilities</CardTitle>
                          <CardDescription>Specialized tools for {selectedRealm.title.toLowerCase()} workflows</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <SpaceNavigation spaceNavItems={spaceNavItems} currentPath={currentPath} />
                        </CardContent>
                      </Card>
                    </div>
                    
                    <div className="md:col-span-4 space-y-4">
                      <Card className="bg-card/50 border border-primary/10">
                        <CardHeader>
                          <CardTitle>Featured Workflows</CardTitle>
                          <CardDescription>Popular in {selectedRealm.title} realm</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            {featuredWorkflows.slice(0, 2).map((workflow, index) => (
                              <div key={index} className="p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors border border-white/10 cursor-pointer" onClick={() => {
                                navigate(`/workflow/${workflow.id}`);
                                onOpenChange(false);
                              }}>
                                <div className="flex items-center gap-3 mb-2">
                                  <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center">
                                    <GitBranch className="w-5 h-5" />
                                  </div>
                                  <div>
                                    <h4 className="font-medium">{workflow.title}</h4>
                                    <p className="text-xs text-white/60">{workflow.usageStats.runs} runs</p>
                                  </div>
                                </div>
                                <p className="text-sm text-white/70 line-clamp-2">{workflow.description}</p>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card className="bg-card/50 border border-primary/10">
                        <CardHeader>
                          <CardTitle>Quick Actions</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            <Button className="w-full flex items-center justify-start gap-3" variant="outline" onClick={() => {
                              navigate(`/space/${spaceId}/agents`);
                              onOpenChange(false);
                            }}>
                              <Bot className="h-5 w-5" />
                              <span>Browse Agents</span>
                            </Button>
                            <Button className="w-full flex items-center justify-start gap-3" variant="outline" onClick={() => {
                              navigate(`/space/${spaceId}/workspaces`);
                              onOpenChange(false);
                            }}>
                              <LayoutGrid className="h-5 w-5" />
                              <span>Manage Workspaces</span>
                            </Button>
                            <Button className="w-full flex items-center justify-start gap-3" variant="outline" onClick={() => {
                              navigate(`/community/${spaceId}`);
                              onOpenChange(false);
                            }}>
                              <Users className="h-5 w-5" />
                              <span>Community Space</span>
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default SpaceNavigationDialog;
