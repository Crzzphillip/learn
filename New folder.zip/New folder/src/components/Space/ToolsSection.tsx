
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import AppCard from "./AppCard";
import { LucideIcon, Sparkles, Tag } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Tool } from "@/types/space";

interface ToolsSectionProps {
  tools: Tool[];
  primaryColor?: string;
  themeTitle?: string;
  themeDescription?: string;
  showCategories?: boolean;
  maxVisible?: number;
}

const ToolsSection = ({ 
  tools, 
  primaryColor = "#7E69AB", 
  themeTitle = "Tools & Utilities",
  themeDescription = "Powerful tools to enhance your creative process",
  showCategories = true,
  maxVisible = 6
}: ToolsSectionProps) => {
  const navigate = useNavigate();
  const { spaceId } = useParams();

  const handleViewAll = () => {
    if (spaceId) {
      navigate(`/space/${spaceId}/tools`);
    }
  };

  // Ensure tools is an array
  const safeTools = Array.isArray(tools) ? tools : [];
  
  // Filter to only show maxVisible tools if needed
  const visibleTools = maxVisible ? safeTools.slice(0, maxVisible) : safeTools;

  return (
    <div className="mb-8">
      <div className="flex flex-col space-y-2 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-semibold">{themeTitle}</h2>
            <Sparkles className="w-5 h-5" style={{ color: primaryColor }} />
          </div>
          <Button 
            variant="outline" 
            onClick={handleViewAll}
            style={{ 
              borderColor: `${primaryColor}30`,
              background: `${primaryColor}10`,
            }}
            className="hover:border-primary/50 hover:bg-primary/20 transition-colors duration-300"
          >
            View All
          </Button>
        </div>
        <p className="text-muted-foreground text-sm">{themeDescription}</p>
      </div>
      
      {/* Single grid with all tools, categories as tags */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {visibleTools.map((tool, index) => (
          <div key={tool.id || index} className="group relative">
            <AppCard 
              {...tool} 
              primaryColor={tool.themeColor || primaryColor}
            />
            {showCategories && tool.category && (
              <div className="absolute top-3 right-3 z-10">
                <Badge 
                  variant="secondary" 
                  className="flex items-center gap-1 bg-black/50 backdrop-blur-md"
                >
                  <Tag className="w-3 h-3" />
                  {tool.category.charAt(0).toUpperCase() + tool.category.slice(1)}
                </Badge>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ToolsSection;
