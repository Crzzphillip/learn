
import { Zap } from "lucide-react";

interface CreditBadgeProps {
  amount?: string;
  credits?: string;
  locked?: boolean;
}

const CreditBadge = ({ amount, credits, locked }: CreditBadgeProps) => (
  <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full ${
    locked ? 'bg-gray-500/10 text-gray-400' : 'bg-primary/10 text-primary'
  } text-xs`}>
    <Zap className="w-3.5 h-3.5" />
    <span>{credits || amount} credits</span>
  </div>
);

export default CreditBadge;
