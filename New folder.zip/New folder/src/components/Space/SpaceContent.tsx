
import { Separator } from "@/components/ui/separator";
import FeaturedWorkflowsSection from "@/components/Space/FeaturedWorkflowsSection";
import CommunityContent from "@/components/Space/CommunityContent";
import ToolsSection from "@/components/Space/ToolsSection";
import AgentsSection from "@/components/Space/AgentsSection";
import WorkflowsSection from "@/components/Space/WorkflowsSection";
import AppsSection from "@/components/Space/AppsSection";
import ResourcesSection from "@/components/Space/ResourcesSection";
import { SpaceTemplate } from "@/types/space";
import WelcomeBannerCard from "./WelcomeBannerCard";
import SpaceTypeContent from "./SpaceTypeContent";
import { getThemeContent, getThemeStyles } from "@/utils/spaceThemeUtils";
import { Workflow } from "@/types/explore";

interface SpaceContentProps {
  spaceTemplate: SpaceTemplate;
  featuredWorkflows: any[];
  reviewItems: any[];
  tools: any[];
  agents: any[];
  workflows: any[];
  enhancedWorkflows: any[];
  apps: any[];
  resources: any[];
  onApproveContent: (id: string) => void;
  onRejectContent: (id: string) => void;
}

const SpaceContent = ({
  spaceTemplate,
  featuredWorkflows = [],
  reviewItems = [],
  tools = [],
  agents = [],
  workflows = [],
  enhancedWorkflows = [],
  apps = [],
  resources = [],
  onApproveContent,
  onRejectContent
}: SpaceContentProps) => {
  const themeContent = getThemeContent(spaceTemplate);
  const styles = getThemeStyles(spaceTemplate);
  
  // Ensure all arrays are actually arrays before spreading
  const safeWorkflows = Array.isArray(workflows) ? workflows : [];
  const safeEnhancedWorkflows = Array.isArray(enhancedWorkflows) ? enhancedWorkflows : [];
  
  // Combine the workflow arrays safely
  const combinedWorkflows: Workflow[] = [...safeWorkflows, ...safeEnhancedWorkflows];

  return (
    <>
      <WelcomeBannerCard themeContent={themeContent} styles={styles} />
      
      <SpaceTypeContent spaceTemplate={spaceTemplate} />
      
      <Separator className={`my-8 ${styles.divider}`} />
      
      {Array.isArray(featuredWorkflows) && featuredWorkflows.length > 0 && (
        <FeaturedWorkflowsSection workflows={featuredWorkflows} />
      )}
      
      {spaceTemplate.type === 'community' && (
        <CommunityContent
          reviewItems={reviewItems}
          onApprove={onApproveContent}
          onReject={onRejectContent}
        />
      )}
      
      <div className="space-y-10">
        {Array.isArray(tools) && tools.length > 0 && <ToolsSection tools={tools} />}
        {Array.isArray(agents) && agents.length > 0 && <AgentsSection agents={agents} />}
        {combinedWorkflows.length > 0 && <WorkflowsSection workflows={combinedWorkflows} />}
        {Array.isArray(apps) && apps.length > 0 && <AppsSection apps={apps} />}
      </div>
      
      {Array.isArray(resources) && resources.length > 0 && <ResourcesSection resources={resources} />}
    </>
  );
};

export default SpaceContent;
