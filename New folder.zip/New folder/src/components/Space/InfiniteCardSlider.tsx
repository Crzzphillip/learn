
import { useRef, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ChevronLeft, ChevronRight, LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

interface AgentCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  stats: {
    usedBy: string;
    rating: string;
  };
  gradient: string;
}

interface WorkflowCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  stats: {
    runs: string;
    copies: string;
  };
  gradient: string;
}

interface TrendCardProps {
  title: string;
  change: string;
  description: string;
  isUp: boolean;
  gradient: string;
}

interface InfiniteCardSliderProps {
  featuredAgents: AgentCardProps[];
  featuredWorkflows: WorkflowCardProps[];
  trends: TrendCardProps[];
}

const InfiniteCardSlider = ({ featuredAgents, featuredWorkflows, trends }: InfiniteCardSliderProps) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [showLeftControl, setShowLeftControl] = useState(false);
  const [showRightControl, setShowRightControl] = useState(true);

  // Check if scroll controls should be visible
  useEffect(() => {
    const handleScroll = () => {
      if (scrollRef.current) {
        setShowLeftControl(scrollRef.current.scrollLeft > 20);
        setShowRightControl(
          scrollRef.current.scrollLeft < 
          scrollRef.current.scrollWidth - scrollRef.current.clientWidth - 20
        );
      }
    };

    const scrollElement = scrollRef.current;
    if (scrollElement) {
      scrollElement.addEventListener("scroll", handleScroll);
      // Initial check
      handleScroll();
      
      return () => scrollElement.removeEventListener("scroll", handleScroll);
    }
  }, [featuredAgents, featuredWorkflows, trends]);

  const scrollLeft = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: -300, behavior: "smooth" });
    }
  };

  const scrollRight = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: 300, behavior: "smooth" });
    }
  };

  // Render agent card
  const renderAgentCard = (agent: AgentCardProps, index: number) => {
    const Icon = agent.icon;
    return (
      <div 
        key={`agent-${index}`}
        className={`glass-panel rounded-xl flex-shrink-0 min-w-[280px] max-w-[320px] mx-2 p-5 bg-gradient-to-br ${agent.gradient}`}
      >
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-lg bg-black/30 grid place-items-center">
            <Icon className="w-5 h-5" />
          </div>
          <h3 className="font-medium text-lg">{agent.title}</h3>
        </div>
        <p className="text-sm text-muted-foreground mb-4">{agent.description}</p>
        <div className="mt-auto flex justify-between text-sm">
          <div>
            <p className="text-muted-foreground">Used by</p>
            <p className="font-medium">{agent.stats.usedBy}</p>
          </div>
          <div className="text-right">
            <p className="text-muted-foreground">Rating</p>
            <p className="font-medium">{agent.stats.rating}</p>
          </div>
        </div>
      </div>
    );
  };

  // Render workflow card
  const renderWorkflowCard = (workflow: WorkflowCardProps, index: number) => {
    const Icon = workflow.icon;
    return (
      <div 
        key={`workflow-${index}`}
        className={`glass-panel rounded-xl flex-shrink-0 min-w-[280px] max-w-[320px] mx-2 p-5 bg-gradient-to-br ${workflow.gradient}`}
      >
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-lg bg-black/30 grid place-items-center">
            <Icon className="w-5 h-5" />
          </div>
          <h3 className="font-medium text-lg">{workflow.title}</h3>
        </div>
        <p className="text-sm text-muted-foreground mb-4">{workflow.description}</p>
        <div className="mt-auto flex justify-between text-sm">
          <div>
            <p className="text-muted-foreground">Runs</p>
            <p className="font-medium">{workflow.stats.runs}</p>
          </div>
          <div className="text-right">
            <p className="text-muted-foreground">Copies</p>
            <p className="font-medium">{workflow.stats.copies}</p>
          </div>
        </div>
      </div>
    );
  };

  // Render trend card
  const renderTrendCard = (trend: TrendCardProps, index: number) => {
    return (
      <div 
        key={`trend-${index}`}
        className={`glass-panel rounded-xl flex-shrink-0 min-w-[280px] max-w-[320px] mx-2 p-5 bg-gradient-to-br ${trend.gradient}`}
      >
        <div className="flex justify-between items-start mb-3">
          <h3 className="font-medium text-lg">{trend.title}</h3>
          <span className={`text-sm font-medium px-2 py-1 rounded-full ${trend.isUp ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
            {trend.change}
          </span>
        </div>
        <p className="text-sm text-muted-foreground">{trend.description}</p>
      </div>
    );
  };

  return (
    <div className="relative">
      {showLeftControl && (
        <motion.div 
          className="absolute left-0 top-1/2 -translate-y-1/2 z-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <Button
            size="icon"
            variant="secondary"
            className="rounded-full w-10 h-10 bg-background/80 backdrop-blur-sm"
            onClick={scrollLeft}
          >
            <ChevronLeft className="w-5 h-5" />
          </Button>
        </motion.div>
      )}
      
      <div 
        ref={scrollRef}
        className="flex overflow-x-auto py-4 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent hide-scrollbar"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {/* Agent Cards */}
        {featuredAgents.map(renderAgentCard)}
        
        {/* Workflow Cards */}
        {featuredWorkflows.map(renderWorkflowCard)}
        
        {/* Trend Cards */}
        {trends.map(renderTrendCard)}
      </div>
      
      {showRightControl && (
        <motion.div 
          className="absolute right-0 top-1/2 -translate-y-1/2 z-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <Button
            size="icon"
            variant="secondary"
            className="rounded-full w-10 h-10 bg-background/80 backdrop-blur-sm"
            onClick={scrollRight}
          >
            <ChevronRight className="w-5 h-5" />
          </Button>
        </motion.div>
      )}
    </div>
  );
};

export default InfiniteCardSlider;

