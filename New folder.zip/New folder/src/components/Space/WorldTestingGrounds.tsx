
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Beaker, Sparkles, Clock, Check, XCircle, RotateCcw, Lightbulb } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface Test {
  id: string;
  name: string;
  type: "ab" | "feature" | "performance" | "usability";
  status: "running" | "completed" | "failed" | "scheduled";
  participants: number;
  goal: string;
  progress: number;
  result?: "positive" | "negative" | "neutral";
  insights?: string[];
}

const testData: Test[] = [
  {
    id: "test-1",
    name: "Agent Recommendation UI",
    type: "ab",
    status: "running",
    participants: 248,
    goal: "Increase conversion by 15%",
    progress: 65
  },
  {
    id: "test-2",
    name: "New Workflow Engine",
    type: "performance",
    status: "completed",
    participants: 1450,
    goal: "Reduce processing time by 30%",
    progress: 100,
    result: "positive",
    insights: [
      "35% faster execution time",
      "22% reduction in memory usage",
      "User satisfaction increased by 18%"
    ]
  },
  {
    id: "test-3",
    name: "Code Generation Features",
    type: "feature",
    status: "scheduled",
    participants: 0,
    goal: "Evaluate developer experience",
    progress: 0
  },
  {
    id: "test-4",
    name: "Search Algorithm Update",
    type: "performance",
    status: "failed",
    participants: 875,
    goal: "Improve search accuracy by 25%",
    progress: 100,
    result: "negative",
    insights: [
      "Only 5% improvement in accuracy",
      "2x increase in response time",
      "Negative user feedback"
    ]
  }
];

interface WorldTestingGroundsProps {
  className?: string;
  primaryColor?: string;
}

const WorldTestingGrounds = ({ className = "", primaryColor = "#7E69AB" }: WorldTestingGroundsProps) => {
  const [activeTest, setActiveTest] = useState<Test>(testData[0]);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "ab": return <Sparkles className="h-4 w-4" />;
      case "feature": return <Lightbulb className="h-4 w-4" />;
      case "performance": return <RotateCcw className="h-4 w-4" />;
      case "usability": return <Check className="h-4 w-4" />;
      default: return <Beaker className="h-4 w-4" />;
    }
  };
  
  const getTypeLabel = (type: string) => {
    switch (type) {
      case "ab": return "A/B Test";
      case "feature": return "Feature Test";
      case "performance": return "Performance";
      case "usability": return "Usability";
      default: return "Unknown";
    }
  };

  const getStatusInfo = (status: string) => {
    switch (status) {
      case "running":
        return { color: "bg-blue-400/20 text-blue-400", icon: <Clock className="h-3 w-3 mr-1" /> };
      case "completed":
        return { color: "bg-emerald-400/20 text-emerald-400", icon: <Check className="h-3 w-3 mr-1" /> };
      case "failed":
        return { color: "bg-rose-400/20 text-rose-400", icon: <XCircle className="h-3 w-3 mr-1" /> };
      case "scheduled":
        return { color: "bg-amber-400/20 text-amber-400", icon: <Clock className="h-3 w-3 mr-1" /> };
      default:
        return { color: "bg-slate-400/20 text-slate-400", icon: null };
    }
  };

  const getResultColor = (result?: string) => {
    switch (result) {
      case "positive": return "text-emerald-400";
      case "negative": return "text-rose-400";
      case "neutral": return "text-slate-400";
      default: return "text-slate-400";
    }
  };

  return (
    <Card className={`bg-black/20 border-white/10 backdrop-blur-md ${className}`}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2 text-lg font-medium text-white/90">
            <div className="w-6 h-6 rounded-full flex items-center justify-center"
                 style={{ backgroundColor: `${primaryColor}30` }}>
              <Beaker className="h-4 w-4" style={{ color: primaryColor }} />
            </div>
            Testing Grounds
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex overflow-x-auto py-1 gap-2 scrollbar-hide">
            {testData.map((test) => {
              const statusInfo = getStatusInfo(test.status);
              return (
                <Button
                  key={test.id}
                  variant="outline"
                  size="sm"
                  className={`h-8 px-2 whitespace-nowrap text-xs ${activeTest.id === test.id ? 'bg-white/10' : 'bg-black/20'}`}
                  onClick={() => setActiveTest(test)}
                >
                  <div className="w-2 h-2 rounded-full mr-1.5" 
                       style={{ backgroundColor: test.status === 'running' ? primaryColor : 'transparent' }} />
                  {test.name}
                </Button>
              );
            })}
          </div>
          
          <div className="rounded-lg border border-white/10 bg-black/20 p-3">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="font-medium">{activeTest.name}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="outline" className={`text-xs ${getStatusInfo(activeTest.status).color}`}>
                    {getStatusInfo(activeTest.status).icon}
                    {activeTest.status.charAt(0).toUpperCase() + activeTest.status.slice(1)}
                  </Badge>
                  <span className="text-xs text-white/60">
                    {getTypeIcon(activeTest.type)}
                    <span className="ml-1">{getTypeLabel(activeTest.type)}</span>
                  </span>
                </div>
              </div>
              
              <div className="bg-black/30 px-2 py-1 rounded text-xs flex flex-col items-end">
                <span className="text-white/70">Participants</span>
                <span className="font-bold">{activeTest.participants.toLocaleString()}</span>
              </div>
            </div>
            
            <div className="mb-3">
              <div className="flex justify-between text-xs mb-1">
                <span>Goal: {activeTest.goal}</span>
                <span>{activeTest.progress}%</span>
              </div>
              <Progress 
                value={activeTest.progress} 
                className="h-1.5 bg-white/10" 
                indicatorClassName="bg-gradient-to-r"
                style={{
                  ["--tw-gradient-from" as any]: primaryColor,
                  ["--tw-gradient-to" as any]: `${primaryColor}CC`,
                }}
              />
            </div>
            
            {activeTest.insights && (
              <div className="mt-4">
                <h4 className="text-xs font-medium text-white/70 mb-2">Insights:</h4>
                <ul className="space-y-1">
                  {activeTest.insights.map((insight, idx) => (
                    <li key={idx} className={`text-xs flex items-start ${getResultColor(activeTest.result)}`}>
                      <span className="inline-block w-3 h-3 mr-1 mt-0.5">{idx + 1}.</span>
                      {insight}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            
            {activeTest.status !== "running" && (
              <Button 
                size="sm" 
                className="w-full mt-3 text-xs"
                style={{
                  backgroundColor: primaryColor,
                  color: "white"
                }}
              >
                {activeTest.status === "completed" ? "View Full Report" : 
                  activeTest.status === "scheduled" ? "Start Test Now" : "Analyze Failure"}
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default WorldTestingGrounds;
