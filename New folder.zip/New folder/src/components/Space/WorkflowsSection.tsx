
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import WorkflowCard from "./WorkflowCard";
import { Workflow } from "@/types/explore";
import { getWorkspaces, Workspace } from "@/services/workspaceService";
import { useState, useEffect } from "react";

interface WorkflowsSectionProps {
  workflows?: Workflow[];
}

const WorkflowsSection = ({ workflows = [] }: WorkflowsSectionProps) => {
  const navigate = useNavigate();
  const { spaceId } = useParams();
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);

  useEffect(() => {
    if (spaceId) {
      // Get workspaces for the current space
      const spaceWorkspaces = getWorkspaces(spaceId);
      
      if (spaceId === 'leonardo') {
        // Filter for canvas workspaces in Leonardo space
        setWorkspaces(spaceWorkspaces.filter(w => w.type === 'canvas'));
      } else if (spaceId === 'aiforge') {
        // Filter for AI Forge workspaces
        setWorkspaces(spaceWorkspaces.filter(w => w.type === 'aiforge'));
      } else {
        // For other spaces, show standard workspaces
        setWorkspaces(spaceWorkspaces.filter(w => w.type === 'standard'));
      }
    }
  }, [spaceId]);

  const safeWorkflows = Array.isArray(workflows) ? workflows : [];

  const handleViewAll = () => {
    if (spaceId) {
      navigate(`/space/${spaceId}/workspaces`);
    }
  };

  const isLeonardoSpace = spaceId === 'leonardo';
  const isAIForgeSpace = spaceId === 'aiforge';
  const sectionTitle = isLeonardoSpace 
    ? "Canvas Workspaces" 
    : isAIForgeSpace 
      ? "AIForge Workspaces" 
      : "Development Workspaces";

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-semibold">{sectionTitle}</h2>
        <Button variant="outline" onClick={handleViewAll}>View All</Button>
      </div>
      
      {isLeonardoSpace || isAIForgeSpace || workspaces.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {workspaces.slice(0, 4).map((workspace) => (
            <WorkflowCard 
              key={workspace.id} 
              id={workspace.id}
              title={workspace.title}
              description={workspace.description}
              agents={[]}
              credits="0" 
              locked={false}
              image={`https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=${encodeURIComponent(workspace.title)}`}
              author={{ name: workspace.creator.name, avatar: workspace.creator.avatar }}
              usageStats={{ runs: String(workspace.members.length * 10), rating: "4.5" }}
              tags={[workspace.canvasType || workspace.type]}
              onOpen={() => navigate(`/workspace/${workspace.id}`)}
            />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {safeWorkflows.map((workflow, index) => (
            <WorkflowCard 
              key={workflow.id || index} 
              id={workflow.id}
              title={workflow.title}
              description={workflow.description}
              agents={workflow.agents}
              credits={workflow.credits}
              locked={workflow.locked}
              image={workflow.image}
              author={workflow.author}
              usageStats={workflow.usageStats}
              tags={workflow.tags}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default WorkflowsSection;
