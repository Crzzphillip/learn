
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import AppCard from "./AppCard";
import { LucideIcon } from "lucide-react";

interface App {
  id?: string;
  title: string;
  description: string;
  icon: LucideIcon;
  credits: string;
  locked: boolean;
  image: string;
}

interface AppsSectionProps {
  apps: App[];
  primaryColor?: string;
}

const AppsSection = ({ apps, primaryColor = "#7E69AB" }: AppsSectionProps) => {
  const navigate = useNavigate();
  const { spaceId } = useParams();

  const handleViewAll = () => {
    if (spaceId) {
      navigate(`/space/${spaceId}/apps`);
    }
  };

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-semibold">Apps & Integration</h2>
        <Button 
          variant="outline" 
          onClick={handleViewAll}
          style={{ 
            borderColor: `${primaryColor}30`
          }}
          className="hover:border-primary/50"
        >
          View All
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {apps.map((app, index) => (
          <AppCard 
            key={app.id || index} 
            {...app} 
            primaryColor={primaryColor}
          />
        ))}
      </div>
    </div>
  );
};

export default AppsSection;
