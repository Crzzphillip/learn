import { SpaceTemplate } from "@/types/space";
import CryptoFeatures from "@/components/Crypto/CryptoFeatures";
import ImageGenerationFeatures from "@/components/ImageGeneration/ImageGenerationFeatures";
import EducationFeatures from "@/components/Education/EducationFeatures";
import EducationPaths from "@/components/Education/EducationPaths";
import EducationResources from "@/components/Education/EducationResources";
import FloraFeatures from "@/components/Flora/FloraFeatures";
import FinanceFeatures from "@/components/Finance/FinanceFeatures";
import ManufacturingFeatures from "@/components/Manufacturing/ManufacturingFeatures";
import LeonardoFeatures from "@/components/Leonardo/LeonardoFeatures";
import CADFeatures from "@/components/CAD/CADFeatures";
import SurveyWorkspace from "@/components/CAD/SurveyWorkspace";
import SurveyAgents from "@/components/CAD/SurveyAgents";
import DataAnalytics from "@/components/CAD/DataAnalytics";

interface SpaceTypeContentProps {
  spaceTemplate: SpaceTemplate;
}

const SpaceTypeContent = ({ spaceTemplate }: SpaceTypeContentProps) => {
  const renderSpecializedFeatures = () => {
    if (spaceTemplate.features) {
      switch (spaceTemplate.type) {
        case 'crypto':
          return <CryptoFeatures features={spaceTemplate.features} />;
        case 'image-generation':
          return <ImageGenerationFeatures features={spaceTemplate.features} />;
        case 'education':
          return <EducationFeatures features={spaceTemplate.features} />;
        case 'flora':
          return <FloraFeatures features={spaceTemplate.features} />;
        case 'finance':
          return <FinanceFeatures features={spaceTemplate.features} />;
        case 'manufacturing':
          return <ManufacturingFeatures features={spaceTemplate.features} />;
        case 'leonardo':
          return <LeonardoFeatures features={spaceTemplate.features} />;
        case 'cad':
          return (
            <>
              <CADFeatures spaceTemplate={spaceTemplate} />
              <SurveyWorkspace />
              <SurveyAgents />
              <DataAnalytics />
            </>
          );
        default:
          return null;
      }
    }
    return null;
  };

  const renderLearningPaths = () => {
    if (spaceTemplate.type === 'education' && spaceTemplate.learningPaths) {
      return <EducationPaths learningPaths={spaceTemplate.learningPaths} />;
    }
    return null;
  };

  const renderEducationalResources = () => {
    if (spaceTemplate.type === 'education' && spaceTemplate.resources) {
      return <EducationResources resources={spaceTemplate.resources} />;
    }
    return null;
  };

  return (
    <>
      {renderSpecializedFeatures()}
      {renderLearningPaths()}
      {renderEducationalResources()}
    </>
  );
};

export default SpaceTypeContent;
