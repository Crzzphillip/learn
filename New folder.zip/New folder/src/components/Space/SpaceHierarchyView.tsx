
import { useState } from "react";
import { ChevronRight, FolderTree } from "lucide-react";
import { SpaceHierarchy } from "@/types/space";
import { cn } from "@/lib/utils";
import { Button } from "../ui/button";

interface SpaceHierarchyViewProps {
  hierarchy: SpaceHierarchy[];
  currentSpaceId?: string;
  onSpaceSelect: (spaceId: string) => void;
  level?: number;
}

const SpaceHierarchyView = ({
  hierarchy,
  currentSpaceId,
  onSpaceSelect,
  level = 0
}: SpaceHierarchyViewProps) => {
  const [expandedSpaces, setExpandedSpaces] = useState<Record<string, boolean>>({});

  const toggleExpand = (spaceId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    setExpandedSpaces(prev => ({
      ...prev,
      [spaceId]: !prev[spaceId]
    }));
  };

  return (
    <div className={cn("space-y-1", level > 0 && "ml-4")}>
      {hierarchy.map((space) => {
        const isExpanded = expandedSpaces[space.id];
        const hasChildren = space.children.length > 0;
        
        return (
          <div key={space.id} className="space-y-1">
            <div className="flex w-full">
              <Button
                variant="ghost"
                className={cn(
                  "flex-1 justify-start gap-2",
                  currentSpaceId === space.id && "bg-accent"
                )}
                onClick={() => onSpaceSelect(space.id)}
              >
                <FolderTree className="h-4 w-4" />
                <span className="flex-1 text-left">{space.title}</span>
              </Button>
              
              {hasChildren && (
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-10 w-10 p-0"
                  onClick={(e) => toggleExpand(space.id, e)}
                >
                  <ChevronRight 
                    className={cn(
                      "h-4 w-4 transition-transform", 
                      isExpanded && "transform rotate-90"
                    )} 
                  />
                </Button>
              )}
            </div>
            
            {hasChildren && isExpanded && (
              <SpaceHierarchyView
                hierarchy={space.children}
                currentSpaceId={currentSpaceId}
                onSpaceSelect={onSpaceSelect}
                level={level + 1}
              />
            )}
          </div>
        );
      })}
    </div>
  );
};

export default SpaceHierarchyView;
