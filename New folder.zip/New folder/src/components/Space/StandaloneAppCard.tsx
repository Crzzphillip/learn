
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import CreditBadge from "./CreditBadge";
import { Badge } from "@/components/ui/badge";
import { Lock, ArrowRight, Layers } from "lucide-react";

interface StandaloneAppCardProps {
  id?: string;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  credits: string;
  locked: boolean;
  image: string;
  sourceType: 'agent' | 'workflow' | 'workspace';
  source?: {
    id: string;
    name: string;
  };
}

const StandaloneAppCard = ({ 
  title, 
  description, 
  icon: Icon, 
  credits, 
  locked, 
  id,
  sourceType,
  source
}: StandaloneAppCardProps) => {
  const navigate = useNavigate();

  const handleClick = () => {
    if (!locked && id) {
      navigate(`/app/${id}`);
    }
  };

  const getSourceIcon = () => {
    switch(sourceType) {
      case 'agent': return <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">Agent-based</Badge>;
      case 'workflow': return <Badge variant="outline" className="bg-blue-500/10 text-blue-500 border-blue-500/20">Workflow-based</Badge>;
      case 'workspace': return <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">Workspace-based</Badge>;
      default: return null;
    }
  };

  return (
    <div 
      className="relative group cursor-pointer bg-background/80 backdrop-blur-sm rounded-xl border border-white/10 p-6"
      onClick={handleClick}
    >
      {locked && (
        <div className="absolute inset-0 bg-background/80 backdrop-blur-sm rounded-xl flex items-center justify-center">
          <div className="text-center">
            <Lock className="w-8 h-8 mx-auto mb-2" />
            <p className="text-sm font-medium">Subscribe to unlock</p>
          </div>
        </div>
      )}
      
      <div className="flex items-start justify-between mb-4">
        <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-xl grid place-items-center">
          <Icon className="w-6 h-6" />
        </div>
        <CreditBadge amount={credits} />
      </div>
      
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-sm text-white/80 mb-4">{description}</p>
      
      <div className="mb-4">
        {getSourceIcon()}
      </div>
      
      <Button variant="outline" size="sm" className="w-full backdrop-blur-sm bg-white/10 hover:bg-white/20">
        Launch App
      </Button>
      
      {source && (
        <div className="mt-4 pt-2 border-t border-white/10">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Based on</span>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-xs p-0 h-6 hover:bg-transparent hover:text-primary"
              onClick={(e) => {
                e.stopPropagation();
                navigate(`/${sourceType}/${source.id}`);
              }}
            >
              {source.name}
              <ArrowRight className="w-3 h-3 ml-1" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default StandaloneAppCard;
