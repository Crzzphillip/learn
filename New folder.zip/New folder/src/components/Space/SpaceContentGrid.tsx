
import React from "react";
import { SpaceHierarchy } from "@/types/space";
import { Star, Users, ChevronRight, ChevronLeft, Code, GitBranch, Database, LayoutTemplate, Paintbrush, Eye, FileCode } from "lucide-react";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import SpaceToolCards from "./SpaceToolCards";

interface SpaceContentGridProps {
  spaceId: string;
  spaceTitle: string;
  spaceType: string;
  spaceGradient: string;
  primaryColor: string;
  accentColor: string;
  className?: string;
  children: React.ReactNode;
}

const SpaceContentGrid: React.FC<SpaceContentGridProps> = ({
  children,
  spaceId,
  spaceTitle,
  spaceType,
  spaceGradient,
  primaryColor,
  accentColor,
  className
}) => {
  const navigate = useNavigate();
  
  return <div className={cn("relative w-full mb-12", className)}>
      <div className="mt-6 mb-6">
        <div className="flex items-center gap-3 mb-2">
          <h1 className="text-3xl font-semibold">{spaceTitle}</h1>
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Star className="h-4 w-4 fill-yellow-500 text-yellow-500" />
            <span>4.8</span>
            <span className="text-xs">•</span>
            <Users className="h-3 w-3" />
            <span>2.3k</span>
          </div>
        </div>
        <div className="text-sm text-muted-foreground mb-8">
          Explore tools, resources, and workflows for {spaceType} development
        </div>

        {/* Tools Section */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Space Tools</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <SpaceToolCards spaceType={spaceType} primaryColor={primaryColor} />
          </div>
        </div>
      </div>
      
      {children}
    </div>;
};

export default SpaceContentGrid;
