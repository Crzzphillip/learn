
import { useNavigate } from "react-router-dom";
import { TrendingUp, GitBranch, Star, ThumbsUp, ZapIcon, CreditCard, Clock, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TrendingWorkspace as TypedTrendingWorkspace } from "@/types/explore";

// Use the same type from explore.ts
export type TrendingWorkspace = TypedTrendingWorkspace;

interface TrendingWorkspacesSectionProps {
  workspaces: TrendingWorkspace[];
  spaceId: string;
}

const TrendingWorkspacesSection = ({ workspaces, spaceId }: TrendingWorkspacesSectionProps) => {
  const navigate = useNavigate();
  
  if (!workspaces || workspaces.length === 0) {
    return null;
  }
  
  return (
    <div className="relative mb-8">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <TrendingUp className="w-5 h-5 text-primary" />
        Trending Workspaces
      </h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {workspaces.slice(0, 2).map((workspace) => (
          <Card key={workspace.id} className="group overflow-hidden bg-black/20 border-white/10 backdrop-blur-sm hover:border-primary/30 transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500/30 to-violet-500/30 flex items-center justify-center backdrop-blur-xl">
                  <GitBranch className="w-6 h-6" />
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="font-semibold text-lg">{workspace.title}</h3>
                    <div className="flex items-center gap-1 text-sm text-white/60">
                      <Star className="w-4 h-4 text-yellow-500" />
                      <span>{workspace.reviews || 0}</span>
                      <span className="mx-1">•</span>
                      <ThumbsUp className="w-4 h-4 text-blue-500" />
                      <span>{workspace.upvotes || 0}</span>
                    </div>
                  </div>
                  
                  <p className="text-sm text-white/70 mb-4">{workspace.description}</p>
                  
                  <div className="bg-black/40 p-3 rounded-lg mb-4 border border-primary/10">
                    <div className="flex justify-between items-center mb-2">
                      <div className="flex items-center gap-2">
                        <ZapIcon className="w-4 h-4 text-yellow-400" />
                        <span className="text-sm font-medium">Saved Credits</span>
                      </div>
                      <span className="text-lg font-bold text-green-500">{workspace.savedCredits}</span>
                    </div>
                    <Progress value={(workspace.savedCredits / workspace.totalCredits) * 100} className="h-2 bg-black/60" />
                    <p className="text-xs text-white/60 mt-2 italic">"{workspace.testimonial || 'No testimonial available'}"</p>
                  </div>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {workspace.tags.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="bg-black/50 backdrop-blur-md border-none">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={workspace.owner.avatar} />
                        <AvatarFallback>{workspace.owner.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span className="text-xs text-white/60">{workspace.owner.name}</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-primary" />
                      <span className="text-sm font-medium">
                        {workspace.price && typeof workspace.price.value !== 'undefined' ? 
                          `${workspace.price.value} ${workspace.price.type === "credits" ? "credits" : 
                            workspace.price.type === "subscription" ? "/month" : "bid"}` :
                          "Free"}
                      </span>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-2 text-xs text-white/60">
                    <div className="flex items-center gap-1">
                      <Users className="w-3 h-3" />
                      <span>{workspace.usageStats.users} users</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <GitBranch className="w-3 h-3" />
                      <span>{workspace.usageStats.runs} runs</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{workspace.usageStats.lastRun}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <div className="flex justify-end mt-4">
        <Button variant="outline" size="sm" className="text-sm" onClick={() => navigate(`/space/${spaceId}/workflows`)}>
          View all trending workspaces
        </Button>
      </div>
    </div>
  );
};

export default TrendingWorkspacesSection;
