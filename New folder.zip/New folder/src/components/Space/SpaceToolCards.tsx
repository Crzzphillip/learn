
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Code, 
  Image, 
  Paintbrush, 
  Eye, 
  FileCode, 
  PanelTop, 
  BarChart, 
  LineChart, 
  CandlestickChart,
  GraduationCap,
  BookOpen,
  Video,
  Wrench,
  Play,
  Download,
  Copy,
  Settings,
  GitBranch,
  Database,
  LayoutTemplate
} from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";

interface SpaceToolCardsProps {
  spaceType: string;
  primaryColor: string;
  className?: string;
}

const SpaceToolCards: React.FC<SpaceToolCardsProps> = ({ 
  spaceType, 
  primaryColor,
  className 
}) => {
  const navigate = useNavigate();
  const { spaceId } = useParams();
  
  const getToolsForSpaceType = () => {
    switch (spaceType) {
      case 'development':
        return [
          { id: 'code-editor', name: 'Code Editor', icon: Code, description: 'Advanced code editing with AI-assisted capabilities' },
          { id: 'preview-viewer', name: 'Preview Viewer', icon: Eye, description: 'Real-time preview of your application changes' },
          { id: 'terminal', name: 'Terminal', icon: FileCode, description: 'Integrated terminal for command execution' },
          { id: 'git-integration', name: 'Git Integration', icon: GitBranch, description: 'Simplified git operations and branch management' },
          { id: 'database-designer', name: 'Database Designer', icon: Database, description: 'Visual database schema design and optimization' },
        ];
      case 'image-generation':
        return [
          { id: 'canvas-editor', name: 'Canvas Editor', icon: LayoutTemplate, description: 'Blank canvas for creating new images' },
          { id: 'image-editor', name: 'Image Editor', icon: Paintbrush, description: 'Edit and modify images with AI assistance' },
          { id: 'style-transfer', name: 'Style Transfer', icon: Eye, description: 'Apply artistic styles to your images' },
          { id: 'batch-processing', name: 'Batch Processing', icon: PanelTop, description: 'Process multiple images with the same operations' },
        ];
      case 'crypto':
        return [
          { id: 'price-charts', name: 'Price Charts', icon: LineChart, description: 'Real-time price charts for cryptocurrencies' },
          { id: 'portfolio-tracker', name: 'Portfolio Tracker', icon: BarChart, description: 'Track your cryptocurrency portfolio performance' },
          { id: 'market-scanner', name: 'Market Scanner', icon: CandlestickChart, description: 'Scan the market for trading opportunities' },
          { id: 'transaction-history', name: 'Transaction History', icon: PanelTop, description: 'View and manage your transaction history' },
        ];
      case 'education':
        return [
          { id: 'course-builder', name: 'Course Builder', icon: GraduationCap, description: 'Create and structure educational courses' },
          { id: 'study-materials', name: 'Study Materials', icon: BookOpen, description: 'Access and organize study materials' },
          { id: 'video-lessons', name: 'Video Lessons', icon: Video, description: 'Create and view video-based lessons' },
          { id: 'progress-tracker', name: 'Progress Tracker', icon: BarChart, description: 'Track learning progress and achievements' },
        ];
      case 'finance-advisor':
        return [
          { id: 'budget-planner', name: 'Budget Planner', icon: LineChart, description: 'Create and manage personal or business budgets' },
          { id: 'investment-simulator', name: 'Investment Simulator', icon: CandlestickChart, description: 'Simulate investment strategies and outcomes' },
          { id: 'tax-calculator', name: 'Tax Calculator', icon: BarChart, description: 'Calculate estimated taxes and deductions' },
          { id: 'expense-tracker', name: 'Expense Tracker', icon: PanelTop, description: 'Track and categorize personal or business expenses' },
        ];
      default:
        return [
          { id: 'general-tool-1', name: 'General Tool 1', icon: Code, description: 'All-purpose tool for this space' },
          { id: 'general-tool-2', name: 'General Tool 2', icon: Image, description: 'Another essential tool for this space' },
          { id: 'general-tool-3', name: 'General Tool 3', icon: BarChart, description: 'Analytics tool for this space' },
          { id: 'general-tool-4', name: 'General Tool 4', icon: PanelTop, description: 'Management tool for this space' },
        ];
    }
  };

  const tools = getToolsForSpaceType();
  
  const handleToolLaunch = (toolId: string) => {
    navigate(`/space/${spaceId}/tool/${toolId}`);
  };
  
  const handleToolConfig = (toolId: string) => {
    toast.info(`Opening configuration for ${toolId}`);
  };
  
  const handleToolClone = (toolId: string) => {
    toast.success(`Cloned ${toolId} successfully`);
  };
  
  const handleToolSave = (toolId: string) => {
    toast.success(`Saved ${toolId} successfully`);
  };

  // Individual tool card component
  const ToolCard = ({ tool, index }: { tool: { id: string, name: string, icon: any, description: string }, index: number }) => {
    const Icon = tool.icon;
    
    return (
      <Card className="flex-shrink-0 min-w-[300px] bg-black/20 border-white/10 backdrop-blur-md hover:border-white/30 transition-all duration-300">
        <CardHeader className="pb-2 pt-4">
          <CardTitle className="flex items-center gap-2 text-lg font-medium text-white/90">
            <div className="w-8 h-8 rounded-full flex items-center justify-center"
                style={{ backgroundColor: `${primaryColor}30` }}>
              <Icon className="h-5 w-5" style={{ color: primaryColor }} />
            </div>
            {tool.name}
          </CardTitle>
        </CardHeader>
        <CardContent className="pb-3">
          <div className="mb-3">
            <p className="text-sm text-white/70">{tool.description}</p>
          </div>
          
          <div className="relative h-20 rounded-lg overflow-hidden bg-black/40 flex items-center justify-center mb-3">
            <div className="absolute inset-0 opacity-70 bg-black/40">
              <img
                src="https://images.unsplash.com/photo-1518432031352-d6fc5c10da5a?q=80&w=2574&auto=format&fit=crop"
                alt="Tool Visualization"
                className="w-full h-full object-cover opacity-20"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent" />
            
            <motion.div
              className="relative z-10"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <div 
                className="w-10 h-10 rounded-lg flex items-center justify-center transition-all"
                style={{ backgroundColor: `${primaryColor}40` }}
              >
                <Icon className="w-5 h-5" style={{ color: primaryColor }} />
              </div>
            </motion.div>
          </div>
          
          <div className="grid grid-cols-2 gap-2 mt-3">
            <button
              className="flex items-center justify-center p-2 rounded-lg bg-black/30 border border-white/10 hover:bg-black/50 transition-colors"
              onClick={() => handleToolLaunch(tool.id)}
            >
              <Play className="h-3.5 w-3.5 mr-1" style={{ color: primaryColor }} />
              <span className="text-xs">Launch</span>
            </button>
            
            <button
              className="flex items-center justify-center p-2 rounded-lg bg-black/30 border border-white/10 hover:bg-black/50 transition-colors"
              onClick={() => handleToolConfig(tool.id)}
            >
              <Settings className="h-3.5 w-3.5 mr-1" style={{ color: primaryColor }} />
              <span className="text-xs">Config</span>
            </button>
            
            <button
              className="flex items-center justify-center p-2 rounded-lg bg-black/30 border border-white/10 hover:bg-black/50 transition-colors"
              onClick={() => handleToolClone(tool.id)}
            >
              <Copy className="h-3.5 w-3.5 mr-1" style={{ color: primaryColor }} />
              <span className="text-xs">Clone</span>
            </button>
            
            <button
              className="flex items-center justify-center p-2 rounded-lg bg-black/30 border border-white/10 hover:bg-black/50 transition-colors"
              onClick={() => handleToolSave(tool.id)}
            >
              <Download className="h-3.5 w-3.5 mr-1" style={{ color: primaryColor }} />
              <span className="text-xs">Save</span>
            </button>
          </div>
        </CardContent>
      </Card>
    );
  };

  // Return array of individual tool cards
  return (
    <>
      {tools.map((tool, index) => (
        <ToolCard key={index} tool={tool} index={index} />
      ))}
    </>
  );
};

export default SpaceToolCards;
