
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, X } from "lucide-react";

export interface ContentReviewItem {
  id: string;
  title: string;
  content: string;
  type: 'post' | 'comment' | 'resource' | 'agent' | 'workflow';
  author: {
    id: string;
    name: string;
    email: string;
    avatar: string;
  };
  timestamp: string;
  status: 'pending' | 'approved' | 'rejected';
  reportCount?: number;
  reportReasons?: string[];
  description: string;
  submittedAt: string;
}

interface CommunityContentReviewProps {
  items: ContentReviewItem[];
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}

const CommunityContentReview = ({
  items,
  onApprove,
  onReject,
}: CommunityContentReviewProps) => {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Content Review Queue</h3>
      <div className="grid gap-4">
        {items.map((item) => (
          <Card key={item.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <CardTitle>{item.title}</CardTitle>
                  <CardDescription>by {item.author.name}</CardDescription>
                </div>
                <Badge
                  variant={
                    item.status === 'approved'
                      ? 'default'
                      : item.status === 'rejected'
                      ? 'destructive'
                      : 'secondary'
                  }
                >
                  {item.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">{item.description}</p>
            </CardContent>
            <CardFooter className="justify-between">
              <div className="text-sm text-muted-foreground">
                Submitted {item.submittedAt}
              </div>
              {item.status === 'pending' && (
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onApprove(item.id)}
                  >
                    <Check className="w-4 h-4 mr-1" /> Approve
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => onReject(item.id)}
                  >
                    <X className="w-4 h-4 mr-1" /> Reject
                  </Button>
                </div>
              )}
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default CommunityContentReview;
