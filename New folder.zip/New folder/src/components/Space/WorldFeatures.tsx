
import { LucideIcon, Sparkles, Lock } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SpaceFeature } from "@/types/space";
import { cn } from "@/lib/utils";

interface WorldFeaturesProps {
  features: SpaceFeature[];
  title?: string;
  description?: string;
  primaryColor?: string;
  gradient?: string;
  className?: string;
  showEmptyState?: boolean;
}

const WorldFeatures = ({ 
  features, 
  title = "World Features", 
  description = "Discover specialized tools and capabilities for this realm",
  primaryColor = "#7E69AB",
  gradient = "from-purple-500/20 to-blue-500/20",
  className,
  showEmptyState = false
}: WorldFeaturesProps) => {
  // Group features by category
  const featuresByCategory = features.reduce((acc, feature) => {
    if (!acc[feature.category]) {
      acc[feature.category] = [];
    }
    acc[feature.category].push(feature);
    return acc;
  }, {} as Record<string, SpaceFeature[]>);

  // Show empty state if requested and no features
  if (showEmptyState && features.length === 0) {
    return (
      <div className={cn("mb-8", className)}>
        <div className="mb-6">
          <h2 className="text-2xl font-semibold flex items-center gap-2 mb-2">
            {title}
            <Sparkles className="w-5 h-5" style={{ color: primaryColor }} />
          </h2>
          <p className="text-muted-foreground">{description}</p>
        </div>
        
        <Card className="bg-black/20 border border-white/10 overflow-hidden text-center p-8">
          <CardContent className="flex flex-col items-center justify-center py-10">
            <Sparkles className="w-12 h-12 mb-4 opacity-50" />
            <h3 className="text-xl font-medium mb-2">No features available yet</h3>
            <p className="text-muted-foreground max-w-md mx-auto">
              This world is still evolving. Check back soon for new and exciting capabilities!
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className={cn("mb-8", className)}>
      <div className="mb-6">
        <h2 className="text-2xl font-semibold flex items-center gap-2 mb-2">
          {title}
          <Sparkles className="w-5 h-5" style={{ color: primaryColor }} />
        </h2>
        <p className="text-muted-foreground">{description}</p>
      </div>

      <div className="space-y-6">
        {Object.entries(featuresByCategory).map(([category, categoryFeatures]) => (
          <div key={category}>
            <h3 className="text-xl font-medium mb-4 flex items-center gap-2">
              <span 
                className="w-2 h-2 rounded-full inline-block"
                style={{ backgroundColor: primaryColor }}
              />
              {category.charAt(0).toUpperCase() + category.slice(1)} Tools
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {categoryFeatures.map((feature) => (
                <Card 
                  key={feature.id} 
                  className={`bg-black/20 border border-white/10 hover:bg-black/30 transition-all duration-300 overflow-hidden group`}
                  style={{ 
                    borderColor: feature.isAvailable ? `${primaryColor}30` : 'rgba(255,255,255,0.1)'
                  }}
                >
                  <div className={`absolute inset-0 opacity-10 bg-gradient-to-br ${gradient}`} />
                  <CardHeader className="relative pb-2">
                    <CardTitle className="flex items-center justify-between">
                      <span className="flex items-center gap-2">
                        <feature.icon className="w-5 h-5" style={{ color: primaryColor }} />
                        {feature.title}
                      </span>
                      {!feature.isAvailable && (
                        <Lock className="w-4 h-4 text-white/40" />
                      )}
                    </CardTitle>
                    <CardDescription>{feature.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="relative">
                    <Button 
                      variant={feature.isAvailable ? "default" : "outline"} 
                      className={feature.isAvailable 
                        ? "w-full bg-gradient-to-r from-purple-500/80 to-blue-600/80 hover:from-purple-500 hover:to-blue-600 transition-all" 
                        : "w-full"
                      }
                      style={feature.isAvailable 
                        ? { background: `linear-gradient(to right, ${primaryColor}CC, ${primaryColor}99)` } 
                        : {}
                      }
                      disabled={!feature.isAvailable}
                    >
                      {feature.isAvailable ? "Access Feature" : "Coming Soon"}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default WorldFeatures;
