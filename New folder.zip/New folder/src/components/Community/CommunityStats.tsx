
import { LucideIcon, Users, MessageSquare, Trophy, Award } from "lucide-react";
import { SpaceStat } from "@/types/space";

export const getDefaultCommunityStats = (): SpaceStat[] => {
  return [
    {
      icon: Users,
      label: "Active Members",
      value: "3.2k"
    },
    {
      icon: MessageSquare,
      label: "Discussions",
      value: "896"
    },
    {
      icon: Trophy,
      label: "Challenges",
      value: "24"
    },
    {
      icon: Award,
      label: "User Badges",
      value: "45"
    }
  ];
};

export default getDefaultCommunityStats;
