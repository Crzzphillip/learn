import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar } from "@/components/ui/avatar";
import { Download, Heart, Share2, BookOpen, FileCode, Video, FileText, Plus, Filter, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { dummyDatabase, Resource } from "@/services/dummyDatabase";

const ResourceSharing = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [resources, setResources] = useState<Resource[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchResources = async () => {
      try {
        setIsLoading(true);
        const fetchedResources = await dummyDatabase.getResources();
        setResources(fetchedResources);
      } catch (error) {
        console.error("Error fetching resources:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchResources();
  }, []);

  const toggleLike = async (resourceId: string) => {
    try {
      await dummyDatabase.toggleResourceLike(resourceId);
      const updatedResources = await dummyDatabase.getResources();
      setResources(updatedResources);
    } catch (error) {
      console.error("Error toggling resource like:", error);
    }
  };

  const handleDownload = async (resourceId: string) => {
    try {
      await dummyDatabase.incrementResourceDownload(resourceId);
      const updatedResources = await dummyDatabase.getResources();
      setResources(updatedResources);
    } catch (error) {
      console.error("Error incrementing download count:", error);
    }
  };

  const handleShare = (resourceId: string) => {
    // In a real app, this would open a sharing dialog or copy link to clipboard
    console.log("Sharing resource:", resourceId);
    navigator.clipboard.writeText(`https://example.com/resource/${resourceId}`);
    toast.success("Link copied to clipboard");
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'template':
        return <FileText className="w-5 h-5" />;
      case 'guide':
        return <BookOpen className="w-5 h-5" />;
      case 'code':
        return <FileCode className="w-5 h-5" />;
      case 'video':
        return <Video className="w-5 h-5" />;
      default:
        return <FileText className="w-5 h-5" />;
    }
  };

  // Filter resources based on search query
  const filteredResources = resources.filter(resource => 
    resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    resource.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    resource.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold">Resource Library</h2>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Upload Resource
          </Button>
        </div>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search resources..."
          className="pl-10"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="all">All Resources</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="guides">Guides</TabsTrigger>
          <TabsTrigger value="code">Code</TabsTrigger>
          <TabsTrigger value="datasets">Datasets</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-6">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="animate-pulse h-64" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredResources.map((resource) => (
                <Card key={resource.id} className="overflow-hidden border border-primary/10 bg-card/50 backdrop-blur-sm hover:bg-card/80 transition-colors">
                  {resource.thumbnailUrl && (
                    <div className="h-40 overflow-hidden bg-gradient-to-br from-primary/5 to-primary/10">
                      <img 
                        src={resource.thumbnailUrl} 
                        alt={resource.title} 
                        className="w-full h-full object-cover opacity-80 hover:opacity-100 transition-opacity"
                      />
                    </div>
                  )}
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className="flex items-center gap-1">
                        {getTypeIcon(resource.type)}
                        <span className="capitalize">{resource.type}</span>
                      </Badge>
                      <Avatar className="w-6 h-6">
                        <img src={resource.author.avatar} alt={resource.author.name} />
                      </Avatar>
                    </div>
                    <CardTitle className="text-lg mt-2">{resource.title}</CardTitle>
                    <CardDescription className="line-clamp-2">{resource.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex flex-wrap gap-2 mb-2">
                      {resource.tags.map(tag => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between border-t border-border/30 pt-3">
                    <div className="flex items-center gap-3">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className={`px-2 ${resource.isLiked ? 'text-primary' : ''}`}
                        onClick={() => toggleLike(resource.id)}
                      >
                        <Heart className={`w-4 h-4 mr-1 ${resource.isLiked ? 'fill-primary' : ''}`} />
                        {resource.likes}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="px-2"
                        onClick={() => handleDownload(resource.id)}
                      >
                        <Download className="w-4 h-4 mr-1" />
                        {resource.downloadCount}
                      </Button>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="px-2"
                      onClick={() => handleShare(resource.id)}
                    >
                      <Share2 className="w-4 h-4" />
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        {["templates", "guides", "code", "datasets"].map((tabValue) => (
          <TabsContent key={tabValue} value={tabValue} className="mt-6">
            <div className="bg-card p-6 rounded-xl text-center">
              <p className="text-muted-foreground">Showing {tabValue} resources...</p>
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

export default ResourceSharing;
