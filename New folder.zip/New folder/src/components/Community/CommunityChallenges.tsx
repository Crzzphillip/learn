
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Clock, Users, Award, ChevronRight } from "lucide-react";
import { Progress } from "@/components/ui/progress";

const challenges = [
  {
    id: "challenge-1",
    title: "AI Agent Building Challenge",
    description: "Build an AI agent that can perform a specific task and submit it for review.",
    participants: 42,
    deadline: "3 days left",
    difficulty: "Intermediate",
    category: "Development",
    prize: "500 Credits",
    progress: 0
  },
  {
    id: "challenge-2",
    title: "Prompt Engineering Contest",
    description: "Create the most effective prompt for a given task and compete with others.",
    participants: 78,
    deadline: "1 week left",
    difficulty: "Beginner",
    category: "Prompt Engineering",
    prize: "300 Credits",
    progress: 60
  },
  {
    id: "challenge-3",
    title: "LangGraph Optimization Challenge",
    description: "Optimize a provided LangGraph workflow for better performance and accuracy.",
    participants: 36,
    deadline: "5 days left",
    difficulty: "Advanced",
    category: "Optimization",
    prize: "1000 Credits",
    progress: 25
  }
];

const CommunityChallenges = () => {
  const [activeChallenges, setActiveChallenges] = useState(challenges);

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner": return "text-green-400 bg-green-500/10 border-green-500/20";
      case "Intermediate": return "text-yellow-400 bg-yellow-500/10 border-yellow-500/20";
      case "Advanced": return "text-red-400 bg-red-500/10 border-red-500/20";
      default: return "text-blue-400 bg-blue-500/10 border-blue-500/20";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold">Community Challenges</h2>
        <Button>
          <Trophy className="w-4 h-4 mr-2" />
          View Leaderboard
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {activeChallenges.map((challenge) => (
          <Card key={challenge.id} className="border-primary/10 bg-card/50 backdrop-blur-sm hover:bg-card/80 transition-colors">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-xl">{challenge.title}</CardTitle>
                  <CardDescription className="mt-2">{challenge.description}</CardDescription>
                </div>
                <Badge variant="outline" className={`${getDifficultyColor(challenge.difficulty)}`}>
                  {challenge.difficulty}
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent>
              <div className="flex flex-wrap gap-4 mb-4">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{challenge.participants} Participants</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{challenge.deadline}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Award className="w-4 h-4 text-primary" />
                  <span className="text-sm">{challenge.prize}</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Your progress</span>
                  <span>{challenge.progress}%</span>
                </div>
                <Progress value={challenge.progress} className="h-2" />
              </div>
            </CardContent>
            
            <CardFooter className="flex justify-between border-t border-border/30 pt-4">
              <Badge variant="secondary" className="bg-primary/10 border-none">
                {challenge.category}
              </Badge>
              <Button variant="ghost" className="gap-1 text-primary">
                View Challenge <ChevronRight className="w-4 h-4" />
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default CommunityChallenges;
