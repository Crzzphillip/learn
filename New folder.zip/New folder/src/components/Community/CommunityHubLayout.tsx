import { useState } from "react";
import { 
  MessageSquare, Users, FileText, Brain, Workflow, 
  AppWindow, GitBranch, Star, Bookmark, Heart, 
  MoreHorizontal, ArrowUpRight, ArrowDownRight, 
  Reply, BookOpen, Sparkles, Award, Trophy, 
  Lightbulb, Image as ImageIcon, Users as UsersIcon,
  Layout, Grid, Settings, Bell, Search, Plus
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface CommunityHubLayoutProps {
  spaceId: string;
  children: React.ReactNode;
}

const CommunityHubLayout = ({ spaceId, children }: CommunityHubLayoutProps) => {
  const [activeTab, setActiveTab] = useState("feed");
  const [searchQuery, setSearchQuery] = useState("");

  // Mock data for community stats
  const communityStats = {
    members: 1250,
    online: 342,
    threads: 450,
    resources: 320,
    events: 12
  };

  return (
    <div className="flex h-screen bg-background">
      {/* Left Sidebar */}
      <div className="w-64 border-r border-border/50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex flex-col h-full">
          {/* Community Info */}
          <div className="p-4 border-b border-border/50">
            <div className="flex items-center gap-3 mb-4">
              <Avatar className="w-12 h-12">
                <AvatarImage src="/avatars/community.jpg" />
                <AvatarFallback>CM</AvatarFallback>
              </Avatar>
              <div>
                <h2 className="font-semibold">AI Development Hub</h2>
                <p className="text-sm text-muted-foreground">1.2K members</p>
              </div>
            </div>
            <Button className="w-full" size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Create Space Item
            </Button>
          </div>

          {/* Navigation */}
          <ScrollArea className="flex-1">
            <nav className="p-4 space-y-1">
              <Button variant="ghost" className="w-full justify-start" size="sm">
                <Layout className="w-4 h-4 mr-2" />
                Feed
              </Button>
              <Button variant="ghost" className="w-full justify-start" size="sm">
                <MessageSquare className="w-4 h-4 mr-2" />
                Discussions
              </Button>
              <Button variant="ghost" className="w-full justify-start" size="sm">
                <Users className="w-4 h-4 mr-2" />
                Members
              </Button>
              <Button variant="ghost" className="w-full justify-start" size="sm">
                <FileText className="w-4 h-4 mr-2" />
                Resources
              </Button>
              <Button variant="ghost" className="w-full justify-start" size="sm">
                <Brain className="w-4 h-4 mr-2" />
                Space Items
              </Button>
              <Button variant="ghost" className="w-full justify-start" size="sm">
                <Workflow className="w-4 h-4 mr-2" />
                Workflows
              </Button>
              <Button variant="ghost" className="w-full justify-start" size="sm">
                <AppWindow className="w-4 h-4 mr-2" />
                Apps
              </Button>
              <Button variant="ghost" className="w-full justify-start" size="sm">
                <GitBranch className="w-4 h-4 mr-2" />
                Workspaces
              </Button>
              <Button variant="ghost" className="w-full justify-start" size="sm">
                <Sparkles className="w-4 h-4 mr-2" />
                Events
              </Button>
            </nav>
          </ScrollArea>

          {/* User Profile */}
          <div className="p-4 border-t border-border/50">
            <div className="flex items-center gap-3">
              <Avatar>
                <AvatarImage src="/avatars/user.jpg" />
                <AvatarFallback>U</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <p className="text-sm font-medium">Your Name</p>
                <p className="text-xs text-muted-foreground">@username</p>
              </div>
              <Button variant="ghost" size="icon">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Bar */}
        <div className="h-16 border-b border-border/50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 flex items-center px-4">
          <div className="flex-1">
            <div className="relative w-96">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search community..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon">
              <Bell className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon">
              <Settings className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-auto">
          {children}
        </div>
      </div>
    </div>
  );
};

export default CommunityHubLayout; 