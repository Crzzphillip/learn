
import { Users, Bell, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";

const CommunityInfo = () => {
  return (
    <Card className="bg-card/70 backdrop-blur-sm border border-primary/10">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <Users className="w-5 h-5" />
          Community Info
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="text-sm font-medium mb-1">Community Leaders</div>
          <div className="flex -space-x-2">
            <Avatar className="border-2 border-background w-8 h-8">
              <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Alex" alt="Leader" />
            </Avatar>
            <Avatar className="border-2 border-background w-8 h-8">
              <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah" alt="Leader" />
            </Avatar>
            <Avatar className="border-2 border-background w-8 h-8">
              <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Michael" alt="Leader" />
            </Avatar>
          </div>
        </div>
        
        <div>
          <div className="text-sm font-medium mb-1">Announcements</div>
          <p className="text-sm text-muted-foreground">
            New AI challenge starting this week! Build an agent that can summarize research papers.
          </p>
        </div>

        <div>
          <div className="text-sm font-medium mb-1">Active Now</div>
          <div className="flex items-center gap-2">
            <div className="flex -space-x-2">
              <Avatar className="border-2 border-background w-6 h-6">
                <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=User1" alt="User" />
              </Avatar>
              <Avatar className="border-2 border-background w-6 h-6">
                <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=User2" alt="User" />
              </Avatar>
            </div>
            <span className="text-sm text-muted-foreground">+46 members</span>
          </div>
        </div>
        
        <Separator />
        
        <div className="flex flex-col gap-2">
          <Button variant="outline" size="sm" className="justify-start">
            <Bell className="w-4 h-4 mr-2" />
            Subscribe to Updates
          </Button>
          <Button variant="outline" size="sm" className="justify-start">
            <Share2 className="w-4 h-4 mr-2" />
            Share Community
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default CommunityInfo;
