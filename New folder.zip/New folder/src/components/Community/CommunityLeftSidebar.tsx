
import { Button } from "@/components/ui/button";
import CommunityInfo from "./CommunityInfo";
import SpaceCreditsManager from "@/components/Space/SpaceCreditsManager";
import { toast } from "sonner";
import { SpaceCredits } from "@/types/space";

interface SpaceHierarchyItem {
  id: string;
  title: string;
  children: SpaceHierarchyItem[];
}

interface CommunityLeftSidebarProps {
  spaceId?: string;
  spaceHierarchy: SpaceHierarchyItem[];
  credits: SpaceCredits;
}

const CommunityLeftSidebar = ({ 
  credits 
}: CommunityLeftSidebarProps) => {
  const handlePurchaseCredits = () => {
    toast.success('Opening credits purchase dialog');
  };
  
  const handleUpgradeSubscription = () => {
    toast.success('Opening subscription upgrade dialog');
  };

  return (
    <div className="col-span-3 space-y-6 sticky top-6 max-h-[calc(100vh-8rem)]">
      <CommunityInfo />
      
      <SpaceCreditsManager 
        credits={credits} 
        onPurchaseCredits={handlePurchaseCredits} 
        onUpgradeSubscription={handleUpgradeSubscription} 
      />
    </div>
  );
};

export default CommunityLeftSidebar;
