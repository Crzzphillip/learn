
import { LucideIcon, Users } from "lucide-react";
import { SpaceTemplate, SpaceType } from "@/types/space";

export const getDefaultCommunityTemplate = (): SpaceTemplate => {
  return {
    title: "AI Developer Community",
    description: "A collaborative space for AI developers to share knowledge, resources, and build together.",
    type: "community" as SpaceType,
    gradient: "from-blue-500/20 to-indigo-500/20",
    icon: Users,
    primaryColor: "blue",
    secondaryColor: "#1A1F2C",
    accentColor: "#9F8AC1"
  };
};

export default getDefaultCommunityTemplate;
