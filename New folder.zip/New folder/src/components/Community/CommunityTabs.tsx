
import { useState } from "react";
import { MessageSquare, Book, Trophy, Award, Star } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import DiscussionForum from "./DiscussionForum";
import ResourceSharing from "./ResourceSharing";
import CommunityChallenges from "./CommunityChallenges";
import AchievementsAndBadges from "./AchievementsAndBadges";
import CommunityReviews from "./CommunityReviews";

interface CommunityTabsProps {
  spaceId?: string;
  defaultTab?: string;
}

const CommunityTabs = ({ spaceId, defaultTab = "discussions" }: CommunityTabsProps) => {
  const [activeTab, setActiveTab] = useState(defaultTab);

  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="w-full grid grid-cols-5">
        <TabsTrigger value="discussions" className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4" />
          <span>Discussions</span>
        </TabsTrigger>
        <TabsTrigger value="resources" className="flex items-center gap-2">
          <Book className="w-4 h-4" />
          <span>Resources</span>
        </TabsTrigger>
        <TabsTrigger value="challenges" className="flex items-center gap-2">
          <Trophy className="w-4 h-4" />
          <span>Challenges</span>
        </TabsTrigger>
        <TabsTrigger value="achievements" className="flex items-center gap-2">
          <Award className="w-4 h-4" />
          <span>Achievements</span>
        </TabsTrigger>
        <TabsTrigger value="reviews" className="flex items-center gap-2">
          <Star className="w-4 h-4" />
          <span>Reviews</span>
        </TabsTrigger>
      </TabsList>
      
      <TabsContent value="discussions" className="mt-6">
        <DiscussionForum spaceId={spaceId} spaceName="AI Developer Forum" />
      </TabsContent>
      
      <TabsContent value="resources" className="mt-6">
        <ResourceSharing />
      </TabsContent>
      
      <TabsContent value="challenges" className="mt-6">
        <CommunityChallenges />
      </TabsContent>
      
      <TabsContent value="achievements" className="mt-6">
        <AchievementsAndBadges />
      </TabsContent>
      
      <TabsContent value="reviews" className="mt-6">
        <CommunityReviews />
      </TabsContent>
    </Tabs>
  );
};

export default CommunityTabs;
