
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Award, Star, Code, BookOpen, MessageSquare, Heart, PenTool } from "lucide-react";
import { cn } from "@/lib/utils";

const achievements = [
  {
    id: "achievement-1",
    title: "Prolific Contributor",
    description: "Make 50 contributions to the community",
    icon: PenTool,
    progress: 76,
    maxProgress: 100,
    achieved: false,
    categories: ["contribution"]
  },
  {
    id: "achievement-2",
    title: "Code Master",
    description: "Share 10 code snippets that get at least 5 likes",
    icon: Code,
    progress: 8,
    maxProgress: 10,
    achieved: false,
    categories: ["coding"]
  },
  {
    id: "achievement-3",
    title: "Community Pillar",
    description: "Participate in community discussions for 30 days straight",
    icon: MessageSquare,
    progress: 30,
    maxProgress: 30,
    achieved: true,
    categories: ["community"]
  },
  {
    id: "achievement-4",
    title: "Knowledge Sharer",
    description: "Create and share 5 educational resources",
    icon: BookOpen,
    progress: 3,
    maxProgress: 5,
    achieved: false,
    categories: ["education"]
  },
  {
    id: "achievement-5",
    title: "Rising Star",
    description: "Receive 100 likes on your contributions",
    icon: Star,
    progress: 82,
    maxProgress: 100,
    achieved: false,
    categories: ["recognition"]
  },
  {
    id: "achievement-6",
    title: "Helping Hand",
    description: "Answer 20 community questions",
    icon: Heart,
    progress: 20,
    maxProgress: 20,
    achieved: true,
    categories: ["community", "contribution"]
  }
];

const badges = [
  {
    id: "badge-1",
    name: "Community Pillar",
    description: "A cornerstone of our community",
    icon: Award,
    color: "text-amber-500 bg-amber-500/10",
    earned: true
  },
  {
    id: "badge-2",
    name: "Helping Hand",
    description: "Always ready to assist others",
    icon: Heart,
    color: "text-red-500 bg-red-500/10",
    earned: true
  },
  {
    id: "badge-3",
    name: "Code Master",
    description: "Expert in crafting efficient code",
    icon: Code,
    color: "text-blue-500 bg-blue-500/10",
    earned: false
  },
  {
    id: "badge-4",
    name: "Rising Star",
    description: "A rapidly growing community presence",
    icon: Star,
    color: "text-purple-500 bg-purple-500/10",
    earned: false
  },
  {
    id: "badge-5",
    name: "Knowledge Sharer",
    description: "Dedicated to sharing wisdom with others",
    icon: BookOpen,
    color: "text-emerald-500 bg-emerald-500/10",
    earned: false
  }
];

const AchievementsAndBadges = () => {
  const [filter, setFilter] = useState<string>("all");
  
  const filteredAchievements = filter === "all" 
    ? achievements 
    : achievements.filter(a => a.categories.includes(filter));
  
  const earnedBadges = badges.filter(badge => badge.earned);
  const unearnedBadges = badges.filter(badge => !badge.earned);

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold mb-6">Your Achievements</h2>
        <div className="flex flex-wrap gap-2 mb-6">
          <button 
            className={`px-3 py-1 rounded-full text-sm ${filter === "all" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
            onClick={() => setFilter("all")}
          >
            All
          </button>
          {["contribution", "coding", "community", "education", "recognition"].map(category => (
            <button
              key={category}
              className={`px-3 py-1 rounded-full text-sm capitalize ${filter === category ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
              onClick={() => setFilter(category)}
            >
              {category}
            </button>
          ))}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredAchievements.map((achievement) => (
            <Card 
              key={achievement.id} 
              className={cn(
                "border-primary/10 backdrop-blur-sm",
                achievement.achieved ? "bg-primary/5" : "bg-card/50"
              )}
            >
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg ${achievement.achieved ? "bg-primary/20" : "bg-muted"} flex items-center justify-center`}>
                      <achievement.icon className={`w-5 h-5 ${achievement.achieved ? "text-primary" : "text-muted-foreground"}`} />
                    </div>
                    <div>
                      <CardTitle className="text-base font-medium">
                        {achievement.title}
                        {achievement.achieved && <Award className="w-4 h-4 text-amber-500 ml-2 inline" />}
                      </CardTitle>
                      <CardDescription>{achievement.description}</CardDescription>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>{achievement.achieved ? "Completed!" : "In progress"}</span>
                    <span>{achievement.progress}/{achievement.maxProgress}</span>
                  </div>
                  <Progress 
                    value={(achievement.progress / achievement.maxProgress) * 100} 
                    className={`h-2 ${achievement.achieved ? "bg-primary/20" : ""}`} 
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
      
      <div>
        <h2 className="text-2xl font-semibold mb-6">Your Badges</h2>
        <h3 className="text-lg font-medium mb-3">Earned Badges</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 mb-8">
          {earnedBadges.map((badge) => (
            <div key={badge.id} className="flex flex-col items-center text-center">
              <div className={`w-16 h-16 rounded-full ${badge.color} flex items-center justify-center mb-2`}>
                <badge.icon className="w-8 h-8" />
              </div>
              <h4 className="font-medium text-sm">{badge.name}</h4>
              <p className="text-xs text-muted-foreground">{badge.description}</p>
            </div>
          ))}
        </div>
        
        <h3 className="text-lg font-medium mb-3">Badges to Earn</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 opacity-60">
          {unearnedBadges.map((badge) => (
            <div key={badge.id} className="flex flex-col items-center text-center">
              <div className={`w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-2`}>
                <badge.icon className="w-8 h-8 text-muted-foreground" />
              </div>
              <h4 className="font-medium text-sm">{badge.name}</h4>
              <p className="text-xs text-muted-foreground">{badge.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AchievementsAndBadges;
