
import { useState } from "react";
import { Star, MessageSquare, ThumbsUp, Calendar, User, Filter, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

const reviews = [
  {
    id: "review-1",
    title: "An incredible learning experience",
    content: "This space has been transformational for my AI development skills. The resources are comprehensive and up-to-date, and the community is incredibly supportive.",
    rating: 5,
    likes: 24,
    comments: 3,
    date: "2024-03-15",
    user: {
      name: "Alex Rivera",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alex",
      title: "Software Engineer"
    },
    tags: ["learning", "community", "resources"]
  },
  {
    id: "review-2",
    title: "Great for beginners, still growing",
    content: "As someone new to AI development, I found this space very approachable. The tutorials are well-structured and the agents are powerful. There are still some features in development, but overall it's a great platform.",
    rating: 4,
    likes: 18,
    comments: 5,
    date: "2024-03-10",
    user: {
      name: "Emma Wilson",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Emma",
      title: "Data Scientist"
    },
    tags: ["beginner-friendly", "tutorials", "improvements"]
  },
  {
    id: "review-3",
    title: "Powerful tooling, complex learning curve",
    content: "The advanced features in this space are impressive, especially the custom agent development tools. However, the learning curve can be steep for new users. Once you get past the initial complexity, it's an incredibly powerful platform.",
    rating: 4,
    likes: 32,
    comments: 7,
    date: "2024-03-05",
    user: {
      name: "Michael Chen",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Michael",
      title: "AI Researcher"
    },
    tags: ["advanced", "tooling", "learning-curve"]
  }
];

const CommunityReviews = () => {
  const [allReviews, setAllReviews] = useState(reviews);
  const [searchQuery, setSearchQuery] = useState("");
  const [newReview, setNewReview] = useState({
    title: "",
    content: "",
    rating: 5
  });
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleAddReview = () => {
    if (!newReview.title || !newReview.content) {
      toast.error("Please provide both a title and content for your review");
      return;
    }

    const review = {
      id: `review-${Date.now()}`,
      ...newReview,
      likes: 0,
      comments: 0,
      date: new Date().toISOString().split("T")[0],
      user: {
        name: "Current User",
        avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=CurrentUser",
        title: "Community Member"
      },
      tags: ["user-review"]
    };

    setAllReviews([review, ...allReviews]);
    setNewReview({ title: "", content: "", rating: 5 });
    setIsDialogOpen(false);
    toast.success("Your review has been added");
  };

  // Filter reviews based on search query
  const filteredReviews = searchQuery
    ? allReviews.filter(
        review =>
          review.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          review.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
          review.user.name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : allReviews;

  // Calculate the average rating
  const averageRating = allReviews.reduce((acc, review) => acc + review.rating, 0) / allReviews.length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold">Community Reviews</h2>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add Review
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Share your experience</DialogTitle>
                <DialogDescription>
                  Your review helps others understand what to expect from this community.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="rating" className="text-right">
                    Rating
                  </Label>
                  <div className="col-span-3 flex items-center">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        className="focus:outline-none"
                        onClick={() => setNewReview({ ...newReview, rating: star })}
                      >
                        <Star
                          className={`w-5 h-5 ${
                            star <= newReview.rating
                              ? "text-yellow-500 fill-yellow-500"
                              : "text-muted-foreground"
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="title" className="text-right">
                    Title
                  </Label>
                  <Input
                    id="title"
                    value={newReview.title}
                    onChange={(e) => setNewReview({ ...newReview, title: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="content" className="text-right">
                    Review
                  </Label>
                  <Textarea
                    id="content"
                    value={newReview.content}
                    onChange={(e) => setNewReview({ ...newReview, content: e.target.value })}
                    className="col-span-3"
                    rows={5}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddReview}>Submit Review</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <div className="relative mb-6">
            <Input
              placeholder="Search reviews..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
            <SearchIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          </div>

          <div className="space-y-4">
            {filteredReviews.length > 0 ? (
              filteredReviews.map((review) => (
                <Card key={review.id} className="border-primary/10 bg-card/50 backdrop-blur-sm hover:bg-card/80 transition-colors">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10 border border-primary/10">
                          <AvatarImage src={review.user.avatar} alt={review.user.name} />
                          <AvatarFallback>
                            <User className="h-5 w-5" />
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">{review.user.name}</div>
                          <div className="text-sm text-muted-foreground">{review.user.title}</div>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star
                              key={star}
                              className={`w-4 h-4 ${
                                star <= review.rating
                                  ? "text-yellow-500 fill-yellow-500"
                                  : "text-muted-foreground"
                              }`}
                            />
                          ))}
                        </div>
                        <div className="text-sm text-muted-foreground ml-2 flex items-center">
                          <Calendar className="w-3.5 h-3.5 mr-1" />
                          {review.date}
                        </div>
                      </div>
                    </div>
                    <CardTitle className="text-lg mt-2">{review.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{review.content}</p>
                    <div className="flex flex-wrap gap-2 mt-3">
                      {review.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="bg-primary/10 border-none">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                  <div className="px-6 py-3 border-t border-border/30 flex items-center gap-4">
                    <button className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors">
                      <ThumbsUp className="h-3.5 w-3.5" />
                      {review.likes}
                    </button>
                    <button className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors">
                      <MessageSquare className="h-3.5 w-3.5" />
                      {review.comments}
                    </button>
                  </div>
                </Card>
              ))
            ) : (
              <Card className="border-primary/10 bg-card/50 p-8 text-center">
                <p className="text-muted-foreground">No reviews found matching your search.</p>
              </Card>
            )}
          </div>
        </div>

        <div>
          <Card className="border-primary/10 bg-card/50 backdrop-blur-sm sticky top-4">
            <CardHeader>
              <CardTitle>Community Rating</CardTitle>
              <CardDescription>Based on {allReviews.length} reviews</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center mb-4">
                <div className="text-5xl font-bold mr-2">{averageRating.toFixed(1)}</div>
                <div className="flex flex-col">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`w-5 h-5 ${
                          star <= Math.round(averageRating)
                            ? "text-yellow-500 fill-yellow-500"
                            : "text-muted-foreground"
                        }`}
                      />
                    ))}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    {allReviews.length} reviews
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                {[5, 4, 3, 2, 1].map((rating) => {
                  const count = allReviews.filter((r) => r.rating === rating).length;
                  const percentage = (count / allReviews.length) * 100;
                  return (
                    <div key={rating} className="flex items-center gap-2">
                      <div className="w-6 text-sm text-muted-foreground">{rating}</div>
                      <div className="w-7">
                        <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                      </div>
                      <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-yellow-500 rounded-full"
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                      <div className="w-8 text-sm text-muted-foreground">{count}</div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

const SearchIcon = MessageSquare;

export default CommunityReviews;
