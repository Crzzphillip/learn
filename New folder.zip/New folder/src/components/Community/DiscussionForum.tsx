
import { useState, useEffect } from "react";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { MessageSquare, ThumbsUp, Reply, Flag, Bookmark, Filter } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { dummyDatabase, ForumPost } from "@/services/dummyDatabase";

interface DiscussionForumProps {
  spaceId?: string;
  spaceName?: string;
}

const DiscussionForum = ({ spaceId, spaceName = "Community Forum" }: DiscussionForumProps) => {
  const [newPostContent, setNewPostContent] = useState("");
  const [posts, setPosts] = useState<ForumPost[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        setIsLoading(true);
        const fetchedPosts = await dummyDatabase.getPosts();
        setPosts(fetchedPosts);
      } catch (error) {
        console.error("Error fetching posts:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchPosts();
  }, [spaceId]);

  const handlePostSubmit = async () => {
    if (!newPostContent.trim()) return;
    
    try {
      const newPost = await dummyDatabase.addPost(newPostContent);
      setPosts([newPost, ...posts]);
      setNewPostContent("");
    } catch (error) {
      console.error("Error adding post:", error);
    }
  };

  const toggleLike = async (postId: string) => {
    try {
      await dummyDatabase.toggleLike(postId);
      const updatedPosts = await dummyDatabase.getPosts();
      setPosts(updatedPosts);
    } catch (error) {
      console.error("Error toggling like:", error);
    }
  };

  const toggleBookmark = async (postId: string) => {
    try {
      await dummyDatabase.toggleBookmark(postId);
      const updatedPosts = await dummyDatabase.getPosts();
      setPosts(updatedPosts);
    } catch (error) {
      console.error("Error toggling bookmark:", error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold">{spaceName}</h2>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          <Button>
            <MessageSquare className="w-4 h-4 mr-2" />
            New Post
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">All Discussions</TabsTrigger>
          <TabsTrigger value="popular">Most Popular</TabsTrigger>
          <TabsTrigger value="recent">Recent Activity</TabsTrigger>
          <TabsTrigger value="unanswered">Unanswered</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="mt-4">
          <div className="bg-card p-4 rounded-xl mb-6">
            <Textarea 
              value={newPostContent}
              onChange={(e) => setNewPostContent(e.target.value)}
              placeholder="Start a new discussion..."
              className="mb-3 min-h-24"
            />
            <div className="flex justify-end">
              <Button onClick={handlePostSubmit} disabled={!newPostContent.trim()}>
                Post Discussion
              </Button>
            </div>
          </div>

          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-card rounded-xl p-4 animate-pulse h-48" />
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {posts.map((post) => (
                <div key={post.id} className="bg-card rounded-xl p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-10 h-10 border border-primary/10">
                        <img src={post.author.avatar} alt={post.author.name} />
                      </Avatar>
                      <div>
                        <div className="font-medium">
                          {post.author.name}
                          {post.author.role === "Official" && (
                            <Badge variant="default" className="ml-2">
                              {post.author.role}
                            </Badge>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground">{post.timestamp}</div>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Flag className="w-4 h-4" />
                    </Button>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">{post.title}</h3>
                    <p className="text-muted-foreground">{post.content}</p>
                  </div>

                  <div className="flex flex-wrap gap-2 pt-2">
                    {post.tags.map((tag) => (
                      <Badge key={tag} variant="secondary">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-border/30">
                    <div className="flex gap-4">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => toggleLike(post.id)}
                        className={post.isLiked ? "text-primary" : ""}
                      >
                        <ThumbsUp className={`w-4 h-4 mr-1 ${post.isLiked ? "fill-primary" : ""}`} />
                        {post.likes}
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Reply className="w-4 h-4 mr-1" />
                        {post.replies}
                      </Button>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => toggleBookmark(post.id)}
                      className={post.isBookmarked ? "text-primary" : ""}
                    >
                      <Bookmark className={`w-4 h-4 ${post.isBookmarked ? "fill-primary" : ""}`} />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="popular" className="mt-4">
          <div className="bg-card p-6 rounded-xl text-center">
            <p className="text-muted-foreground">Showing most popular discussions...</p>
          </div>
        </TabsContent>
        
        <TabsContent value="recent" className="mt-4">
          <div className="bg-card p-6 rounded-xl text-center">
            <p className="text-muted-foreground">Showing recently active discussions...</p>
          </div>
        </TabsContent>
        
        <TabsContent value="unanswered" className="mt-4">
          <div className="bg-card p-6 rounded-xl text-center">
            <p className="text-muted-foreground">Showing unanswered discussions...</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DiscussionForum;
