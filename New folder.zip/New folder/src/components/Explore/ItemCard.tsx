
import React from "react";
import { ChevronRight, Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";

interface ItemCardProps {
  item: any;
  type: string;
  viewMode: "grid" | "list";
}

const ItemCard = ({ item, type, viewMode }: ItemCardProps) => {
  const navigate = useNavigate();
  const { title, description, category, rating, listens, tags } = item;
  const Icon = item.icon;

  const handleItemClick = () => {
    // Navigate based on the item type
    switch (type) {
      case "agents":
        navigate(`/agent/${item.id}`);
        break;
      case "personas":
        navigate(`/persona/${item.id}`);
        break;
      case "spaces":
        navigate(`/space/${item.id}`);
        break;
      case "workspaces":
        navigate(`/workspace/${item.id}`);
        break;
      case "workflows":
        navigate(`/workflow/${item.id}`);
        break;
      case "apps":
        navigate(`/app/${item.id}`);
        break;
      default:
        // Default fallback
        navigate(`/${type}/${item.id}`);
    }
  };

  return (
    <Card
      className={`h-full bg-card/50 border-primary/10 hover:border-primary/30 hover:shadow-md transition-all duration-300 cursor-pointer overflow-hidden ${
        viewMode === "list" ? "flex" : ""
      }`}
      onClick={handleItemClick}
    >
      <CardContent className={`p-0 ${viewMode === "list" ? "flex flex-1" : ""}`}>
        {viewMode === "grid" ? (
          // Grid view layout
          <div>
            <div className="relative h-48 bg-black/20">
              {item.image && (
                <img
                  src={item.image}
                  alt={title}
                  className="w-full h-full object-cover"
                />
              )}
              <div className="absolute top-4 left-4 bg-black/50 backdrop-blur-sm text-white text-xs px-2 py-1 rounded-full flex items-center">
                <Star className="w-3 h-3 mr-1 text-yellow-400" />
                {rating}
              </div>
              {category && (
                <div className="absolute top-4 right-4 bg-primary/20 backdrop-blur-sm text-primary text-xs px-2 py-1 rounded-full">
                  {category}
                </div>
              )}
            </div>

            <div className="p-6">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    {Icon && <Icon className="h-5 w-5 text-primary" />}
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">{title}</h3>
                    <div className="text-xs text-muted-foreground">
                      {listens} {parseInt(listens) > 1 ? "users" : "user"}
                    </div>
                  </div>
                </div>
              </div>

              <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                {description}
              </p>

              {tags && tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-auto">
                  {tags.slice(0, 3).map((tag: string, index: number) => (
                    <span
                      key={index}
                      className="text-xs px-2 py-1 rounded-full bg-black/20 border border-primary/10"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : (
          // List view layout
          <div className="flex w-full">
            <div className="w-48 h-36 bg-black/20 flex-shrink-0">
              {item.image && (
                <img
                  src={item.image}
                  alt={title}
                  className="w-full h-full object-cover"
                />
              )}
            </div>

            <div className="p-6 flex flex-col justify-between flex-1">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                    {Icon && <Icon className="h-4 w-4 text-primary" />}
                  </div>
                  <div>
                    <h3 className="font-semibold">{title}</h3>
                    <div className="flex items-center gap-2">
                      <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary">
                        {category}
                      </span>
                      <div className="flex items-center text-xs text-muted-foreground">
                        <Star className="w-3 h-3 mr-1 text-yellow-400" />
                        {rating}
                      </div>
                    </div>
                  </div>
                </div>

                <p className="text-sm text-muted-foreground mb-4">
                  {description}
                </p>
              </div>

              <div className="flex items-center justify-between">
                <div className="text-xs text-muted-foreground">
                  {listens} {parseInt(listens) > 1 ? "users" : "user"}
                </div>
                
                {tags && tags.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {tags.slice(0, 2).map((tag: string, index: number) => (
                      <span
                        key={index}
                        className="text-xs px-2 py-1 rounded-full bg-black/20 border border-primary/10"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
                
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ItemCard;
