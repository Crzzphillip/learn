
import React from "react";

export interface SearchHeaderProps {
  title: string;
  subtitle: string;
}

const SearchHeader = ({ title, subtitle }: SearchHeaderProps) => {
  return (
    <div className="bg-gradient-to-b from-primary/30 to-background/80 py-12">
      <div className="container">
        <h1 className="text-4xl font-bold mb-2">{title}</h1>
        <p className="text-lg text-muted-foreground">{subtitle}</p>
      </div>
    </div>
  );
};

export default SearchHeader;
