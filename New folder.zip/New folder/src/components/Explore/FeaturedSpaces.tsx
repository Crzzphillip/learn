
import { useNavigate } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FeaturedSpace } from "@/types/explore";

interface FeaturedSpacesProps {
  spaces: FeaturedSpace[];
}

const FeaturedSpaces = ({ spaces }: FeaturedSpacesProps) => {
  const navigate = useNavigate();

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-semibold mb-2">Featured Spaces</h2>
          <p className="text-muted-foreground">Explore trending collaborative environments</p>
        </div>
        <Button variant="outline" size="lg" className="gap-2">
          View All <ArrowRight className="w-4 h-4" />
        </Button>
      </div>
      <div className="grid grid-cols-2 gap-6">
        {spaces.map(space => (
          <div 
            key={space.id} 
            onClick={() => navigate(`/space/${space.id}`)} 
            className="group flex rounded-xl overflow-hidden bg-card/50 border border-primary/10 hover:bg-card/70 transition-all duration-300 cursor-pointer"
          >
            <div className="w-1/3 relative">
              <img 
                src={space.image} 
                alt={space.title}
                className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/30 to-transparent" />
              <div className="absolute bottom-4 left-4 w-12 h-12 rounded-lg bg-primary/20 grid place-items-center backdrop-blur-sm">
                <space.icon className="w-6 h-6 text-primary" />
              </div>
            </div>
            <div className="w-2/3 p-6">
              <h3 className="text-xl font-semibold mb-2">{space.title}</h3>
              <p className="text-sm text-muted-foreground mb-4">{space.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-sm px-2.5 py-1 rounded-full bg-primary/20 text-primary">
                  {space.category}
                </span>
                <div className="flex items-center gap-1">
                  <span className="text-sm text-muted-foreground">{space.listens} users</span>
                  <span className="mx-1">•</span>
                  <span className="text-sm font-medium text-white/80">★ {space.rating}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FeaturedSpaces;
