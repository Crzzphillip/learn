
import { useNavigate } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { PopularAgent } from "@/services/exploreService";

interface PopularAgentsProps {
  agents: PopularAgent[];
}

const PopularAgents = ({ agents }: PopularAgentsProps) => {
  const navigate = useNavigate();

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-semibold mb-2">Popular AI Agents</h2>
          <p className="text-muted-foreground">Discover top-performing AI assistants</p>
        </div>
        <Button 
          variant="outline" 
          size="lg" 
          className="gap-2"
          onClick={() => navigate('/explore/agents')}
        >
          View All <ArrowRight className="w-4 h-4" />
        </Button>
      </div>
      <div className="grid grid-cols-3 gap-6">
        {agents.map(agent => (
          <div 
            key={agent.id} 
            onClick={() => navigate(`/agent/${agent.id}`)} 
            className="group relative overflow-hidden rounded-xl bg-card/50 border border-primary/10 hover:bg-card/70 transition-all duration-300 p-6 cursor-pointer"
          >
            <div className="flex gap-4 items-start mb-6">
              <Avatar className="w-16 h-16 rounded-xl ring-2 ring-primary/20">
                <AvatarImage src={agent.avatar} alt={agent.name} />
                <AvatarFallback>{agent.name[0]}</AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-semibold text-lg mb-1">{agent.name}</h3>
                <span className="text-sm px-2.5 py-1 rounded-full bg-primary/20 text-primary">
                  {agent.category}
                </span>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">{agent.posts}</p>
            <div className="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-primary/40 to-primary opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        ))}
      </div>
    </div>
  );
};

export default PopularAgents;
