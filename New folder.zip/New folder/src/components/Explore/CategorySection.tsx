import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { ArrowRight, Code } from "lucide-react";
import { Button } from "@/components/ui/button";
import * as LucideIcons from "lucide-react";
import { Category, CategorySpace } from "@/types/explore";

interface CategorySectionProps {
  category: Category;
  lastItemRef?: React.RefObject<HTMLDivElement>;
}

const CategorySection = ({ category, lastItemRef }: CategorySectionProps) => {
  const navigate = useNavigate();
  const [isHovering, setIsHovering] = useState(false);

  // Helper function to dynamically get the Lucide icon component
  const getIconComponent = (icon: string | React.ComponentType | undefined) => {
    if (!icon) return Code;
    if (typeof icon === 'string') {
      // @ts-ignore - dynamic icon lookup
      return LucideIcons[icon] || Code;
    }
    return icon;
  };

  const handleExploreCategory = () => {
    navigate(`/explore/spaces?category=${category.id}`);
  };

  const CategoryIcon = getIconComponent(category?.icon);

  return (
    <div ref={lastItemRef}>
      {/* Category Banner */}
      <div 
        className="relative h-[200px] rounded-xl overflow-hidden mb-8 bg-black"
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={() => setIsHovering(false)}
      >
        <img 
          src={category?.image} 
          alt={category?.title}
          className="w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-black/50 to-transparent" />
        <div className="absolute inset-0 flex items-center">
          <div className="container">
            <div className="max-w-2xl">
              <div className="flex items-center gap-4 mb-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${category?.gradient || 'from-primary/20 to-primary/40'} grid place-items-center`}>
                  <CategoryIcon className="w-6 h-6" />
                </div>
                <h2 className="text-3xl font-bold">{category?.title}</h2>
              </div>
              <p className="text-lg text-white/80">{category?.description}</p>
            </div>
          </div>
        </div>
        
        {/* Hover button */}
        <div className={`absolute bottom-4 right-4 transition-opacity duration-300 ${isHovering ? 'opacity-100' : 'opacity-0'}`}>
          <Button 
            onClick={handleExploreCategory}
            className="bg-primary hover:bg-primary/90 flex items-center gap-2"
          >
            Explore {category?.title} <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Category Spaces */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {category?.spaces?.map(space => {
          const SpaceIcon = getIconComponent(space?.icon);
          return (
            <div 
              key={space?.id}
              onClick={() => navigate(`/space/${space?.id}`)}
              className="group relative overflow-hidden rounded-xl bg-card/50 border border-primary/10 hover:bg-card/70 transition-all duration-300 p-6 cursor-pointer"
            >
              <div className="relative w-full h-32 rounded-lg overflow-hidden mb-6">
                <img 
                  src={space?.image} 
                  alt={space?.title} 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent" />
              </div>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-lg bg-primary/20 grid place-items-center">
                  <SpaceIcon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold text-lg">{space?.title}</h3>
              </div>
              <p className="text-sm text-muted-foreground mb-4">{space?.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-sm px-2.5 py-1 rounded-full bg-primary/20 text-primary">
                  {space?.category}
                </span>
                <div className="flex items-center gap-2">
                  <p className="text-sm text-muted-foreground">{space?.listens} users</p>
                  <div className="px-2.5 py-1 rounded-full bg-primary/20 text-primary">
                    <span className="text-sm font-medium">★ {space?.rating}</span>
                  </div>
                </div>
              </div>
              <div className="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-primary/40 to-primary opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          )
        })}
      </div>
    </div>
  );
};

export default CategorySection;
