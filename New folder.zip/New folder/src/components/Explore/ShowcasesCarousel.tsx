
import { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Showcase } from '@/types/explore';
import { Button } from '@/components/ui/button';
import { showcasesService } from '@/services/showcasesService';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

export const ShowcasesCarousel = () => {
  const navigate = useNavigate();
  const [showcases, setShowcases] = useState<Showcase[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const carouselRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchShowcases = async () => {
      try {
        setIsLoading(true);
        const data = await showcasesService.getAllShowcases();
        setShowcases(data);
      } catch (error) {
        console.error("Error fetching showcases:", error);
        toast.error("Failed to load showcases");
      } finally {
        setIsLoading(false);
      }
    };

    fetchShowcases();
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (!carouselRef.current) return;
    
    const { scrollLeft, clientWidth } = carouselRef.current;
    const scrollTo = direction === 'left' 
      ? scrollLeft - clientWidth * 0.8 
      : scrollLeft + clientWidth * 0.8;
    
    carouselRef.current.scrollTo({
      left: scrollTo,
      behavior: 'smooth'
    });
  };

  const handleSeeAllClick = () => {
    navigate('/showcases');
  };

  if (isLoading) {
    return (
      <div className="bg-card/50 border-none p-6 rounded-xl mb-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Featured Showcases</h2>
        </div>
        <div className="flex gap-4 overflow-hidden">
          {[1, 2, 3].map((i) => (
            <div key={i} className="min-w-[300px] h-[400px] rounded-xl bg-card/40 animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card/50 border-none p-6 rounded-xl mb-12">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Featured Showcases</h2>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="icon" 
            onClick={() => scroll('left')}
            aria-label="Scroll left"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="icon" 
            onClick={() => scroll('right')}
            aria-label="Scroll right"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Button variant="outline" className="ml-2" onClick={handleSeeAllClick}>
            See all showcases
          </Button>
        </div>
      </div>

      <div 
        ref={carouselRef}
        className="flex gap-4 overflow-x-auto scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent pb-4"
        style={{ scrollbarWidth: 'thin' }}
      >
        {showcases.map((showcase) => (
          <div 
            key={showcase.id} 
            className="min-w-[360px] flex-shrink-0 rounded-xl overflow-hidden bg-black/20 border border-white/5 transition-all hover:border-primary/30 duration-300 cursor-pointer"
            onClick={() => navigate(`/showcases`)}
          >
            <div className="relative h-[200px] overflow-hidden">
              <img
                src={showcase.image}
                alt={showcase.title}
                className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
              />
              <div className="absolute top-4 left-4 bg-black/60 text-xs font-medium px-2.5 py-1 rounded-full backdrop-blur-sm">
                {showcase.category}
              </div>
              {showcase.type && (
                <div className="absolute top-4 right-4 bg-primary/20 text-primary text-xs font-medium px-2.5 py-1 rounded-full backdrop-blur-sm">
                  {showcase.type.toUpperCase()}
                </div>
              )}
            </div>
            <div className="p-5">
              <h3 className="text-xl font-semibold mb-4">{showcase.title}</h3>
              <div className="space-y-2">
                {showcase.features.map((feature, index) => (
                  <div key={index} className="bg-black/20 px-3 py-2 rounded-lg text-sm">
                    {feature}
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ShowcasesCarousel;
