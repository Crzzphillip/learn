
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Carousel, CarouselContent, CarouselItem } from "@/components/ui/carousel";
import * as LucideIcons from "lucide-react";
import { FeaturedSpace as TypedFeaturedSpace } from "@/types/explore";

interface FeaturedWorkspacesProps {
  workspaces: TypedFeaturedSpace[];
}

const FeaturedWorkspaces = ({ workspaces }: FeaturedWorkspacesProps) => {
  const navigate = useNavigate();
  const [api, setApi] = useState<any>(null);

  useEffect(() => {
    if (!api) return;

    const interval = setInterval(() => {
      api.scrollNext();
    }, 5000);

    return () => clearInterval(interval);
  }, [api]);

  // Helper function to dynamically get the Lucide icon component
  const getIconComponent = (icon: any) => {
    if (typeof icon === 'string') {
      // @ts-ignore - dynamic icon lookup
      return LucideIcons[icon] || LucideIcons.Code;
    }
    return icon;
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-semibold mb-2">Featured AI Workspaces</h2>
          <p className="text-muted-foreground">Explore trending collaborative environments</p>
        </div>
        <Button 
          variant="outline" 
          size="lg" 
          className="gap-2"
          onClick={() => navigate('/explore/workspaces')}
        >
          View All <ArrowRight className="w-4 h-4" />
        </Button>
      </div>
      <Carousel
        opts={{
          align: "start",
          loop: true,
        }}
        setApi={setApi}
        className="w-full"
      >
        <CarouselContent>
          {workspaces.map((workspace) => {
            const Icon = getIconComponent(workspace.icon);
            return (
              <CarouselItem key={workspace.id} className="md:basis-1/2 lg:basis-1/2">
                <div 
                  onClick={() => navigate(`/workspace/${workspace.id}`)}
                  className="group flex rounded-xl overflow-hidden bg-card/50 border border-primary/10 hover:bg-card/70 transition-all duration-300 cursor-pointer mx-3"
                >
                  <div className="w-1/3 relative">
                    <img 
                      src={workspace.image} 
                      alt={workspace.title}
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-black/30 to-transparent" />
                    <div className="absolute bottom-4 left-4 w-12 h-12 rounded-lg bg-primary/20 grid place-items-center backdrop-blur-sm">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                  </div>
                  <div className="w-2/3 p-6">
                    <h3 className="text-xl font-semibold mb-2">{workspace.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{workspace.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-sm px-2.5 py-1 rounded-full bg-primary/20 text-primary">
                        {workspace.category}
                      </span>
                      <div className="flex items-center gap-1">
                        <span className="text-sm text-muted-foreground">{workspace.listens} users</span>
                        <span className="mx-1">•</span>
                        <span className="text-sm font-medium text-white/80">★ {workspace.rating}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CarouselItem>
            );
          })}
        </CarouselContent>
      </Carousel>
    </div>
  );
};

export default FeaturedWorkspaces;
