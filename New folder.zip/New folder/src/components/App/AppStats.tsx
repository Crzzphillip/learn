
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from "recharts";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Download, Users, Star, Repeat, Activity } from "lucide-react";
import { useState } from "react";

interface AppStatsProps {
  app: any;
  className?: string;
}

const usageData = [
  { date: "Jan", users: 120, sessions: 345 },
  { date: "Feb", users: 168, sessions: 389 },
  { date: "Mar", users: 245, sessions: 462 },
  { date: "Apr", users: 350, sessions: 578 },
  { date: "May", users: 426, sessions: 689 },
  { date: "Jun", users: 529, sessions: 721 },
  { date: "Jul", users: 632, sessions: 846 }
];

const feedbackData = [
  { date: "Jan", rating: 4.2 },
  { date: "Feb", rating: 4.3 },
  { date: "Mar", rating: 4.1 },
  { date: "Apr", rating: 4.4 },
  { date: "May", rating: 4.6 },
  { date: "Jun", rating: 4.7 },
  { date: "Jul", rating: 4.8 }
];

const AppStats = ({ app, className = "" }: AppStatsProps) => {
  const [activeTab, setActiveTab] = useState("usage");

  return (
    <Card className={`glass-panel border-primary/10 ${className}`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">App Analytics</CardTitle>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Activity className="w-4 h-4" />
            <span>Last updated: 2 hours ago</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-4 gap-4 mb-6">
          <div className="p-4 rounded-lg bg-secondary/10">
            <div className="flex items-center gap-2 mb-2">
              <Download className="w-5 h-5 text-blue-400" />
              <span className="text-sm font-medium">Installs</span>
            </div>
            <div className="text-2xl font-bold">{app?.installs || "2,548"}</div>
            <div className="text-xs text-green-400">↑ 12% this month</div>
          </div>
          
          <div className="p-4 rounded-lg bg-secondary/10">
            <div className="flex items-center gap-2 mb-2">
              <Users className="w-5 h-5 text-purple-400" />
              <span className="text-sm font-medium">Active Users</span>
            </div>
            <div className="text-2xl font-bold">{app?.activeUsers || "1,243"}</div>
            <div className="text-xs text-green-400">↑ 8% this month</div>
          </div>
          
          <div className="p-4 rounded-lg bg-secondary/10">
            <div className="flex items-center gap-2 mb-2">
              <Star className="w-5 h-5 text-amber-400" />
              <span className="text-sm font-medium">Rating</span>
            </div>
            <div className="text-2xl font-bold">{app?.rating || "4.8"}</div>
            <div className="text-xs text-green-400">↑ 0.2 this month</div>
          </div>
          
          <div className="p-4 rounded-lg bg-secondary/10">
            <div className="flex items-center gap-2 mb-2">
              <Repeat className="w-5 h-5 text-green-400" />
              <span className="text-sm font-medium">Retention</span>
            </div>
            <div className="text-2xl font-bold">{app?.retention || "72%"}</div>
            <div className="text-xs text-green-400">↑ 5% this month</div>
          </div>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="usage">Usage Analytics</TabsTrigger>
            <TabsTrigger value="feedback">User Feedback</TabsTrigger>
          </TabsList>
          
          <TabsContent value="usage" className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={usageData} margin={{ top: 10, right: 30, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="date" stroke="rgba(255,255,255,0.5)" />
                <YAxis stroke="rgba(255,255,255,0.5)" />
                <Tooltip
                  contentStyle={{ backgroundColor: 'rgba(0,0,0,0.8)', border: '1px solid rgba(255,255,255,0.2)' }}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="users" 
                  name="Active Users" 
                  stroke="#8884d8" 
                  strokeWidth={2}
                  activeDot={{ r: 8 }} 
                />
                <Line 
                  type="monotone" 
                  dataKey="sessions" 
                  name="Sessions" 
                  stroke="#82ca9d" 
                  strokeWidth={2} 
                />
              </LineChart>
            </ResponsiveContainer>
          </TabsContent>
          
          <TabsContent value="feedback" className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={feedbackData} margin={{ top: 10, right: 30, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="date" stroke="rgba(255,255,255,0.5)" />
                <YAxis 
                  stroke="rgba(255,255,255,0.5)" 
                  domain={[0, 5]} 
                  ticks={[0, 1, 2, 3, 4, 5]} 
                />
                <Tooltip
                  contentStyle={{ backgroundColor: 'rgba(0,0,0,0.8)', border: '1px solid rgba(255,255,255,0.2)' }}
                />
                <Bar 
                  dataKey="rating" 
                  name="Average Rating" 
                  fill="#FFD700" 
                  radius={[4, 4, 0, 0]} 
                />
              </BarChart>
            </ResponsiveContainer>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default AppStats;
