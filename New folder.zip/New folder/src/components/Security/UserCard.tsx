
import { User } from '@/data/securityPermissionsData';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { useState } from 'react';
import { Mail, ShieldAlert, User as UserIcon, Lock } from 'lucide-react';

interface UserCardProps {
  user: User;
  roles: { id: string; name: string }[];
  onRoleChange: (userId: string, roleId: string) => void;
  onStatusChange: (userId: string, status: 'active' | 'inactive' | 'pending') => void;
}

const UserCard = ({ user, roles, onRoleChange, onStatusChange }: UserCardProps) => {
  const [currentRole, setCurrentRole] = useState(user.role);
  const [currentStatus, setCurrentStatus] = useState(user.status);
  
  const handleRoleChange = (roleId: string) => {
    setCurrentRole(roleId);
    onRoleChange(user.id, roleId);
  };
  
  const handleStatusToggle = () => {
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
    setCurrentStatus(newStatus);
    onStatusChange(user.id, newStatus);
  };
  
  const getStatusColor = (status: string) => {
    switch(status) {
      case 'active': return 'text-green-500';
      case 'inactive': return 'text-red-500';
      case 'pending': return 'text-yellow-500';
      default: return 'text-gray-500';
    }
  };
  
  const getRoleName = (roleId: string) => {
    const role = roles.find(r => r.id === roleId);
    return role ? role.name : 'Unknown Role';
  };
  
  return (
    <div className="border rounded-lg p-5 bg-card">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-12 h-12 rounded-full overflow-hidden bg-muted">
          {user.avatar ? (
            <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full grid place-items-center bg-primary/10">
              <UserIcon className="w-6 h-6 text-primary" />
            </div>
          )}
        </div>
        <div className="flex-1">
          <h3 className="font-medium">{user.name}</h3>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Mail className="w-3 h-3" />
            {user.email}
          </div>
          <div className={`text-xs ${getStatusColor(user.status)} mt-1`}>
            {user.status.charAt(0).toUpperCase() + user.status.slice(1)}
          </div>
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-blue-500" />
            <span className="text-sm font-medium">Role</span>
          </div>
          <Select value={currentRole} onValueChange={handleRoleChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select role" />
            </SelectTrigger>
            <SelectContent>
              {roles.map((role) => (
                <SelectItem key={role.id} value={role.id}>{role.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-green-500" />
            <span className="text-sm font-medium">2FA Enabled</span>
          </div>
          <Switch checked={user.twoFactorEnabled} disabled />
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <UserIcon className="w-4 h-4 text-red-500" />
            <span className="text-sm font-medium">Status</span>
          </div>
          <Switch 
            checked={user.status === 'active'} 
            onCheckedChange={handleStatusToggle} 
          />
        </div>
        
        <div className="text-sm text-muted-foreground">
          Last login: {new Date(user.lastLogin).toLocaleString()}
        </div>
      </div>
    </div>
  );
};

export default UserCard;
