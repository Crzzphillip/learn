
import { Role, Permission } from '@/data/securityPermissionsData';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Shield, Users, Check } from 'lucide-react';
import { useState } from 'react';

interface RoleCardProps {
  role: Role;
  allPermissions: Permission[];
  onPermissionsChange: (roleId: string, permissionIds: string[]) => void;
}

const RoleCard = ({ role, allPermissions, onPermissionsChange }: RoleCardProps) => {
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>(
    role.permissions.map(p => p.id)
  );
  const [isEditing, setIsEditing] = useState(false);
  
  const handlePermissionChange = (permissionId: string, checked: boolean) => {
    setSelectedPermissions(prev => {
      if (checked) {
        return [...prev, permissionId];
      } else {
        return prev.filter(id => id !== permissionId);
      }
    });
  };
  
  const handleSave = () => {
    onPermissionsChange(role.id, selectedPermissions);
    setIsEditing(false);
  };
  
  const groupPermissionsByCategory = () => {
    const grouped: Record<string, Permission[]> = {};
    
    allPermissions.forEach(permission => {
      if (!grouped[permission.category]) {
        grouped[permission.category] = [];
      }
      grouped[permission.category].push(permission);
    });
    
    return grouped;
  };
  
  const permissionsByCategory = groupPermissionsByCategory();
  
  return (
    <div className="border rounded-lg overflow-hidden">
      <div className="p-5 bg-card">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-lg bg-primary/10 grid place-items-center">
            <Shield className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="font-medium text-lg">{role.name}</h3>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Users className="w-3 h-3" />
              {role.userCount} users
            </div>
          </div>
        </div>
        
        <p className="text-sm text-muted-foreground mb-4">{role.description}</p>
        
        {!isEditing ? (
          <Button variant="outline" size="sm" className="w-full" onClick={() => setIsEditing(true)}>
            Edit Permissions
          </Button>
        ) : (
          <div className="space-y-4">
            <ScrollArea className="h-[200px] border rounded-md p-4">
              {Object.entries(permissionsByCategory).map(([category, permissions]) => (
                <div key={category} className="mb-4">
                  <h4 className="text-sm font-medium uppercase text-muted-foreground mb-2">
                    {category}
                  </h4>
                  <div className="space-y-2">
                    {permissions.map(permission => (
                      <div key={permission.id} className="flex items-start gap-2">
                        <Checkbox 
                          id={`permission-${permission.id}`} 
                          checked={selectedPermissions.includes(permission.id)}
                          onCheckedChange={(checked) => 
                            handlePermissionChange(permission.id, checked as boolean)
                          }
                        />
                        <div className="grid gap-1.5">
                          <label
                            htmlFor={`permission-${permission.id}`}
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            {permission.name}
                          </label>
                          <p className="text-xs text-muted-foreground">
                            {permission.description}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </ScrollArea>
            
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setIsEditing(false)}>
                Cancel
              </Button>
              <Button className="flex-1 gap-1" onClick={handleSave}>
                <Check className="w-4 h-4" />
                Save Changes
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RoleCard;
