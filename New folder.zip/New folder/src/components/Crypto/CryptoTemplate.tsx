
import { Bitcoin, TrendingUp, DollarSign, BarChart2 } from "lucide-react";
import { SpaceTemplate, SpaceType } from "@/types/space";

export const getDefaultCryptoTemplate = (): SpaceTemplate => {
  return {
    title: "Crypto Trading Space",
    description: "Advanced AI-powered platform for cryptocurrency trading, analysis, and automated strategies.",
    type: "crypto" as SpaceType,
    gradient: "from-[#1A1F2C] to-[#403E43]",
    icon: Bitcoin,
    primaryColor: "#8E9196",
    secondaryColor: "#1A1F2C",
    accentColor: "#7077A1",
    features: [
      {
        id: "trading-pairs",
        title: "Trading Pairs & Market Access",
        description: "Access spot, margin, futures trading across multiple exchanges",
        icon: Bitcoin,
        category: "trading",
        isAvailable: true
      },
      {
        id: "ai-trading",
        title: "AI-Driven Trading Automation",
        description: "Automate strategies with AI-powered trading bots",
        icon: TrendingUp,
        category: "automation",
        isAvailable: true
      },
      {
        id: "advanced-orders",
        title: "Advanced Order Execution",
        description: "Use limit, market, stop-loss, and trailing stop orders",
        icon: DollarSign,
        category: "trading",
        isAvailable: true
      },
      {
        id: "market-insights",
        title: "Market & Data Insights",
        description: "Real-time market data and AI-based predictions",
        icon: BarChart2,
        category: "analytics",
        isAvailable: true
      }
    ],
    widgets: [
      {
        id: "price-chart",
        title: "Price Chart",
        type: "chart",
        size: "large",
        priority: 1
      },
      {
        id: "trading-volume",
        title: "Trading Volume",
        type: "chart",
        size: "medium",
        priority: 2
      },
      {
        id: "bot-performance",
        title: "Bot Performance",
        type: "stats",
        size: "medium",
        priority: 3
      },
      {
        id: "market-overview",
        title: "Market Overview",
        type: "stats",
        size: "full",
        priority: 4
      }
    ]
  };
};

export default getDefaultCryptoTemplate;
