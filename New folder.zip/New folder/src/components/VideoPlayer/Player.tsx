
import { Play } from "lucide-react";

const VideoPlayer = () => {
  return (
    <div className="relative aspect-video rounded-lg overflow-hidden bg-black">
      <img
        src="/lovable-uploads/0a1baea5-6a03-47a0-87a5-2d8084ef4e3d.png"
        alt="Video thumbnail"
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 flex items-center justify-center">
        <button className="w-16 h-16 rounded-full bg-white/10 backdrop-blur-lg flex items-center justify-center hover:bg-white/20 transition-colors">
          <Play className="w-8 h-8 text-white" />
        </button>
      </div>
    </div>
  );
};

export default VideoPlayer;
