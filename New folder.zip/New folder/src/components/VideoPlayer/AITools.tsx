
const AITools = () => {
  return (
    <div className="glass-panel rounded-xl p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">AI Tools</h3>
        <button className="px-4 py-1.5 bg-primary text-primary-foreground rounded-full text-sm font-medium hover:bg-primary/90 transition-colors button-hover">
          Upgrade
        </button>
      </div>
      
      <p className="text-sm text-muted-foreground">
        Taking your video to the next step with AI
      </p>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="p-4 bg-secondary/50 rounded-xl hover:bg-secondary/70 transition-all duration-200 cursor-pointer group">
          <div className="mb-2 text-2xl group-hover:scale-110 transition-transform duration-200">📹</div>
          <h4 className="font-medium mb-1">Generate Summary</h4>
          <p className="text-sm text-muted-foreground">AI-powered video summaries</p>
        </div>
        
        <div className="p-4 bg-secondary/50 rounded-xl hover:bg-secondary/70 transition-all duration-200 cursor-pointer group">
          <div className="mb-2 text-2xl group-hover:scale-110 transition-transform duration-200">📝</div>
          <h4 className="font-medium mb-1">Create Transcript</h4>
          <p className="text-sm text-muted-foreground">Accurate transcription</p>
        </div>
      </div>
      
      <div className="space-y-2">
        <button className="w-full py-2.5 flex items-center gap-3 hover:bg-secondary/50 rounded-lg px-4 transition-all duration-200 group">
          <span className="text-xl group-hover:scale-110 transition-transform duration-200">🎯</span>
          <span className="font-medium">Filter Words</span>
        </button>
        
        <button className="w-full py-2.5 flex items-center gap-3 hover:bg-secondary/50 rounded-lg px-4 transition-all duration-200 group">
          <span className="text-xl group-hover:scale-110 transition-transform duration-200">🔇</span>
          <span className="font-medium">Remove Silences</span>
        </button>
        
        <button className="w-full py-2.5 flex items-center gap-3 hover:bg-secondary/50 rounded-lg px-4 transition-all duration-200 group">
          <span className="text-xl group-hover:scale-110 transition-transform duration-200">✍️</span>
          <span className="font-medium">Generate Title</span>
        </button>
      </div>
    </div>
  );
};

export default AITools;
