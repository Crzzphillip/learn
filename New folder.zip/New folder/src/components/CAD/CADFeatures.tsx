import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { SpaceTemplate } from "@/types/space";
import { Ruler, Box, Layers, Zap, AlertCircle, FileText, Users, Cloud } from "lucide-react";

interface CADFeaturesProps {
  spaceTemplate: SpaceTemplate;
}

const CADFeatures = ({ spaceTemplate }: CADFeaturesProps) => {
  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      <Card className="bg-card/50 backdrop-blur-sm">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Ruler className="h-5 w-5 text-primary" />
            <CardTitle>Survey Drawing Generation</CardTitle>
          </div>
          <CardDescription>
            AI-powered AutoCAD survey drawing generation with real-time feedback
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-4 space-y-2">
            <li>Interactive drawing creation</li>
            <li>Real-time validation</li>
            <li>AutoCAD integration</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-card/50 backdrop-blur-sm">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Box className="h-5 w-5 text-primary" />
            <CardTitle>Survey Data Processing</CardTitle>
          </div>
          <CardDescription>
            Advanced data processing and analysis tools for survey data
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-4 space-y-2">
            <li>Automated data validation</li>
            <li>Pattern recognition</li>
            <li>Predictive analysis</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-card/50 backdrop-blur-sm">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            <CardTitle>Collaboration Hub</CardTitle>
          </div>
          <CardDescription>
            Team collaboration tools for survey projects
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-4 space-y-2">
            <li>Real-time collaboration</li>
            <li>Version control</li>
            <li>Project sharing</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
};

export default CADFeatures; 