import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Ruler, Save, Share2, Download, Layers, Settings } from "lucide-react";
import { useState, useEffect } from "react";
import { autocadService, AutoCADDrawing, SurveyPoint } from "@/services/autocadService";
import { toast } from "sonner";

const SurveyWorkspace = () => {
  const [drawing, setDrawing] = useState<AutoCADDrawing | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [points, setPoints] = useState<SurveyPoint[]>([]);

  useEffect(() => {
    const connectToAutoCAD = async () => {
      const connected = await autocadService.connect();
      setIsConnected(connected);
    };
    connectToAutoCAD();
  }, []);

  const handleCreateDrawing = async () => {
    try {
      const newDrawing = await autocadService.createDrawing("Survey Drawing");
      setDrawing(newDrawing);
      toast.success("Created new survey drawing");
    } catch (error) {
      toast.error("Failed to create drawing");
    }
  };

  const handleAddPoints = async () => {
    if (!drawing) return;

    const newPoints: SurveyPoint[] = [
      {
        id: Math.random().toString(36).substr(2, 9),
        x: Math.random() * 100,
        y: Math.random() * 100,
        z: Math.random() * 10,
        description: "Survey Point",
        accuracy: 0.95
      }
    ];

    try {
      await autocadService.addSurveyPoints(newPoints);
      setPoints([...points, ...newPoints]);
    } catch (error) {
      toast.error("Failed to add points");
    }
  };

  const handleExport = async (format: 'dwg' | 'dxf' | 'pdf') => {
    try {
      const result = await autocadService.exportDrawing(format);
      toast.success(result);
    } catch (error) {
      toast.error("Failed to export drawing");
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-card/50 backdrop-blur-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Ruler className="h-5 w-5 text-primary" />
              <CardTitle>Survey Project Workspace</CardTitle>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={handleCreateDrawing}>
                <Layers className="h-4 w-4 mr-2" />
                New Drawing
              </Button>
              <Button size="sm" variant="outline" onClick={handleAddPoints}>
                <Ruler className="h-4 w-4 mr-2" />
                Add Points
              </Button>
              <Button size="sm" variant="outline">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            <div className="aspect-video bg-muted rounded-lg border border-border">
              {/* Survey Drawing Canvas Area */}
              <div className="h-full w-full flex items-center justify-center text-muted-foreground">
                {isConnected ? (
                  drawing ? (
                    <div className="text-center">
                      <p className="text-lg font-medium">{drawing.name}</p>
                      <p className="text-sm">Status: {drawing.status}</p>
                      <p className="text-sm">Points: {points.length}</p>
                    </div>
                  ) : (
                    "Create a new drawing to begin"
                  )
                ) : (
                  "Connecting to AutoCAD..."
                )}
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 rounded-lg border border-border">
                <h3 className="font-medium mb-2">Project Details</h3>
                <div className="text-sm text-muted-foreground">
                  <p>Project: {drawing?.name || "No drawing"}</p>
                  <p>Status: {drawing?.status || "Not started"}</p>
                  <p>Layers: {drawing?.layers.length || 0}</p>
                </div>
              </div>
              <div className="p-4 rounded-lg border border-border">
                <h3 className="font-medium mb-2">Survey Data</h3>
                <div className="text-sm text-muted-foreground">
                  <p>Points: {points.length}</p>
                  <p>Last Added: {points.length > 0 ? new Date().toLocaleTimeString() : "None"}</p>
                  <p>AutoCAD: {isConnected ? "Connected" : "Disconnected"}</p>
                </div>
              </div>
              <div className="p-4 rounded-lg border border-border">
                <h3 className="font-medium mb-2">Export Options</h3>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => handleExport('dwg')}>
                    DWG
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleExport('dxf')}>
                    DXF
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleExport('pdf')}>
                    PDF
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SurveyWorkspace; 