import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bot, Plus } from "lucide-react";

const SurveyAgents = () => {
  const agents = [
    {
      name: "Survey Validator",
      description: "Validates survey data and measurements",
      status: "Active"
    },
    {
      name: "Drawing Generator",
      description: "Generates AutoCAD drawings from survey data",
      status: "Available"
    },
    {
      name: "Data Processor",
      description: "Processes and analyzes survey measurements",
      status: "Available"
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Survey Agents</h2>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          New Agent
        </Button>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {agents.map((agent, index) => (
          <Card key={index} className="bg-card/50 backdrop-blur-sm">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Bot className="h-5 w-5 text-primary" />
                <CardTitle className="text-lg">{agent.name}</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">{agent.description}</p>
              <div className="flex justify-between items-center">
                <span className={`text-sm ${
                  agent.status === 'Active' ? 'text-green-500' : 'text-blue-500'
                }`}>
                  {agent.status}
                </span>
                <Button size="sm" variant="outline">
                  Configure
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default SurveyAgents; 