import { Ruler, Box, Layers, Zap, AlertCircle, FileText, Users, Cloud } from "lucide-react";
import { SpaceTemplate, SpaceType } from "@/types/space";

export const getCADTemplate = (): SpaceTemplate => {
  return {
    title: "CAD Space",
    description: "AI-powered AutoCAD survey drawing generation and management",
    type: "cad" as SpaceType,
    gradient: "from-[#2563EB] to-[#3B82F6]",
    icon: Ruler,
    primaryColor: "#2563EB",
    secondaryColor: "#3B82F6",
    accentColor: "#60A5FA",
    features: [
      {
        id: "user-interaction",
        title: "Enhanced User Interaction",
        description: "Interactive UI with real-time feedback and natural language commands",
        icon: Users,
        category: "interaction",
        isAvailable: true
      },
      {
        id: "data-processing",
        title: "Advanced Data Processing",
        description: "Machine learning for predictive analysis and pattern recognition",
        icon: Zap,
        category: "processing",
        isAvailable: true
      },
      {
        id: "autocad-integration",
        title: "AutoCAD Integration",
        description: "Direct API integration with real-time sync and feature support",
        icon: Box,
        category: "integration",
        isAvailable: true
      },
      {
        id: "validation",
        title: "Error Handling & Validation",
        description: "Input validation, error reporting, and version control",
        icon: AlertCircle,
        category: "validation",
        isAvailable: true
      },
      {
        id: "performance",
        title: "Performance & Scalability",
        description: "Optimized processing for large datasets with cloud options",
        icon: Cloud,
        category: "performance",
        isAvailable: true
      },
      {
        id: "documentation",
        title: "Documentation & Support",
        description: "Comprehensive guides, tutorials, and community support",
        icon: FileText,
        category: "support",
        isAvailable: true
      }
    ]
  };
}; 