import { LucideIcon } from "lucide-react";

export type SpaceType = 'development' | 'creative' | 'productivity' | 'marketing' | 'communication' | 
  'community' | 'personal' | 'crypto' | 'image-generation' | 'education' | 'flora' | 
  'finance' | 'manufacturing' | 'healthcare' | 'legal' | 'leonardo' | 'cad';

export interface SpaceTemplate {
  type: SpaceType;
  title: string;
  description: string;
  gradient: string;
  icon: LucideIcon;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  features?: SpaceFeature[];
  widgets?: SpaceWidget[];
  specializations?: SpaceSpecialization[];
  tools?: SpaceTool[];
  learningPaths?: LearningPath[];
  resources?: EducationalResource[];
  industryDatasets?: IndustryDataset[];
  complianceFrameworks?: ComplianceFramework[];
  domainSpecificModels?: DomainSpecificModel[];
}

export interface SpaceNavPage {
  name: string;
  path: string;
  description: string;
  color: string;
}

export interface SpaceFeature {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  category: string;
  isAvailable: boolean;
}

export interface SpaceWidget {
  id: string;
  title: string;
  type: 'chart' | 'stats' | 'activity' | 'control-panel' | 'preview' | 'marketplace' | 'calendar' | 'dashboard' | 'editor';
  size: 'small' | 'medium' | 'large' | 'full';
  priority: number;
}

export interface SpaceSpecialization {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  gradient: string;
}

export interface SpaceTool {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  category: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  isAvailable: boolean;
}

export interface Tool {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  credits: string;
  locked: boolean;
  image: string;
  category?: string;
  themeColor?: string;
  route?: string;
  author?: {
    name: string;
    avatar: string;
    role: string;
  };
  usageStats?: {
    runs: string;
    copies: string;
    rating: string;
  };
  tags?: string[];
}

export interface LearningPath {
  id: string;
  title: string;
  description: string;
  modules: number;
  duration: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  icon: LucideIcon;
}

export interface EducationalResource {
  id: string;
  title: string;
  type: 'video' | 'article' | 'tutorial' | 'course' | 'documentation';
  author: string;
  duration: string;
  icon: LucideIcon;
}

export interface SpaceData {
  id: string;
  type: SpaceType;
  title: string;
  description: string;
  banner: string;
  parentSpaceId?: string;
  isSubspace: boolean;
  isPrivate: boolean;
  isCommunity: boolean;
  isPersonal: boolean;
  status: 'active' | 'pending' | 'review';
  stats: SpaceStat[];
  credits: SpaceCredits;
  template: SpaceTemplate;
  createdBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SpaceStat {
  icon: LucideIcon;
  label: string;
  value: string;
}

export interface SpaceCredits {
  balance: number;
  usage: {
    agents: number;
    workflows: number;
    tools: number;
    apps: number;
  };
  earnings: number;
  subscriptionTier: 'free' | 'basic' | 'pro' | 'enterprise';
}

export interface SpaceHierarchy {
  id: string;
  title: string;
  parentId?: string;
  children: SpaceHierarchy[];
}

export interface IndustryDataset {
  id: string;
  name: string;
  description: string;
  source: string;
  lastUpdated: string;
  size: string;
  format: string;
  accessLevel: 'public' | 'licensed' | 'private';
}

export interface ComplianceFramework {
  id: string;
  name: string;
  description: string;
  region: string;
  sector: string;
  requirements: number;
  lastUpdated: string;
}

export interface DomainSpecificModel {
  id: string;
  name: string;
  description: string;
  type: 'predictive' | 'analytical' | 'generative';
  accuracy: number;
  trainingDataset: string;
  lastUpdated: string;
  capabilities: string[];
}
