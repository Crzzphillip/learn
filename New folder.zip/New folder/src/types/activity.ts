
import { User } from "./user";

export type ActivityType = 
  'agent-creation' | 
  'agent-update' | 
  'workflow-creation' | 
  'workflow-update' | 
  'app-deployment' | 
  'resource-share' | 
  'discussion' | 
  'community-challenge' | 
  'integration-setup';

export interface Activity {
  id: string;
  type: string;
  title: string;
  description: string;
  timestamp: string;
  user: User;
  details?: Record<string, any>; // Additional details specific to the activity type
}

export interface ActivityFilter {
  types?: ActivityType[];
  fromDate?: Date;
  toDate?: Date;
  userId?: string;
}
