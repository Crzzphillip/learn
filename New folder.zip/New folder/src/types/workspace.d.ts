
export interface ComponentCategory {
  id: string;
  name: string;
  type: string;
  description: string;
}

export interface WorkspaceComponent {
  id: string;
  type: string;
  category: string;
  name: string;
  description: string;
  icon?: React.ReactElement;
  iconName?: string; // Added iconName property
  tags?: string[];
  compatibleWith?: string[];
  capabilities?: string[];
  aiPowered?: boolean;
  configOptions?: {
    name: string;
    type: string;
    options?: string[];
    default?: string;
  }[];
}

export interface WorkspaceTemplate {
  id: string;
  name: string;
  description: string;
  icon?: React.ReactElement;
  iconName?: string; // Added iconName property
  components: string[];
  connections: {
    source: string;
    target: string;
  }[];
  category: string;
  tags: string[];
  aiForgeTemplate?: boolean;
  complexity: 'beginner' | 'intermediate' | 'advanced';
}

export interface Message {
  id: string;
  from: string;
  to: string;
  content: string;
  timestamp: Date;
}
