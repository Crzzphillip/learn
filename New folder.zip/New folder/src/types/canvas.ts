
export interface Canvas {
  id: string;
  name: string;
  preview: string;
  createdAt: string;
  updatedAt: string;
  creator: string;
  type: 'drawing' | 'inpainting' | 'generation';
  tags: string[];
}

export interface CanvasToolOption {
  id: string;
  name: string;
  icon: string;
}

export interface CanvasSettings {
  brushSize: number;
  brushColor: string;
  brushOpacity: number;
  brushHardness: number;
}

export interface GenerationSettings {
  prompt: string;
  negativePrompt: string;
  creativityStrength: number;
  guidanceScale: number;
  seed: number;
  steps: number;
}
