
export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role?: 'Owner' | 'Admin' | 'Editor' | 'Viewer' | 'Official';
  status?: 'online' | 'offline' | 'away';
  lastActive?: Date;
}

export interface UserCredentials {
  email: string;
  password: string;
}

export interface UserPreferences {
  theme: 'light' | 'dark' | 'system';
  notifications: {
    email: boolean;
    push: boolean;
    inApp: boolean;
  };
  defaultView: string;
}

export interface UserPermission {
  resource: string;
  action: 'read' | 'write' | 'delete' | 'admin';
}

export interface UserProfile extends User {
  bio?: string;
  location?: string;
  website?: string;
  company?: string;
  title?: string;
  skills?: string[];
  interests?: string[];
  permissions?: UserPermission[];
  preferences?: UserPreferences;
  joinedAt: Date;
}
