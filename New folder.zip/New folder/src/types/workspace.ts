import { ReactNode } from 'react';

export type WorkspaceType = 'standard' | 'aiforge' | 'canvas';

export interface WorkspaceComponent {
  id: string;
  type: 'agent' | 'workflow' | 'app' | 'integration' | 'template' | 'extension' | 'tool';
  category?: string;
  name: string;
  description: string;
  icon: ReactNode;
  tags?: string[];
  compatibleWith?: string[];
  capabilities?: string[];
  aiPowered?: boolean;
  configOptions?: {
    name: string;
    type: 'select' | 'text' | 'boolean' | 'number';
    options?: string[];
    default?: any;
  }[];
}

export interface Message {
  id: string;
  from: string;
  to: string;
  content: string;
  timestamp: Date;
}

export interface WorkspaceTemplate {
  id: string;
  name: string;
  description: string;
  icon: ReactNode;
  components: string[]; // List of component IDs to include
  connections: Array<{source: string, target: string}>; // Predefined connections
  category: string;
  tags: string[];
  previewImage?: string;
  aiForgeTemplate?: boolean;
  industry?: string;
  complexity?: 'beginner' | 'intermediate' | 'advanced';
}

export interface ComponentCategory {
  id: string;
  name: string;
  type: 'agent' | 'workflow' | 'app' | 'integration' | 'template' | 'extension' | 'tool';
  description: string;
}

export interface Capability {
  id: string;
  name: string;
  icon: ReactNode;
  description: string;
}

export interface AIForgeWorkspace {
  id: string;
  name: string;
  description: string;
  icon: ReactNode;
  createdAt: Date;
  updatedAt: Date;
  components: string[];
  connections: Array<{source: string, target: string}>;
  features: {
    codeGeneration?: boolean;
    visualEditor?: boolean;
    collaborationTools?: boolean;
    backendManagement?: boolean;
    deploymentPipelines?: boolean;
    guidedWorkflows?: boolean;
    uxEnhancements?: boolean;
    nonDeveloperFeatures?: boolean;
    projectManagement?: boolean;
    codeRefactoring?: boolean;
    testingSuite?: boolean;
    crossDomainIntegration?: boolean;
    inclusiveDevelopment?: boolean;
  };
  analytics: {
    codeGenerated: string;
    componentsCreated: number;
    testsRun: number;
    deploymentsCompleted: number;
    lastUpdated: string;
  };
}

// Define a consistent Analytics type for standard workspace
export interface StandardWorkspaceAnalytics {
  leads: number;
  conversions: number;
  revenue: string;
  growth: string;
  lastUpdated: string;
}

// This type helps unify different workspace types for component props
export interface WorkspaceDisplayData {
  id: string;
  name: string;
  description: string;
  created: string;
  lastModified: string;
  templateType: string;
  templateIcon: string;
  owner: {
    id: string;
    name: string;
    avatar: string;
  };
  collaborators: Array<{
    id: string;
    name: string;
    avatar: string;
    role: string;
  }>;
  components: Array<{
    id: string;
    type: string;
    name: string;
    description: string;
  }>;
  exportOptions: Array<{
    id: string;
    type: string;
    name: string;
    icon: string;
  }>;
  integrations: Array<{
    id: string;
    name: string;
    icon: string;
    status: string;
  }>;
  timelinePoints: Array<{
    id: string;
    timestamp: string;
    title: string;
    description: string;
  }>;
  savedStates: Array<{
    id: string;
    timestamp: string;
    title: string;
    description: string;
  }>;
  analytics: StandardWorkspaceAnalytics;
}

// Canvas workspace types
export interface CanvasWorkspace {
  id: string;
  name: string;
  description: string;
  type: 'drawing' | 'inpainting' | 'generation';
  preview: string;
  createdAt: string;
  updatedAt: string;
  creator: {
    name: string;
    avatar: string;
  };
  canvasData: string; // SVG or other canvas representation
}

export interface TextStyle {
  bold: boolean;
  fontSize: number;
  alignment: 'left' | 'center' | 'right';
}

export interface LinkSettings {
  url: string;
  newTab: boolean;
  noFollow: boolean;
}

export interface DevicePreview {
  type: 'desktop' | 'tablet' | 'mobile';
  width: string;
}

export type ComponentType = 'button' | 'text' | 'image';

export interface WorkspaceState {
  currentDevice: DevicePreview['type'];
  textStyles: TextStyle;
  linkSettings: LinkSettings;
  isPropertiesPanelOpen: boolean;
  isTextSettingsExpanded: boolean;
  isLinkSettingsExpanded: boolean;
  selectedComponent: {
    id: string;
    type: ComponentType;
  } | null;
}

export interface WorkspaceAction {
  type: 
    | 'SET_DEVICE' 
    | 'UPDATE_TEXT_STYLE' 
    | 'UPDATE_LINK_SETTINGS'
    | 'TOGGLE_PROPERTIES_PANEL'
    | 'TOGGLE_TEXT_SETTINGS'
    | 'TOGGLE_LINK_SETTINGS'
    | 'SELECT_COMPONENT'
    | 'UPDATE_COMPONENT_PROPERTY';
  payload?: any;
}
