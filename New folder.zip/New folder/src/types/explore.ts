
import { LucideIcon } from "lucide-react";

export interface PopularAgent {
  id: string;
  name: string;
  category: string;
  posts: string;
  avatar: string;
}

export interface FeaturedSpace {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  category: string;
  listens: string;
  rating: string;
  image: string;
}

export interface CategorySpace {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  category: string;
  rating: string;
  listens: string;
  duration: string;
  image: string;
}

export interface Category {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  gradient: string;
  image: string;
  spaces: CategorySpace[];
}

export interface Showcase {
  id: string;
  title: string;
  category: string;
  features: string[];
  image: string;
  type: 'agent' | 'workflow' | 'workspace' | 'app';
  description: string;
  stats?: {
    users?: number;
    rating?: number;
    efficiency?: number;
  };
  author?: {
    name: string;
    avatar: string;
  };
  demoUrl?: string;
  benchmarks?: Benchmark[];
}

export interface TrendingWorkspace {
  id: string;
  title: string;
  description: string;
  savedCredits: number;
  totalCredits: number;
  owner: {
    name: string;
    avatar: string;
  };
  testimonial: string;
  reviews: string | number;
  upvotes: string | number;
  price: {
    value: string | number;
    type: string;
  };
  usageStats: {
    users: string | number;
    runs: string | number;
    lastRun: string;
  };
  tags: string[];
  successRate?: number;
  benchmarks?: Benchmark[];
  image?: string;
}

export interface Benchmark {
  id: string;
  name: string;
  score: number;
  category: BenchmarkCategory;
  description: string;
  maxScore: number;
  comparison?: {
    avgScore: number;
    topScore: number;
    bottomScore: number;
  };
  details?: {
    metric: string;
    value: string | number;
    change?: string;
    trend?: 'up' | 'down' | 'neutral';
  }[];
  lastUpdated: string;
}

export type BenchmarkCategory = 
  | 'performance' 
  | 'accuracy' 
  | 'reliability' 
  | 'efficiency' 
  | 'cost' 
  | 'reasoning' 
  | 'planning'
  | 'adaptability'
  | 'tool-use'
  | 'multi-step'
  | 'human-alignment';

export interface Agent {
  id?: string;
  title: string;
  description: string;
  icon: LucideIcon;
  category: string;
  rating: string;
  credits: string;
  locked: boolean;
  personas?: string[];
  image: string;
}

export interface Workflow {
  id?: string;
  title: string;
  description: string;
  icon?: LucideIcon;
  category?: string;
  rating?: string;
  credits: string;
  locked: boolean;
  image: string;
  agents?: string[]; // Add agents property as optional string array
  author?: {
    name: string;
    avatar: string;
    role?: string;
  };
  usageStats?: {
    runs?: string;
    copies?: string;
    rating?: string;
  };
  tags?: string[];
}

export interface Tool {
  id?: string;
  title: string;
  description: string;
  icon: LucideIcon;
  category?: string;
  credits: string;
  locked: boolean;
  image: string;
}

export interface Resource {
  id?: string;
  title: string;
  description: string;
  icon?: LucideIcon;
  category?: string;
  rating?: string;
  credits?: string;
  locked?: boolean;
  type?: string;
  image?: string;
  downloads?: number;
}

export interface App {
  id?: string;
  title: string;
  description: string;
  icon: LucideIcon;
  credits: string;
  locked: boolean;
  image: string;
}
