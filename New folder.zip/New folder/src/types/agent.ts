
export interface AgentDetails {
  title: string;
  description: string;
  category: string;
  rating: string;
  credits: string;
  personas: string[];
  reviews: AgentReview[];
  useCases: UseCase[];
}

export interface AgentReview {
  user: string;
  rating: number;
  comment: string;
}

export interface UseCase {
  id: string;
  user: string;
  userAvatar: string;
  title: string;
  description: string;
  industry: string;
  results: string;
  date: string;
}

export interface AgentBenchmark {
  id: string;
  name: string;
  score: number;
  category: string;
  maximum: number;
  description: string;
}

export interface AgentTask {
  icon: any;
  title: string;
  description: string;
  examples: string[];
}

export interface AgentWorkflow {
  id: string;
  name: string;
  description: string;
  nodes: any[];
  edges: any[];
  metadata: {
    timestamp: number;
    author: string;
  };
}

// Adding the missing Message type
export interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
  credits: number;
  attachments?: string[];
}

// Adding the missing Comment type
export interface Comment {
  id: string;
  user: string;
  content: string;
  timestamp: Date | string;
  likes: number;
  isLiked: boolean;
  replies?: Comment[];
}
