import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/components/Theme/ThemeProvider";
import Landing from "./pages/Landing";
import Space from "./pages/Space";
import Home from "./pages/Home";
import Library from "./pages/Library";
import Notifications from "./pages/Notifications";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";
import Agent from "./pages/Agent";
import ChatRoom from "./pages/ChatRoom";
import Workflow from "./pages/Workflow";
import WorkflowBuilder from "./pages/WorkflowBuilder";
import WorkflowRun from "./pages/WorkflowRun";
import Workspace from "./pages/Workspace";
import CreateWorkspace from "./pages/CreateWorkspace";
import CreatePage from "./pages/CreatePage";
import CreateWorkspacePage from "./pages/CreateWorkspacePage";
import WorkspaceBuilder from "./pages/WorkspaceBuilder";
import App from "./pages/App";
import AppCreator from "./pages/AppCreator";
import Explore from "./pages/Explore";
import ExploreCategory from "./pages/ExploreCategory";
import ExploreAll from "./pages/ExploreAll";
import FluxAssistant from "./components/Workflow/FluxAssistant";
import AgentsPage from "./pages/AgentsPage";
import AppsPage from "./pages/AppsPage";
import WorkflowsPage from "./pages/WorkflowsPage";
import WorkspacesPage from "./pages/WorkspacesPage";
import WorkshopsPage from "./pages/WorkshopsPage";
import WorkshopPage from "./pages/WorkshopPage";
import ToolsPage from "./pages/ToolsPage";
import ResourcesPage from "./pages/ResourcesPage";
import CommunitySpace from "./pages/CommunitySpace";
import CommunityPage from "./pages/Community";
import Blog from "./pages/Blog";
import BlogPost from "./pages/BlogPost";
import SpaceSettings from "./pages/SpaceSettings";
import EducationPage from "./pages/EducationPage";
import ManageSpacePage from "./pages/ManageSpacePage";
import ToolPage from "./pages/ToolPage";
import SpaceAllInPage from "./pages/SpaceAllInPage";
import WorkspaceRun from "./pages/WorkspaceRun";
import Persona from "./pages/Persona";
import Showcases from "./pages/Showcases";
import ShowcaseDetail from "./pages/ShowcaseDetail";
import SpaceBenchmarks from "./pages/SpaceBenchmarks";
import IntegrationHub from "./pages/IntegrationHub";
import MCPServer from "./pages/MCPServer";
import Marketplace from "./pages/Marketplace";
import SecurityPermissions from "./pages/SecurityPermissions";
import WebsiteWorkspaceCreator from './pages/WebsiteWorkspaceCreator';
import CommunityChat from "@/pages/CommunityChat";
import CommunityDiscussions from "@/pages/CommunityDiscussions";
import CommunityMembers from "@/pages/CommunityMembers";
import CommunityResources from "@/pages/CommunityResources";
import CommunityEvents from "@/pages/CommunityEvents";

const MyDashboard = () => <div className="p-8"><h1 className="text-2xl font-bold">My Dashboard</h1></div>;
const MySaved = () => <div className="p-8"><h1 className="text-2xl font-bold">Saved Content</h1></div>;
const MySubscriptions = () => <div className="p-8"><h1 className="text-2xl font-bold">My Subscriptions</h1></div>;
const MyCredits = () => <div className="p-8"><h1 className="text-2xl font-bold">Credits Usage</h1></div>;
const MyEarnings = () => <div className="p-8"><h1 className="text-2xl font-bold">My Earnings</h1></div>;
const MyFavorites = () => <div className="p-8"><h1 className="text-2xl font-bold">My Favorites</h1></div>;

const queryClient = new QueryClient();

const AppRouter = () => (
  <ThemeProvider defaultTheme="dark">
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/create" element={<CreatePage />} />
          <Route path="/create/workspace" element={<CreateWorkspacePage />} />
          <Route path="/create/workspace/:templateId" element={<WebsiteWorkspaceCreator />} />
          <Route path="/community" element={<CommunityPage/>} />
          
          <Route path="/workspace/:workspaceId" element={<Workspace />} />
          <Route path="/workspace/:workspaceId/run" element={<WorkspaceRun />} />
          <Route path="/explore" element={<Explore />} />
          <Route path="/showcases" element={<Showcases />} />
          <Route path="/showcase/:showcaseId" element={<ShowcaseDetail />} />
          <Route path="/home" element={<Home />} />
          <Route path="/library" element={<Library />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/explore/:type" element={<ExploreAll />} />
          <Route path="/explore/:spacecategoryid" element={<ExploreCategory />} />
          <Route path="/space/:spaceId" element={<Space />} />
          <Route path="/space/:spaceId/agents" element={<AgentsPage />} />
          <Route path="/space/:spaceId/apps" element={<AppsPage />} />
          <Route path="/space/:spaceId/workflows" element={<WorkflowsPage />} />
          <Route path="/space/:spaceId/workspaces" element={<WorkspacesPage />} />
          <Route path="/space/:spaceId/tools" element={<ToolsPage />} />
          <Route path="/space/:spaceId/tool/:toolId" element={<ToolPage />} />
          <Route path="/space/:spaceId/resources" element={<ResourcesPage />} />
          <Route path="/space/:spaceId/education" element={<EducationPage />} />
          <Route path="/space/:spaceId/settings" element={<SpaceSettings />} />
          <Route path="/space/:spaceId/workshops" element={<WorkshopsPage />} />
          <Route path="/space/:spaceId/manage" element={<ManageSpacePage />} />
          <Route path="/space/:spaceId/allin" element={<SpaceAllInPage />} />
          <Route path="/space/:spaceId/benchmarks" element={<SpaceBenchmarks />} />
          
          <Route path="/space/:spaceId/integrations" element={<IntegrationHub />} />
          <Route path="/space/:spaceId/mcpserver" element={<MCPServer />} />
          <Route path="/space/:spaceId/marketplace" element={<Marketplace />} />
          <Route path="/space/:spaceId/security" element={<SecurityPermissions />} />
          <Route path="/integrations" element={<IntegrationHub />} />
          <Route path="/mcpserver" element={<MCPServer />} />
          <Route path="/marketplace" element={<Marketplace />} />
          <Route path="/security" element={<SecurityPermissions />} />
          
          <Route path="/agent/:agentId" element={<Agent />} />
          <Route path="/agent/:agentId/chat" element={<ChatRoom />} />
          <Route path="/persona/:personaId" element={<Persona />} />
          <Route path="/workflow/:workflowId" element={<Workflow />} />
          <Route path="/workflow/:workflowId/run" element={<WorkflowRun />} />
          <Route path="/workflow/builder" element={<WorkflowBuilder />} />
          <Route path="/workshop/:workshopId" element={<WorkshopPage />} />
          <Route path="/app/:appId" element={<App />} />
          
          <Route path="/create-app/agent/:agentId" element={<AppCreator type="agent" />} />
          <Route path="/create-app/workflow/:workflowId" element={<AppCreator type="workflow" />} />
          <Route path="/create-app/workspace/:workspaceId" element={<AppCreator type="workspace" />} />
          
          <Route path="/space/:spaceId/agent/:agentId" element={<Agent />} />
          <Route path="/space/:spaceId/workflow/:workflowId" element={<Workflow />} />
          <Route path="/space/:spaceId/workflow/builder" element={<WorkflowBuilder />} />
          <Route path="/space/:spaceId/app/:appId" element={<App />} />
          
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:blogId" element={<BlogPost />} />
          
          <Route path="/community/:spaceId" element={<CommunitySpace />} />
          <Route path="/community/:spaceId/chat" element={<CommunityChat />} />
          <Route path="/community/:spaceId/discussions" element={<CommunityDiscussions />} />
          <Route path="/community/:spaceId/members" element={<CommunityMembers />} />
          <Route path="/community/:spaceId/resources" element={<CommunityResources />} />
          <Route path="/community/:spaceId/events" element={<CommunityEvents />} />
          
          <Route path="/my-space/dashboard" element={<MyDashboard />} />
          <Route path="/my-space/saved" element={<MySaved />} />
          <Route path="/my-space/subscriptions" element={<MySubscriptions />} />
          <Route path="/my-space/credits" element={<MyCredits />} />
          <Route path="/my-space/earnings" element={<MyEarnings />} />
          <Route path="/my-space/favorites" element={<MyFavorites />} />
          
          <Route path="*" element={<NotFound />} />
        </Routes>
        <FluxAssistant />
      </BrowserRouter>
    </TooltipProvider>
  </ThemeProvider>
);

export default function Root() {
  return (
    <QueryClientProvider client={queryClient}>
      <AppRouter />
    </QueryClientProvider>
  );
}
