
import { useState, useEffect } from "react";
import { spaceDataService } from "@/services/spaceDataService";
import { SpaceTemplate, SpaceStat } from "@/types/space";
import { Agent, Workflow, Tool, Resource, App, TrendingWorkspace } from "@/types/explore";
import { ContentReviewItem } from "@/services/dummyDatabase";
import { leonardoWorkflowService } from "@/services/leonardoWorkflowService";

const useSpaceData = (initialSpaceId?: string) => {
  const [isLoading, setIsLoading] = useState(true);
  const [selectedSpaceId, setSelectedSpaceId] = useState(initialSpaceId || 'development');
  const [reviewItems, setReviewItems] = useState<ContentReviewItem[]>([]);
  const [spaceTemplate, setSpaceTemplate] = useState<SpaceTemplate>(spaceDataService.getSpaceTemplate(selectedSpaceId));
  const [stats, setStats] = useState<SpaceStat[]>(spaceDataService.getSpaceStats());
  const [trendData, setTrendData] = useState(spaceDataService.getTrendData());
  const [trendingWorkspaces, setTrendingWorkspaces] = useState<TrendingWorkspace[]>(spaceDataService.getTrendingWorkspaces());
  const [filteredAgents, setFilteredAgents] = useState<Agent[]>([]);
  const [filteredWorkflows, setFilteredWorkflows] = useState<Workflow[]>([]);
  const [filteredApps, setFilteredApps] = useState<App[]>([]);
  const [filteredTools, setFilteredTools] = useState<Tool[]>([]);
  const [filteredResources, setFilteredResources] = useState<Resource[]>([]);
  const [filteredEnhancedWorkflows, setFilteredEnhancedWorkflows] = useState<Workflow[]>([]);
  const [filteredFeaturedWorkflows, setFilteredFeaturedWorkflows] = useState<Workflow[]>([]);

  // Log spaceId for debugging
  useEffect(() => {
    console.log("Current spaceId in useSpaceData:", selectedSpaceId);
    if (!selectedSpaceId || selectedSpaceId === 'undefined') {
      console.warn("Invalid spaceId detected in useSpaceData:", selectedSpaceId);
    }
  }, [selectedSpaceId]);

  // Fetch and set all the data based on the selected space ID
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      
      try {
        // Get the space template
        const template = spaceDataService.getSpaceTemplate(selectedSpaceId);
        setSpaceTemplate(template);
        
        // Get stats and trend data
        setStats(spaceDataService.getSpaceStats());
        setTrendData(spaceDataService.getTrendData());
        
        // Get trending workspaces
        setTrendingWorkspaces(spaceDataService.getTrendingWorkspaces());
        
        // Get filtered content based on space ID
        setFilteredAgents(spaceDataService.getFilteredAgents());
        
        // Handle workflows based on space type
        if (selectedSpaceId === 'leonardo') {
          try {
            const leonardoWorkflows = await leonardoWorkflowService.getLeonardoWorkflows();
            setFilteredWorkflows(leonardoWorkflows);
            
            const leonardoFeaturedWorkflows = await leonardoWorkflowService.getFeaturedLeonardoWorkflows();
            setFilteredFeaturedWorkflows(leonardoFeaturedWorkflows);
          } catch (error) {
            console.error("Error fetching Leonardo workflows:", error);
            setFilteredWorkflows([]);
            setFilteredFeaturedWorkflows([]);
          }
        } else {
          try {
            const workflows = await spaceDataService.getFilteredWorkflows(selectedSpaceId);
            setFilteredWorkflows(Array.isArray(workflows) ? workflows : []);
            
            const featuredWorkflows = await spaceDataService.getFilteredFeaturedWorkflows(selectedSpaceId);
            setFilteredFeaturedWorkflows(Array.isArray(featuredWorkflows) ? featuredWorkflows : []);
          } catch (error) {
            console.error("Error fetching workflows:", error);
            setFilteredWorkflows([]);
            setFilteredFeaturedWorkflows([]);
          }
        }
        
        setFilteredApps(spaceDataService.getFilteredApps());
        setFilteredTools(spaceDataService.getFilteredTools());
        setFilteredResources(spaceDataService.getFilteredResources());
        setFilteredEnhancedWorkflows(spaceDataService.getFilteredEnhancedWorkflows());
        
        // Get review items
        try {
          const items = await spaceDataService.getReviewItems();
          setReviewItems(Array.isArray(items) ? items : []);
        } catch (error) {
          console.error("Error fetching review items:", error);
          setReviewItems([]);
        }
      } catch (error) {
        console.error("Error fetching space data:", error);
        // Reset states to empty arrays if there's an error
        setFilteredAgents([]);
        setFilteredWorkflows([]);
        setFilteredApps([]);
        setFilteredTools([]);
        setFilteredResources([]);
        setFilteredEnhancedWorkflows([]);
        setFilteredFeaturedWorkflows([]);
        setReviewItems([]);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, [selectedSpaceId]);

  // Handler for approving content
  const handleApproveContent = async (id: string) => {
    await spaceDataService.approveContent(id);
    try {
      const updatedItems = await spaceDataService.getReviewItems();
      setReviewItems(Array.isArray(updatedItems) ? updatedItems : []);
    } catch (error) {
      console.error("Error updating review items after approval:", error);
    }
  };
  
  // Handler for rejecting content
  const handleRejectContent = async (id: string) => {
    await spaceDataService.rejectContent(id);
    try {
      const updatedItems = await spaceDataService.getReviewItems();
      setReviewItems(Array.isArray(updatedItems) ? updatedItems : []);
    } catch (error) {
      console.error("Error updating review items after rejection:", error);
    }
  };
  
  // Get the selected space object
  const selectedSpace = {
    title: spaceTemplate.title,
    description: spaceTemplate.description,
    type: spaceTemplate.type,
    id: selectedSpaceId
  };

  return {
    isLoading,
    selectedSpaceId,
    setSelectedSpaceId,
    reviewItems,
    spaceTemplate,
    stats,
    trendData,
    selectedSpace,
    filteredAgents,
    filteredWorkflows,
    filteredApps,
    filteredTools,
    filteredResources,
    filteredEnhancedWorkflows,
    filteredFeaturedWorkflows,
    trendingWorkspaces,
    handleApproveContent,
    handleRejectContent
  };
};

export default useSpaceData;
