
import { useState, useEffect } from 'react';
import { SpaceTemplate, SpaceStat } from '@/types/space';
import { Agent, Workflow, Tool, Resource, App, TrendingWorkspace } from '@/types/explore';
import { ContentReviewItem } from '@/components/Space/CommunityContentReview';
import { spaceDataService } from '@/services/spaceDataService';

export interface SpaceDataResult {
  isLoading: boolean;
  selectedSpaceId: string;
  setSelectedSpaceId: (id: string) => void;
  reviewItems: ContentReviewItem[];
  spaceTemplate: SpaceTemplate;
  stats: SpaceStat[];
  trendData: {
    title: string;
    change: string;
    description: string;
    isUp: boolean;
    gradient: string;
  }[];
  selectedSpace: {
    id: string;
    title: string;
  };
  filteredAgents: Agent[];
  filteredWorkflows: Workflow[];
  filteredApps: App[];
  filteredTools: Tool[];
  filteredResources: Resource[];
  filteredEnhancedWorkflows: Workflow[];
  filteredFeaturedWorkflows: Workflow[];
  trendingWorkspaces: TrendingWorkspace[];
  handleApproveContent: (id: string) => Promise<void>;
  handleRejectContent: (id: string) => Promise<void>;
}

const useSpaceData = (spaceId?: string): SpaceDataResult => {
  const [selectedSpaceId, setSelectedSpaceId] = useState<string>(spaceId || 'development');
  const [reviewItems, setReviewItems] = useState<ContentReviewItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Get space template
  const spaceTemplate = spaceDataService.getSpaceTemplate(selectedSpaceId);
  
  // Get space stats
  const stats = spaceDataService.getSpaceStats();
  
  // Get trend data
  const trendData = spaceDataService.getTrendData();
  
  // Mocked selected space
  const selectedSpace = {
    id: selectedSpaceId,
    title: spaceTemplate.title
  };
  
  // Filtered data
  const filteredAgents = spaceDataService.getFilteredAgents();
  const filteredWorkflows = spaceDataService.getFilteredWorkflows();
  const filteredApps = spaceDataService.getFilteredApps();
  const filteredTools = spaceDataService.getFilteredTools();
  const filteredResources = spaceDataService.getFilteredResources();
  const filteredEnhancedWorkflows = spaceDataService.getFilteredEnhancedWorkflows();
  const filteredFeaturedWorkflows = spaceDataService.getFilteredFeaturedWorkflows();
  const trendingWorkspaces = spaceDataService.getTrendingWorkspaces();

  // Fetch review items
  useEffect(() => {
    const fetchReviewItems = async () => {
      try {
        setIsLoading(true);
        const items = await spaceDataService.getReviewItems();
        // Transform the items to match ContentReviewItem from CommunityContentReview
        const transformedItems = items.map(item => ({
          ...item,
          description: item.content,
          submittedAt: item.timestamp
        }));
        setReviewItems(transformedItems);
      } catch (error) {
        console.error('Error fetching review items:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchReviewItems();
  }, [selectedSpaceId]);

  // Handle approve content
  const handleApproveContent = async (id: string): Promise<void> => {
    try {
      await spaceDataService.approveContent(id);
      const updatedItems = await spaceDataService.getReviewItems();
      const transformedItems = updatedItems.map(item => ({
        ...item,
        description: item.content,
        submittedAt: item.timestamp
      }));
      setReviewItems(transformedItems);
    } catch (error) {
      console.error('Error approving content:', error);
    }
  };

  // Handle reject content
  const handleRejectContent = async (id: string): Promise<void> => {
    try {
      await spaceDataService.rejectContent(id);
      const updatedItems = await spaceDataService.getReviewItems();
      const transformedItems = updatedItems.map(item => ({
        ...item,
        description: item.content,
        submittedAt: item.timestamp
      }));
      setReviewItems(transformedItems);
    } catch (error) {
      console.error('Error rejecting content:', error);
    }
  };

  return {
    isLoading,
    selectedSpaceId,
    setSelectedSpaceId,
    reviewItems,
    spaceTemplate,
    stats,
    trendData,
    selectedSpace,
    filteredAgents,
    filteredWorkflows,
    filteredApps,
    filteredTools,
    filteredResources,
    filteredEnhancedWorkflows,
    filteredFeaturedWorkflows,
    trendingWorkspaces,
    handleApproveContent,
    handleRejectContent
  };
};

export default useSpaceData;
