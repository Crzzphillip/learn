import { Code, Palette, MessageSquare, Zap, Laptop, Bitcoin, Image, GraduationCap, Wand, Layers, Star, Rocket, DollarSign, Factory, Ruler } from "lucide-react";
import { SpaceTemplate } from "@/types/space";
import { getDefaultCryptoTemplate } from "@/components/Crypto/CryptoTemplate";
import { getDefaultImageGenerationTemplate } from "@/components/ImageGeneration/ImageGenerationTemplate";
import { getDefaultEducationTemplate } from "@/components/Education/EducationTemplate";
import { getFloraCreativeTemplate } from "@/components/Flora/FloraTemplate";
import { getFinanceSpaceTemplate } from "@/components/Finance/FinanceTemplate";
import { getManufacturingSpaceTemplate } from "@/components/Manufacturing/ManufacturingTemplate";
import { getLeonardoAiTemplate } from "@/components/Leonardo/LeonardoTemplate";
import { getCADTemplate } from "@/components/CAD/CADTemplate";

export const spaceTemplates: Record<string, SpaceTemplate> = {
  development: {
    type: 'development',
    title: 'Development Space',
    description: 'AI-powered coding assistants and development tools',
    gradient: 'from-[#1A1F2C] to-[#7E69AB]',
    icon: Code,
    primaryColor: '#7E69AB',
    secondaryColor: '#1A1F2C',
    accentColor: '#9F8AC1'
  },
  codecraft: {
    type: 'development',
    title: 'CodeCraft Space',
    description: 'Advanced coding environment with AI-powered tools',
    gradient: 'from-[#2D3250] to-[#7077A1]',
    icon: Laptop,
    primaryColor: '#7077A1',
    secondaryColor: '#2D3250',
    accentColor: '#424769'
  },
  creative: {
    type: 'creative',
    title: 'Creative Space',
    description: 'AI tools for design, content creation, and artistic endeavors',
    gradient: 'from-[#D946EF] to-[#8B5CF6]',
    icon: Palette,
    primaryColor: '#D946EF',
    secondaryColor: '#8B5CF6',
    accentColor: '#E37EF3'
  },
  communication: {
    type: 'communication',
    title: 'Communication Space',
    description: 'AI-powered tools for better communication and content writing',
    gradient: 'from-[#0EA5E9] to-[#2DD4BF]',
    icon: MessageSquare,
    primaryColor: '#0EA5E9',
    secondaryColor: '#2DD4BF',
    accentColor: '#38BDF8'
  },
  productivity: {
    type: 'productivity',
    title: 'Productivity Space',
    description: 'AI assistants for workflow automation and task management',
    gradient: 'from-[#F59E0B] to-[#EF4444]',
    icon: Zap,
    primaryColor: '#F59E0B',
    secondaryColor: '#EF4444',
    accentColor: '#FBBF24'
  },
  crypto: getDefaultCryptoTemplate(),
  "image-generation": getDefaultImageGenerationTemplate(),
  education: getDefaultEducationTemplate(),
  flora: getFloraCreativeTemplate(),
  finance: getFinanceSpaceTemplate(),
  manufacturing: getManufacturingSpaceTemplate(),
  leonardo: getLeonardoAiTemplate(),
  cad: getCADTemplate()
};
