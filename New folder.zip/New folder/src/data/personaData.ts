
export interface PersonaData {
  id: string;
  name: string;
  description: string;
  category: string;
  rating: number;
  users: number;
  creator: string;
  createdAt: string;
  icon: string;
  abilities: string[];
  limitations: string[];
  promptExamples?: {
    title: string;
    prompt: string;
  }[];
  capabilities?: {
    title: string;
    description: string;
    icon: string;
  }[];
}

export interface PersonaReview {
  id: string;
  user: string;
  avatar: string;
  rating: number;
  comment: string;
  date: string;
  likes: number;
  replies: number;
}

export interface PersonaShowcase {
  id: string;
  title: string;
  description: string;
  type: 'text' | 'code' | 'image';
  preview: string;
  user: string;
  userAvatar: string;
  date: string;
  tags: string[];
  likes: number;
  comments: number;
}

export interface PersonaUseCase {
  id: string;
  title: string;
  description: string;
  industry: string;
  results: string;
  user: string;
  userAvatar: string;
  date: string;
  likes?: number; // Making this optional to match existing code
}
