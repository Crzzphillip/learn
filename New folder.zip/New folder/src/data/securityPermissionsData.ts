
export interface Role {
  id: string;
  name: string;
  description: string;
  permissions: Permission[];
  userCount: number;
}

export interface Permission {
  id: string;
  name: string;
  description: string;
  category: 'read' | 'write' | 'admin' | 'system';
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: string;
  status: 'active' | 'inactive' | 'pending';
  lastLogin: string;
  twoFactorEnabled: boolean;
}

export const permissions: Permission[] = [
  {
    id: 'perm-1',
    name: 'view_agents',
    description: 'Can view AI agents',
    category: 'read'
  },
  {
    id: 'perm-2',
    name: 'create_agents',
    description: 'Can create new AI agents',
    category: 'write'
  },
  {
    id: 'perm-3',
    name: 'edit_agents',
    description: 'Can edit existing AI agents',
    category: 'write'
  },
  {
    id: 'perm-4',
    name: 'delete_agents',
    description: 'Can delete AI agents',
    category: 'admin'
  },
  {
    id: 'perm-5',
    name: 'view_workflows',
    description: 'Can view workflows',
    category: 'read'
  },
  {
    id: 'perm-6',
    name: 'create_workflows',
    description: 'Can create new workflows',
    category: 'write'
  },
  {
    id: 'perm-7',
    name: 'manage_users',
    description: 'Can manage user accounts',
    category: 'admin'
  },
  {
    id: 'perm-8',
    name: 'system_settings',
    description: 'Can modify system settings',
    category: 'system'
  },
  {
    id: 'perm-9',
    name: 'view_marketplace',
    description: 'Can view marketplace items',
    category: 'read'
  },
  {
    id: 'perm-10',
    name: 'purchase_marketplace',
    description: 'Can purchase items from marketplace',
    category: 'write'
  }
];

export const roles: Role[] = [
  {
    id: 'role-1',
    name: 'Administrator',
    description: 'Full access to all features and settings',
    permissions: permissions,
    userCount: 3
  },
  {
    id: 'role-2',
    name: 'Developer',
    description: 'Can create and manage agents and workflows',
    permissions: permissions.filter(p => p.id !== 'perm-7' && p.id !== 'perm-8'),
    userCount: 12
  },
  {
    id: 'role-3',
    name: 'Analyst',
    description: 'Can view and use existing agents and workflows',
    permissions: permissions.filter(p => p.category === 'read' || p.id === 'perm-10'),
    userCount: 28
  },
  {
    id: 'role-4',
    name: 'Guest',
    description: 'Limited read-only access',
    permissions: permissions.filter(p => p.id === 'perm-1' || p.id === 'perm-5' || p.id === 'perm-9'),
    userCount: 45
  }
];

export const users: User[] = [
  {
    id: 'user-1',
    name: 'Alex Johnson',
    email: 'alex@example.com',
    avatar: '/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png',
    role: 'role-1',
    status: 'active',
    lastLogin: '2023-11-15T08:45:22Z',
    twoFactorEnabled: true
  },
  {
    id: 'user-2',
    name: 'Sarah Williams',
    email: 'sarah@example.com',
    avatar: '/lovable-uploads/7fc80395-bb0d-41ca-9843-b95a80b861eb.png',
    role: 'role-2',
    status: 'active',
    lastLogin: '2023-11-14T15:30:10Z',
    twoFactorEnabled: true
  },
  {
    id: 'user-3',
    name: 'Michael Chen',
    email: 'michael@example.com',
    avatar: '/lovable-uploads/92e31f95-4874-41ef-b38a-12bfb2ea47b3.png',
    role: 'role-2',
    status: 'active',
    lastLogin: '2023-11-15T09:12:45Z',
    twoFactorEnabled: false
  },
  {
    id: 'user-4',
    name: 'Emily Garcia',
    email: 'emily@example.com',
    avatar: '/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png',
    role: 'role-3',
    status: 'inactive',
    lastLogin: '2023-11-10T11:20:33Z',
    twoFactorEnabled: false
  },
  {
    id: 'user-5',
    name: 'David Kim',
    email: 'david@example.com',
    avatar: '/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png',
    role: 'role-3',
    status: 'active',
    lastLogin: '2023-11-14T16:45:18Z',
    twoFactorEnabled: true
  }
];
