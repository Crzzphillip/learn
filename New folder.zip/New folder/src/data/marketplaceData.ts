
export interface MarketplaceItem {
  id: string;
  name: string;
  description: string;
  category: 'agent' | 'workflow' | 'tool' | 'template' | 'app';
  imageUrl: string;
  author: {
    name: string;
    avatar: string;
  };
  rating: number;
  reviewCount: number;
  price: number;
  downloads: number;
  tags: string[];
  createdAt: string;
  lastUpdated: string;
}

export const marketplaceItems: MarketplaceItem[] = [
  {
    id: 'item-1',
    name: 'Data Analyzer Agent',
    description: 'Powerful agent for analyzing and visualizing complex datasets.',
    category: 'agent',
    imageUrl: '/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png',
    author: {
      name: 'AI Analytics',
      avatar: '/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png'
    },
    rating: 4.8,
    reviewCount: 124,
    price: 50,
    downloads: 3450,
    tags: ['analytics', 'data science', 'visualization'],
    createdAt: '2023-09-10T12:00:00Z',
    lastUpdated: '2023-11-05T09:30:00Z'
  },
  {
    id: 'item-2',
    name: 'Content Generation Workflow',
    description: 'End-to-end workflow for creating marketing content automatically.',
    category: 'workflow',
    imageUrl: '/lovable-uploads/7fc80395-bb0d-41ca-9843-b95a80b861eb.png',
    author: {
      name: 'Creative AI Studio',
      avatar: '/lovable-uploads/7fc80395-bb0d-41ca-9843-b95a80b861eb.png'
    },
    rating: 4.6,
    reviewCount: 89,
    price: 75,
    downloads: 2100,
    tags: ['content', 'marketing', 'automation'],
    createdAt: '2023-08-15T14:20:00Z',
    lastUpdated: '2023-10-22T11:45:00Z'
  },
  {
    id: 'item-3',
    name: 'Code Review Tool',
    description: 'AI-powered tool that analyzes and improves your code quality.',
    category: 'tool',
    imageUrl: '/lovable-uploads/92e31f95-4874-41ef-b38a-12bfb2ea47b3.png',
    author: {
      name: 'Dev Tools Pro',
      avatar: '/lovable-uploads/92e31f95-4874-41ef-b38a-12bfb2ea47b3.png'
    },
    rating: 4.9,
    reviewCount: 212,
    price: 120,
    downloads: 5600,
    tags: ['development', 'code quality', 'productivity'],
    createdAt: '2023-07-05T09:15:00Z',
    lastUpdated: '2023-11-10T16:30:00Z'
  },
  {
    id: 'item-4',
    name: 'Customer Support Template',
    description: 'Ready-to-use template for building AI customer support systems.',
    category: 'template',
    imageUrl: '/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png',
    author: {
      name: 'Service AI',
      avatar: '/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png'
    },
    rating: 4.5,
    reviewCount: 76,
    price: 35,
    downloads: 1850,
    tags: ['customer service', 'support', 'template'],
    createdAt: '2023-09-25T10:40:00Z',
    lastUpdated: '2023-10-30T15:15:00Z'
  },
  {
    id: 'item-5',
    name: 'Document Processing App',
    description: 'Complete app for extracting, analyzing, and organizing document data.',
    category: 'app',
    imageUrl: '/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png',
    author: {
      name: 'Document AI',
      avatar: '/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png'
    },
    rating: 4.7,
    reviewCount: 105,
    price: 95,
    downloads: 2750,
    tags: ['document processing', 'data extraction', 'organization'],
    createdAt: '2023-08-30T08:20:00Z',
    lastUpdated: '2023-11-12T14:45:00Z'
  }
];
