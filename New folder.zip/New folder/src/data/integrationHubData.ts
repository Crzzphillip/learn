
export interface IntegrationItem {
  id: string;
  name: string;
  description: string;
  category: 'api' | 'data' | 'communication' | 'cloud' | 'tools';
  imageUrl: string;
  status: 'active' | 'pending' | 'inactive';
  connectionCount: number;
  lastUsed?: string;
}

export const integrationItems: IntegrationItem[] = [
  {
    id: 'integration-1',
    name: 'OpenAI',
    description: 'Connect with OpenAI models for advanced AI capabilities.',
    category: 'api',
    imageUrl: '/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png',
    status: 'active',
    connectionCount: 15,
    lastUsed: '2023-11-15T09:45:00Z'
  },
  {
    id: 'integration-2',
    name: 'Azure Services',
    description: 'Integrate with Azure cloud services for scalable infrastructure.',
    category: 'cloud',
    imageUrl: '/lovable-uploads/7fc80395-bb0d-41ca-9843-b95a80b861eb.png',
    status: 'active',
    connectionCount: 8,
    lastUsed: '2023-11-10T15:30:00Z'
  },
  {
    id: 'integration-3',
    name: 'Slack',
    description: 'Connect your workflows to Slack for team notifications.',
    category: 'communication',
    imageUrl: '/lovable-uploads/92e31f95-4874-41ef-b38a-12bfb2ea47b3.png',
    status: 'active',
    connectionCount: 12,
    lastUsed: '2023-11-12T13:15:00Z'
  },
  {
    id: 'integration-4',
    name: 'MongoDB',
    description: 'Connect to MongoDB databases for document storage.',
    category: 'data',
    imageUrl: '/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png',
    status: 'pending',
    connectionCount: 0
  },
  {
    id: 'integration-5',
    name: 'Google Cloud',
    description: 'Integrate with Google Cloud Platform services.',
    category: 'cloud',
    imageUrl: '/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png',
    status: 'inactive',
    connectionCount: 3,
    lastUsed: '2023-10-05T11:20:00Z'
  },
  {
    id: 'integration-6',
    name: 'GitHub',
    description: 'Connect with GitHub for code repository integration.',
    category: 'tools',
    imageUrl: '/lovable-uploads/0a1baea5-6a03-47a0-87a5-2d8084ef4e3d.png',
    status: 'active',
    connectionCount: 9,
    lastUsed: '2023-11-14T16:40:00Z'
  }
];
