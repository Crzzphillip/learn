
import { Benchmark } from '@/types/explore';

export const agentBenchmarks: Record<string, Benchmark[]> = {
  "agent-1": [
    {
      id: "bench-a1-1",
      name: "AgentBench",
      score: 87,
      maxScore: 100,
      category: "reasoning",
      description: "Tests reasoning and decision-making in multi-turn, open-ended tasks",
      comparison: {
        avgScore: 68,
        topScore: 92,
        bottomScore: 45
      },
      details: [
        { metric: "System Operation", value: 92, change: "+5%", trend: "up" },
        { metric: "Database Navigation", value: 88, change: "+3%", trend: "up" },
        { metric: "Web Browsing", value: 81, change: "-2%", trend: "down" }
      ],
      lastUpdated: "2025-03-12"
    },
    {
      id: "bench-a1-2",
      name: "τ-Bench",
      score: 78,
      maxScore: 100,
      category: "adaptability",
      description: "Evaluates adaptability in dynamic user and tool interactions",
      comparison: {
        avgScore: 61,
        topScore: 85,
        bottomScore: 42
      },
      details: [
        { metric: "User Adaptation", value: 83, change: "+7%", trend: "up" },
        { metric: "API Handling", value: 75, change: "+2%", trend: "up" },
        { metric: "Policy Adherence", value: 76, change: "+1%", trend: "up" }
      ],
      lastUpdated: "2025-02-28"
    },
    {
      id: "bench-a1-3",
      name: "GAIA",
      score: 56,
      maxScore: 100,
      category: "multi-step",
      description: "Tests general intelligence across reasoning and multi-modal tasks",
      comparison: {
        avgScore: 42,
        topScore: 74,
        bottomScore: 29
      },
      details: [
        { metric: "Complex Planning", value: 48, change: "+13%", trend: "up" },
        { metric: "Tool Usage", value: 62, change: "+10%", trend: "up" },
        { metric: "Information Retrieval", value: 58, change: "+8%", trend: "up" }
      ],
      lastUpdated: "2025-03-15"
    }
  ],
  "agent-2": [
    {
      id: "bench-a2-1",
      name: "MLE-Bench",
      score: 81,
      maxScore: 100,
      category: "tool-use",
      description: "Tests autonomous coding and ML experimentation capabilities",
      comparison: {
        avgScore: 64,
        topScore: 89,
        bottomScore: 48
      },
      details: [
        { metric: "Algorithm Selection", value: 86, change: "+4%", trend: "up" },
        { metric: "Feature Engineering", value: 79, change: "+6%", trend: "up" },
        { metric: "Hyperparameter Tuning", value: 78, change: "+3%", trend: "up" }
      ],
      lastUpdated: "2025-03-10"
    },
    {
      id: "bench-a2-2",
      name: "TheAgentCompany",
      score: 73,
      maxScore: 100,
      category: "planning",
      description: "Simulates a software company environment with coding and team tasks",
      comparison: {
        avgScore: 58,
        topScore: 80,
        bottomScore: 40
      },
      details: [
        { metric: "Code Quality", value: 77, change: "+5%", trend: "up" },
        { metric: "Task Completion", value: 68, change: "+2%", trend: "up" },
        { metric: "Communication", value: 74, change: "+8%", trend: "up" }
      ],
      lastUpdated: "2025-02-20"
    }
  ]
};

export const workflowBenchmarks: Record<string, Benchmark[]> = {
  "workflow-1": [
    {
      id: "bench-w1-1",
      name: "ITBench",
      score: 92,
      maxScore: 100,
      category: "efficiency",
      description: "Measures enterprise IT automation efficiency",
      comparison: {
        avgScore: 74,
        topScore: 95,
        bottomScore: 52
      },
      details: [
        { metric: "Task Automation", value: 94, change: "+6%", trend: "up" },
        { metric: "Error Handling", value: 89, change: "+4%", trend: "up" },
        { metric: "Execution Time", value: 93, change: "+7%", trend: "up" }
      ],
      lastUpdated: "2025-03-18"
    },
    {
      id: "bench-w1-2",
      name: "CollaborativeAgentBench",
      score: 85,
      maxScore: 100,
      category: "human-alignment",
      description: "Tests workflows collaborating with humans on complex tasks",
      comparison: {
        avgScore: 69,
        topScore: 88,
        bottomScore: 45
      },
      details: [
        { metric: "Human Handoff", value: 86, change: "+9%", trend: "up" },
        { metric: "Instruction Following", value: 82, change: "+5%", trend: "up" },
        { metric: "Feedback Integration", value: 87, change: "+11%", trend: "up" }
      ],
      lastUpdated: "2025-03-05"
    }
  ],
  "workflow-2": [
    {
      id: "bench-w2-1",
      name: "ProcessBench",
      score: 76,
      maxScore: 100,
      category: "reliability",
      description: "Evaluates reliability in multi-step business processes",
      comparison: {
        avgScore: 62,
        topScore: 85,
        bottomScore: 40
      },
      details: [
        { metric: "Process Completion", value: 78, change: "+3%", trend: "up" },
        { metric: "Exception Management", value: 74, change: "+5%", trend: "up" },
        { metric: "Data Integrity", value: 76, change: "+4%", trend: "up" }
      ],
      lastUpdated: "2025-02-25"
    }
  ]
};

export const workspaceBenchmarks: Record<string, Benchmark[]> = {
  "workspace-1": [
    {
      id: "bench-ws1-1",
      name: "IntegrationBench",
      score: 88,
      maxScore: 100,
      category: "efficiency",
      description: "Measures efficiency of integrated workspace components",
      comparison: {
        avgScore: 70,
        topScore: 92,
        bottomScore: 48
      },
      details: [
        { metric: "Component Interoperability", value: 91, change: "+7%", trend: "up" },
        { metric: "Resource Usage", value: 84, change: "+3%", trend: "up" },
        { metric: "Response Time", value: 89, change: "+5%", trend: "up" }
      ],
      lastUpdated: "2025-03-14"
    }
  ]
};

export const appBenchmarks: Record<string, Benchmark[]> = {
  "app-1": [
    {
      id: "bench-app1-1",
      name: "UserExperienceBench",
      score: 91,
      maxScore: 100,
      category: "human-alignment",
      description: "Evaluates user experience and interface effectiveness",
      comparison: {
        avgScore: 75,
        topScore: 94,
        bottomScore: 56
      },
      details: [
        { metric: "UI Responsiveness", value: 93, change: "+4%", trend: "up" },
        { metric: "Task Completion Rate", value: 90, change: "+6%", trend: "up" },
        { metric: "User Satisfaction", value: 90, change: "+5%", trend: "up" }
      ],
      lastUpdated: "2025-03-08"
    }
  ]
};

// Function to get benchmarks for any entity by type and ID
export const getBenchmarks = (
  type: 'agent' | 'workflow' | 'workspace' | 'app', 
  id: string
): Benchmark[] => {
  switch(type) {
    case 'agent':
      return agentBenchmarks[id] || [];
    case 'workflow':
      return workflowBenchmarks[id] || [];
    case 'workspace':
      return workspaceBenchmarks[id] || [];
    case 'app':
      return appBenchmarks[id] || [];
    default:
      return [];
  }
};

// Function to get benchmarks by space ID (mock implementation)
export const getBenchmarksBySpace = (spaceId: string): Benchmark[] => {
  // In a real app, you'd query benchmarks related to this space
  // For demo purposes, we'll return a mix of benchmarks
  const allBenchmarks = [
    ...Object.values(agentBenchmarks).flat(),
    ...Object.values(workflowBenchmarks).flat(),
    ...Object.values(workspaceBenchmarks).flat(),
    ...Object.values(appBenchmarks).flat()
  ];
  
  // Filter or transform based on spaceId if needed
  return allBenchmarks.slice(0, 8); // Return first 8 benchmarks for demo
};

// Benchmark categories with descriptions
export const benchmarkCategories = {
  'performance': 'Measures raw processing speed and resource utilization',
  'accuracy': 'Evaluates correctness of outputs and predictions',
  'reliability': 'Tests consistency and stability under various conditions',
  'efficiency': 'Assesses resource usage relative to output quality',
  'cost': 'Measures computational and operational expenses',
  'reasoning': 'Tests logical processing and inference capabilities',
  'planning': 'Evaluates ability to create and execute multi-step plans',
  'adaptability': 'Tests response to changing conditions and requirements',
  'tool-use': 'Assesses effective use of external tools and APIs',
  'multi-step': 'Evaluates performance on complex, multi-stage tasks',
  'human-alignment': 'Measures alignment with human preferences and expectations'
};
