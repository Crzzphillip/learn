
import { Code, Palette, LineChart, Brain, Zap, Globe, Bot, LayoutGrid, Workflow, AppWindow } from "lucide-react";

export const dummyExploreData = {
  agents: [
    {
      id: "agent-1",
      title: "CodeGenius AI",
      description: "Advanced coding assistant with expertise in 20+ programming languages",
      icon: Code,
      category: "Development",
      rating: "4.9",
      listens: "120K",
      image: "/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png",
      tags: ["Coding", "Development", "Assistance"]
    },
    {
      id: "agent-2",
      title: "DesignSense AI",
      description: "Your creative partner for UI/UX design and visual content creation",
      icon: Palette,
      category: "Design",
      rating: "4.8",
      listens: "95K",
      image: "/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png",
      tags: ["Design", "Creative", "UI/UX"]
    },
    {
      id: "agent-3",
      title: "DataWizard AI",
      description: "Turn complex data into actionable insights and visualizations",
      icon: LineChart,
      category: "Analytics",
      rating: "4.7",
      listens: "85K",
      image: "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png",
      tags: ["Data", "Analytics", "Visualization"]
    },
    {
      id: "agent-4",
      title: "ContentMaster AI",
      description: "Generate high-quality content for blogs, marketing, and social media",
      icon: Brain,
      category: "Content",
      rating: "4.8",
      listens: "110K",
      image: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png",
      tags: ["Content", "Writing", "Marketing"]
    },
    {
      id: "agent-5",
      title: "ResearchAssistant AI",
      description: "Accelerate research with intelligent search and analysis capabilities",
      icon: Globe,
      category: "Research",
      rating: "4.6",
      listens: "75K",
      image: "/lovable-uploads/02aed6e2-2911-4e2d-a6c7-36e8e7d361b5.png",
      tags: ["Research", "Academic", "Analysis"]
    },
    {
      id: "agent-6",
      title: "CustomerSupport AI",
      description: "24/7 customer support automation with human-like interactions",
      icon: Bot,
      category: "Support",
      rating: "4.7",
      listens: "90K",
      image: "/lovable-uploads/0a1baea5-6a03-47a0-87a5-2d8084ef4e3d.png",
      tags: ["Support", "Service", "Automation"]
    }
  ],
  
  spaces: [
    {
      id: "space-1",
      title: "Development Hub",
      description: "Comprehensive workspace for software development teams",
      icon: Code,
      category: "Development",
      rating: "4.9",
      listens: "85K",
      image: "/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png",
      tags: ["Development", "Teams", "Collaboration"]
    },
    {
      id: "space-2",
      title: "Design Studio",
      description: "Collaborative space for designers to create and iterate",
      icon: Palette,
      category: "Design",
      rating: "4.8",
      listens: "65K",
      image: "/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png",
      tags: ["Design", "Creative", "Collaboration"]
    },
    {
      id: "space-3",
      title: "Data Analysis Center",
      description: "Turn raw data into actionable business insights",
      icon: LineChart,
      category: "Analytics",
      rating: "4.7",
      listens: "55K",
      image: "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png",
      tags: ["Data", "Analytics", "Business Intelligence"]
    },
    {
      id: "space-4",
      title: "Content Creation Studio",
      description: "Everything you need for content creation and marketing",
      icon: Brain,
      category: "Content",
      rating: "4.8",
      listens: "70K",
      image: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png",
      tags: ["Content", "Marketing", "Creation"]
    },
    {
      id: "space-5",
      title: "Research Lab",
      description: "Advanced tools for academic and scientific research",
      icon: Globe,
      category: "Research",
      rating: "4.6",
      listens: "45K",
      image: "/lovable-uploads/02aed6e2-2911-4e2d-a6c7-36e8e7d361b5.png",
      tags: ["Research", "Academic", "Scientific"]
    },
    {
      id: "space-6",
      title: "Support Center",
      description: "Streamline customer support with AI-powered tools",
      icon: Bot,
      category: "Support",
      rating: "4.7",
      listens: "60K",
      image: "/lovable-uploads/0a1baea5-6a03-47a0-87a5-2d8084ef4e3d.png",
      tags: ["Support", "Customer Service", "Automation"]
    }
  ],
  
  personas: [
    {
      id: "persona-1",
      title: "Developer Assistant",
      description: "Your coding companion with expertise in multiple languages",
      icon: Code,
      category: "Development",
      rating: "4.9",
      listens: "110K",
      image: "/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png",
      tags: ["Coding", "Development", "Assistance"]
    },
    {
      id: "persona-2",
      title: "Creative Director",
      description: "AI persona specialized in creative direction and design thinking",
      icon: Palette,
      category: "Design",
      rating: "4.8",
      listens: "85K",
      image: "/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png",
      tags: ["Design", "Creative", "Direction"]
    },
    {
      id: "persona-3",
      title: "Data Analyst",
      description: "Turn complex data into clear insights and recommendations",
      icon: LineChart,
      category: "Analytics",
      rating: "4.7",
      listens: "75K",
      image: "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png",
      tags: ["Data", "Analytics", "Insights"]
    },
    {
      id: "persona-4",
      title: "Content Strategist",
      description: "Expert in content planning, creation, and optimization",
      icon: Brain,
      category: "Content",
      rating: "4.8",
      listens: "95K",
      image: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png",
      tags: ["Content", "Strategy", "Marketing"]
    },
    {
      id: "persona-5",
      title: "Research Scientist",
      description: "AI researcher with expertise in scientific methodology",
      icon: Globe,
      category: "Research",
      rating: "4.6",
      listens: "65K",
      image: "/lovable-uploads/02aed6e2-2911-4e2d-a6c7-36e8e7d361b5.png",
      tags: ["Research", "Science", "Methodology"]
    },
    {
      id: "persona-6",
      title: "Customer Success Manager",
      description: "Focused on delivering exceptional customer experiences",
      icon: Bot,
      category: "Support",
      rating: "4.7",
      listens: "80K",
      image: "/lovable-uploads/0a1baea5-6a03-47a0-87a5-2d8084ef4e3d.png",
      tags: ["Support", "Success", "Customer"]
    }
  ],
  
  workspaces: [
    {
      id: "workspace-1",
      title: "AI Development Suite",
      description: "Complete workspace for AI development and deployment",
      icon: LayoutGrid,
      category: "Development",
      rating: "4.9",
      listens: "70K",
      image: "/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png",
      tags: ["AI", "Development", "Deployment"]
    },
    {
      id: "workspace-2",
      title: "Creative Studio Pro",
      description: "Integrated workspace for creative professionals",
      icon: Palette,
      category: "Design",
      rating: "4.8",
      listens: "55K",
      image: "/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png",
      tags: ["Creative", "Design", "Professional"]
    },
    {
      id: "workspace-3",
      title: "Data Intelligence Center",
      description: "Comprehensive analytics and data visualization workspace",
      icon: LineChart,
      category: "Analytics",
      rating: "4.7",
      listens: "50K",
      image: "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png",
      tags: ["Data", "Intelligence", "Analytics"]
    },
    {
      id: "workspace-4",
      title: "Content Marketing Hub",
      description: "All-in-one workspace for content creation and distribution",
      icon: Brain,
      category: "Content",
      rating: "4.8",
      listens: "65K",
      image: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png",
      tags: ["Content", "Marketing", "Distribution"]
    },
    {
      id: "workspace-5",
      title: "Research Collaboration Suite",
      description: "Platform for collaborative scientific research",
      icon: Globe,
      category: "Research",
      rating: "4.6",
      listens: "40K",
      image: "/lovable-uploads/02aed6e2-2911-4e2d-a6c7-36e8e7d361b5.png",
      tags: ["Research", "Collaboration", "Science"]
    },
    {
      id: "workspace-6",
      title: "Customer Experience Office",
      description: "Unified workspace for managing customer relationships",
      icon: Bot,
      category: "Support",
      rating: "4.7",
      listens: "45K",
      image: "/lovable-uploads/0a1baea5-6a03-47a0-87a5-2d8084ef4e3d.png",
      tags: ["Customer", "Experience", "Management"]
    }
  ],
  
  workflows: [
    {
      id: "workflow-1",
      title: "CI/CD Pipeline Automation",
      description: "Streamline your development workflow with automated CI/CD",
      icon: Workflow,
      category: "Development",
      rating: "4.9",
      listens: "60K",
      image: "/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png",
      tags: ["CI/CD", "Automation", "DevOps"]
    },
    {
      id: "workflow-2",
      title: "Design System Manager",
      description: "Manage design systems and component libraries efficiently",
      icon: Palette,
      category: "Design",
      rating: "4.8",
      listens: "45K",
      image: "/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png",
      tags: ["Design", "System", "Components"]
    },
    {
      id: "workflow-3",
      title: "Data Processing Pipeline",
      description: "End-to-end data processing and analysis workflow",
      icon: LineChart,
      category: "Analytics",
      rating: "4.7",
      listens: "40K",
      image: "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png",
      tags: ["Data", "Processing", "Analytics"]
    },
    {
      id: "workflow-4",
      title: "Content Production System",
      description: "Streamline content creation from ideation to publication",
      icon: Brain,
      category: "Content",
      rating: "4.8",
      listens: "55K",
      image: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png",
      tags: ["Content", "Production", "Publishing"]
    },
    {
      id: "workflow-5",
      title: "Research Protocol Manager",
      description: "Standardize and automate research protocols",
      icon: Globe,
      category: "Research",
      rating: "4.6",
      listens: "35K",
      image: "/lovable-uploads/02aed6e2-2911-4e2d-a6c7-36e8e7d361b5.png",
      tags: ["Research", "Protocol", "Management"]
    },
    {
      id: "workflow-6",
      title: "Customer Support Workflow",
      description: "Automated customer support ticket management system",
      icon: Bot,
      category: "Support",
      rating: "4.7",
      listens: "50K",
      image: "/lovable-uploads/0a1baea5-6a03-47a0-87a5-2d8084ef4e3d.png",
      tags: ["Support", "Tickets", "Automation"]
    }
  ],
  
  apps: [
    {
      id: "app-1",
      title: "CodeAssist Pro",
      description: "Intelligent code assistance and suggestion app",
      icon: AppWindow,
      category: "Development",
      rating: "4.9",
      listens: "80K",
      image: "/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png",
      tags: ["Code", "Assistance", "Development"]
    },
    {
      id: "app-2",
      title: "DesignVision AI",
      description: "AI-powered design tool for digital products",
      icon: Palette,
      category: "Design",
      rating: "4.8",
      listens: "65K",
      image: "/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png",
      tags: ["Design", "AI", "Tool"]
    },
    {
      id: "app-3",
      title: "DataInsight Dashboard",
      description: "Interactive data visualization and analytics app",
      icon: LineChart,
      category: "Analytics",
      rating: "4.7",
      listens: "60K",
      image: "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png",
      tags: ["Data", "Dashboard", "Analytics"]
    },
    {
      id: "app-4",
      title: "ContentForge AI",
      description: "Advanced content creation and optimization app",
      icon: Brain,
      category: "Content",
      rating: "4.8",
      listens: "75K",
      image: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png",
      tags: ["Content", "Creation", "Optimization"]
    },
    {
      id: "app-5",
      title: "ResearchCompanion",
      description: "Digital assistant for academic and scientific research",
      icon: Globe,
      category: "Research",
      rating: "4.6",
      listens: "55K",
      image: "/lovable-uploads/02aed6e2-2911-4e2d-a6c7-36e8e7d361b5.png",
      tags: ["Research", "Academic", "Assistant"]
    },
    {
      id: "app-6",
      title: "SupportDesk AI",
      description: "Intelligent customer support and ticketing system",
      icon: Bot,
      category: "Support",
      rating: "4.7",
      listens: "70K",
      image: "/lovable-uploads/0a1baea5-6a03-47a0-87a5-2d8084ef4e3d.png",
      tags: ["Support", "Ticketing", "AI"]
    }
  ]
};
