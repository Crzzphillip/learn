
import { Showcase } from '@/types/explore';

export const showcases: Showcase[] = [
  {
    id: '1',
    title: 'Image Generation Showcase',
    category: 'CREATIVE & DESIGN',
    type: 'agent',
    description: 'Transform text descriptions into stunning visual imagery with AI-powered generation tools that adapt to your creative vision.',
    features: [
      'Realistic Renders', 
      'Style Transfer', 
      'AI Art Creation'
    ],
    image: '/lovable-uploads/63ca806d-a9f9-4d6f-aaed-d7330df00964.png',
    stats: {
      users: 12453,
      rating: 4.8,
      efficiency: 92
    },
    author: {
      name: 'Creative AI Labs',
      avatar: '/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png'
    },
    demoUrl: '/showcase/image-generation'
  },
  {
    id: '2',
    title: 'Text-to-Speech Showcase',
    category: 'AUDIO & SPEECH',
    type: 'workflow',
    description: 'Generate natural-sounding speech from text input with control over voice characteristics, emotion, and language support.',
    features: [
      'Natural Voice Synthesis', 
      'Multiple Languages', 
      'Emotional Tone Control'
    ],
    image: '/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png',
    stats: {
      users: 8721,
      rating: 4.6,
      efficiency: 89
    },
    author: {
      name: 'Voice AI Solutions',
      avatar: '/lovable-uploads/0a1baea5-6a03-47a0-87a5-2d8084ef4e3d.png'
    },
    demoUrl: '/showcase/text-to-speech'
  },
  {
    id: '3',
    title: 'Data Visualization Suite',
    category: 'DATA & ANALYTICS',
    type: 'workspace',
    description: 'Transform complex datasets into intuitive visual representations that reveal patterns and insights for informed decision-making.',
    features: [
      'Interactive Dashboards', 
      'Real-time Processing', 
      'Custom Report Generation'
    ],
    image: '/lovable-uploads/0a1baea5-6a03-47a0-87a5-2d8084ef4e3d.png',
    stats: {
      users: 5634,
      rating: 4.7,
      efficiency: 95
    },
    author: {
      name: 'Data Insights Team',
      avatar: '/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png'
    },
    demoUrl: '/showcase/data-visualization'
  },
  {
    id: '4',
    title: 'Code Generation Assistant',
    category: 'DEVELOPMENT & CODING',
    type: 'agent',
    description: 'Accelerate software development with AI-powered code generation across multiple programming languages and frameworks.',
    features: [
      'Multi-language Support', 
      'Testing Generation', 
      'Documentation Builder'
    ],
    image: '/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png',
    stats: {
      users: 15982,
      rating: 4.9,
      efficiency: 97
    },
    author: {
      name: 'DevTools AI',
      avatar: '/lovable-uploads/63ca806d-a9f9-4d6f-aaed-d7330df00964.png'
    },
    demoUrl: '/showcase/code-generation'
  },
  {
    id: '5',
    title: 'Content Writing Platform',
    category: 'CONTENT & MARKETING',
    type: 'app',
    description: 'Generate high-quality marketing content optimized for SEO with brand voice customization and multilingual capabilities.',
    features: [
      'SEO Optimization', 
      'Brand Voice Adaptation', 
      'Multilingual Content'
    ],
    image: '/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png',
    stats: {
      users: 9853,
      rating: 4.5,
      efficiency: 88
    },
    author: {
      name: 'Content AI Solutions',
      avatar: '/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png'
    },
    demoUrl: '/showcase/content-writing'
  },
  {
    id: '6',
    title: 'Healthcare Diagnostic Assistant',
    category: 'HEALTHCARE',
    type: 'workflow',
    description: 'Support medical professionals with AI-powered diagnostic suggestions and treatment recommendations based on patient data.',
    features: [
      'Symptom Analysis', 
      'Treatment Recommendations', 
      'Medical Research Integration'
    ],
    image: '/lovable-uploads/63ca806d-a9f9-4d6f-aaed-d7330df00964.png',
    stats: {
      users: 4521,
      rating: 4.8,
      efficiency: 94
    },
    author: {
      name: 'MedTech AI',
      avatar: '/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png'
    },
    demoUrl: '/showcase/healthcare'
  },
  {
    id: '7',
    title: 'Legal Document Analysis',
    category: 'LEGAL & COMPLIANCE',
    type: 'agent',
    description: 'Automate legal document review and analysis with AI that can identify key clauses, potential risks, and compliance issues.',
    features: [
      'Contract Review', 
      'Compliance Checking', 
      'Legal Research Assistant'
    ],
    image: '/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png',
    stats: {
      users: 3842,
      rating: 4.7,
      efficiency: 91
    },
    author: {
      name: 'LegalTech Solutions',
      avatar: '/lovable-uploads/0a1baea5-6a03-47a0-87a5-2d8084ef4e3d.png'
    },
    demoUrl: '/showcase/legal-analysis'
  },
  {
    id: '8',
    title: 'Financial Planning Assistant',
    category: 'FINANCE',
    type: 'workspace',
    description: 'Provide personalized financial advice and planning based on user financial data, goals, and risk tolerance profiles.',
    features: [
      'Investment Strategies', 
      'Budget Optimization', 
      'Retirement Planning'
    ],
    image: '/lovable-uploads/0a1baea5-6a03-47a0-87a5-2d8084ef4e3d.png',
    stats: {
      users: 7254,
      rating: 4.6,
      efficiency: 89
    },
    author: {
      name: 'FinTech Advisors',
      avatar: '/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png'
    },
    demoUrl: '/showcase/financial-planning'
  }
];

export const showcasesByType = {
  agent: showcases.filter(showcase => showcase.type === 'agent'),
  workflow: showcases.filter(showcase => showcase.type === 'workflow'),
  workspace: showcases.filter(showcase => showcase.type === 'workspace'),
  app: showcases.filter(showcase => showcase.type === 'app')
};

export const showcaseCategories = [
  'CREATIVE & DESIGN',
  'AUDIO & SPEECH',
  'DATA & ANALYTICS',
  'DEVELOPMENT & CODING',
  'CONTENT & MARKETING',
  'HEALTHCARE',
  'LEGAL & COMPLIANCE',
  'FINANCE'
];
