
export interface MCPServerItem {
  id: string;
  name: string;
  status: 'online' | 'offline' | 'maintenance';
  type: 'primary' | 'secondary' | 'backup';
  region: string;
  load: number;
  uptime: string;
  lastPing: string;
  ip: string;
  connections: number;
}

export const mcpServers: MCPServerItem[] = [
  {
    id: 'server-1',
    name: 'MCP-Primary-East',
    status: 'online',
    type: 'primary',
    region: 'East US',
    load: 62,
    uptime: '99.98%',
    lastPing: '2023-11-15T09:55:12Z',
    ip: '10.0.0.1',
    connections: 1256
  },
  {
    id: 'server-2',
    name: 'MCP-Secondary-East',
    status: 'online',
    type: 'secondary',
    region: 'East US',
    load: 48,
    uptime: '99.95%',
    lastPing: '2023-11-15T09:55:36Z',
    ip: '10.0.0.2',
    connections: 876
  },
  {
    id: 'server-3',
    name: 'MCP-Primary-West',
    status: 'online',
    type: 'primary',
    region: 'West US',
    load: 73,
    uptime: '99.92%',
    lastPing: '2023-11-15T09:54:58Z',
    ip: '10.0.1.1',
    connections: 1432
  },
  {
    id: 'server-4',
    name: 'MCP-Backup-East',
    status: 'offline',
    type: 'backup',
    region: 'East US',
    load: 0,
    uptime: '98.56%',
    lastPing: '2023-11-14T22:30:15Z',
    ip: '10.0.0.3',
    connections: 0
  },
  {
    id: 'server-5',
    name: 'MCP-Primary-EU',
    status: 'maintenance',
    type: 'primary',
    region: 'Europe',
    load: 5,
    uptime: '99.75%',
    lastPing: '2023-11-15T08:12:33Z',
    ip: '10.1.0.1',
    connections: 105
  }
];
