
import { Code, Palette, GamepadIcon, LineChart, Smartphone, Globe } from "lucide-react";
import { PopularAgent, FeaturedSpace, Category } from "@/types/explore";

export const popularAgents: PopularAgent[] = [
  {
    id: "agent-1",
    name: "CodeMaster",
    category: "Development",
    posts: "1,234 interactions",
    avatar: "/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png"
  },
  {
    id: "agent-2",
    name: "DesignPro",
    category: "Design",
    posts: "2,345 interactions",
    avatar: "/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png"
  },
  {
    id: "agent-3",
    name: "DataWiz",
    category: "Analytics",
    posts: "3,456 interactions",
    avatar: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png"
  }
];

export const featuredSpaces: FeaturedSpace[] = [
  {
    id: "space-1",
    title: "AI Development Hub",
    description: "Collaborative space for AI developers",
    icon: Code,
    category: "Development",
    listens: "50,000",
    rating: "4.9",
    image: "/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png"
  },
  {
    id: "space-2",
    title: "Creative AI Studio",
    description: "AI-powered creative tools and resources",
    icon: Palette,
    category: "Design",
    listens: "35,000",
    rating: "4.8",
    image: "/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png"
  }
];

export const categories: Category[] = [
  {
    id: "coding",
    title: "Software Development",
    description: "Explore AI-powered coding assistants and development tools",
    icon: Code,
    gradient: "from-blue-500/20 to-cyan-500/20",
    image: "/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png",
    spaces: [
      {
        id: "codecraft",
        title: "CodeCraft AI",
        description: "Expert coding assistant for multiple programming languages",
        icon: Code,
        category: "Development",
        rating: "4.9",
        listens: "100,056",
        duration: "24/7 Available",
        image: "/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png"
      },
      {
        id: "webdev-ai",
        title: "WebDev AI",
        description: "Your intelligent web development companion",
        icon: Code,
        category: "Development",
        rating: "4.8",
        listens: "85,234",
        duration: "24/7 Available",
        image: "/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png"
      },
      {
        id: "backend-buddy",
        title: "Backend Buddy",
        description: "AI assistant specialized in backend development",
        icon: Code,
        category: "Development",
        rating: "4.7",
        listens: "75,129",
        duration: "24/7 Available",
        image: "/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png"
      }
    ]
  },
  {
    id: "gaming",
    title: "Gaming & Entertainment",
    description: "Discover AI companions for gaming and interactive experiences",
    icon: GamepadIcon,
    gradient: "from-purple-500/20 to-pink-500/20",
    image: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png",
    spaces: [
      {
        id: "game-master",
        title: "Game Master AI",
        description: "Your ultimate gaming companion and strategy advisor",
        icon: GamepadIcon,
        category: "Gaming",
        rating: "4.9",
        listens: "120,345",
        duration: "24/7 Available",
        image: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png"
      },
      {
        id: "esports-coach",
        title: "Esports Coach",
        description: "Professional AI coaching for competitive gaming",
        icon: GamepadIcon,
        category: "Gaming",
        rating: "4.8",
        listens: "95,678",
        duration: "24/7 Available",
        image: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png"
      },
      {
        id: "game-dev-assistant",
        title: "Game Dev Assistant",
        description: "AI-powered game development helper",
        icon: GamepadIcon,
        category: "Gaming",
        rating: "4.7",
        listens: "82,431",
        duration: "24/7 Available",
        image: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png"
      }
    ]
  },
  {
    id: "finance",
    title: "Finance & Trading",
    description: "AI-powered tools for financial analysis and trading",
    icon: LineChart,
    gradient: "from-green-500/20 to-emerald-500/20",
    image: "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png",
    spaces: [
      {
        id: "trading-assistant",
        title: "Trading Assistant Pro",
        description: "AI-powered trading insights and analysis",
        icon: LineChart,
        category: "Finance",
        rating: "4.9",
        listens: "150,789",
        duration: "24/7 Available",
        image: "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png"
      },
      {
        id: "finance-advisor",
        title: "Finance Advisor AI",
        description: "Personal finance and investment guidance",
        icon: LineChart,
        category: "Finance",
        rating: "4.8",
        listens: "130,456",
        duration: "24/7 Available",
        image: "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png"
      },
      {
        id: "crypto-analyst",
        title: "Crypto Analyst AI",
        description: "Cryptocurrency market analysis and insights",
        icon: LineChart,
        category: "Finance",
        rating: "4.7",
        listens: "110,234",
        duration: "24/7 Available",
        image: "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png"
      }
    ]
  },
  {
    id: "mobile",
    title: "Mobile Development",
    description: "Build amazing mobile applications with AI assistance",
    icon: Smartphone,
    gradient: "from-orange-500/20 to-red-500/20",
    image: "/lovable-uploads/02aed6e2-2911-4e2d-a6c7-36e8e7d361b5.png",
    spaces: [
      {
        id: "mobile-dev-pro",
        title: "Mobile Dev Pro",
        description: "Complete mobile app development assistant",
        icon: Smartphone,
        category: "Mobile",
        rating: "4.9",
        listens: "90,567",
        duration: "24/7 Available",
        image: "/lovable-uploads/02aed6e2-2911-4e2d-a6c7-36e8e7d361b5.png"
      },
      {
        id: "ios-expert",
        title: "iOS Expert AI",
        description: "Specialized iOS development assistant",
        icon: Smartphone,
        category: "Mobile",
        rating: "4.8",
        listens: "85,234",
        duration: "24/7 Available",
        image: "/lovable-uploads/02aed6e2-2911-4e2d-a6c7-36e8e7d361b5.png"
      },
      {
        id: "android-guru",
        title: "Android Guru",
        description: "Your Android development companion",
        icon: Smartphone,
        category: "Mobile",
        rating: "4.7",
        listens: "80,123",
        duration: "24/7 Available",
        image: "/lovable-uploads/02aed6e2-2911-4e2d-a6c7-36e8e7d361b5.png"
      }
    ]
  },
  {
    id: "web",
    title: "Web Development",
    description: "Create stunning websites with AI-powered tools",
    icon: Globe,
    gradient: "from-indigo-500/20 to-blue-500/20",
    image: "/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png",
    spaces: [
      {
        id: "frontend-master",
        title: "Frontend Master AI",
        description: "Expert assistance for frontend development",
        icon: Globe,
        category: "Web",
        rating: "4.9",
        listens: "95,678",
        duration: "24/7 Available",
        image: "/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png"
      },
      {
        id: "ui-designer",
        title: "UI Designer AI",
        description: "AI-powered UI design assistance",
        icon: Globe,
        category: "Web",
        rating: "4.8",
        listens: "88,345",
        duration: "24/7 Available",
        image: "/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png"
      },
      {
        id: "web-optimizer",
        title: "Web Optimizer",
        description: "Performance optimization for web applications",
        icon: Globe,
        category: "Web",
        rating: "4.7",
        listens: "82,567",
        duration: "24/7 Available",
        image: "/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png"
      }
    ]
  }
];
