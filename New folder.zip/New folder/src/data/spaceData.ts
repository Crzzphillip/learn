import { 
  Code, 
  Users, 
  Zap, 
  Clock, 
  CreditCard, 
  AppWindow, 
  Database, 
  Shield, 
  GitBranch, 
  BookOpen, 
  GraduationCap,
  Wand,
  Image,
  Layers,
  Star,
  Rocket,
  Palette
} from "lucide-react";
import { SpaceCredits, SpaceHierarchy, SpaceStat } from "@/types/space";

export const getSpaceStats = (): SpaceStat[] => {
  return [
    {
      icon: Users,
      label: "Active Developers",
      value: "1.8k"
    },
    {
      icon: Zap,
      label: "Space Credits",
      value: "200"
    },
    {
      icon: Clock,
      label: "Subscription",
      value: "Pro Plan"
    },
    {
      icon: CreditCard,
      label: "Monthly Credits",
      value: "1000"
    }
  ];
};

export const getSpaceHierarchy = (): SpaceHierarchy[] => {
  return [{
    id: 'space-1',
    title: 'Development Space',
    children: [{
      id: 'space-1-1',
      title: 'Frontend Development',
      children: []
    }, {
      id: 'space-1-2',
      title: 'Backend Development',
      children: []
    }]
  }];
};

export const getSpaceCredits = (): SpaceCredits => {
  return {
    balance: 1000,
    usage: {
      agents: 250,
      workflows: 150,
      tools: 100,
      apps: 50
    },
    earnings: 320,
    subscriptionTier: 'pro'
  };
};

export const getReviewItems = () => {
  return [{
    id: 'review-1',
    title: 'Advanced Code Generator Agent',
    description: 'AI-powered code generation with multiple language support',
    type: 'agent' as const,
    author: 'John Doe',
    submittedAt: '2024-03-15',
    status: 'pending' as const
  }, {
    id: 'review-2',
    title: 'Database Schema Designer',
    description: 'Visual database schema design workflow',
    type: 'workflow' as const,
    author: 'Jane Smith',
    submittedAt: '2024-03-14',
    status: 'pending' as const
  }];
};

export const getAgents = () => {
  return [{
    id: "code-assistant",
    title: "Code Assistant",
    description: "AI coding companion for software development and debugging.",
    icon: Code,
    category: "Development",
    rating: "4.9",
    credits: "15",
    locked: false,
    personas: ["Full-stack Dev", "Code Reviewer", "Architect"],
    image: "/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png"
  }, {
    title: "Documentation Writer",
    description: "Generate clear, comprehensive technical documentation.",
    icon: Code,
    category: "Documentation",
    rating: "4.8",
    credits: "10",
    locked: true,
    personas: ["Technical Writer", "API Documenter", "Guide Creator"],
    image: "/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png"
  }, {
    title: "DevOps Engineer",
    description: "Automate deployment pipelines and infrastructure setup.",
    icon: Code,
    category: "DevOps",
    rating: "4.7",
    credits: "20",
    locked: true,
    personas: ["Infrastructure Expert", "Security Specialist"],
    image: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png"
  }, {
    id: "creative-director",
    title: "Creative Director",
    description: "Guide and refine creative concepts with professional vision.",
    icon: Wand,
    category: "Creative",
    rating: "4.9",
    credits: "25",
    locked: false,
    personas: ["Art Director", "Brand Strategist", "Visual Storyteller"],
    image: "/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png"
  }, {
    id: "design-generator",
    title: "Design Generator",
    description: "Create stunning visual designs with professional quality.",
    icon: Palette,
    category: "Design",
    rating: "4.8",
    credits: "15",
    locked: false,
    personas: ["Logo Designer", "UI/UX Designer", "Visual Artist"],
    image: "/lovable-uploads/a7c91920-4306-4301-a915-3c2b53219a6b.png"
  }, {
    id: "content-multiplier",
    title: "Content Multiplier",
    description: "Scale creative content with intelligent variations and adaptations.",
    icon: Layers,
    category: "Content",
    rating: "4.7",
    credits: "20",
    locked: false,
    personas: ["Content Strategist", "Creative Optimizer", "Brand Scaler"],
    image: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png"
  }];
};

export const getWorkflows = () => {
  return [{
    id: "code-review",
    title: "Automated Code Review",
    description: "End-to-end code review and optimization workflow. Used by 234 developers to improve code quality.",
    agents: ["Code Assistant (Code Reviewer)", "Documentation Writer (Technical Writer)"],
    credits: "25",
    locked: false,
    image: "/lovable-uploads/02aed6e2-2911-4e2d-a6c7-36e8e7d361b5.png",
    author: {
      name: "Sarah Chen",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah",
      role: "Senior Developer"
    },
    usageStats: {
      runs: "1.2k",
      copies: "234",
      rating: "4.9"
    }
  }, {
    title: "CI/CD Pipeline Setup",
    description: "Complete deployment pipeline setup and configuration. Popular among DevOps teams for quick infrastructure setup.",
    agents: ["DevOps Engineer (Infrastructure Expert)", "Code Assistant (Architect)"],
    credits: "35",
    locked: true,
    image: "/lovable-uploads/ea7ece53-211d-4668-ade8-28de9d6f41ee.png",
    author: {
      name: "Mike Patel",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Mike",
      role: "DevOps Lead"
    },
    usageStats: {
      runs: "856",
      copies: "189",
      rating: "4.8"
    }
  }];
};

export const getApps = () => {
  return [{
    id: "code-analyzer",
    title: "Code Analyzer",
    description: "Analyze and optimize your codebase with AI assistance.",
    icon: AppWindow,
    credits: "30",
    locked: false,
    image: "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png"
  }, {
    title: "API Builder",
    description: "Design and document APIs with automated testing.",
    icon: AppWindow,
    credits: "40",
    locked: true,
    image: "/lovable-uploads/92e31f95-4874-41ef-b38a-12bfb2ea47b3.png"
  }];
};

export const getTools = () => {
  return [{
    id: "git-tools",
    title: "Git Integration Tools",
    description: "Streamline your Git workflow with branch management and PR automation.",
    icon: GitBranch,
    credits: "10",
    locked: false,
    image: "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png",
    category: "version-control"
  }, {
    id: "schema-designer",
    title: "Database Schema Designer",
    description: "Visual database schema design with AI-powered optimization.",
    icon: Database,
    credits: "15",
    locked: false,
    image: "/lovable-uploads/92e31f95-4874-41ef-b38a-12bfb2ea47b3.png",
    category: "database"
  }, {
    id: "security-scanner",
    title: "Security Scanner",
    description: "Automated security vulnerability detection and fixes.",
    icon: Shield,
    credits: "20",
    locked: true,
    image: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png",
    category: "security"
  }];
};

export const getEnhancedWorkflows = () => {
  return [{
    id: "project-setup",
    title: "Full Project Setup",
    description: "Complete project initialization with repository, CI/CD, and documentation.",
    agents: ["DevOps Engineer (Infrastructure Expert)", "Documentation Writer (Technical Writer)"],
    credits: "40",
    locked: false,
    image: "/lovable-uploads/02aed6e2-2911-4e2d-a6c7-36e8e7d361b5.png"
  }, {
    id: "team-onboarding",
    title: "Team Onboarding",
    description: "Streamlined developer onboarding with automated setup and documentation.",
    agents: ["Code Assistant (Architect)", "Documentation Writer (Guide Creator)"],
    credits: "30",
    locked: true,
    image: "/lovable-uploads/ea7ece53-211d-4668-ade8-28de9d6f41ee.png"
  }];
};

export const getResources = () => {
  return [{
    id: "code-templates",
    title: "Code Templates",
    description: "Curated collection of production-ready code templates.",
    icon: Code,
    category: "Development",
    rating: "4.9",
    credits: "5",
    locked: false,
    type: "Template Library",
    image: "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png"
  }, {
    id: "best-practices",
    title: "Best Practices Guide",
    description: "Comprehensive guide for modern development practices.",
    icon: BookOpen,
    category: "Learning",
    rating: "4.8",
    credits: "10",
    locked: false,
    type: "Documentation",
    image: "/lovable-uploads/92e31f95-4874-41ef-b38a-12bfb2ea47b3.png"
  }, {
    id: "learning-paths",
    title: "Learning Paths",
    description: "Structured learning paths for various technologies.",
    icon: GraduationCap,
    category: "Education",
    rating: "4.7",
    credits: "15",
    locked: true,
    type: "Course",
    image: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png"
  }];
};

export const getFeaturedWorkflows = () => {
  return [{
    id: "fullstack-setup",
    title: "Full-Stack App Setup",
    description: "Complete setup for a React + Node.js application with authentication and database integration.",
    agents: ["Code Assistant (Full-stack Dev)", "DevOps Engineer (Infrastructure Expert)"],
    credits: "45",
    locked: false,
    image: "/lovable-uploads/02aed6e2-2911-4e2d-a6c7-36e8e7d361b5.png",
    author: {
      name: "Alex Rivera",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alex",
      role: "Lead Developer"
    },
    usageStats: {
      runs: "2.3k",
      copies: "567",
      rating: "4.9"
    },
    tags: ["Featured", "Most Copied"]
  }, {
    id: "api-development",
    title: "REST API Development",
    description: "Structured workflow for designing, implementing, and documenting RESTful APIs.",
    agents: ["Code Assistant (Backend Dev)", "Documentation Writer (API Documenter)"],
    credits: "30",
    locked: false,
    image: "/lovable-uploads/92e31f95-4874-41ef-b38a-12bfb2ea47b3.png",
    author: {
      name: "Emma Wilson",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Emma",
      role: "API Architect"
    },
    usageStats: {
      runs: "1.8k",
      copies: "432",
      rating: "4.8"
    },
    tags: ["Featured", "Trending"]
  }];
};

export const getTrendingWorkspaces = () => {
  return [
    {
      id: "trending-workflow-1",
      title: "E-commerce Store Builder",
      description: "Create a complete e-commerce store with product listings, cart, and checkout in minutes.",
      savedCredits: 220,
      totalCredits: 300,
      owner: {
        name: "Sarah Johnson",
        avatar: "https://randomuser.me/api/portraits/women/44.jpg"
      },
      testimonial: "Just saved 220 credits using this new e-commerce shop builder workflow. Built my entire store in under an hour!",
      reviews: 48,
      upvotes: 218,
      price: {
        value: 25,
        type: "credits"
      },
      usageStats: {
        users: 723,
        runs: 1482,
        lastRun: "5m ago"
      },
      tags: ["e-commerce", "store", "automated"],
      successRate: 98
    },
    {
      id: "trending-workflow-2",
      title: "AI Content Creation Suite",
      description: "Generate blog posts, product descriptions, and marketing copy with advanced AI.",
      savedCredits: 150,
      totalCredits: 200,
      owner: {
        name: "Michael Chen",
        avatar: "https://randomuser.me/api/portraits/men/32.jpg"
      },
      testimonial: "Created a month's worth of content in just one afternoon. This workflow is a game-changer!",
      reviews: 36,
      upvotes: 187,
      price: {
        value: 30,
        type: "credits"
      },
      usageStats: {
        users: 512,
        runs: 978,
        lastRun: "12m ago"
      },
      tags: ["content", "AI", "marketing"],
      successRate: 95
    },
    {
      id: "trending-workflow-3",
      title: "SEO Performance Optimizer",
      description: "Analyze and optimize your website's SEO performance with actionable insights.",
      savedCredits: 180,
      totalCredits: 250,
      owner: {
        name: "Alex Rodriguez",
        avatar: "https://randomuser.me/api/portraits/men/67.jpg"
      },
      testimonial: "Boosted our site's ranking for key terms by 35% in just two weeks. Worth every credit!",
      reviews: 29,
      upvotes: 156,
      price: {
        value: 20,
        type: "credits"
      },
      usageStats: {
        users: 438,
        runs: 762,
        lastRun: "1h ago"
      },
      tags: ["SEO", "analytics", "optimization"],
      successRate: 93
    },
    {
      id: "trending-workflow-4",
      title: "Full-Stack App Scaffolder",
      description: "Generate a complete React/Node.js application structure with database integration.",
      savedCredits: 300,
      totalCredits: 400,
      owner: {
        name: "Jessica Patel",
        avatar: "https://randomuser.me/api/portraits/women/23.jpg"
      },
      testimonial: "Saved weeks of boilerplate setup. Got my MVP up and running in just two days!",
      reviews: 52,
      upvotes: 245,
      price: {
        value: 40,
        type: "credits"
      },
      usageStats: {
        users: 845,
        runs: 1678,
        lastRun: "3m ago"
      },
      tags: ["development", "full-stack", "React", "Node.js"],
      successRate: 97
    }
  ];
};

export const getFloraWorkflows = () => {
  return [{
    id: "logo-variation",
    title: "Logo Design Multiplier",
    description: "Generate 100+ variations of your logo with professional quality and control.",
    agents: ["Design Generator (Logo Designer)", "Creative Director (Brand Strategist)"],
    credits: "30",
    locked: false,
    image: "/lovable-uploads/02aed6e2-2911-4e2d-a6c7-36e8e7d361b5.png",
    author: {
      name: "Emma Chen",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Emma",
      role: "Lead Designer"
    },
    usageStats: {
      runs: "3.4k",
      copies: "678",
      rating: "4.9"
    },
    tags: ["Featured", "Popular"]
  }, {
    id: "video-generation",
    title: "Video Content Creation",
    description: "Transform static images into mind-blowing videos with multiple model options.",
    agents: ["Content Multiplier (Creative Optimizer)", "Creative Director (Visual Storyteller)"],
    credits: "45",
    locked: false,
    image: "/lovable-uploads/ea7ece53-211d-4668-ade8-28de9d6f41ee.png",
    author: {
      name: "Alex Rivera",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alex",
      role: "Video Producer"
    },
    usageStats: {
      runs: "2.1k",
      copies: "412",
      rating: "4.8"
    },
    tags: ["Featured", "Trending"]
  }, {
    id: "brand-identity",
    title: "Complete Brand Identity",
    description: "Create a cohesive brand identity with logo, color palette, typography, and visual elements.",
    agents: ["Design Generator (UI/UX Designer)", "Creative Director (Brand Strategist)"],
    credits: "60",
    locked: false,
    image: "/lovable-uploads/92e31f95-4874-41ef-b38a-12bfb2ea47b3.png",
    author: {
      name: "Sophia Johnson",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sophia",
      role: "Brand Designer"
    },
    usageStats: {
      runs: "1.8k",
      copies: "326",
      rating: "4.9"
    },
    tags: ["Featured", "Best Seller"]
  }];
};

export const getFloraTools = () => {
  return [{
    id: "runway-integration",
    title: "Runway Integration",
    description: "Generate high-quality videos from images with advanced AI models.",
    icon: Image,
    credits: "25",
    locked: false,
    image: "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png",
    category: "video-generation"
  }, {
    id: "luma-integration",
    title: "Luma Integration",
    description: "Create realistic 3D assets and animations with advanced AI.",
    icon: Star,
    credits: "30",
    locked: false,
    image: "/lovable-uploads/92e31f95-4874-41ef-b38a-12bfb2ea47b3.png",
    category: "3d-generation"
  }, {
    id: "creative-multiplier",
    title: "Creative Multiplier",
    description: "Scale your creative work with controlled variations and iterations.",
    icon: Rocket,
    credits: "20",
    locked: false,
    image: "/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png",
    category: "scaling"
  }, {
    id: "design-studio",
    title: "AI Design Studio",
    description: "Professional-grade design tools with AI assistance and control.",
    icon: Palette,
    credits: "35",
    locked: false,
    image: "/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png",
    category: "design"
  }];
};
