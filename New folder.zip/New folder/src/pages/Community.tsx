import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowRight, 
  Users, 
  MessageSquare, 
  Trophy, 
  Award,
  Code,
  Brain,
  Palette,
  Image,
  Music,
  ChevronLeft,
  Search,
  Grid3X3,
  List
} from 'lucide-react';
import Sidebar from "@/components/Layout/Sidebar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Category, CategorySpace } from "@/types/explore";

// Featured community data
const featuredCommunity = {
  id: 'featured-1',
  title: 'AI Developer Hub',
  description: 'Join a thriving community of AI developers, researchers, and enthusiasts. Share knowledge, collaborate on projects, and explore the future of AI together.',
  image: '/ai-hub-hero.jpg',
  members: '15.2K',
  discussions: '3.8K',
  icon: Code,
};

// Mock data - replace with actual data fetching
const communities = [
  {
    id: '1',
    title: 'Machine Learning Community',
    description: 'Deep dive into ML algorithms, neural networks, and practical applications',
    image: '/community-ml.jpg',
    icon: Brain,
    stats: {
      members: '8.2K',
      discussions: '2.3K',
      rating: '4.8'
    },
    tags: ['Machine Learning', 'Neural Networks', 'Data Science']
  },
  {
    id: '2',
    title: 'Creative AI Lab',
    description: 'Explore the intersection of AI and creativity in art, music, and design',
    image: '/community-creative.jpg',
    icon: Palette,
    stats: {
      members: '6.4K',
      discussions: '1.8K',
      rating: '4.7'
    },
    tags: ['AI Art', 'Music Generation', 'Creative Tech']
  },
  {
    id: '3',
    title: 'NLP Research Group',
    description: 'Advanced discussions on natural language processing and language models',
    image: '/community-nlp.jpg',
    icon: MessageSquare,
    stats: {
      members: '5.1K',
      discussions: '1.5K',
      rating: '4.9'
    },
    tags: ['NLP', 'Language Models', 'Research']
  },
  {
    id: '4',
    title: 'AI Ethics Forum',
    description: 'Discussing the ethical implications and responsible development of AI',
    image: '/community-ethics.jpg',
    icon: Award,
    stats: {
      members: '4.8K',
      discussions: '2.1K',
      rating: '4.8'
    },
    tags: ['Ethics', 'Responsible AI', 'Policy']
  },
  {
    id: '5',
    title: 'Computer Vision Hub',
    description: 'Explore image processing, object detection, and visual AI applications',
    image: '/community-vision.jpg',
    icon: Image,
    stats: {
      members: '7.3K',
      discussions: '1.9K',
      rating: '4.7'
    },
    tags: ['Computer Vision', 'Image Processing', 'Object Detection']
  },
  {
    id: '6',
    title: 'AI Music Collective',
    description: 'Creating and exploring AI-powered music composition and sound design',
    image: '/community-music.jpg',
    icon: Music,
    stats: {
      members: '3.9K',
      discussions: '1.2K',
      rating: '4.6'
    },
    tags: ['AI Music', 'Sound Design', 'Composition']
  }
];

const CommunityPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isHovering, setIsHovering] = useState<{[key: string]: boolean}>({});

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="border-b border-white/10">
          <div className="container py-4">
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => navigate(-1)}
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>
              <h1 className="text-xl font-semibold">Discover Communities</h1>
              <div className="ml-auto flex items-center gap-4">
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    placeholder="Search communities..."
                    className="pl-9"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    className={viewMode === 'grid' ? 'bg-primary/20' : ''}
                    onClick={() => setViewMode('grid')}
                  >
                    <Grid3X3 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className={viewMode === 'list' ? 'bg-primary/20' : ''}
                    onClick={() => setViewMode('list')}
                  >
                    <List className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
      </div>

        <div className="flex-1 overflow-auto">
          {/* Featured Community Hero */}
          <div 
            className="relative h-[400px] bg-gradient-to-br from-primary/20 to-primary/40 cursor-pointer"
            onClick={() => navigate(`/community/${featuredCommunity.id}`)}
          >
            <img 
              src={featuredCommunity.image}
              alt={featuredCommunity.title}
              className="w-full h-full object-cover opacity-40"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent" />
            <div className="absolute inset-0 flex items-center">
              <div className="container">
                <div className="max-w-2xl">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 rounded-xl bg-primary/20 grid place-items-center">
                      <featuredCommunity.icon className="w-6 h-6 text-primary" />
                    </div>
                    <h1 className="text-4xl font-bold">{featuredCommunity.title}</h1>
                  </div>
                  <p className="text-xl text-white/80 mb-6">{featuredCommunity.description}</p>
                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-2">
                      <Users className="w-5 h-5 text-primary" />
                      <span>{featuredCommunity.members} members</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MessageSquare className="w-5 h-5 text-primary" />
                      <span>{featuredCommunity.discussions} discussions</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Communities Grid */}
          <div className="container py-12">
            <div className={viewMode === 'grid' ? 
              "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : 
              "space-y-4"
            }>
              {communities.map(community => (
                <Card 
                  key={community.id}
                  className={`group relative overflow-hidden bg-card/50 border-primary/10 hover:bg-card/70 transition-all duration-300 cursor-pointer ${
                    viewMode === 'list' ? 'flex gap-6' : ''
                  }`}
                  onClick={() => navigate(`/community/${community.id}`)}
                >
                  <div className={`relative ${viewMode === 'list' ? 'w-48' : 'h-48'}`}>
                    <img 
                      src={community.image}
                      alt={community.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent" />
                  </div>
                  
                  <div className="p-6 flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/20 grid place-items-center">
                        <community.icon className="w-5 h-5 text-primary" />
                      </div>
                      <h3 className="font-semibold text-lg">{community.title}</h3>
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-4">{community.description}</p>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {community.tags.map((tag, index) => (
                        <span key={index} className="text-sm px-2.5 py-1 rounded-full bg-primary/20 text-primary">
                          {tag}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">{community.stats.members}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MessageSquare className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">{community.stats.discussions}</span>
                      </div>
                      <div className="flex items-center gap-1 ml-auto">
                        <span className="text-sm font-medium text-primary">★</span>
                        <span className="text-sm text-muted-foreground">{community.stats.rating}</span>
                      </div>
                    </div>
                  </div>

                  <div className="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-primary/40 to-primary opacity-0 group-hover:opacity-100 transition-opacity" />
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CommunityPage;