
import { useParams } from "react-router-dom";
import Sidebar from "@/components/Layout/Sidebar";
import { getWorkflows, getFeaturedWorkflows } from "@/data/spaceData";
import WorkflowsSection from "@/components/Space/WorkflowsSection";
import FeaturedWorkflowsSection from "@/components/Space/FeaturedWorkflowsSection";
import BackToSpace from "@/components/Space/BackToSpace";
import SpaceLeftSidebar from "@/components/Space/SpaceLeftSidebar";
import PageSearchBar from "@/components/Space/PageSearchBar";
import { useState } from "react";

const WorkflowsPage = () => {
  const { spaceId } = useParams();
  const allWorkflows = getWorkflows();
  const allFeaturedWorkflows = getFeaturedWorkflows();
  const [workflows, setWorkflows] = useState(allWorkflows);
  const [featuredWorkflows, setFeaturedWorkflows] = useState(allFeaturedWorkflows);

  const handleSearch = (query: string) => {
    if (query.trim() === "") {
      setWorkflows(allWorkflows);
      setFeaturedWorkflows(allFeaturedWorkflows);
      return;
    }
    
    const lowercaseQuery = query.toLowerCase();
    
    const filteredWorkflows = allWorkflows.filter(workflow => 
      workflow.title.toLowerCase().includes(lowercaseQuery) || 
      workflow.description.toLowerCase().includes(lowercaseQuery)
    );
    
    const filteredFeaturedWorkflows = allFeaturedWorkflows.filter(workflow => 
      workflow.title.toLowerCase().includes(lowercaseQuery) || 
      workflow.description.toLowerCase().includes(lowercaseQuery)
    );
    
    setWorkflows(filteredWorkflows);
    setFeaturedWorkflows(filteredFeaturedWorkflows);
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex">
        <SpaceLeftSidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <main className="flex-1 overflow-auto">
            <div className="container py-8">
              <div className="flex items-center justify-between mb-6">
                <BackToSpace spaceId={spaceId || ""} />
                <PageSearchBar 
                  placeholder="Search workflows..." 
                  onSearch={handleSearch}
                />
              </div>
              
              <div className="mb-8">
                <h1 className="text-3xl font-bold mb-2">Workflows</h1>
                <p className="text-muted-foreground">
                  Browse and use workflows available in this space
                </p>
              </div>
              
              <FeaturedWorkflowsSection workflows={featuredWorkflows} />
              <WorkflowsSection workflows={workflows} />
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default WorkflowsPage;
