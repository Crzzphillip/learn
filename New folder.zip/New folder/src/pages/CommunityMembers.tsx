import { useState } from "react";
import { useParams } from "react-router-dom";
import { Users, Search, Plus, Mail, Star, Award, Trophy, Lightbulb } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";

const CommunityMembers = () => {
  const { spaceId } = useParams();
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  // Mock data for members
  const members = [
    {
      id: 1,
      name: "Alex Chen",
      avatar: "/avatars/alex.jpg",
      role: "AI Engineer",
      joined: "2 months ago",
      contributions: 45,
      expertise: ["AI", "ML", "Deployment"],
      isOnline: true
    },
    {
      id: 2,
      name: "Sarah Johnson",
      avatar: "/avatars/sarah.jpg",
      role: "Data Scientist",
      joined: "1 month ago",
      contributions: 32,
      expertise: ["Data Analysis", "Python", "Statistics"],
      isOnline: false
    },
    // ... more members
  ];

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Community Members</h1>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search members..."
              className="pl-8 w-64"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button size="sm" className="gap-2">
            <Plus className="w-4 h-4" />
            Invite Members
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-8">
          {/* Members List */}
          <Card className="bg-card/50 border-primary/10">
            <CardContent className="p-4">
              <div className="space-y-4">
                {members.map((member) => (
                  <div key={member.id} className="flex items-center gap-4 p-4 rounded-lg hover:bg-black/20">
                    <div className="relative">
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={member.avatar} />
                        <AvatarFallback>{member.name[0]}</AvatarFallback>
                      </Avatar>
                      {member.isOnline && (
                        <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-background" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{member.name}</h3>
                        <Badge variant="secondary">{member.role}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">Joined {member.joined}</p>
                      <div className="flex items-center gap-2 mt-2">
                        {member.expertise.map((skill) => (
                          <Badge key={skill} variant="outline">{skill}</Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="icon">
                        <Mail className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Star className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="col-span-4">
          {/* Community Stats */}
          <Card className="bg-card/50 border-primary/10 mb-6">
            <CardHeader>
              <CardTitle className="text-lg">Community Stats</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Total Members</span>
                  <span className="font-medium">1,250</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Active Members</span>
                  <span className="font-medium">342</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">New This Week</span>
                  <span className="font-medium">45</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Top Contributors */}
          <Card className="bg-card/50 border-primary/10">
            <CardHeader>
              <CardTitle className="text-lg">Top Contributors</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {members.slice(0, 3).map((member) => (
                  <div key={member.id} className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={member.avatar} />
                      <AvatarFallback>{member.name[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="font-medium">{member.name}</p>
                      <p className="text-sm text-muted-foreground">{member.contributions} contributions</p>
                    </div>
                    <Award className="w-4 h-4 text-yellow-500" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CommunityMembers; 