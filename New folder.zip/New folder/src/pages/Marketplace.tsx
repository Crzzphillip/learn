
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import Sidebar from '@/components/Layout/Sidebar';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import BackToSpace from '@/components/Space/BackToSpace';
import SpaceLeftSidebar from '@/components/Space/SpaceLeftSidebar';
import { Search, ShoppingCart, Filter, Star } from 'lucide-react';
import { MarketplaceItem } from '@/data/marketplaceData';
import { marketplaceService } from '@/services/marketplaceService';
import MarketplaceItemCard from '@/components/Marketplace/MarketplaceItemCard';
import { toast } from 'sonner';

const Marketplace = () => {
  const { spaceId } = useParams();
  const [items, setItems] = useState<MarketplaceItem[]>([]);
  const [filteredItems, setFilteredItems] = useState<MarketplaceItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const [sortBy, setSortBy] = useState('popular');
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    const fetchItems = async () => {
      try {
        const data = await marketplaceService.getMarketplaceItems();
        setItems(data);
        setFilteredItems(data);
        setIsLoading(false);
      } catch (error) {
        console.error("Failed to fetch marketplace items:", error);
        toast.error("Failed to load marketplace items. Please try again.");
        setIsLoading(false);
      }
    };
    
    fetchItems();
  }, []);
  
  useEffect(() => {
    let result = items;
    
    // Apply search filter
    if (searchQuery) {
      result = result.filter(item => 
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }
    
    // Apply tab filter
    if (activeTab !== 'all') {
      result = result.filter(item => item.category === activeTab);
    }
    
    // Apply sorting
    result = [...result].sort((a, b) => {
      switch (sortBy) {
        case 'popular':
          return b.downloads - a.downloads;
        case 'rating':
          return b.rating - a.rating;
        case 'price-low':
          return a.price - b.price;
        case 'price-high':
          return b.price - a.price;
        case 'newest':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        default:
          return 0;
      }
    });
    
    setFilteredItems(result);
  }, [searchQuery, activeTab, sortBy, items]);
  
  const handlePurchase = async (id: string) => {
    const success = await marketplaceService.purchaseItem(id);
  };
  
  const handleDownload = async (id: string) => {
    const success = await marketplaceService.downloadItem(id);
    if (success) {
      const updatedItems = items.map(item => {
        if (item.id === id) {
          return { ...item, downloads: item.downloads + 1 };
        }
        return item;
      });
      setItems(updatedItems);
    }
  };
  
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex">
        <SpaceLeftSidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <main className="flex-1 overflow-auto">
            <div className="container py-6">
              <BackToSpace spaceId={spaceId || ""} />
              
              <div className="flex items-center justify-between mb-6">
                <h1 className="text-2xl font-bold">Marketplace</h1>
                <div className="flex items-center gap-2">
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-[160px]">
                      <SelectValue placeholder="Sort By" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="popular">Most Popular</SelectItem>
                      <SelectItem value="rating">Highest Rated</SelectItem>
                      <SelectItem value="price-low">Price: Low to High</SelectItem>
                      <SelectItem value="price-high">Price: High to Low</SelectItem>
                      <SelectItem value="newest">Newest First</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="mb-6">
                <div className="relative">
                  <Search className="absolute top-3 left-3 h-4 w-4 text-muted-foreground" />
                  <Input 
                    className="pl-10" 
                    placeholder="Search for tools, agents, workflows..." 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <div className="flex items-center justify-between mb-4">
                  <TabsList>
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="agent">Agents</TabsTrigger>
                    <TabsTrigger value="workflow">Workflows</TabsTrigger>
                    <TabsTrigger value="tool">Tools</TabsTrigger>
                    <TabsTrigger value="template">Templates</TabsTrigger>
                    <TabsTrigger value="app">Apps</TabsTrigger>
                  </TabsList>
                  
                  <Button variant="outline" size="sm" className="gap-2">
                    <Filter className="w-4 h-4" />
                    Filter
                  </Button>
                </div>
                
                <TabsContent value="all" className="space-y-0 mt-0">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredItems.map(item => (
                      <MarketplaceItemCard 
                        key={item.id} 
                        item={item} 
                        onPurchase={handlePurchase}
                        onDownload={handleDownload}
                      />
                    ))}
                  </div>
                </TabsContent>
                
                {['agent', 'workflow', 'tool', 'template', 'app'].map(category => (
                  <TabsContent key={category} value={category} className="space-y-0 mt-0">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {filteredItems.map(item => (
                        <MarketplaceItemCard 
                          key={item.id} 
                          item={item} 
                          onPurchase={handlePurchase}
                          onDownload={handleDownload}
                        />
                      ))}
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default Marketplace;
