
import { useState } from "react";
import { useParams } from "react-router-dom";
import Sidebar from "@/components/Layout/Sidebar";
import SpaceBanner from "@/components/Space/SpaceBanner";
import SpaceLeftSidebar from "@/components/Space/SpaceLeftSidebar";
import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";
import { getSpaceStats } from "@/data/spaceData";
import { spaceTemplates } from "@/config/spaceTemplates";
import { getResources } from "@/data/spaceData";
import AgentCard from "@/components/Space/AgentCard";

const ResourcesPage = () => {
  const { spaceId } = useParams();
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  
  // Get stats, template, and resources data
  const stats = getSpaceStats();
  const spaceTemplate = spaceTemplates[spaceId as string] || spaceTemplates.development;
  const resources = getResources();

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-auto">
          <SpaceBanner stats={stats} template={spaceTemplate} />
          
          <div className="container py-6">
            {/* Mobile Sidebar Toggle */}
            <div className="md:hidden mb-4">
              <Button 
                variant="outline" 
                size="sm" 
                className="gap-2" 
                onClick={() => setShowMobileSidebar(!showMobileSidebar)}
              >
                <Menu className="h-4 w-4" />
                Menu
              </Button>
            </div>
          </div>
          
          <div className="container pb-12 grid grid-cols-12 gap-6 relative">
            {/* Space Left Sidebar - Hidden on mobile, visible on desktop */}
            <div className="hidden md:block col-span-3 sticky top-6 max-h-[calc(100vh-8rem)]">
              <SpaceLeftSidebar />
            </div>
            
            {/* Mobile Sidebar - Conditionally rendered */}
            {showMobileSidebar && (
              <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 md:hidden">
                <div className="h-full w-64 p-4">
                  <SpaceLeftSidebar onClose={() => setShowMobileSidebar(false)} />
                </div>
              </div>
            )}

            {/* Main content area */}
            <div className="col-span-12 md:col-span-9 space-y-8">
              <div>
                <h1 className="text-3xl font-bold mb-6">Learning Resources</h1>
                <p className="text-muted-foreground mb-8">
                  Explore educational content, tutorials, and learning resources to enhance your skills and knowledge.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {resources.map((resource) => (
                    <AgentCard 
                      key={resource.id}
                      {...resource}
                      personas={[resource.type]}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ResourcesPage;
