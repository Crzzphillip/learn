
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Sidebar from "@/components/Layout/Sidebar";
import SpaceLeftSidebar from "@/components/Space/SpaceLeftSidebar";
import BackToSpace from "@/components/Space/BackToSpace";
import BenchmarkGrid from "@/components/Benchmarks/BenchmarkGrid";
import { benchmarkService } from "@/services/benchmarkService";
import { Benchmark, BenchmarkCategory } from "@/types/explore";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, ChartBar, Award, Zap, Brain } from "lucide-react";
import { Button } from "@/components/ui/button";
import { benchmarkCategories } from "@/data/benchmarksData";
import { Progress } from "@/components/ui/progress";

const SpaceBenchmarks = () => {
  const { spaceId } = useParams();
  const navigate = useNavigate();
  const [benchmarks, setBenchmarks] = useState<Benchmark[]>([]);
  const [agentBenchmarks, setAgentBenchmarks] = useState<Benchmark[]>([]);
  const [workflowBenchmarks, setWorkflowBenchmarks] = useState<Benchmark[]>([]);
  const [workspaceBenchmarks, setWorkspaceBenchmarks] = useState<Benchmark[]>([]);
  const [appBenchmarks, setAppBenchmarks] = useState<Benchmark[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<string>("overview");
  const [selectedCategory, setSelectedCategory] = useState<BenchmarkCategory | 'all'>('all');

  useEffect(() => {
    const fetchBenchmarks = async () => {
      try {
        setIsLoading(true);
        
        // Get all benchmarks for the space
        const spaceData = await benchmarkService.getSpaceBenchmarks(spaceId || "");
        setBenchmarks(spaceData);
        
        // Mock data - in a real app these would be filtered from an API
        // Get benchmarks for specific entity types
        const agentData = spaceData.filter(b => b.id.includes("a"));
        const workflowData = spaceData.filter(b => b.id.includes("w"));
        const workspaceData = spaceData.filter(b => b.id.includes("ws"));
        const appData = spaceData.filter(b => b.id.includes("app"));
        
        setAgentBenchmarks(agentData);
        setWorkflowBenchmarks(workflowData);
        setWorkspaceBenchmarks(workspaceData);
        setAppBenchmarks(appData);
      } catch (error) {
        console.error("Error fetching benchmarks:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchBenchmarks();
  }, [spaceId]);

  const handleGoBack = () => {
    navigate(`/space/${spaceId}`);
  };

  const getAverageScore = (benchmarks: Benchmark[]): number => {
    if (benchmarks.length === 0) return 0;
    const sum = benchmarks.reduce((acc, b) => acc + b.score, 0);
    return Math.round(sum / benchmarks.length);
  };

  const getCategoryScores = (benchmarks: Benchmark[]): Record<string, number> => {
    const categories = {} as Record<string, { sum: number, count: number }>;
    
    benchmarks.forEach(b => {
      if (!categories[b.category]) {
        categories[b.category] = { sum: 0, count: 0 };
      }
      categories[b.category].sum += b.score;
      categories[b.category].count += 1;
    });
    
    const result = {} as Record<string, number>;
    Object.entries(categories).forEach(([category, data]) => {
      result[category] = Math.round(data.sum / data.count);
    });
    
    return result;
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <SpaceLeftSidebar />
      
      <div className="flex-1 container max-w-6xl py-8">
        <BackToSpace spaceId={spaceId || ""} />
        
        <div className="flex items-center gap-4 mb-8">
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full" 
            onClick={handleGoBack}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <ChartBar className="h-8 w-8" />
            Performance Benchmarks
          </h1>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-8">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="agents">Agents</TabsTrigger>
            <TabsTrigger value="workflows">Workflows</TabsTrigger>
            <TabsTrigger value="workspaces">Workspaces</TabsTrigger>
            <TabsTrigger value="apps">Apps</TabsTrigger>
            <TabsTrigger value="categories">By Category</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <Card className="bg-card/50 border-primary/10">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-muted-foreground">Average Score</p>
                      <h3 className="text-3xl font-bold mt-1">{getAverageScore(benchmarks)}/100</h3>
                    </div>
                    <Award className="h-8 w-8 text-primary" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-card/50 border-primary/10">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-muted-foreground">Total Benchmarks</p>
                      <h3 className="text-3xl font-bold mt-1">{benchmarks.length}</h3>
                    </div>
                    <ChartBar className="h-8 w-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-card/50 border-primary/10">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-muted-foreground">Best Category</p>
                      <h3 className="text-3xl font-bold mt-1">
                        {Object.entries(getCategoryScores(benchmarks))
                          .sort(([, a], [, b]) => b - a)[0]?.[0] || "N/A"}
                      </h3>
                    </div>
                    <Brain className="h-8 w-8 text-indigo-500" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-card/50 border-primary/10">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-muted-foreground">Last Updated</p>
                      <h3 className="text-xl font-bold mt-1">
                        {benchmarks[0]?.lastUpdated || "N/A"}
                      </h3>
                    </div>
                    <Zap className="h-8 w-8 text-amber-500" />
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <Card className="bg-card/50 border-primary/10">
                <CardHeader>
                  <CardTitle>Category Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {Object.entries(getCategoryScores(benchmarks))
                      .sort(([, a], [, b]) => b - a)
                      .map(([category, score]) => (
                        <div key={category} className="space-y-1">
                          <div className="flex justify-between items-center text-sm">
                            <span className="capitalize">{category}</span>
                            <span className="font-medium">{score}/100</span>
                          </div>
                          <Progress 
                            value={score} 
                            className="h-2" 
                            indicatorClassName={score >= 80 ? "bg-emerald-500" : score >= 60 ? "bg-blue-500" : "bg-amber-500"}
                          />
                        </div>
                      ))
                    }
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-card/50 border-primary/10">
                <CardHeader>
                  <CardTitle>Entity Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-sm">
                        <span>Agents</span>
                        <span className="font-medium">{getAverageScore(agentBenchmarks)}/100</span>
                      </div>
                      <Progress 
                        value={getAverageScore(agentBenchmarks)} 
                        className="h-2" 
                        indicatorClassName="bg-indigo-500"
                      />
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-sm">
                        <span>Workflows</span>
                        <span className="font-medium">{getAverageScore(workflowBenchmarks)}/100</span>
                      </div>
                      <Progress 
                        value={getAverageScore(workflowBenchmarks)} 
                        className="h-2" 
                        indicatorClassName="bg-blue-500"
                      />
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-sm">
                        <span>Workspaces</span>
                        <span className="font-medium">{getAverageScore(workspaceBenchmarks)}/100</span>
                      </div>
                      <Progress 
                        value={getAverageScore(workspaceBenchmarks)} 
                        className="h-2" 
                        indicatorClassName="bg-purple-500"
                      />
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-sm">
                        <span>Apps</span>
                        <span className="font-medium">{getAverageScore(appBenchmarks)}/100</span>
                      </div>
                      <Progress 
                        value={getAverageScore(appBenchmarks)} 
                        className="h-2" 
                        indicatorClassName="bg-green-500"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <h2 className="text-2xl font-semibold mb-6">Recent Benchmarks</h2>
            <BenchmarkGrid 
              benchmarks={benchmarks.slice(0, 6)} 
              compact={true}
              showCategories={false}
              loading={isLoading}
            />
          </TabsContent>
          
          <TabsContent value="agents">
            <BenchmarkGrid 
              benchmarks={agentBenchmarks} 
              title="Agent Benchmarks" 
              loading={isLoading}
            />
          </TabsContent>
          
          <TabsContent value="workflows">
            <BenchmarkGrid 
              benchmarks={workflowBenchmarks} 
              title="Workflow Benchmarks" 
              loading={isLoading}
            />
          </TabsContent>
          
          <TabsContent value="workspaces">
            <BenchmarkGrid 
              benchmarks={workspaceBenchmarks} 
              title="Workspace Benchmarks" 
              loading={isLoading}
            />
          </TabsContent>
          
          <TabsContent value="apps">
            <BenchmarkGrid 
              benchmarks={appBenchmarks} 
              title="App Benchmarks" 
              loading={isLoading}
            />
          </TabsContent>
          
          <TabsContent value="categories">
            <Tabs 
              value={selectedCategory} 
              onValueChange={(value) => setSelectedCategory(value as BenchmarkCategory | 'all')}
            >
              <TabsList className="mb-6">
                <TabsTrigger value="all">All Categories</TabsTrigger>
                {Object.keys(benchmarkCategories).map(category => (
                  <TabsTrigger key={category} value={category}>
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </TabsTrigger>
                ))}
              </TabsList>
              
              <TabsContent value="all">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                  {Object.entries(benchmarkCategories).map(([category, description]) => (
                    <Card key={category} className="bg-card/50 border-primary/10">
                      <CardHeader className="pb-2">
                        <CardTitle className="capitalize text-lg">
                          {category.replace(/-/g, ' ')} Benchmarks
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground text-sm mb-4">{description}</p>
                        <div className="flex justify-between items-center">
                          <span>Average Score</span>
                          <span className="font-bold">
                            {getAverageScore(benchmarks.filter(b => b.category === category))}/100
                          </span>
                        </div>
                        <Progress 
                          value={getAverageScore(benchmarks.filter(b => b.category === category))} 
                          className="h-2 mt-2" 
                        />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              {Object.keys(benchmarkCategories).map(category => (
                <TabsContent key={category} value={category}>
                  <BenchmarkGrid 
                    benchmarks={benchmarks.filter(b => b.category === category)} 
                    title={`${category.charAt(0).toUpperCase() + category.slice(1)} Benchmarks`}
                    showCategories={false}
                    loading={isLoading}
                  />
                </TabsContent>
              ))}
            </Tabs>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default SpaceBenchmarks;
