
import { useState } from 'react';
import { useParams } from 'react-router-dom';
import Sidebar from '@/components/Layout/Sidebar';
import SpaceLeftSidebar from '@/components/Space/SpaceLeftSidebar';
import BackToSpace from '@/components/Space/BackToSpace';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Search, Users, Lock, Key, UserPlus, UserMinus, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';

const SecurityPermissions = () => {
  const { spaceId } = useParams();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('users');

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex">
        <SpaceLeftSidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <main className="flex-1 overflow-auto">
            <div className="container py-6">
              <BackToSpace spaceId={spaceId || ""} />
              
              <div className="flex items-center justify-between mb-6">
                <h1 className="text-2xl font-bold">Security & Permissions</h1>
                <Button className="gap-2">
                  <UserPlus className="w-4 h-4" />
                  Add User
                </Button>
              </div>
              
              <div className="mb-6">
                <div className="relative">
                  <Search className="absolute top-3 left-3 h-4 w-4 text-muted-foreground" />
                  <Input 
                    className="pl-10" 
                    placeholder="Search users, roles or permissions..." 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <div className="flex items-center justify-between mb-4">
                  <TabsList>
                    <TabsTrigger value="users">Users</TabsTrigger>
                    <TabsTrigger value="roles">Roles</TabsTrigger>
                    <TabsTrigger value="permissions">Permissions</TabsTrigger>
                    <TabsTrigger value="audit">Audit Log</TabsTrigger>
                  </TabsList>
                </div>
                
                <TabsContent value="users" className="space-y-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle>Users & Access</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <p className="text-muted-foreground">Manage user access and permissions for this space.</p>
                        {/* User list would go here */}
                        <div className="text-center py-8 text-muted-foreground">
                          User management interface to be implemented
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="roles" className="space-y-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle>Role Management</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <p className="text-muted-foreground">Define and manage roles for this space.</p>
                        {/* Role management interface would go here */}
                        <div className="text-center py-8 text-muted-foreground">
                          Role management interface to be implemented
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="permissions" className="space-y-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle>Permission Settings</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <p className="text-muted-foreground">Configure granular permissions for different resources.</p>
                        {/* Permission settings would go here */}
                        <div className="text-center py-8 text-muted-foreground">
                          Permission configuration interface to be implemented
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="audit" className="space-y-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle>Audit Log</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <p className="text-muted-foreground">View security-related events and activities.</p>
                        {/* Audit log would go here */}
                        <div className="text-center py-8 text-muted-foreground">
                          Audit log interface to be implemented
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default SecurityPermissions;
