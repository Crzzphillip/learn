import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Edit, Star, Activity, Users, Code, Image } from "lucide-react";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import Sidebar from "@/components/Layout/Sidebar";
import PersonaDetails from "@/components/Persona/PersonaDetails";
import PersonaReview from "@/components/Persona/PersonaReview";
import PersonaUseCases from "@/components/Persona/PersonaUseCases";
import PersonaShowcases from "@/components/Persona/PersonaShowcases";
import { dummyExploreData } from "@/data/dummyExploreData";

const Persona = () => {
  const { personaId } = useParams<{ personaId: string }>();
  const navigate = useNavigate();
  const [persona, setPersona] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("details");

  useEffect(() => {
    const fetchPersona = async () => {
      try {
        setIsLoading(true);
        // In a real app, this would be an API call
        // For now, we'll use the dummy data
        setTimeout(() => {
          const foundPersona = dummyExploreData.personas.find(p => p.id === personaId);
          
          if (foundPersona) {
            setPersona(foundPersona);
          } else {
            toast.error("Persona not found");
            navigate("/explore/personas");
          }
          
          setIsLoading(false);
        }, 800);
      } catch (error) {
        console.error("Error fetching persona:", error);
        toast.error("Failed to load persona");
        setIsLoading(false);
      }
    };

    if (personaId) {
      fetchPersona();
    }
  }, [personaId, navigate]);

  const handleEditPersona = () => {
    toast.info("Edit functionality will be implemented soon!");
  };

  const handleGoBack = () => {
    navigate("/explore/personas");
  };

  if (isLoading) {
    return (
      <div className="flex h-screen bg-background">
        <Sidebar />
        <div className="flex-1 flex justify-center items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (!persona) {
    return (
      <div className="flex h-screen bg-background">
        <Sidebar />
        <div className="flex-1 p-8">
          <div className="flex flex-col items-center justify-center h-full">
            <h2 className="text-2xl font-semibold mb-4">Persona not found</h2>
            <Button onClick={handleGoBack}>Back to Personas</Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="container py-8">
          <div className="flex items-center gap-2 mb-6">
            <Button variant="ghost" size="icon" onClick={handleGoBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-3xl font-bold">{persona.title}</h1>
            <Button variant="outline" size="sm" className="ml-auto gap-2" onClick={handleEditPersona}>
              <Edit className="w-4 h-4" />
              Edit Persona
            </Button>
          </div>

          <Card className="p-6 mb-6 bg-card/50 border-primary/10">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="w-full md:w-1/3 lg:w-1/4">
                <div className="relative aspect-square rounded-xl overflow-hidden border border-primary/10 bg-black/20">
                  <img
                    src={persona.image}
                    alt={persona.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              <div className="w-full md:w-2/3 lg:w-3/4">
                <h2 className="text-2xl font-semibold mb-2">{persona.title}</h2>
                <p className="text-muted-foreground mb-4">{persona.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {persona.tags && persona.tags.map((tag: string) => (
                    <span key={tag} className="px-2.5 py-0.5 rounded-full bg-primary/10 text-primary text-xs">
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="flex flex-col items-center p-3 rounded-lg bg-black/20 border border-primary/10">
                    <Star className="w-5 h-5 text-primary mb-1" />
                    <span className="font-semibold">{persona.rating}</span>
                    <span className="text-xs text-muted-foreground">Rating</span>
                  </div>
                  <div className="flex flex-col items-center p-3 rounded-lg bg-black/20 border border-primary/10">
                    <Activity className="w-5 h-5 text-primary mb-1" />
                    <span className="font-semibold">{persona.listens}</span>
                    <span className="text-xs text-muted-foreground">Interactions</span>
                  </div>
                  <div className="flex flex-col items-center p-3 rounded-lg bg-black/20 border border-primary/10">
                    <Users className="w-5 h-5 text-primary mb-1" />
                    <span className="font-semibold">14.3K</span>
                    <span className="text-xs text-muted-foreground">Users</span>
                  </div>
                  <div className="flex flex-col items-center p-3 rounded-lg bg-black/20 border border-primary/10">
                    <Code className="w-5 h-5 text-primary mb-1" />
                    <span className="font-semibold">3.2K</span>
                    <span className="text-xs text-muted-foreground">Projects</span>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="mb-6">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="review">Reviews</TabsTrigger>
              <TabsTrigger value="usecases">Use Cases</TabsTrigger>
              <TabsTrigger value="showcases">Showcases</TabsTrigger>
            </TabsList>
            <TabsContent value="details">
              <PersonaDetails personaId={personaId || ""} />
            </TabsContent>
            <TabsContent value="review">
              <PersonaReview personaId={personaId || ""} />
            </TabsContent>
            <TabsContent value="usecases">
              <PersonaUseCases personaId={personaId || ""} />
            </TabsContent>
            <TabsContent value="showcases">
              <PersonaShowcases personaId={personaId || ""} />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Persona;
