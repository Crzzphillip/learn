
import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Calendar, Clock, Tag } from "lucide-react";
import { format } from "date-fns";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { blogService, BlogPost } from "@/services/blogService";
import Sidebar from "@/components/Layout/Sidebar";
import { toast } from "sonner";

const BlogPostPage = () => {
  const { blogId } = useParams<{ blogId: string }>();
  const navigate = useNavigate();
  const [post, setPost] = useState<BlogPost | null>(null);
  const [loading, setLoading] = useState(true);
  const [relatedPosts, setRelatedPosts] = useState<BlogPost[]>([]);

  useEffect(() => {
    const fetchPost = async () => {
      setLoading(true);
      try {
        // Try to fetch by ID first
        let fetchedPost = await blogService.getPostById(blogId || "");
        
        // If not found, try to fetch by slug
        if (!fetchedPost && blogId) {
          fetchedPost = await blogService.getPostBySlug(blogId);
        }
        
        if (fetchedPost) {
          setPost(fetchedPost);
          
          // Fetch related posts in the same category
          const related = await blogService.getPostsByCategory(fetchedPost.category);
          setRelatedPosts(related.filter(p => p.id !== fetchedPost.id).slice(0, 3));
        } else {
          toast.error("Blog post not found");
          navigate("/blog");
        }
      } catch (error) {
        console.error("Error fetching blog post:", error);
        toast.error("Failed to load blog post");
      } finally {
        setLoading(false);
      }
    };
    
    if (blogId) {
      fetchPost();
    }
  }, [blogId, navigate]);

  const handleBack = () => {
    navigate("/blog");
  };

  if (loading) {
    return (
      <div className="flex h-screen bg-background">
        <Sidebar />
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-pulse flex flex-col items-center">
            <div className="h-8 w-64 bg-primary/20 rounded mb-4"></div>
            <div className="h-4 w-32 bg-primary/20 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="flex h-screen bg-background">
        <Sidebar />
        <div className="flex-1 flex flex-col items-center justify-center">
          <h2 className="text-2xl font-bold mb-4">Blog Post Not Found</h2>
          <Button onClick={handleBack}>Return to Blog</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-auto">
        <div className="container py-12 max-w-4xl mx-auto">
          <Button 
            variant="ghost" 
            size="sm" 
            className="mb-6 -ml-2" 
            onClick={handleBack}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Blog
          </Button>
          
          {/* Featured Image */}
          <div className="rounded-xl overflow-hidden mb-8 h-[300px] bg-black">
            <img 
              src={post.featuredImage || "https://placehold.co/1200x600/232323/FFFFFF/png?text=Blog+Post"} 
              alt={post.title}
              className="w-full h-full object-cover"
            />
          </div>
          
          {/* Title and Meta */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-4">{post.title}</h1>
            
            <div className="flex items-center gap-6 text-muted-foreground mb-6">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>{format(new Date(post.publishedAt), 'MMMM d, yyyy')}</span>
              </div>
              
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span>{post.readTime} min read</span>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Avatar className="h-10 w-10">
                <AvatarImage src={post.author.avatar} alt={post.author.name} />
                <AvatarFallback>{post.author.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{post.author.name}</p>
                <p className="text-sm text-muted-foreground">Author</p>
              </div>
            </div>
          </div>
          
          <Separator className="my-8" />
          
          {/* Content */}
          <div className="prose prose-invert max-w-none">
            <div dangerouslySetInnerHTML={{ __html: post.content }} />
          </div>
          
          {/* Tags */}
          <div className="mt-8 mb-12">
            <div className="flex flex-wrap gap-2">
              {post.tags.map(tag => (
                <Badge key={tag} variant="outline" className="bg-primary/10">
                  <Tag className="h-3 w-3 mr-1" />
                  {tag}
                </Badge>
              ))}
            </div>
          </div>
          
          {/* Related Posts */}
          {relatedPosts.length > 0 && (
            <div className="mt-12">
              <h3 className="text-2xl font-bold mb-6">Related Posts</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {relatedPosts.map(related => (
                  <div 
                    key={related.id} 
                    className="rounded-lg overflow-hidden border border-primary/10 cursor-pointer hover:bg-black/20 transition"
                    onClick={() => navigate(`/blog/${related.slug}`)}
                  >
                    <div className="h-40 bg-black">
                      <img 
                        src={related.featuredImage || "https://placehold.co/800x400/232323/FFFFFF/png?text=Related+Post"} 
                        alt={related.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="p-4">
                      <h4 className="font-semibold mb-2 line-clamp-2">{related.title}</h4>
                      <p className="text-sm text-muted-foreground line-clamp-2">{related.excerpt}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BlogPostPage;
