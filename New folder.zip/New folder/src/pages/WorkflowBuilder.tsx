import { useCallback, useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  ReactFlow,
  MiniMap,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
  Edge,
  Node,
  Panel,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { Bot, Zap, Play, Plus } from 'lucide-react';
import Sidebar from '@/components/Layout/Sidebar';
import { Button } from '@/components/ui/button';
import FluxAssistant from '@/components/Workflow/FluxAssistant';
import WorkflowToolbar from '@/components/Workflow/WorkflowToolbar';
import WorkspaceManager from '@/components/Workspace/WorkspaceManager';
import AgentNode from '@/components/Workflow/nodes/AgentNode';
import ActionNode from '@/components/Workflow/nodes/ActionNode';
import TriggerNode from '@/components/Workflow/nodes/TriggerNode';
import BackToSpace from '@/components/Space/BackToSpace';
import CollaborationIndicators from '@/components/Workspace/CollaborationIndicators';

const nodeTypes = {
  agent: AgentNode,
  action: ActionNode,
  trigger: TriggerNode,
};

const initialNodes: Node[] = [
  {
    id: 'trigger-1',
    type: 'trigger',
    data: { label: 'Start Workflow' },
    position: { x: 400, y: 100 },
  },
];

const initialEdges: Edge[] = [];

const WorkflowBuilder = () => {
  const { spaceId } = useParams();
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  const addNode = (type: 'agent' | 'action' | 'trigger') => {
    const newNode = {
      id: `${type}-${nodes.length + 1}`,
      type,
      data: {
        label: type === 'agent' ? 'New Agent' : type === 'action' ? 'New Action' : 'New Trigger',
      },
      position: { x: 400, y: Math.random() * 300 + 100 },
    };

    setNodes((nds) => [...nds, newNode]);
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <div className="container py-4">
          <BackToSpace spaceId={spaceId || ""} />
        </div>
        <WorkflowToolbar />
        <div className="flex-1 relative">
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            nodeTypes={nodeTypes}
            fitView
          >
            <Background />
            <Controls />
            <MiniMap />
            <Panel position="top-left" className="bg-background/95 p-4 rounded-lg shadow-lg m-4">
              <div className="space-y-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full gap-2"
                  onClick={() => addNode('trigger')}
                >
                  <Play className="w-4 h-4" />
                  Add Trigger
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full gap-2"
                  onClick={() => addNode('agent')}
                >
                  <Bot className="w-4 h-4" />
                  Add Agent
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full gap-2"
                  onClick={() => addNode('action')}
                >
                  <Zap className="w-4 h-4" />
                  Add Action
                </Button>
              </div>
            </Panel>
            
            <CollaborationIndicators workspaceId="ws-1" />
          </ReactFlow>
          <WorkspaceManager />
          <FluxAssistant />
        </div>
      </div>
    </div>
  );
};

export default WorkflowBuilder;
