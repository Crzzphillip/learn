import { useState } from "react";
import { useParams } from "react-router-dom";
import { Calendar, Search, Plus, Clock, MapPin, Users, Share2, Bookmark } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const CommunityEvents = () => {
  const { spaceId } = useParams();
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [viewMode, setViewMode] = useState("upcoming");

  // Mock data for events
  const events = [
    {
      id: 1,
      title: "AI Workshop: Building Your First Model",
      description: "Learn the fundamentals of AI model development in this hands-on workshop",
      type: "Workshop",
      date: "2024-03-15",
      time: "14:00",
      location: "Virtual",
      attendees: 45,
      maxAttendees: 50,
      organizer: {
        name: "Tech Community",
        avatar: "/avatars/tech-community.jpg"
      },
      tags: ["AI", "Workshop", "Beginner"],
      status: "upcoming"
    },
    {
      id: 2,
      title: "Monthly Community Meetup",
      description: "Join us for our monthly community gathering and networking event",
      type: "Meetup",
      date: "2024-03-20",
      time: "18:00",
      location: "Community Hub",
      attendees: 28,
      maxAttendees: 30,
      organizer: {
        name: "Community Team",
        avatar: "/avatars/community-team.jpg"
      },
      tags: ["Networking", "Social"],
      status: "upcoming"
    },
    // ... more events
  ];

  const eventTypes = [
    { value: "all", label: "All Events" },
    { value: "workshop", label: "Workshops" },
    { value: "meetup", label: "Meetups" },
    { value: "webinar", label: "Webinars" },
    { value: "hackathon", label: "Hackathons" }
  ];

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Community Events</h1>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search events..."
              className="pl-8 w-64"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              {eventTypes.map((type) => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button size="sm" className="gap-2">
            <Plus className="w-4 h-4" />
            Create Event
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-8">
          {/* Events List */}
          <Card className="bg-card/50 border-primary/10">
            <CardContent className="p-4">
              <div className="space-y-4">
                {events.map((event) => (
                  <div key={event.id} className="flex items-start gap-4 p-4 rounded-lg hover:bg-black/20">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <Calendar className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{event.title}</h3>
                        <Badge variant="secondary">{event.type}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{event.description}</p>
                      <div className="flex items-center gap-2 mt-2">
                        {event.tags.map((tag) => (
                          <Badge key={tag} variant="outline">{tag}</Badge>
                        ))}
                      </div>
                      <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {event.date} at {event.time}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          {event.location}
                        </span>
                        <span className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          {event.attendees}/{event.maxAttendees} attending
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="icon">
                        <Share2 className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Bookmark className="w-4 h-4" />
                      </Button>
                      <Button size="sm">Join Event</Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="col-span-4">
          {/* Upcoming Events */}
          <Card className="bg-card/50 border-primary/10 mb-6">
            <CardHeader>
              <CardTitle className="text-lg">Upcoming Events</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {events.slice(0, 3).map((event) => (
                  <div key={event.id} className="flex items-center gap-3">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <Calendar className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{event.title}</p>
                      <p className="text-sm text-muted-foreground">
                        {event.date} • {event.attendees} attending
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Event Categories */}
          <Card className="bg-card/50 border-primary/10">
            <CardHeader>
              <CardTitle className="text-lg">Event Types</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {eventTypes.map((type) => (
                  <div key={type.value} className="flex items-center justify-between p-2 rounded-lg hover:bg-black/20">
                    <span>{type.label}</span>
                    <Badge variant="secondary">12</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CommunityEvents; 