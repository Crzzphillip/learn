
import { useParams } from "react-router-dom";
import Sidebar from "@/components/Layout/Sidebar";
import { getAgents } from "@/data/spaceData";
import AgentsSection from "@/components/Space/AgentsSection";
import BackToSpace from "@/components/Space/BackToSpace";
import SpaceLeftSidebar from "@/components/Space/SpaceLeftSidebar";
import PageSearchBar from "@/components/Space/PageSearchBar";
import { useState } from "react";

const AgentsPage = () => {
  const { spaceId } = useParams();
  const allAgents = getAgents();
  const [agents, setAgents] = useState(allAgents);

  const handleSearch = (query: string) => {
    if (query.trim() === "") {
      setAgents(allAgents);
      return;
    }
    
    const lowercaseQuery = query.toLowerCase();
    const filteredAgents = allAgents.filter(agent => 
      agent.title.toLowerCase().includes(lowercaseQuery) || 
      agent.description.toLowerCase().includes(lowercaseQuery)
    );
    
    setAgents(filteredAgents);
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex">
        <SpaceLeftSidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <main className="flex-1 overflow-auto">
            <div className="container py-8">
              <div className="flex items-center justify-between mb-6">
                <BackToSpace spaceId={spaceId || ""} />
                <PageSearchBar 
                  placeholder="Search agents..." 
                  onSearch={handleSearch}
                />
              </div>
              
              <div className="mb-8">
                <h1 className="text-3xl font-bold mb-2">AI Agents</h1>
                <p className="text-muted-foreground">
                  Browse and use AI agents available in this space
                </p>
              </div>
              
              <AgentsSection agents={agents} />
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default AgentsPage;
