import { useParams } from "react-router-dom";
import Sidebar from "@/components/Layout/Sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, Users, Plus, Star, ArrowRight, Zap, Video, Timer, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import BackToSpace from "@/components/Space/BackToSpace";
import SpaceLeftSidebar from "@/components/Space/SpaceLeftSidebar";
import CreditBadge from "@/components/Space/CreditBadge";
import { SpaceTemplate } from "@/types/space";

// Mock workshops data
const WORKSHOPS = [
  {
    id: 'ws-1',
    title: 'Advanced AI Prompt Engineering',
    description: 'Learn techniques to craft effective prompts for AI systems and optimize outputs',
    creator: { name: 'Alex Morgan', avatar: '/lovable-uploads/0a1baea5-6a03-47a0-87a5-2d8084ef4e3d.png' },
    participants: 24,
    favorites: 18,
    nextSession: '2023-07-15T14:30:00Z',
    duration: 90,
    credits: '15',
    tags: ['AI', 'Prompt', 'Optimization'],
    template: {
      type: 'development',
      title: 'Development Workshop',
      description: 'Coding and development focused workshops',
      gradient: 'from-[#1A1F2C] to-[#7E69AB]',
      icon: Video,
      primaryColor: '#7E69AB',
      secondaryColor: '#1A1F2C',
      accentColor: '#9F8AC1'
    } as SpaceTemplate
  },
  {
    id: 'ws-2',
    title: 'Design Systems Workshop',
    description: 'Build consistent, scalable design systems using AI-powered tools',
    creator: { name: 'Morgan Freeman', avatar: '/lovable-uploads/02aed6e2-2911-4e2d-a6c7-36e8e7d361b5.png' },
    participants: 18,
    favorites: 12,
    nextSession: '2023-07-16T16:00:00Z',
    duration: 120,
    credits: '20',
    tags: ['Design', 'UI/UX', 'Systems'],
    template: {
      type: 'creative',
      title: 'Creative Workshop',
      description: 'Creative and design-focused workshops',
      gradient: 'from-[#D946EF] to-[#8B5CF6]',
      icon: Video,
      primaryColor: '#D946EF',
      secondaryColor: '#8B5CF6',
      accentColor: '#E37EF3'
    } as SpaceTemplate
  },
  {
    id: 'ws-3',
    title: 'AI Workflow Automation',
    description: 'Automate complex workflows using AI agents and custom tools',
    creator: { name: 'Jane Doe', avatar: '/lovable-uploads/34e44087-065a-4d4c-b862-dfcb994cf8a5.png' },
    participants: 32,
    favorites: 24,
    nextSession: '2023-07-17T10:00:00Z',
    duration: 60,
    credits: '10',
    tags: ['Automation', 'Workflow', 'Productivity'],
    template: {
      type: 'productivity',
      title: 'Productivity Workshop',
      description: 'Productivity and workflow optimization workshops',
      gradient: 'from-[#F59E0B] to-[#EF4444]',
      icon: Video,
      primaryColor: '#F59E0B',
      secondaryColor: '#EF4444',
      accentColor: '#FBBF24'
    } as SpaceTemplate
  }
];

const WorkshopsPage = () => {
  const { spaceId } = useParams();

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex">
        <SpaceLeftSidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <main className="flex-1 overflow-auto">
            <div className="container py-8">
              <BackToSpace spaceId={spaceId || ""} />
              
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h1 className="text-3xl font-bold mb-2">Live Workshops</h1>
                  <p className="text-muted-foreground">
                    Interactive sessions where teams can collaborate and learn in real-time
                  </p>
                </div>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Workshop
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {WORKSHOPS.map((workshop) => (
                  <Card key={workshop.id} className="hover:shadow-md transition-shadow group overflow-hidden">
                    <div 
                      className={`h-2 w-full ${workshop.template.gradient}`}
                    />
                    <CardHeader className="pb-2">
                      <CardTitle>{workshop.title}</CardTitle>
                      <CardDescription className="line-clamp-2">{workshop.description}</CardDescription>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={workshop.creator.avatar} />
                          <AvatarFallback>{workshop.creator.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="text-sm">
                          Hosted by <span className="font-medium">{workshop.creator.name}</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1 text-sm">
                          <Calendar className="w-4 h-4 text-muted-foreground" />
                          <span>{formatDate(workshop.nextSession)}</span>
                        </div>
                        <div className="flex items-center gap-1 text-sm">
                          <Timer className="w-4 h-4 text-muted-foreground" />
                          <span>{workshop.duration} min</span>
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap gap-2">
                        {workshop.tags.map((tag, index) => (
                          <Badge key={index} variant="outline" className="bg-black/5">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <CreditBadge amount={workshop.credits} />
                        <div className="flex items-center gap-3 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Users className="w-4 h-4" />
                            <span>{workshop.participants}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4" />
                            <span>{workshop.favorites}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                    
                    <CardFooter className="border-t pt-4">
                      <Button 
                        className="w-full gap-2 group-hover:bg-primary/90"
                        variant="default"
                      >
                        Join Workshop
                        <ArrowRight className="w-4 h-4" />
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
                
                <Card className="hover:shadow-md transition-shadow border-dashed border-2 border-muted">
                  <div className="flex flex-col items-center justify-center h-full py-12">
                    <div className="w-12 h-12 rounded-full bg-muted/50 flex items-center justify-center mb-4">
                      <Plus className="w-6 h-6 text-muted-foreground" />
                    </div>
                    <h3 className="text-xl font-medium mb-2">Host a Workshop</h3>
                    <p className="text-muted-foreground text-center mb-6 max-w-xs">
                      Share your knowledge and collaborate with others in real-time
                    </p>
                    <Button className="gap-2">
                      <Plus className="w-4 h-4" />
                      Create Workshop
                    </Button>
                  </div>
                </Card>
              </div>
              
              <div className="mt-12">
                <h2 className="text-2xl font-bold mb-4">About Workshops</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <Zap className="w-5 h-5 text-primary" />
                      Live Collaboration
                    </h3>
                    <p className="text-muted-foreground">
                      Workshops provide a structured environment for real-time collaboration, allowing teams to work together on projects, share knowledge, and learn new skills.
                    </p>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <Clock className="w-5 h-5 text-primary" />
                      Scheduled Sessions
                    </h3>
                    <p className="text-muted-foreground">
                      Join scheduled workshop sessions with experts and peers. Each session is focused on specific topics or skills, with opportunities for hands-on practice and Q&A.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default WorkshopsPage;
