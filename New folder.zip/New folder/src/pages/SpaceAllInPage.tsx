import { useState, useRef } from "react";
import { useParams } from "react-router-dom";
import { Search, SlidersHorizontal, Grid3X3, List } from "lucide-react";
import SpaceLayout from "@/components/Space/SpaceLayout";
import SpaceLeftSidebar from "@/components/Space/SpaceLeftSidebar";
import PageSearchBar from "@/components/Space/PageSearchBar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import useSpaceData from "@/hooks/useSpaceData";
import { 
  spaceContentService, 
  CONTENT_TYPES,
  type SpaceContent,
  type ContentType 
} from "@/services/spaceContentService";

const SpaceAllInPage = () => {
  const { spaceId } = useParams();
  const [activeType, setActiveType] = useState<ContentType>("All");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [searchQuery, setSearchQuery] = useState("");
  const lastItemRef = useRef<HTMLDivElement>(null);
  
  const {
    spaceTemplate,
    stats,
    trendData,
    filteredAgents,
    filteredWorkflows,
    filteredApps,
    filteredTools,
    filteredResources,
    trendingWorkspaces,
  } = useSpaceData(spaceId);

  // Get all content using service
  const allContent = spaceContentService.getAllContent(
    filteredAgents,
    filteredWorkflows,
    filteredApps,
    filteredTools,
    filteredResources,
    trendingWorkspaces
  );

  // Filter content using service
  const filteredContent = spaceContentService.filterContent(
    allContent,
    searchQuery,
    activeType
  );

  // Handle search
  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  return (
    <SpaceLayout 
      stats={stats} 
      template={spaceTemplate} 
      trendData={trendData}
    >
      <div className="container grid grid-cols-12 gap-8">
        {/* Left Sidebar */}
        <div className="col-span-3">
          <SpaceLeftSidebar />
        </div>
        
        {/* Main Content */}
        <div className="col-span-9">
          {/* Search and Filter Bar */}
          <div className="flex flex-col gap-4 mb-8">
            <div className="flex items-center justify-between">
              <h1 className="text-3xl font-bold">All Content</h1>
              <div className="flex items-center gap-3">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className={viewMode === "grid" ? "bg-primary/20" : ""}
                  onClick={() => setViewMode("grid")}
                >
                  <Grid3X3 className="w-5 h-5" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className={viewMode === "list" ? "bg-primary/20" : ""}
                  onClick={() => setViewMode("list")}
                >
                  <List className="w-5 h-5" />
                </Button>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <PageSearchBar 
                placeholder="Search all content..."
                onSearch={handleSearch}
                className="w-full max-w-md"
              />
              <Button variant="outline" className="gap-2">
                <SlidersHorizontal className="w-4 h-4" />
                Filter
              </Button>
            </div>
            
            {/* Content Type Filters */}
            <div className="flex flex-wrap gap-2">
              {CONTENT_TYPES.map(type => (
                <Button
                  key={type}
                  variant={activeType === type ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActiveType(type)}
                  className={activeType === type ? "" : "bg-black/20 border-white/10"}
                >
                  {type}
                </Button>
              ))}
            </div>
          </div>
          
          {/* Content Grid */}
          <div className={`grid ${
            viewMode === "grid" 
              ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3" 
              : "grid-cols-1"
          } gap-6`}>
            {filteredContent.map((item, index) => (
              <ContentCard 
                key={`${item.type}-${item.id || index}`}
                item={item}
                viewMode={viewMode}
                isLast={index === filteredContent.length - 1}
                lastItemRef={lastItemRef}
              />
            ))}
          </div>
        </div>
      </div>
    </SpaceLayout>
  );
};

// Content Card Component
interface ContentCardProps {
  item: SpaceContent;
  viewMode: "grid" | "list";
  isLast: boolean;
  lastItemRef: React.RefObject<HTMLDivElement>;
}

const ContentCard = ({ item, viewMode, isLast, lastItemRef }: ContentCardProps) => {
  if (viewMode === "list") {
    return (
      <div ref={isLast ? lastItemRef : null} className="group cursor-pointer">
        <Card className="bg-black/20 backdrop-blur-sm border border-white/10 hover:bg-black/30 transition-all duration-300">
          <div className="flex h-[120px] overflow-hidden">
            <div className="w-[180px] h-full">
              <img 
                src={item.image} 
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300"
              />
            </div>
            <div className="flex-1 p-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-lg">{item.title}</h3>
                  <Badge variant="outline" className="bg-black/30">
                    {item.type}
                  </Badge>
                </div>
                <p className="text-sm text-white/70 line-clamp-2 mt-1">{item.description}</p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div ref={isLast ? lastItemRef : null} className="group cursor-pointer">
      <Card className="overflow-hidden bg-black/20 backdrop-blur-sm border border-white/10 hover:bg-black/30 transition-all duration-300">
        <div className="relative">
          <div className="h-[200px] overflow-hidden">
            <img 
              src={item.image} 
              alt={item.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
          </div>
          <div className="absolute bottom-0 left-0 right-0 p-4">
            <div className="flex items-center justify-between mb-1">
              <h3 className="font-semibold text-lg line-clamp-1">{item.title}</h3>
              <Badge variant="outline" className="bg-black/30 text-xs">
                {item.type}
              </Badge>
            </div>
            <p className="text-sm text-white/70 line-clamp-2">{item.description}</p>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default SpaceAllInPage;
