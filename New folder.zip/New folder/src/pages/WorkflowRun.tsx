
import { useParams, useNavigate } from "react-router-dom";
import { useState } from "react";
import Sidebar from "@/components/Layout/Sidebar";
import SpaceLeftSidebar from "@/components/Space/SpaceLeftSidebar";
import ChatPanel from "@/components/Agent/ChatPanel";
import { Menu, Settings, X, Play, Download, Clock, Workflow as WorkflowIcon, Code, Box } from "lucide-react";
import { Button } from "@/components/ui/button";
import ChatSettingsDialog from "@/components/Agent/ChatSettingsDialog";
import AgentSessions from "@/components/Agent/AgentSessions";
import ViewTabs, { ViewType } from "@/components/Agent/ViewTabs";
import CodeView from "@/components/Agent/Views/CodeView";
import ImageView from "@/components/Agent/Views/ImageView";
import CanvasView from "@/components/Agent/Views/CanvasView";
import FileView from "@/components/Agent/Views/FileView";
import WorkflowView from "@/components/Workflow/Views/WorkflowView";
import NodeView from "@/components/Workflow/Views/NodeView";

// Extend the ViewType to include our new workflow-specific views
type WorkflowViewType = ViewType | "workflow" | "nodeview";

interface DualViewState {
  id: string;
  views: [WorkflowViewType, WorkflowViewType];
}

const WorkflowRun = () => {
  const { workflowId } = useParams();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [selectedPersona, setSelectedPersona] = useState<string | null>(null);
  const [activeView, setActiveView] = useState<WorkflowViewType>("chat");
  const [activeDualView, setActiveDualView] = useState<DualViewState | null>(null);
  
  // Sample data for views
  const [codeData, setCodeData] = useState({ 
    code: "function processNode() {\n  console.log('Processing workflow node...');\n  return { success: true, data: { result: 'Node output' } };\n}", 
    language: "javascript" 
  });
  const [imageData, setImageData] = useState({ 
    images: ["https://placehold.co/600x400/png"] 
  });
  const [canvasData, setCanvasData] = useState({ 
    canvasData: "<svg width='100%' height='100%' viewBox='0 0 800 600'><circle cx='400' cy='300' r='150' fill='#6246ea' /></svg>" 
  });
  const [fileData, setFileData] = useState({ 
    files: [
      { name: "workflow-output.json", url: "#", size: "2.4 KB" },
      { name: "generated-content.md", url: "#", size: "1.8 MB" }
    ] 
  });
  
  const handlePersonaSelect = (personaId: string) => {
    setSelectedPersona(personaId);
    setIsSettingsOpen(false);
  };
  
  const handleDualViewSelect = (views: [WorkflowViewType, WorkflowViewType], id: string) => {
    setActiveDualView({ id, views });
  };
  
  // Render a single view based on the view type
  const renderView = (viewType: WorkflowViewType) => {
    switch (viewType) {
      case "chat":
        return <ChatPanel agentTitle="Content Creation Suite" onClose={() => window.history.back()} />;
      case "code":
        return <CodeView code={codeData.code} language={codeData.language} />;
      case "image":
        return <ImageView images={imageData.images} />;
      case "canvas":
        return <CanvasView canvasData={canvasData.canvasData} />;
      case "file":
        return <FileView files={fileData.files} />;
      case "workflow":
        return <WorkflowView workflowId={workflowId || ""} />;
      case "nodeview":
        return <NodeView workflowId={workflowId || ""} />;
      default:
        return <ChatPanel agentTitle="Content Creation Suite" onClose={() => window.history.back()} />;
    }
  };
  
  // Render the active view content
  const renderActiveView = () => {
    if (activeView === "dual" && activeDualView) {
      return (
        <div className="grid grid-cols-2 gap-4 h-full">
          <div className="h-full">{renderView(activeDualView.views[0])}</div>
          <div className="h-full">{renderView(activeDualView.views[1])}</div>
        </div>
      );
    } else {
      return renderView(activeView);
    }
  };
  
  return (
    <div className="flex h-screen bg-background">
      {/* Top navigation bar */}
      <div className="fixed top-0 left-0 right-0 z-40 bg-black/80 backdrop-blur-lg border-b border-white/10">
        <div className="container mx-auto py-2 px-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => window.history.back()} className="text-white/70 hover:text-white">
              <X className="w-4 h-4 mr-1" />
              Close
            </Button>
            <div className="h-5 w-px bg-white/20"></div>
            <Button variant="ghost" size="sm" className="text-white/70 hover:text-white">
              <WorkflowIcon className="w-4 h-4 mr-1" />
              View Full Graph
            </Button>
          </div>
          
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" className="text-white/70 hover:text-white">
              <Download className="w-4 h-4 mr-1" />
              Export
            </Button>
            <Button variant="ghost" size="sm" className="text-white/70 hover:text-white">
              <Clock className="w-4 h-4 mr-1" />
              Schedule
            </Button>
            <Button variant="outline" size="sm" className="text-white border-white/20 hover:bg-white/10">
              <Play className="w-4 h-4 mr-1" />
              Run in Background
            </Button>
          </div>
        </div>
      </div>

      {/* Collapsible Sidebar with Overlay */}
      <div className="relative z-30">
        {/* Backdrop */}
        {isSidebarOpen && <div className="fixed inset-0 bg-black/50 backdrop-blur-sm transition-opacity" onClick={() => setIsSidebarOpen(false)} />}
        
        {/* Sidebar, SpaceLeftSidebar, and AgentSessions Container */}
        <div className={`fixed inset-y-0 left-0 flex transform transition-transform duration-300 ease-in-out 
            ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="relative h-full">
            <Button variant="ghost" size="icon" className="absolute top-4 right-4 z-50" onClick={() => setIsSidebarOpen(false)}>
              <X className="w-5 h-5" />
            </Button>
            <Sidebar />
          </div>
          
          {/* Space Left Sidebar - conditionally shown if spaceId is available */}
          <div className="h-full ml-5">
            <SpaceLeftSidebar className="h-full" />
          </div>
          
          {/* Agent Sessions */}
          <div className="h-full ml-5">
            <AgentSessions agentId={workflowId} className="h-full" />
          </div>
        </div>
      </div>
      
      <div className="flex-1 flex flex-col w-full">
        <div className="absolute top-16 left-4 z-20 flex flex-col gap-2">
          <Button variant="ghost" size="icon" onClick={() => setIsSidebarOpen(!isSidebarOpen)}>
            <Menu className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setIsSettingsOpen(true)}>
            <Settings className="w-5 h-5" />
          </Button>
        </div>
        
        <main className="flex-1 overflow-hidden relative mt-12">
          {/* Circular gradient background */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-[800px] h-[800px] rounded-full bg-gradient-to-r from-primary/10 via-primary/5 to-transparent opacity-50 blur-3xl" />
          </div>

          <div className="h-full p-4 flex items-center">
            {/* Main content area - displays the active view */}
            <div className="flex-1 flex flex-col max-w-3xl mx-auto">
              {renderActiveView()}
            </div>
            
            {/* View tabs fixed at the center right */}
            <div className="fixed right-6 top-1/2 transform -translate-y-1/2 z-10">
              <WorkflowViewTabs 
                activeView={activeView} 
                onChange={(view) => setActiveView(view as WorkflowViewType)}
                onDualSelect={handleDualViewSelect}
              />
            </div>
          </div>
        </main>
      </div>

      <ChatSettingsDialog 
        open={isSettingsOpen} 
        onOpenChange={setIsSettingsOpen}
        onPersonaSelect={handlePersonaSelect}
        selectedPersona={selectedPersona}
      />
    </div>
  );
};

// Custom ViewTabs component that extends the original with workflow-specific views
const WorkflowViewTabs = ({ activeView, onChange, onDualSelect }) => {
  // Use the ViewTabs component as base, but add workflow-specific options
  const workflowTabs = [
    {
      id: "workflow",
      icon: WorkflowIcon,
      label: "Workflow",
    },
    {
      id: "nodeview",
      icon: Box,
      label: "Node View",
    }
  ];
  
  // Combine with regular ViewTabs component functionality
  return (
    <ViewTabs 
      activeView={activeView}
      onChange={onChange}
      onDualSelect={onDualSelect}
      extraTabs={workflowTabs}
    />
  );
};

export default WorkflowRun;
