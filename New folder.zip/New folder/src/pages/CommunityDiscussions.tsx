import { useState } from "react";
import { useParams } from "react-router-dom";
import { MessageSquare, Send, Share2, Plus, Search, Users, FileText, Brain, Workflow, AppWindow, GitBranch, Star, Bookmark, Heart, MoreHorizontal, ArrowUpRight, ArrowDownRight, Reply, BookOpen, Sparkles, Award, Trophy, Lightbulb, Image as ImageIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";

const CommunityDiscussions = () => {
  const { spaceId } = useParams();
  const [activeTab, setActiveTab] = useState("all");
  const [newMessage, setNewMessage] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  // Mock data for discussions
  const discussions = [
    {
      id: 1,
      title: "Best practices for AI model deployment",
      author: {
        name: "Alex Chen",
        avatar: "/avatars/alex.jpg",
        role: "AI Engineer"
      },
      content: "I've been working on deploying ML models in production and wanted to share some best practices I've learned...",
      timestamp: "2 hours ago",
      replies: 12,
      views: 245,
      tags: ["AI", "Deployment", "Best Practices"],
      isPinned: true
    },
    // ... more discussions
  ];

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Discussions</h1>
        <Button size="sm" className="gap-2">
          <Plus className="w-4 h-4" />
          New Discussion
        </Button>
      </div>

      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-8">
          {/* Discussion List */}
          <div className="space-y-4">
            {discussions.map((discussion) => (
              <Card key={discussion.id} className="bg-card/50 border-primary/10">
                <CardContent className="p-4">
                  <div className="flex gap-4">
                    <Avatar>
                      <AvatarImage src={discussion.author.avatar} />
                      <AvatarFallback>{discussion.author.name[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{discussion.title}</h3>
                        {discussion.isPinned && (
                          <Badge variant="secondary">Pinned</Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-sm text-muted-foreground">{discussion.author.name}</span>
                        <span className="text-sm text-muted-foreground">•</span>
                        <span className="text-sm text-muted-foreground">{discussion.timestamp}</span>
                      </div>
                      <p className="mt-2 text-sm">{discussion.content}</p>
                      <div className="flex items-center gap-4 mt-4">
                        <div className="flex items-center gap-2">
                          <MessageSquare className="w-4 h-4" />
                          <span className="text-sm">{discussion.replies} replies</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Eye className="w-4 h-4" />
                          <span className="text-sm">{discussion.views} views</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {discussion.tags.map((tag) => (
                            <Badge key={tag} variant="outline">{tag}</Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="col-span-4">
          {/* Quick Stats */}
          <Card className="bg-card/50 border-primary/10 mb-6">
            <CardHeader>
              <CardTitle className="text-lg">Discussion Stats</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Total Discussions</span>
                  <span className="font-medium">245</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Active Discussions</span>
                  <span className="font-medium">45</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Your Contributions</span>
                  <span className="font-medium">12</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Popular Tags */}
          <Card className="bg-card/50 border-primary/10">
            <CardHeader>
              <CardTitle className="text-lg">Popular Tags</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary">AI</Badge>
                <Badge variant="secondary">ML</Badge>
                <Badge variant="secondary">Deployment</Badge>
                <Badge variant="secondary">Best Practices</Badge>
                <Badge variant="secondary">Tutorial</Badge>
                <Badge variant="secondary">Help</Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CommunityDiscussions; 