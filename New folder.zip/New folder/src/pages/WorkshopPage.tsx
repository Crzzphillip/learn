
import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import Sidebar from "@/components/Layout/Sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Calendar, Users, Star, Video, ArrowLeft, MessageSquare, Clock, Award } from 'lucide-react';
import { Progress } from "@/components/ui/progress";
import CreditBadge from "@/components/Space/CreditBadge";
import { AgentDetails } from "@/types/agent";

// Mock workshop data
const WORKSHOP_DATA = {
  id: 'ws-1',
  title: 'Advanced AI Prompt Engineering',
  description: 'Learn techniques to craft effective prompts for AI systems and optimize outputs for various use cases. This hands-on workshop covers best practices for working with large language models.',
  banner: 'https://images.unsplash.com/photo-1581287053822-fd7bf4f4bfec?q=80&w=2244&auto=format&fit=crop',
  creator: {
    name: 'Alex Morgan',
    avatar: '/lovable-uploads/0a1baea5-6a03-47a0-87a5-2d8084ef4e3d.png',
    bio: 'AI Prompt Engineer with 5+ years of experience working with language models'
  },
  schedule: {
    nextSession: '2023-07-15T14:30:00Z',
    duration: 90,
    timezone: 'UTC',
    frequency: 'Weekly on Saturdays'
  },
  stats: {
    participants: 24,
    favorites: 18,
    reviews: 12,
    rating: 4.8
  },
  credits: '15',
  materials: [
    { name: 'Prompt Engineering Handbook', type: 'PDF', size: '2.4 MB' },
    { name: 'Workshop Slides', type: 'PPT', size: '5.1 MB' },
    { name: 'Practice Exercises', type: 'ZIP', size: '1.8 MB' }
  ],
  agenda: [
    { title: 'Introduction to Prompt Engineering', duration: 15 },
    { title: 'Advanced Techniques and Patterns', duration: 25 },
    { title: 'Hands-on Exercise: Crafting Effective Prompts', duration: 30 },
    { title: 'Optimization Strategies and Best Practices', duration: 15 },
    { title: 'Q&A and Discussion', duration: 15 }
  ],
  tags: ['AI', 'Prompt Engineering', 'Language Models'],
  relatedTools: [
    {
      title: 'Prompt Library',
      description: 'Collection of tested prompt templates',
      rating: '4.7',
      credits: '10',
      category: 'AI Tools',
      personas: ['Developer', 'Designer', 'Writer'],
      reviews: [
        { user: 'John Doe', rating: 4, comment: 'Very useful collection' },
        { user: 'Jane Smith', rating: 5, comment: 'Saved me hours of work' }
      ]
    } as AgentDetails,
    {
      title: 'Prompt Analyzer',
      description: 'AI tool to analyze and improve prompts',
      rating: '4.9',
      credits: '8',
      category: 'Analytics',
      personas: ['Developer', 'Researcher', 'Data Scientist'],
      reviews: [
        { user: 'Alice Johnson', rating: 5, comment: 'Game-changing tool' },
        { user: 'Bob Brown', rating: 4, comment: 'Very insightful analysis' }
      ]
    } as AgentDetails
  ]
};

const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', { 
    weekday: 'long',
    month: 'long', 
    day: 'numeric', 
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

const WorkshopPage = () => {
  const { workshopId } = useParams();
  const [activeTab, setActiveTab] = useState('overview');
  
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <div className="relative h-64 overflow-hidden">
          <img 
            src={WORKSHOP_DATA.banner}
            alt={WORKSHOP_DATA.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
          <div className="absolute top-4 left-4">
            <Button variant="outline" size="sm" asChild>
              <Link to="/space/1/workshops">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Workshops
              </Link>
            </Button>
          </div>
          <div className="absolute bottom-4 left-8 right-8">
            <h1 className="text-3xl font-bold text-white">{WORKSHOP_DATA.title}</h1>
            <div className="flex items-center mt-2 gap-4">
              <CreditBadge amount={WORKSHOP_DATA.credits} />
              <div className="flex items-center gap-1 text-white/90">
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                <span>{WORKSHOP_DATA.stats.rating} ({WORKSHOP_DATA.stats.reviews} reviews)</span>
              </div>
            </div>
          </div>
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 container py-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="agenda">Agenda</TabsTrigger>
            <TabsTrigger value="materials">Materials</TabsTrigger>
            <TabsTrigger value="discussions">Discussions</TabsTrigger>
          </TabsList>
          
          <div className="mt-6 grid grid-cols-3 gap-6">
            <div className="col-span-2">
              <TabsContent value="overview" className="mt-0 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>About this Workshop</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{WORKSHOP_DATA.description}</p>
                    
                    <div className="mt-8 space-y-4">
                      <h3 className="text-lg font-semibold">What you'll learn</h3>
                      <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                        <li>Fundamental principles of effective prompt engineering</li>
                        <li>Advanced techniques for optimizing prompt responses</li>
                        <li>Best practices for working with various AI models</li>
                        <li>Troubleshooting and refining problematic prompts</li>
                        <li>Methods for evaluating prompt effectiveness</li>
                      </ul>
                    </div>
                    
                    <div className="mt-8 space-y-4">
                      <h3 className="text-lg font-semibold">Tags</h3>
                      <div className="flex flex-wrap gap-2">
                        {WORKSHOP_DATA.tags.map((tag, index) => (
                          <Badge key={index} variant="secondary">{tag}</Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Related Tools</CardTitle>
                  </CardHeader>
                  <CardContent className="grid grid-cols-2 gap-4">
                    {WORKSHOP_DATA.relatedTools.map((tool, index) => (
                      <Card key={index} className="border shadow-sm">
                        <CardHeader className="p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <CardTitle className="text-base">{tool.title}</CardTitle>
                              <p className="text-sm text-muted-foreground mt-1">{tool.description}</p>
                            </div>
                            <CreditBadge amount={tool.credits} />
                          </div>
                        </CardHeader>
                        <CardContent className="p-4 pt-0">
                          <div className="flex items-center justify-between text-sm">
                            <Badge variant="outline">{tool.category}</Badge>
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                              <span>{tool.rating}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="agenda" className="mt-0 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Workshop Agenda</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      {WORKSHOP_DATA.agenda.map((item, index) => (
                        <div key={index} className="flex items-start gap-4">
                          <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center flex-shrink-0">
                            {index + 1}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <h3 className="font-medium">{item.title}</h3>
                              <Badge variant="outline">{item.duration} min</Badge>
                            </div>
                            <Progress className="h-1.5 mt-2" value={100} />
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="pt-4 border-t">
                      <div className="flex items-center justify-between">
                        <div className="text-sm text-muted-foreground">
                          Total Duration
                        </div>
                        <Badge variant="outline">
                          {WORKSHOP_DATA.agenda.reduce((acc, item) => acc + item.duration, 0)} min
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="materials" className="mt-0 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Workshop Materials</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {WORKSHOP_DATA.materials.map((material, index) => (
                        <div key={index} className="flex items-center justify-between p-3 rounded-md border">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded bg-primary/10 text-primary grid place-items-center">
                              {material.type}
                            </div>
                            <div>
                              <div className="font-medium">{material.name}</div>
                              <div className="text-xs text-muted-foreground">{material.size}</div>
                            </div>
                          </div>
                          <Button variant="outline" size="sm">Download</Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="discussions" className="mt-0 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Workshop Discussions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <MessageSquare className="w-12 h-12 text-muted-foreground/50 mb-4" />
                      <h3 className="text-lg font-medium">No discussions yet</h3>
                      <p className="text-muted-foreground mb-6">
                        Be the first to start a discussion about this workshop
                      </p>
                      <Button>
                        <MessageSquare className="w-4 h-4 mr-2" />
                        New Discussion
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </div>
            
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Next Session</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 rounded-md bg-primary/5 border border-primary/10">
                    <div className="flex items-center gap-3 mb-3">
                      <Calendar className="w-5 h-5 text-primary" />
                      <span className="font-medium">{formatDate(WORKSHOP_DATA.schedule.nextSession)}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Clock className="w-5 h-5 text-primary" />
                      <span>{WORKSHOP_DATA.schedule.duration} minutes</span>
                    </div>
                  </div>
                  
                  <Button className="w-full">
                    <Video className="w-4 h-4 mr-2" />
                    Join Session
                  </Button>
                  
                  <div className="text-sm text-muted-foreground">
                    <p className="mb-1">Frequency: {WORKSHOP_DATA.schedule.frequency}</p>
                    <p>Timezone: {WORKSHOP_DATA.schedule.timezone}</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Instructor</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4 mb-4">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={WORKSHOP_DATA.creator.avatar} />
                      <AvatarFallback>{WORKSHOP_DATA.creator.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{WORKSHOP_DATA.creator.name}</div>
                      <div className="flex items-center mt-1">
                        <Award className="w-4 h-4 text-amber-500 mr-1" />
                        <span className="text-xs">Workshop Creator</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">
                    {WORKSHOP_DATA.creator.bio}
                  </p>
                  <Button variant="outline" size="sm" className="w-full">
                    View Profile
                  </Button>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Workshop Stats</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 rounded-md bg-muted">
                      <div className="text-sm font-medium">Participants</div>
                      <div className="flex items-center">
                        <Users className="w-4 h-4 mr-2" />
                        <span className="text-lg font-bold">{WORKSHOP_DATA.stats.participants}</span>
                      </div>
                    </div>
                    <div className="p-3 rounded-md bg-muted">
                      <div className="text-sm font-medium">Rating</div>
                      <div className="flex items-center">
                        <Star className="w-4 h-4 mr-2 fill-yellow-400 text-yellow-400" />
                        <span className="text-lg font-bold">{WORKSHOP_DATA.stats.rating}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </Tabs>
      </div>
    </div>
  );
};

export default WorkshopPage;
