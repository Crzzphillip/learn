
import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Sidebar from "@/components/Layout/Sidebar";
import { getWorkspaceById, Workspace as WorkspaceType } from "@/services/workspaceService";
import { Play, ArrowLeft, Users, MessageSquare, Settings, FileText, LayoutGrid, Activity } from "lucide-react";
import CollaborativeAvatar from "@/components/Workspace/CollaborativeAvatar";
import WorkspaceOverview from "@/components/Workspace/WorkspaceOverview";
import WorkspaceFlow from "@/components/Workspace/WorkspaceFlow";
import WorkspaceCollaboration from "@/components/Workspace/WorkspaceCollaboration";
import WorkspaceSettings from "@/components/Workspace/WorkspaceSettings";

const Workspace = () => {
  const { workspaceId } = useParams();
  const navigate = useNavigate();
  const [workspace, setWorkspace] = useState<WorkspaceType | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");

  useEffect(() => {
    if (workspaceId) {
      // Fetch workspace data
      const fetchedWorkspace = getWorkspaceById(workspaceId);
      setWorkspace(fetchedWorkspace || null);
      setLoading(false);
    }
  }, [workspaceId]);

  // Handle "Start Session" button click
  const handleStartSession = () => {
    if (!workspaceId) return;
    navigate(`/workspace/${workspaceId}/run`);
  };

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!workspace) {
    return (
      <div className="flex h-screen items-center justify-center flex-col">
        <h1 className="text-2xl font-bold mb-4">Workspace not found</h1>
        <Button onClick={() => navigate(-1)}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Go Back
        </Button>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-auto">
          <div className="container mx-auto py-6">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => navigate(-1)} 
              className="mb-6"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>

            <div className="flex justify-between items-center mb-6">
              <div>
                <h1 className="text-3xl font-bold mb-2">{workspace.title}</h1>
                <p className="text-muted-foreground">{workspace.description}</p>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="flex -space-x-2">
                  {workspace.activeCollaborators && workspace.activeCollaborators.map((collaborator, index) => (
                    <CollaborativeAvatar
                      key={index}
                      user={{
                        id: `user-${index}`,
                        name: collaborator.name,
                        avatar: collaborator.avatar,
                        email: `user${index}@example.com`,
                        role: 'Editor'
                      }}
                      isActive={true}
                      size="md"
                    />
                  ))}
                </div>
                
                <Button 
                  onClick={handleStartSession}
                  size="lg"
                  className={workspace.type === 'canvas' ? 
                    "bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600" : 
                    undefined
                  }
                >
                  <Play className="mr-2 h-4 w-4" />
                  Start Session
                </Button>
              </div>
            </div>

            <Tabs 
              defaultValue="overview"
              value={activeTab}
              onValueChange={setActiveTab}
              className="w-full"
            >
              <TabsList className="mb-6">
                <TabsTrigger value="overview" className="flex items-center gap-2">
                  <LayoutGrid className="h-4 w-4" />
                  Overview
                </TabsTrigger>
                <TabsTrigger value="flow" className="flex items-center gap-2">
                  <Activity className="h-4 w-4" />
                  Flow
                </TabsTrigger>
                <TabsTrigger value="collaboration" className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Collaboration
                </TabsTrigger>
                <TabsTrigger value="chat" className="flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  Team Chat
                </TabsTrigger>
                <TabsTrigger value="docs" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Documentation
                </TabsTrigger>
                <TabsTrigger value="settings" className="flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  Settings
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="space-y-6">
                <WorkspaceOverview workspace={workspace} />
              </TabsContent>
              
              <TabsContent value="flow" className="space-y-6">
                <WorkspaceFlow workspace={workspace} />
              </TabsContent>
              
              <TabsContent value="collaboration" className="space-y-6">
                <WorkspaceCollaboration workspace={workspace} />
              </TabsContent>
              
              <TabsContent value="chat" className="space-y-6">
                <div className="bg-card rounded-lg border shadow-sm p-6 h-[600px]">
                  <h2 className="text-xl font-semibold mb-4">Team Chat</h2>
                  <div className="flex items-center justify-center h-[500px] text-muted-foreground">
                    Team chat functionality coming soon
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="docs" className="space-y-6">
                <div className="bg-card rounded-lg border shadow-sm p-6 h-[600px]">
                  <h2 className="text-xl font-semibold mb-4">Documentation</h2>
                  <div className="flex items-center justify-center h-[500px] text-muted-foreground">
                    Documentation functionality coming soon
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="settings" className="space-y-6">
                <WorkspaceSettings workspace={workspace} />
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Workspace;
