
import { useParams } from "react-router-dom";
import Sidebar from "@/components/Layout/Sidebar";
import { getApps } from "@/data/spaceData";
import AppsSection from "@/components/Space/AppsSection";
import BackToSpace from "@/components/Space/BackToSpace";
import SpaceLeftSidebar from "@/components/Space/SpaceLeftSidebar";
import PageSearchBar from "@/components/Space/PageSearchBar";
import { useState } from "react";

const AppsPage = () => {
  const { spaceId } = useParams();
  const allApps = getApps();
  const [apps, setApps] = useState(allApps);

  const handleSearch = (query: string) => {
    if (query.trim() === "") {
      setApps(allApps);
      return;
    }
    
    const lowercaseQuery = query.toLowerCase();
    const filteredApps = allApps.filter(app => 
      app.title.toLowerCase().includes(lowercaseQuery) || 
      app.description.toLowerCase().includes(lowercaseQuery)
    );
    
    setApps(filteredApps);
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex">
        <SpaceLeftSidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <main className="flex-1 overflow-auto">
            <div className="container py-8">
              <div className="flex items-center justify-between mb-6">
                <BackToSpace spaceId={spaceId || ""} />
                <PageSearchBar 
                  placeholder="Search apps..." 
                  onSearch={handleSearch}
                />
              </div>
              
              <div className="mb-8">
                <h1 className="text-3xl font-bold mb-2">Apps & Integrations</h1>
                <p className="text-muted-foreground">
                  Browse and use apps and integrations available in this space
                </p>
              </div>
              
              <AppsSection apps={apps} />
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default AppsPage;
