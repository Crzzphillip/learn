
import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Bot, Workflow, Layout, Layers, PenTool, Share, Monitor, Palette, DollarSign, Eye, Settings, Save } from 'lucide-react';
import Sidebar from '@/components/Layout/Sidebar';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import BackToSpace from '@/components/Space/BackToSpace';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { toast } from 'sonner';

interface AppCreatorProps {
  type?: 'agent' | 'workflow' | 'workspace';
}

const AppCreator = ({ type = 'workspace' }: AppCreatorProps) => {
  const navigate = useNavigate();
  const { workspaceId, agentId, workflowId, spaceId } = useParams();
  const [currentTab, setCurrentTab] = useState('design');
  const [appName, setAppName] = useState('');
  const [appDescription, setAppDescription] = useState('');
  const [accessType, setAccessType] = useState('private');
  const [price, setPrice] = useState('10');
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Source ID based on the type
  const sourceId = type === 'agent' ? agentId : type === 'workflow' ? workflowId : workspaceId;
  
  const getSourceIcon = () => {
    switch(type) {
      case 'agent': return <Bot className="w-5 h-5" />;
      case 'workflow': return <Workflow className="w-5 h-5" />;
      case 'workspace': return <Layout className="w-5 h-5" />;
      default: return <Layout className="w-5 h-5" />;
    }
  };
  
  const getSourceName = () => {
    switch(type) {
      case 'agent': return 'AI Assistant';
      case 'workflow': return 'Data Processing Workflow';
      case 'workspace': return 'Development Workspace';
      default: return 'Workspace';
    }
  };
  
  const handleCreateApp = () => {
    if (!appName) {
      toast.error("Please provide a name for your app");
      return;
    }
    
    setIsProcessing(true);
    
    // Simulate app creation process
    setTimeout(() => {
      setIsProcessing(false);
      toast.success("App created successfully!");
      navigate(`/app/app-${Date.now()}`);
    }, 2000);
  };
  
  const interfaceTemplates = [
    { id: 'minimal', name: 'Minimal', description: 'Clean interface with essential controls' },
    { id: 'dashboard', name: 'Dashboard', description: 'Detailed interface with analytics' },
    { id: 'conversational', name: 'Conversational', description: 'Chat-based interface' },
    { id: 'wizard', name: 'Step-by-Step', description: 'Guided workflow interface' },
  ];
  
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <div className="border-b bg-background/95 backdrop-blur-sm">
          <div className="container py-4">
            <BackToSpace spaceId={spaceId || ""} />
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <h1 className="text-xl font-semibold">Create Standalone App</h1>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-2"
                  onClick={() => navigate(-1)}
                >
                  <Eye className="w-4 h-4" />
                  Preview
                </Button>
                <Button
                  size="sm"
                  className="gap-2"
                  onClick={handleCreateApp}
                  disabled={isProcessing}
                >
                  <Save className="w-4 h-4" />
                  {isProcessing ? 'Creating...' : 'Create App'}
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        <Tabs value={currentTab} onValueChange={setCurrentTab} className="flex-1 container py-6">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="design" className="gap-2">
              <Palette className="w-4 h-4" />
              Design
            </TabsTrigger>
            <TabsTrigger value="functionality" className="gap-2">
              <Settings className="w-4 h-4" />
              Functionality
            </TabsTrigger>
            <TabsTrigger value="access" className="gap-2">
              <Share className="w-4 h-4" />
              Access & Distribution
            </TabsTrigger>
            <TabsTrigger value="monetization" className="gap-2">
              <DollarSign className="w-4 h-4" />
              Monetization
            </TabsTrigger>
          </TabsList>
          
          <div className="grid grid-cols-[2fr,1fr] gap-6">
            <div className="space-y-6">
              <TabsContent value="design" className="m-0 space-y-6">
                <div className="space-y-2">
                  <h2 className="text-xl font-semibold">App Information</h2>
                  <p className="text-muted-foreground">Customize how your app appears to users</p>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="app-name">App Name</Label>
                    <Input 
                      id="app-name" 
                      placeholder="e.g. Component Crafter" 
                      value={appName}
                      onChange={(e) => setAppName(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="app-description">Description</Label>
                    <Textarea 
                      id="app-description" 
                      placeholder="Describe what your app does..."
                      value={appDescription}
                      onChange={(e) => setAppDescription(e.target.value)}
                      className="min-h-[100px]"
                    />
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Interface Template</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {interfaceTemplates.map(template => (
                      <div 
                        key={template.id}
                        className="border rounded-lg p-4 cursor-pointer hover:border-primary transition-colors"
                        onClick={() => {}}
                      >
                        <h4 className="font-medium">{template.name}</h4>
                        <p className="text-sm text-muted-foreground">{template.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium mb-4">Branding</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="primary-color">Primary Color</Label>
                      <div className="flex gap-2">
                        <Input id="primary-color" type="color" className="w-12 h-10 p-1" />
                        <Input id="primary-color-hex" placeholder="#8B5CF6" />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="logo-upload">Logo (Optional)</Label>
                      <Input id="logo-upload" type="file" />
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="functionality" className="m-0 space-y-6">
                <div className="space-y-2">
                  <h2 className="text-xl font-semibold">App Functionality</h2>
                  <p className="text-muted-foreground">Define how your app works and what it can do</p>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="input-params">Input Parameters</Label>
                    <Textarea 
                      id="input-params" 
                      placeholder="user_prompt: String, max_length: Number, ..."
                      className="font-mono text-sm"
                    />
                    <p className="text-xs text-muted-foreground mt-1">Define what inputs your app needs from users</p>
                  </div>
                  <div>
                    <Label htmlFor="output-format">Output Format</Label>
                    <Textarea 
                      id="output-format" 
                      placeholder="{ content: String, components: Array, ... }"
                      className="font-mono text-sm"
                    />
                    <p className="text-xs text-muted-foreground mt-1">Define what your app returns to users</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Capabilities</h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Switch id="file-upload" />
                        <Label htmlFor="file-upload">File Upload</Label>
                      </div>
                      <Select defaultValue="image">
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="File Types" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="image">Images Only</SelectItem>
                          <SelectItem value="document">Documents</SelectItem>
                          <SelectItem value="all">All Files</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch id="api-access" />
                      <Label htmlFor="api-access">API Access</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch id="save-sessions" />
                      <Label htmlFor="save-sessions">Session History</Label>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Switch id="resource-limit" />
                        <Label htmlFor="resource-limit">Resource Limits</Label>
                      </div>
                      <Input className="w-[180px]" placeholder="Max credits per run" />
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="access" className="m-0 space-y-6">
                <div className="space-y-2">
                  <h2 className="text-xl font-semibold">Access & Distribution</h2>
                  <p className="text-muted-foreground">Control how users can access and use your app</p>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Access Level</h3>
                  <RadioGroup value={accessType} onValueChange={setAccessType}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="private" id="private" />
                      <Label htmlFor="private">Private (Only for me)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="team" id="team" />
                      <Label htmlFor="team">Team (Selected users only)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="public" id="public" />
                      <Label htmlFor="public">Public (Available in marketplace)</Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Distribution Methods</h3>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Switch id="platform-embed" />
                      <Label htmlFor="platform-embed">Platform Embed</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch id="web-embed" />
                      <Label htmlFor="web-embed">Website Embed</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch id="api-endpoint" />
                      <Label htmlFor="api-endpoint">API Endpoint</Label>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="monetization" className="m-0 space-y-6">
                <div className="space-y-2">
                  <h2 className="text-xl font-semibold">Monetization</h2>
                  <p className="text-muted-foreground">Set pricing and manage earnings for your app</p>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Pricing Model</h3>
                  <RadioGroup defaultValue="credit">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="credit" id="credit" />
                      <Label htmlFor="credit">Credit-based Pricing</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="free" id="free" />
                      <Label htmlFor="free">Free</Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="price">Price in Credits</Label>
                  <div className="flex items-center gap-2">
                    <Input 
                      id="price" 
                      type="number" 
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      className="w-32"
                    />
                    <span>credits per use</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Revenue Share</h3>
                  <p className="text-sm text-muted-foreground">You'll receive 70% of all credits spent on your app</p>
                </div>
              </TabsContent>
            </div>
            
            <div>
              <div className="border rounded-lg p-4 space-y-4 sticky top-6">
                <div className="space-y-2">
                  <h3 className="font-medium">Source</h3>
                  <div className="flex items-center gap-2 p-2 bg-muted rounded-md">
                    {getSourceIcon()}
                    <span>{getSourceName()}</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">App Preview</h3>
                  <Card className="border-2 border-dashed">
                    <CardContent className="p-6 flex flex-col items-center justify-center min-h-[300px]">
                      <div className="w-16 h-16 rounded-full bg-primary/20 grid place-items-center mb-4">
                        <Layers className="w-8 h-8 text-primary" />
                      </div>
                      <h4 className="text-lg font-medium text-center">
                        {appName || "Your App Name"}
                      </h4>
                      <p className="text-sm text-center text-muted-foreground mt-2">
                        {appDescription || "App description will appear here..."}
                      </p>
                      <Button className="mt-4">Launch App</Button>
                    </CardContent>
                  </Card>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">Examples</h3>
                  <div className="space-y-2">
                    <div className="text-sm p-2 bg-muted rounded-md">
                      <span className="font-medium block">Component Crafter</span>
                      <span className="text-xs text-muted-foreground">Chat-based UI component generator</span>
                    </div>
                    <div className="text-sm p-2 bg-muted rounded-md">
                      <span className="font-medium block">Campaign Genie</span>
                      <span className="text-xs text-muted-foreground">Marketing content generator</span>
                    </div>
                    <div className="text-sm p-2 bg-muted rounded-md">
                      <span className="font-medium block">Film Factory</span>
                      <span className="text-xs text-muted-foreground">Video production assistant</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Tabs>
      </div>
    </div>
  );
};

export default AppCreator;
