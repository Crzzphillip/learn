
import { useNavigate } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const Landing = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      <div className="relative">
        {/* Hero Section */}
        <div className="relative h-screen">
          <div className="absolute inset-0">
            <img
              src="/lovable-uploads/d2c931c5-6a04-47bf-8c91-c5f07fa5e024.png"
              alt="Hero background"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
          </div>

          <div className="relative h-full container flex flex-col items-center justify-center text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-white to-white/80 bg-clip-text text-transparent">
              AI-Powered Workspace
            </h1>
            <p className="text-lg md:text-xl text-white/80 max-w-2xl mb-8">
              Discover a new way to work with AI. Access powerful AI agents, automated workflows, and creative tools all in one place.
            </p>
            <Button 
              size="lg"
              className="gap-2"
              onClick={() => navigate("/explore")}
            >
              Explore Spaces <ArrowRight className="w-5 h-5" />
            </Button>
          </div>

          {/* Decorative Elements */}
          <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent pointer-events-none" />
          <div className="absolute inset-0 bg-gradient-to-b from-background to-transparent pointer-events-none opacity-40" />
        </div>
      </div>
    </div>
  );
};

export default Landing;
