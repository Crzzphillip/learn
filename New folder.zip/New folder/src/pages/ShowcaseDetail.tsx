
import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import Sidebar from '@/components/Layout/Sidebar';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { 
  BookOpen, 
  Users, 
  Star, 
  ArrowRight, 
  FileText, 
  Link as LinkIcon,
  Code, 
  Workflow, 
  Layout, 
  AppWindow,
  ArrowUpRight,
  MessageSquare,
  ThumbsUp,
  RotateCw,
  Share2
} from 'lucide-react';
import { showcasesService } from '@/services/showcasesService';
import { Showcase } from '@/types/explore';
import { toast } from 'sonner';

const ShowcaseDetail = () => {
  const { showcaseId } = useParams<{ showcaseId: string }>();
  const [showcase, setShowcase] = useState<Showcase | undefined>(undefined);
  const [relatedShowcases, setRelatedShowcases] = useState<Showcase[]>([]);
  const [remixedShowcases, setRemixedShowcases] = useState<Showcase[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchShowcaseData = async () => {
      if (!showcaseId) return;
      
      setLoading(true);
      try {
        const [showcaseData, relatedData, remixedData] = await Promise.all([
          showcasesService.getShowcaseById(showcaseId),
          showcasesService.getRelatedShowcases(showcaseId),
          showcasesService.getRemixedShowcases(showcaseId)
        ]);
        
        setShowcase(showcaseData);
        setRelatedShowcases(relatedData);
        setRemixedShowcases(remixedData);
      } catch (error) {
        console.error("Error fetching showcase details:", error);
        toast.error("Failed to load showcase details");
      } finally {
        setLoading(false);
      }
    };

    fetchShowcaseData();
  }, [showcaseId]);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'agent':
        return <Code className="h-4 w-4" />;
      case 'workflow':
        return <Workflow className="h-4 w-4" />;
      case 'workspace':
        return <Layout className="h-4 w-4" />;
      case 'app':
        return <AppWindow className="h-4 w-4" />;
      default:
        return <Code className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    const categoryToColor: Record<string, string> = {
      'CREATIVE & DESIGN': 'bg-purple-500/10 text-purple-500 border-purple-500/20',
      'AUDIO & SPEECH': 'bg-blue-500/10 text-blue-500 border-blue-500/20',
      'DATA & ANALYTICS': 'bg-green-500/10 text-green-500 border-green-500/20',
      'DEVELOPMENT & CODING': 'bg-orange-500/10 text-orange-500 border-orange-500/20',
      'CONTENT & MARKETING': 'bg-pink-500/10 text-pink-500 border-pink-500/20',
      'HEALTHCARE': 'bg-red-500/10 text-red-500 border-red-500/20',
      'LEGAL & COMPLIANCE': 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
      'FINANCE': 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
    };
    
    return categoryToColor[category] || 'bg-gray-500/10 text-gray-500 border-gray-500/20';
  };

  const handleRemix = () => {
    toast.success("Showcase remixed! You can now customize it.");
    // In a real application, this would create a copy of the showcase for the user
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success("Link copied to clipboard!");
  };

  if (loading) {
    return (
      <div className="flex h-screen bg-background">
        <Sidebar />
        <main className="flex-1 overflow-auto">
          <div className="container max-w-6xl py-8">
            <div className="flex justify-center items-center h-[600px]">
              <div className="animate-pulse flex flex-col items-center gap-4">
                <div className="w-64 h-8 bg-muted rounded-md"></div>
                <div className="w-96 h-6 bg-muted rounded-md"></div>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (!showcase) {
    return (
      <div className="flex h-screen bg-background">
        <Sidebar />
        <main className="flex-1 overflow-auto">
          <div className="container max-w-6xl py-8">
            <div className="flex flex-col items-center justify-center h-[600px] text-center">
              <h2 className="text-2xl font-bold mb-2">Showcase Not Found</h2>
              <p className="text-muted-foreground mb-6">The showcase you're looking for doesn't exist or has been removed.</p>
              <Button asChild>
                <Link to="/showcases">Back to Showcases</Link>
              </Button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="container max-w-6xl py-8">
          {/* Breadcrumb navigation */}
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
            <Link to="/showcases" className="hover:text-foreground transition-colors">
              Showcases
            </Link>
            <ArrowRight className="h-3 w-3" />
            <span className="text-foreground font-medium">{showcase.title}</span>
          </div>

          {/* Showcase header */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            <div className="lg:col-span-2">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">{showcase.title}</h1>
              
              <div className="flex flex-wrap items-center gap-3 mb-6">
                <Badge variant="outline" className={getCategoryColor(showcase.category)}>
                  {showcase.category}
                </Badge>
                <Badge variant="outline" className="gap-1 bg-primary/10 text-primary">
                  {getTypeIcon(showcase.type)}
                  {showcase.type.charAt(0).toUpperCase() + showcase.type.slice(1)}
                </Badge>
                {showcase.stats && (
                  <>
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Users className="h-3.5 w-3.5" />
                      <span>{showcase.stats.users?.toLocaleString()} users</span>
                    </div>
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Star className="h-3.5 w-3.5 text-yellow-500" />
                      <span>{showcase.stats.rating} rating</span>
                    </div>
                  </>
                )}
              </div>
              
              <p className="text-lg text-muted-foreground mb-6">
                {showcase.description}
              </p>
              
              <div className="flex flex-wrap gap-3 mb-8">
                <Button onClick={handleRemix} className="gap-2">
                  <RotateCw className="h-4 w-4" />
                  Remix This Showcase
                </Button>
                <Button variant="outline" asChild>
                  <Link to={showcase.demoUrl || "#"} className="gap-2">
                    <ArrowUpRight className="h-4 w-4" />
                    Try It Now
                  </Link>
                </Button>
                <Button variant="outline" onClick={handleShare} className="gap-2">
                  <Share2 className="h-4 w-4" />
                  Share
                </Button>
              </div>
            </div>
            
            <div>
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Created By</CardTitle>
                </CardHeader>
                <CardContent>
                  {showcase.author ? (
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={showcase.author.avatar} alt={showcase.author.name} />
                        <AvatarFallback>{showcase.author.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{showcase.author.name}</div>
                        <div className="text-sm text-muted-foreground">Creator</div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-muted-foreground">Unknown creator</div>
                  )}
                </CardContent>
                <CardFooter className="pt-0 pb-3 flex-col items-start gap-3">
                  <div className="w-full">
                    <Separator className="my-3" />
                    <h4 className="font-medium mb-2">Performance Metrics</h4>
                    {showcase.stats && (
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <div className="text-sm text-muted-foreground">Users</div>
                          <div className="font-medium">{showcase.stats.users?.toLocaleString()}</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Rating</div>
                          <div className="font-medium flex items-center">
                            {showcase.stats.rating} <Star className="h-3.5 w-3.5 text-yellow-500 ml-1" />
                          </div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Efficiency</div>
                          <div className="font-medium">{showcase.stats.efficiency}%</div>
                        </div>
                        <div>
                          <div className="text-sm text-muted-foreground">Remixes</div>
                          <div className="font-medium">{remixedShowcases.length}</div>
                        </div>
                      </div>
                    )}
                  </div>
                </CardFooter>
              </Card>
            </div>
          </div>
          
          {/* Features section */}
          <div className="mb-10">
            <h2 className="text-2xl font-bold mb-6">Key Features</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {showcase.features.map((feature, index) => (
                <Card key={index} className="bg-card/50">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{feature}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      {/* Simulated feature descriptions */}
                      This {showcase.type} provides powerful {feature.toLowerCase()} capabilities to enhance your workflow.
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
          
          {/* Use cases and examples */}
          <div className="mb-10">
            <h2 className="text-2xl font-bold mb-6">Use Cases & Examples</h2>
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="case-1">
                <AccordionTrigger>Getting Started with {showcase.title}</AccordionTrigger>
                <AccordionContent>
                  <div className="prose prose-sm dark:prose-invert max-w-none">
                    <p>Learn how to quickly set up and configure the {showcase.title} for your specific needs:</p>
                    <ul>
                      <li>Simple installation and configuration process</li>
                      <li>Connect to your existing systems</li>
                      <li>Customize settings for optimal performance</li>
                    </ul>
                    <p>Most users are able to get up and running in less than 15 minutes.</p>
                  </div>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="case-2">
                <AccordionTrigger>Primary Use Case: Productivity Boost</AccordionTrigger>
                <AccordionContent>
                  <div className="prose prose-sm dark:prose-invert max-w-none">
                    <p>The most common application of {showcase.title} is to dramatically improve productivity:</p>
                    <ul>
                      <li>Automate repetitive tasks that used to take hours</li>
                      <li>Reduce manual errors by 95%</li>
                      <li>Free up team resources for higher-value activities</li>
                    </ul>
                    <p>Users report an average time saving of 20+ hours per month after implementing this solution.</p>
                  </div>
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="case-3">
                <AccordionTrigger>Advanced Integration Example</AccordionTrigger>
                <AccordionContent>
                  <div className="prose prose-sm dark:prose-invert max-w-none">
                    <p>For power users, {showcase.title} can be integrated with your entire tech stack:</p>
                    <ul>
                      <li>Connect with popular tools like Slack, Notion, and Google Workspace</li>
                      <li>Create custom workflows spanning multiple applications</li>
                      <li>Build sophisticated automation pipelines</li>
                    </ul>
                    <p>Organizations that implement these advanced integrations see ROI increases of up to 300%.</p>
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
          
          {/* Outcomes section */}
          <div className="mb-10">
            <h2 className="text-2xl font-bold mb-6">Outcomes & Results</h2>
            <Card>
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <div className="bg-primary/20 p-2 rounded-full">
                        <FileText className="h-5 w-5 text-primary" />
                      </div>
                      <h3 className="font-semibold">Productivity</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Users report an average productivity increase of 40% after implementing this {showcase.type}.
                    </p>
                  </div>
                  
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <div className="bg-primary/20 p-2 rounded-full">
                        <MessageSquare className="h-5 w-5 text-primary" />
                      </div>
                      <h3 className="font-semibold">Customer Satisfaction</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Improved response times and accuracy lead to a 35% increase in customer satisfaction scores.
                    </p>
                  </div>
                  
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <div className="bg-primary/20 p-2 rounded-full">
                        <ThumbsUp className="h-5 w-5 text-primary" />
                      </div>
                      <h3 className="font-semibold">Team Adoption</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      95% of teams continue using this {showcase.type} after the first month due to its ease of use.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Related showcases */}
          {relatedShowcases.length > 0 && (
            <div className="mb-10">
              <h2 className="text-2xl font-bold mb-6">Related Showcases</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {relatedShowcases.map(related => (
                  <Card key={related.id} className="overflow-hidden">
                    <img 
                      src={related.image} 
                      alt={related.title} 
                      className="w-full h-40 object-cover"
                    />
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <Badge variant="outline" className={getCategoryColor(related.category)}>
                          {related.category}
                        </Badge>
                        <Badge variant="outline" className="gap-1">
                          {getTypeIcon(related.type)}
                          {related.type}
                        </Badge>
                      </div>
                      <CardTitle className="mt-2">{related.title}</CardTitle>
                      <CardDescription>{related.description.substring(0, 100)}...</CardDescription>
                    </CardHeader>
                    <CardFooter>
                      <Button asChild variant="outline" className="w-full gap-2">
                        <Link to={`/showcase/${related.id}`}>
                          View Details
                          <ArrowRight className="h-4 w-4" />
                        </Link>
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </div>
          )}
          
          {/* Remixed showcases */}
          {remixedShowcases.length > 0 && (
            <div className="mb-10">
              <h2 className="text-2xl font-bold mb-6">Community Remixes</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {remixedShowcases.map(remixed => (
                  <Card key={remixed.id} className="overflow-hidden">
                    <div className="flex flex-col md:flex-row">
                      <img 
                        src={remixed.image} 
                        alt={remixed.title} 
                        className="w-full md:w-40 h-40 object-cover"
                      />
                      <div className="flex-1">
                        <CardHeader className="pb-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="gap-1">
                              {getTypeIcon(remixed.type)}
                              {remixed.type}
                            </Badge>
                            <span className="text-sm text-muted-foreground">Remixed by {remixed.author?.name || "Anonymous"}</span>
                          </div>
                          <CardTitle className="mt-2 text-lg">{remixed.title}</CardTitle>
                        </CardHeader>
                        <CardFooter>
                          <Button asChild variant="outline" size="sm" className="gap-2">
                            <Link to={`/showcase/${remixed.id}`}>
                              <LinkIcon className="h-3.5 w-3.5" />
                              View Remix
                            </Link>
                          </Button>
                        </CardFooter>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default ShowcaseDetail;
