
import { useState, useRef, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useInfiniteQuery } from "@tanstack/react-query";
import { Search, SlidersHorizontal, Grid3X3, List } from "lucide-react";
import * as LucideIcons from "lucide-react";
import Sidebar from "@/components/Layout/Sidebar";
import ItemCard from "@/components/Explore/ItemCard";
import SearchHeader from "@/components/Explore/SearchHeader";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { fetchItems } from "@/services/mockData";
import { dummyExploreData } from "@/data/dummyExploreData";

const typeLabels = {
  agents: "AI Agents",
  spaces: "AI Spaces",
  personas: "AI Personas",
  workspaces: "AI Workspaces",
  workflows: "AI Workflows",
  apps: "AI Apps",
};

const ExploreAll = () => {
  const { type } = useParams<{ type: string }>();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [activeType, setActiveType] = useState(type || "agents");
  const lastItemRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (type && Object.keys(typeLabels).includes(type)) {
      setActiveType(type);
    }
  }, [type]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 500);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    isLoading,
    isError,
  } = useInfiniteQuery({
    queryKey: ["exploreitems", activeType, debouncedQuery],
    queryFn: ({ pageParam = 0 }) => fetchItems({
      pageParam,
      type: activeType,
      searchQuery: debouncedQuery
    }),
    getNextPageParam: (lastPage) => lastPage.nextPage,
    initialPageParam: 0,
  });

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasNextPage && !isFetchingNextPage) {
          fetchNextPage();
        }
      },
      { threshold: 0.5 }
    );

    if (lastItemRef.current) {
      observer.observe(lastItemRef.current);
    }

    return () => observer.disconnect();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  // Get dummy data if no data is available from query
  const getDummyItems = () => {
    if (!dummyExploreData[activeType as keyof typeof dummyExploreData]) {
      return dummyExploreData.workspaces; // Default fallback
    }
    return dummyExploreData[activeType as keyof typeof dummyExploreData];
  };

  const allItems = data?.pages.flatMap((page) => page.items) || [];
  
  // If no items from API, use dummy data
  const displayItems = allItems.length > 0 ? allItems : getDummyItems();

  // Helper function to dynamically get the Lucide icon component
  const getIconComponent = (iconName: string) => {
    // @ts-ignore - dynamic icon lookup
    const Icon = LucideIcons[iconName] || LucideIcons.Code;
    return Icon;
  };

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  const handleTypeChange = (newType: string) => {
    setActiveType(newType);
    navigate(`/explore/${newType}`);
  };

  const pageTitle = `Explore ${typeLabels[activeType as keyof typeof typeLabels] || "Content"}`;
  const pageSubtitle = "Discover top AI solutions and tools";

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />

      <div className="flex-1 flex flex-col overflow-auto">
        <SearchHeader
          title={pageTitle}
          subtitle={pageSubtitle}
        />

        <div className="container py-8">
          <div className="flex flex-col gap-6 mb-8">
            <div className="flex items-center gap-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder={`Search ${typeLabels[activeType as keyof typeof typeLabels] || "items"}...`}
                  className="pl-10"
                  value={searchQuery}
                  onChange={handleSearch}
                />
              </div>
              <Button variant="outline" className="gap-2">
                <SlidersHorizontal className="w-4 h-4" />
                Filter
              </Button>
              <div className="ml-auto flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  className={viewMode === "grid" ? "bg-primary/20" : ""}
                  onClick={() => setViewMode("grid")}
                >
                  <Grid3X3 className="w-5 h-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className={viewMode === "list" ? "bg-primary/20" : ""}
                  onClick={() => setViewMode("list")}
                >
                  <List className="w-5 h-5" />
                </Button>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {Object.entries(typeLabels).map(([key, label]) => (
                <Button
                  key={key}
                  variant={activeType === key ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleTypeChange(key)}
                  className={activeType === key ? "" : "bg-black/20 border-white/10"}
                >
                  {label}
                </Button>
              ))}
            </div>
          </div>

          {isError && (
            <div className="flex flex-col items-center justify-center py-12">
              <h3 className="text-xl font-semibold mb-4">Failed to load items</h3>
              <Button onClick={() => window.location.reload()}>Retry</Button>
            </div>
          )}

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="bg-black/20 border-primary/10 h-[320px] animate-pulse" />
              ))}
            </div>
          ) : (
            <div className={`grid ${
              viewMode === "grid" 
                ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3" 
                : "grid-cols-1"
            } gap-6`}>
              {displayItems.length > 0 ? (
                displayItems.map((item, index) => {
                  // Convert string icon to component for display
                  let itemWithIconComponent = { ...item };
                  if (typeof item.icon === 'string') {
                    itemWithIconComponent.icon = getIconComponent(item.icon);
                  }
                  
                  return (
                    <div
                      key={item.id || index}
                      ref={index === displayItems.length - 1 ? lastItemRef : undefined}
                    >
                      <ItemCard 
                        item={itemWithIconComponent}
                        type={activeType}
                        viewMode={viewMode}
                      />
                    </div>
                  );
                })
              ) : (
                <div className="col-span-full flex flex-col items-center justify-center py-12">
                  <h3 className="text-xl font-semibold mb-2">No {typeLabels[activeType as keyof typeof typeLabels]} found</h3>
                  <p className="text-muted-foreground mb-6">Try adjusting your search or filter criteria</p>
                  <Button onClick={() => setSearchQuery("")}>Clear search</Button>
                </div>
              )}
            </div>
          )}

          {isFetchingNextPage && (
            <div className="flex justify-center mt-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ExploreAll;
