
import Sidebar from "@/components/Layout/Sidebar";
import { Home as HomeIcon, Sparkles, Zap, Users, ArrowRight, Code, Palette, MessageSquare, Layout, Bot, Heart, Brain } from "lucide-react";
import { Button } from "@/components/ui/button";
import AutoScrollBanner from "@/components/Home/AutoScrollBanner";
import QuickStats from "@/components/Home/QuickStats";
import CategoryGrid from "@/components/Home/CategoryGrid";

const Home = () => {
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-auto">
          {/* Hero Banner Section */}
          <div className="relative h-[500px] bg-gradient-to-br from-[#1A1F2C] via-[#151515] to-black overflow-hidden">
            <div className="absolute inset-0 bg-grid-white/5" />
            <div className="container relative h-full flex items-center">
              <div className="max-w-2xl">
                <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-white to-white/70 bg-clip-text text-transparent">
                  Your World, Your Workflow, Your Way
                </h1>
                <p className="text-xl text-white/60 mb-8">
                  Welcome to FlowFusion Spaces - where workflow automation, AI agents, and collaboration merge in specialized domains. Create, customize, and share in a delightful, intuitive platform tailored to your unique needs.
                </p>
                <div className="flex items-center gap-4">
                  <Button size="lg" className="gap-2">
                    <Sparkles className="w-4 h-4" />
                    Create New Space
                  </Button>
                  <Button variant="outline" size="lg" className="gap-2">
                    Explore Spaces
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>

          <div className="container py-12 space-y-16">
            {/* Quick Stats Section */}
            <QuickStats />

            {/* Feature Categories */}
            <CategoryGrid />

            {/* Space Assistant Section */}
            <section className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/10 via-cyan-500/5 to-transparent rounded-3xl" />
              <div className="relative">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-2xl font-semibold mb-2">Meet Your Space Assistant</h2>
                    <p className="text-muted-foreground">Your ever-present guide in FlowFusion Spaces</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {[
                    {
                      icon: Bot,
                      title: "Real-Time Support",
                      description: "Chat with Flux at the canvas's center—it adapts the UI, offers tips, and highlights nodes as you go.",
                    },
                    {
                      icon: Brain,
                      title: "Proactive Guidance",
                      description: "Stuck? Flux glows with helpful hints and cheers you on with encouraging feedback.",
                    },
                    {
                      icon: Heart,
                      title: "Emotional Intelligence",
                      description: "Experience an assistant that adapts to your mood, celebrating successes and providing gentle support when needed.",
                    },
                  ].map((feature, index) => (
                    <div 
                      key={index} 
                      className="group glass-panel p-6 rounded-xl cursor-pointer hover:bg-white/5 transition-all duration-300 backdrop-blur-sm"
                    >
                      <div className="w-12 h-12 rounded-xl bg-emerald-500/10 grid place-items-center mb-4 group-hover:scale-110 transition-transform">
                        <feature.icon className="w-6 h-6 text-emerald-400" />
                      </div>
                      <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                      <p className="text-muted-foreground text-sm">{feature.description}</p>
                      <Button variant="ghost" className="mt-4 gap-2">
                        Learn More <ArrowRight className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* Core Features Section */}
            <section>
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-2xl font-semibold mb-2">Core Features</h2>
                  <p className="text-muted-foreground">Discover what makes FlowFusion unique</p>
                </div>
                <Button variant="outline">View All Features</Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  {
                    icon: Zap,
                    title: "AI-Enhanced Workflow Builder",
                    description: "Build powerful automations with our intuitive drag-and-drop interface.",
                  },
                  {
                    icon: MessageSquare,
                    title: "AI Agents",
                    description: "Collaborate with personalized AI assistants tailored to your needs.",
                  },
                  {
                    icon: Layout,
                    title: "Agentic Apps",
                    description: "Transform your workflows into standalone applications.",
                  },
                ].map((feature, index) => (
                  <div key={index} className="group glass-panel p-6 rounded-xl cursor-pointer hover:bg-white/5 transition-all duration-300">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 grid place-items-center mb-4 group-hover:scale-110 transition-transform">
                      <feature.icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                    <p className="text-muted-foreground text-sm">{feature.description}</p>
                    <Button variant="ghost" className="mt-4 gap-2">
                      Learn More <ArrowRight className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </section>

            {/* Popular Spaces Section */}
            <section>
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-2xl font-semibold mb-2">Popular Spaces</h2>
                  <p className="text-muted-foreground">Explore trending creative domains</p>
                </div>
                <Button variant="outline">Browse All Spaces</Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  {
                    title: "Anime Image Gen",
                    description: "Create stunning anime-style artwork with AI",
                    color: "from-purple-500/20 to-blue-500/20",
                    icon: Palette,
                  },
                  {
                    title: "Tech Article Writing",
                    description: "Craft engaging technical content with AI assistance",
                    color: "from-blue-500/20 to-cyan-500/20",
                    icon: Code,
                  },
                  {
                    title: "Marketing Suite",
                    description: "Automate and optimize your marketing workflows",
                    color: "from-red-500/20 to-orange-500/20",
                    icon: MessageSquare,
                  },
                ].map((space, index) => (
                  <div 
                    key={index}
                    className="glass-panel rounded-xl overflow-hidden cursor-pointer group"
                  >
                    <div className="h-40 relative overflow-hidden">
                      <div className={`absolute inset-0 bg-gradient-to-br ${space.color}`} />
                      <div className="absolute inset-0 backdrop-blur-sm" />
                      <div className="relative h-full flex items-center justify-center">
                        <space.icon className="w-16 h-16 text-white/40" />
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="text-lg font-semibold mb-2">{space.title}</h3>
                      <p className="text-sm text-muted-foreground mb-4">{space.description}</p>
                      <Button variant="outline" className="w-full gap-2">
                        Enter Space
                        <ArrowRight className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Home;
