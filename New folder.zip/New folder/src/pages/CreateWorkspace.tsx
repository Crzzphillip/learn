import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { 
  AlignCenter, 
  AlignLeft, 
  AlignRight, 
  Bold, 
  Monitor,
  Smartphone,
  Tablet,
  Link2,
  Copy,
  Share2,
  ChevronDown,
  Settings2
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { ComponentType, TextStyle, LinkSettings } from '../types/workspace';
import { getComponentProperties, updateComponentProperty, ComponentProperty } from '../services/componentProperties';

type TabType = 'properties' | 'styles' | 'actions';

const CreateWorkspace: React.FC = () => {
  const { templateId } = useParams();
  const [devicePreview, setDevicePreview] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [selectedComponent, setSelectedComponent] = useState<{ id: string; type: ComponentType } | null>(null);
  const [componentProperties, setComponentProperties] = useState<ComponentProperty[]>([]);
  const [activeTab, setActiveTab] = useState<TabType>('properties');

  const handleComponentSelect = (id: string, type: ComponentType) => {
    setSelectedComponent({ id, type });
    setComponentProperties(getComponentProperties(type));
  };

  const handlePropertyChange = (propertyId: string, value: any) => {
    if (selectedComponent) {
      const updatedProperties = updateComponentProperty(selectedComponent.type, propertyId, value);
      setComponentProperties(updatedProperties);
    }
  };

  const renderPropertyInput = (property: ComponentProperty) => {
    switch (property.type) {
      case 'font':
        return (
          <Select
            value={property.value}
            onValueChange={(value) => handlePropertyChange(property.id, value)}
          >
            <SelectTrigger className="bg-white/5 border-white/10">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {property.options?.map((option) => (
                <SelectItem key={option} value={option}>
                  {option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );
      case 'alignment':
        return (
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              className={cn(
                "flex-1",
                property.value === 'left' && "bg-white/10"
              )}
              onClick={() => handlePropertyChange(property.id, 'left')}
            >
              <AlignLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className={cn(
                "flex-1",
                property.value === 'center' && "bg-white/10"
              )}
              onClick={() => handlePropertyChange(property.id, 'center')}
            >
              <AlignCenter className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className={cn(
                "flex-1",
                property.value === 'right' && "bg-white/10"
              )}
              onClick={() => handlePropertyChange(property.id, 'right')}
            >
              <AlignRight className="w-4 h-4" />
            </Button>
          </div>
        );
      case 'background':
        return (
          <div className="space-y-4">
            <div className="flex gap-2">
              {['Solid', 'Gradient', 'Pattern', 'Picture'].map((type) => (
                <Button
                  key={type}
                  variant="ghost"
                  size="sm"
                  className={cn(
                    "flex-1 text-xs",
                    property.value.type === type.toLowerCase() && "bg-white/10"
                  )}
                  onClick={() => handlePropertyChange(property.id, { ...property.value, type: type.toLowerCase() })}
                >
                  {type}
                </Button>
              ))}
            </div>
            {property.value.type === 'solid' && (
              <div className="space-y-2">
                <div className="h-24 rounded-lg overflow-hidden bg-gradient-to-b from-blue-400 to-blue-600" />
                <div className="grid grid-cols-7 gap-2">
                  {property.presetColors?.map((color) => (
                    <button
                      key={color}
                      className={cn(
                        "w-6 h-6 rounded-full",
                        property.value.color === color && "ring-2 ring-purple-600 ring-offset-2 ring-offset-[#1A1A1A]"
                      )}
                      style={{ backgroundColor: color }}
                      onClick={() => handlePropertyChange(property.id, { ...property.value, color })}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        );
      case 'opacity':
        return (
          <div className="flex items-center gap-4">
            <span className="text-sm text-white/60">{property.value}%</span>
            <Slider
              value={[property.value]}
              min={0}
              max={100}
              step={1}
              onValueChange={([value]) => handlePropertyChange(property.id, value)}
              className="flex-1"
            />
          </div>
        );
      case 'text':
        return (
          <Input
            value={property.value}
            onChange={(e) => handlePropertyChange(property.id, e.target.value)}
            className="bg-white/5 border-white/10"
          />
        );
      case 'number':
        return (
          <Input
            type="number"
            value={property.value}
            onChange={(e) => handlePropertyChange(property.id, Number(e.target.value))}
            className="bg-white/5 border-white/10"
          />
        );
      case 'select':
        return (
          <Select
            value={property.value}
            onValueChange={(value) => handlePropertyChange(property.id, value)}
          >
            <SelectTrigger className="bg-white/5 border-white/10">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {property.options?.map((option) => (
                <SelectItem key={option} value={option}>
                  {option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );
      case 'boolean':
        return (
          <Switch
            checked={property.value}
            onCheckedChange={(checked) => handlePropertyChange(property.id, checked)}
          />
        );
      case 'color':
        return (
          <Input
            type="color"
            value={property.value}
            onChange={(e) => handlePropertyChange(property.id, e.target.value)}
            className="bg-white/5 border-white/10 h-8 w-full"
          />
        );
      default:
        return null;
    }
  };

  const renderTabContent = () => {
    if (!selectedComponent) {
      return (
        <div className="text-white/60 text-sm text-center p-4">
          Select a component to view its properties
        </div>
      );
    }

    switch (activeTab) {
      case 'properties':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="font-medium flex items-center gap-2">
                <Settings2 className="w-4 h-4" />
                {selectedComponent.type.charAt(0).toUpperCase() + selectedComponent.type.slice(1)} Properties
              </h3>
              <span className="text-xs text-white/60">24</span>
            </div>
            
            {/* Typography Section */}
            <div className="space-y-4">
              {componentProperties
                .filter(prop => prop.category === 'typography')
                .map((property) => (
                  <div key={property.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-sm text-white/60">
                        {property.name}
                      </label>
                    </div>
                    {renderPropertyInput(property)}
                  </div>
                ))}
            </div>
          </div>
        );
      case 'styles':
        return (
          <div className="space-y-6">
            <h3 className="font-medium">Backgrounds</h3>
            <div className="space-y-4">
              {componentProperties
                .filter(prop => prop.category === 'background')
                .map((property) => (
                  <div key={property.id} className="space-y-2">
                    <label className="text-sm text-white/60">
                      {property.name}
                    </label>
                    {renderPropertyInput(property)}
                  </div>
                ))}
            </div>
          </div>
        );
      case 'actions':
        return (
          <div className="space-y-6">
            <h3 className="font-medium">Actions</h3>
            <div className="space-y-4">
              {componentProperties
                .filter(prop => prop.category === 'advanced')
                .map((property) => (
                  <div key={property.id} className="space-y-2">
                    <label className="text-sm text-white/60">
                      {property.name}
                    </label>
                    {renderPropertyInput(property)}
                  </div>
                ))}
            </div>
          </div>
        );
    }
  };

  return (
    <div className="flex h-screen bg-[#1A1A1A] text-white">
      {/* Left Sidebar - Navigator */}
      <div className="w-64 border-r border-white/10 p-4">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-full bg-purple-600" />
          <span className="font-semibold">Pulse</span>
        </div>
        <div className="relative">
          <input
            type="text"
            placeholder="Search elements"
            className="w-full bg-white/5 rounded-md px-4 py-2 text-sm"
          />
        </div>
        
        {/* Component List */}
        <div className="mt-4 space-y-2">
          <div
            className={cn(
              "p-2 rounded cursor-pointer hover:bg-white/5",
              selectedComponent?.type === 'button' && "bg-white/10"
            )}
            onClick={() => handleComponentSelect('button-1', 'button')}
          >
            Button
          </div>
          <div
            className={cn(
              "p-2 rounded cursor-pointer hover:bg-white/5",
              selectedComponent?.type === 'text' && "bg-white/10"
            )}
            onClick={() => handleComponentSelect('text-1', 'text')}
          >
            Text
          </div>
          <div
            className={cn(
              "p-2 rounded cursor-pointer hover:bg-white/5",
              selectedComponent?.type === 'image' && "bg-white/10"
            )}
            onClick={() => handleComponentSelect('image-1', 'image')}
          >
            Image
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col">
        {/* Top Navigation */}
        <div className="h-14 border-b border-white/10 flex items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon">
              <Monitor className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon">
              <Tablet className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon">
              <Smartphone className="w-4 h-4" />
            </Button>
            <div className="text-sm text-white/60">1440 px</div>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm">
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </Button>
            <Button className="bg-purple-600 hover:bg-purple-700">
              Publish
            </Button>
          </div>
        </div>

        {/* Main Editor Area */}
        <div className="flex-1 flex">
          {/* Preview Area */}
          <div className="flex-1 bg-[#111111] p-8">
            <div className="max-w-[1440px] mx-auto bg-white rounded-lg shadow-xl overflow-hidden min-h-[600px]">
              {/* Your preview content here */}
            </div>
          </div>

          {/* Right Sidebar - Properties */}
          <div className="w-80 border-l border-white/10">
            {/* Tab Navigation */}
            <div className="flex border-b border-white/10">
              <button
                className={cn(
                  "flex-1 px-4 py-3 text-sm font-medium",
                  activeTab === 'properties' ? "text-white border-b-2 border-purple-600" : "text-white/60"
                )}
                onClick={() => setActiveTab('properties')}
              >
                Properties
              </button>
              <button
                className={cn(
                  "flex-1 px-4 py-3 text-sm font-medium",
                  activeTab === 'styles' ? "text-white border-b-2 border-purple-600" : "text-white/60"
                )}
                onClick={() => setActiveTab('styles')}
              >
                Styles
              </button>
              <button
                className={cn(
                  "flex-1 px-4 py-3 text-sm font-medium",
                  activeTab === 'actions' ? "text-white border-b-2 border-purple-600" : "text-white/60"
                )}
                onClick={() => setActiveTab('actions')}
              >
                Actions
              </button>
            </div>

            {/* Tab Content */}
            <div className="p-4">
              {renderTabContent()}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateWorkspace;
