
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import Sidebar from '@/components/Layout/Sidebar';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card } from '@/components/ui/card';
import SpaceLeftSidebar from '@/components/Space/SpaceLeftSidebar';
import BackToSpace from '@/components/Space/BackToSpace';
import { Search, Server, RefreshCw, Plus, Info, GitBranch, Database, Globe } from 'lucide-react';
import { MCPServerItem } from '@/data/mcpServerData';
import { mcpServerService } from '@/services/mcpServerService';
import ServerStatusCard from '@/components/MCPServer/ServerStatusCard';
import { toast } from 'sonner';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';

const MCPServer = () => {
  const { spaceId } = useParams();
  const [servers, setServers] = useState<MCPServerItem[]>([]);
  const [filteredServers, setFilteredServers] = useState<MCPServerItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [regionFilter, setRegionFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [activeTab, setActiveTab] = useState('all');
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [activeView, setActiveView] = useState('servers');
  
  useEffect(() => {
    fetchServers();
  }, []);
  
  const fetchServers = async () => {
    try {
      setIsLoading(true);
      const data = await mcpServerService.getServers();
      setServers(data);
      setFilteredServers(data);
      setIsLoading(false);
    } catch (error) {
      console.error("Failed to fetch MCP servers:", error);
      toast.error("Failed to load MCP servers. Please try again.");
      setIsLoading(false);
    }
  };
  
  const refreshData = async () => {
    setIsRefreshing(true);
    await fetchServers();
    setIsRefreshing(false);
    toast.success("Server data refreshed");
  };
  
  useEffect(() => {
    let result = servers;
    
    if (searchQuery) {
      result = result.filter(server => 
        server.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        server.ip.includes(searchQuery)
      );
    }
    
    if (regionFilter !== 'all') {
      result = result.filter(server => server.region === regionFilter);
    }
    
    if (statusFilter !== 'all') {
      result = result.filter(server => server.status === statusFilter);
    }
    
    if (activeTab !== 'all') {
      result = result.filter(server => server.type === activeTab);
    }
    
    setFilteredServers(result);
  }, [searchQuery, regionFilter, statusFilter, activeTab, servers]);
  
  const handleRestart = async (id: string) => {
    const success = await mcpServerService.restartServer(id);
  };
  
  const handleStatusChange = async (id: string, status: 'online' | 'offline' | 'maintenance') => {
    const success = await mcpServerService.updateServerStatus(id, status);
    if (success) {
      const updatedServers = servers.map(server => {
        if (server.id === id) {
          return { ...server, status };
        }
        return server;
      });
      setServers(updatedServers);
    }
  };
  
  const getAvailableRegions = () => {
    const regions = new Set<string>();
    servers.forEach(server => regions.add(server.region));
    return Array.from(regions);
  };

  const handleAddNewServer = () => {
    toast.info("Server creation feature will be available soon");
  };
  
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex">
        <SpaceLeftSidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <main className="flex-1 overflow-auto">
            <div className="container py-6">
              <BackToSpace spaceId={spaceId || ""} />
              
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <h1 className="text-2xl font-bold">MCP Server Integration</h1>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Info className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent className="max-w-sm">
                        <p>MCP (Model Context Protocol) enables AI agents to access external data sources 
                          and services through a standardized client-server architecture.</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <div className="flex items-center gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="gap-1" 
                    onClick={refreshData} 
                    disabled={isRefreshing}
                  >
                    <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
                    {isRefreshing ? 'Refreshing...' : 'Refresh'}
                  </Button>
                  <Button 
                    variant="default" 
                    size="sm" 
                    className="gap-1" 
                    onClick={handleAddNewServer}
                  >
                    <Plus className="w-4 h-4" />
                    Add New Server
                  </Button>
                </div>
              </div>

              <div className="mb-6">
                <Tabs value={activeView} onValueChange={setActiveView} className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="servers" className="flex items-center gap-2">
                      <Server className="w-4 h-4" />
                      <span>MCP Servers</span>
                    </TabsTrigger>
                    <TabsTrigger value="clients" className="flex items-center gap-2">
                      <GitBranch className="w-4 h-4" />
                      <span>MCP Clients</span>
                    </TabsTrigger>
                    <TabsTrigger value="documentation" className="flex items-center gap-2">
                      <Info className="w-4 h-4" />
                      <span>Documentation</span>
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="servers" className="mt-0 space-y-6">
                    <div className="mb-6">
                      <div className="relative">
                        <Search className="absolute top-3 left-3 h-4 w-4 text-muted-foreground" />
                        <Input 
                          className="pl-10" 
                          placeholder="Search servers by name or IP..." 
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                        />
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between mb-4">
                      <Tabs value={activeTab} onValueChange={setActiveTab}>
                        <TabsList>
                          <TabsTrigger value="all">All</TabsTrigger>
                          <TabsTrigger value="primary">Primary</TabsTrigger>
                          <TabsTrigger value="secondary">Secondary</TabsTrigger>
                          <TabsTrigger value="backup">Backup</TabsTrigger>
                        </TabsList>
                      </Tabs>
                      <div className="flex items-center gap-2">
                        <Select value={regionFilter} onValueChange={setRegionFilter}>
                          <SelectTrigger className="w-[150px]">
                            <SelectValue placeholder="All Regions" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Regions</SelectItem>
                            {getAvailableRegions().map(region => (
                              <SelectItem key={region} value={region}>{region}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        
                        <Select value={statusFilter} onValueChange={setStatusFilter}>
                          <SelectTrigger className="w-[150px]">
                            <SelectValue placeholder="All Statuses" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Statuses</SelectItem>
                            <SelectItem value="online">Online</SelectItem>
                            <SelectItem value="offline">Offline</SelectItem>
                            <SelectItem value="maintenance">Maintenance</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {filteredServers.map(server => (
                        <ServerStatusCard 
                          key={server.id} 
                          server={server} 
                          onRestart={handleRestart}
                          onStatusChange={handleStatusChange}
                        />
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="clients" className="mt-0">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      <Card className="p-5">
                        <div className="mb-2 flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-primary/10 rounded-full grid place-items-center">
                              <GitBranch className="w-5 h-5 text-primary" />
                            </div>
                            <div>
                              <h3 className="font-medium">Database Client</h3>
                              <p className="text-xs text-muted-foreground">Data access for AI agents</p>
                            </div>
                          </div>
                          <Badge variant="success" className="bg-green-500/10 text-green-500 border-green-500/20">Active</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-4">Connects AI agents to database servers for data retrieval and storage operations.</p>
                        <Button variant="outline" size="sm" className="w-full">Configure</Button>
                      </Card>
                      
                      <Card className="p-5">
                        <div className="mb-2 flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-primary/10 rounded-full grid place-items-center">
                              <Globe className="w-5 h-5 text-primary" />
                            </div>
                            <div>
                              <h3 className="font-medium">API Client</h3>
                              <p className="text-xs text-muted-foreground">External API connections</p>
                            </div>
                          </div>
                          <Badge variant="success" className="bg-green-500/10 text-green-500 border-green-500/20">Active</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-4">Enables AI agents to interact with external APIs and web services securely.</p>
                        <Button variant="outline" size="sm" className="w-full">Configure</Button>
                      </Card>
                      
                      <Card className="p-5">
                        <div className="mb-2 flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-primary/10 rounded-full grid place-items-center">
                              <Database className="w-5 h-5 text-primary" />
                            </div>
                            <div>
                              <h3 className="font-medium">File System Client</h3>
                              <p className="text-xs text-muted-foreground">Document storage access</p>
                            </div>
                          </div>
                          <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">Setup Required</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-4">Provides AI agents with access to file systems for document processing.</p>
                        <Button variant="outline" size="sm" className="w-full">Setup</Button>
                      </Card>
                    </div>
                  </TabsContent>

                  <TabsContent value="documentation" className="mt-0">
                    <div className="bg-card rounded-lg p-6 border">
                      <h2 className="text-xl font-semibold mb-4">Understanding MCP Architecture</h2>
                      <p className="mb-4">
                        Model Context Protocol (MCP) is an open standard developed by Anthropic to facilitate communication between AI models and external systems through a structured client-server architecture.
                      </p>
                      
                      <div className="mb-6">
                        <h3 className="text-lg font-medium mb-2">Key Components</h3>
                        <ul className="list-disc pl-5 space-y-2">
                          <li><strong>MCP Hosts:</strong> Your marketplace acts as the host, connecting AI agents to external resources</li>
                          <li><strong>MCP Clients:</strong> Components within your platform that send requests to MCP servers</li>
                          <li><strong>MCP Servers:</strong> External services providing data or tools (databases, APIs, file systems)</li>
                        </ul>
                      </div>
                      
                      <div className="mb-6">
                        <h3 className="text-lg font-medium mb-2">Benefits for AI Agents</h3>
                        <ul className="list-disc pl-5 space-y-2">
                          <li>Access to external data sources and tools</li>
                          <li>Standardized communication protocol</li>
                          <li>Enhanced capabilities beyond native model functions</li>
                          <li>Secure and authenticated connections to services</li>
                        </ul>
                      </div>
                      
                      <div className="flex justify-end mt-6">
                        <Button variant="default">View Full Documentation</Button>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default MCPServer;
