import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { PlusCircle, Search, Layout, Bot, Workflow, Box, Activity, Star, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import Sidebar from "@/components/Layout/Sidebar";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const createOptions = [
  {
    title: "Workspace",
    description: "Create a new workspace for your projects",
    icon: Layout,
    path: "/create/workspace"
  },
  {
    title: "AI Agent",
    description: "Build an intelligent AI agent",
    icon: Bot,
    path: "/agent/new"
  },
  {
    title: "Workflow",
    description: "Design automated workflows",
    icon: Workflow,
    path: "/workflow/builder"
  },
  {
    title: "App",
    description: "Create a new application",
    icon: Box,
    path: "/create-app"
  },
  {
    title: "Benchmark",
    description: "Set up performance benchmarks",
    icon: Activity,
    path: "/benchmarks/new"
  }
];

// Mock data for recent projects
const recentProjects = [
  {
    name: "Personal Space",
    type: "Workspace",
    lastModified: "2 hours ago"
  },
  {
    name: "Chat Assistant",
    type: "AI Agent",
    lastModified: "1 day ago"
  },
  {
    name: "Data Pipeline",
    type: "Workflow",
    lastModified: "3 days ago"
  }
];

const templates = [
  {
    title: "Blank Workspace",
    description: "Start with an empty workspace",
    category: "Basic",
    image: "https://images.unsplash.com/photo-1629904853716-f0bc54eea481?q=80&w=300&h=200&fit=crop",
    path: "/create/workspace/blank"
  },
  {
    title: "AI Chat Assistant",
    description: "Build an intelligent chatbot with advanced AI capabilities",
    category: "AI",
    image: "https://images.unsplash.com/photo-1676299081847-c0d96de06b85?q=80&w=300&h=200&fit=crop",
    path: "/create/workspace/chat-assistant",
    featured: true
  },
  {
    title: "Data Processing Pipeline",
    description: "Automated workflow for data processing and analysis",
    category: "Workflow",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=300&h=200&fit=crop",
    path: "/create/workspace/data-pipeline"
  },
  {
    title: "E-commerce Store",
    description: "Complete e-commerce solution with product management",
    category: "Business",
    image: "https://images.unsplash.com/photo-1472851294608-062f824d29cc?q=80&w=300&h=200&fit=crop",
    path: "/create/workspace/ecommerce",
    featured: true
  },
  {
    title: "Portfolio Website",
    description: "Professional portfolio template with customizable sections",
    category: "Personal",
    image: "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?q=80&w=300&h=200&fit=crop",
    path: "/create/workspace/portfolio"
  },
  {
    title: "Task Management",
    description: "Project and task management system with team collaboration",
    category: "Productivity",
    image: "https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?q=80&w=300&h=200&fit=crop",
    path: "/create/workspace/task-management"
  },
  {
    title: "Blog Platform",
    description: "Modern blog platform with CMS and analytics",
    category: "Content",
    image: "https://images.unsplash.com/photo-1499750310107-5fef28a66643?q=80&w=300&h=200&fit=crop",
    path: "/create/workspace/blog"
  },
  {
    title: "API Gateway",
    description: "Secure API gateway with authentication and monitoring",
    category: "Development",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?q=80&w=300&h=200&fit=crop",
    path: "/create/workspace/api-gateway"
  },
  {
    title: "Learning Management",
    description: "Educational platform with course management and tracking",
    category: "Education",
    image: "https://images.unsplash.com/photo-1509062522246-3755977927d7?q=80&w=300&h=200&fit=crop",
    path: "/create/workspace/lms",
    featured: true
  }
];

const categories = ["All", "Featured", "AI", "Business", "Development", "Personal", "Productivity", "Content", "Education"];

export default function CreatePage() {
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-auto">
          <div className="container mx-auto p-6 space-y-8">
            <div className="flex justify-between items-center">
              <h1 className="text-3xl font-bold">Create New Project</h1>
              <div className="flex items-center gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Search templates..."
                    className="pl-10 w-[250px]"
                  />
                </div>
                <Button>
                  <PlusCircle className="mr-2 h-4 w-4" />
                  New Project
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {createOptions.map((option) => (
                <Link to={option.path} key={option.title}>
                  <Card className="hover:bg-accent/50 transition-colors cursor-pointer">
                    <CardHeader>
                      <div className="flex items-center gap-3">
                        <option.icon className="h-6 w-6" />
                        <CardTitle>{option.title}</CardTitle>
                      </div>
                      <CardDescription>{option.description}</CardDescription>
                    </CardHeader>
                  </Card>
                </Link>
              ))}
            </div>

            <div className="space-y-6">
              <h2 className="text-2xl font-semibold">Recent Projects</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {recentProjects.map((project) => (
                  <Card key={project.name}>
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold">{project.name}</h3>
                          <p className="text-sm text-muted-foreground">{project.type}</p>
                        </div>
                        <p className="text-sm text-muted-foreground">{project.lastModified}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-semibold">Templates</h2>
                <div className="flex gap-2">
                  {categories.map((category) => (
                    <Badge
                      key={category}
                      variant={category === "All" ? "default" : "secondary"}
                      className="cursor-pointer hover:bg-primary/80"
                    >
                      {category}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {templates.map((template) => (
                  <Link to={template.path} key={template.title}>
                    <Card className="group overflow-hidden hover:border-primary/50 transition-all duration-300">
                      <div className="relative aspect-[16/9] overflow-hidden">
                        <img 
                          src={template.image} 
                          alt={template.title}
                          className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-300"
                        />
                        {template.featured && (
                          <div className="absolute top-2 right-2">
                            <Badge variant="default" className="bg-primary/90">
                              <Star className="w-3 h-3 mr-1" />
                              Featured
                            </Badge>
                          </div>
                        )}
                      </div>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle className="group-hover:text-primary transition-colors">
                              {template.title}
                            </CardTitle>
                            <Badge variant="secondary" className="mt-2">
                              {template.category}
                            </Badge>
                          </div>
                        </div>
                        <CardDescription className="mt-2">
                          {template.description}
                        </CardDescription>
                      </CardHeader>
                      <CardFooter className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">
                          Use Template
                        </span>
                        <ArrowRight className="w-4 h-4 text-primary opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                      </CardFooter>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
} 