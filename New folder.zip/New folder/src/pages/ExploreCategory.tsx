import { useParams } from "react-router-dom";
import Sidebar from "@/components/Layout/Sidebar";
import { Brain, Code, Palette, MessageSquare, Star, Users, ArrowRight } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useNavigate } from "react-router-dom";

interface Space {
  id: string;
  title: string;
  description: string;
  icon: any;
  rating: string;
  users: string;
}

const categoryData: Record<string, {
  title: string;
  description: string;
  gradient: string;
  icon: any;
  spaces: Space[];
}> = {
  "development": {
    title: "Development",
    description: "AI-powered coding assistants and development tools",
    gradient: "from-[#1A1F2C] to-[#7E69AB]",
    icon: Code,
    spaces: [
      {
        id: "codecraft",
        title: "CodeCraft AI",
        description: "Expert coding assistant with deep understanding of multiple programming languages.",
        icon: Code,
        rating: "4.9",
        users: "2.4k"
      },
      {
        id: "devops",
        title: "DevOps Assistant",
        description: "Your AI partner for DevOps automation and infrastructure management.",
        icon: Code,
        rating: "4.8",
        users: "1.8k"
      }
    ]
  },
  "creative": {
    title: "Creative",
    description: "AI tools for design, content creation, and artistic endeavors",
    gradient: "from-[#D946EF] to-[#8B5CF6]",
    icon: Palette,
    spaces: [
      {
        id: "creative-muse",
        title: "Creative Muse",
        description: "Your AI partner for creative projects, from design to content creation.",
        icon: Palette,
        rating: "4.8",
        users: "3.2k"
      },
      {
        id: "design-ai",
        title: "Design AI",
        description: "Advanced AI assistant for UI/UX design and visual content creation.",
        icon: Palette,
        rating: "4.7",
        users: "2.1k"
      }
    ]
  },
  "communication": {
    title: "Communication",
    description: "AI-powered tools for better communication and content writing",
    gradient: "from-[#0EA5E9] to-[#2DD4BF]",
    icon: MessageSquare,
    spaces: [
      {
        id: "chat-master",
        title: "ChatMaster Pro",
        description: "Advanced conversational AI for natural and engaging interactions.",
        icon: MessageSquare,
        rating: "4.9",
        users: "4.5k"
      },
      {
        id: "content-wizard",
        title: "Content Wizard",
        description: "AI-powered content creation and optimization assistant.",
        icon: MessageSquare,
        rating: "4.8",
        users: "3.1k"
      }
    ]
  }
};

const SpaceCard = ({ space }: { space: Space }) => {
  const navigate = useNavigate();
  const Icon = space.icon;

  return (
    <Dialog>
      <DialogTrigger asChild>
        <div className="group cursor-pointer">
          <div className="relative h-[400px] rounded-2xl overflow-hidden bg-secondary/10 border border-white/5 hover:border-white/10 transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-br from-secondary/80 via-secondary/50 to-transparent opacity-80" />
            <div className="absolute inset-0 p-8 flex flex-col">
              <div className="flex items-start justify-between mb-auto">
                <div className="w-14 h-14 rounded-xl bg-white/10 backdrop-blur-xl grid place-items-center">
                  <Icon className="w-7 h-7" />
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 backdrop-blur-sm">
                    <Users className="w-4 h-4" />
                    <span className="text-sm font-medium">{space.users}</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 backdrop-blur-sm">
                    <Star className="w-4 h-4 fill-primary text-primary" />
                    <span className="text-sm font-medium">{space.rating}</span>
                  </div>
                </div>
              </div>
              
              <div className="mt-auto">
                <h3 className="text-2xl font-semibold mb-3">{space.title}</h3>
                <p className="text-base text-white/80 mb-6 line-clamp-2">{space.description}</p>
                <div className="flex items-center text-primary">
                  <span className="text-sm font-medium group-hover:translate-x-1 transition-transform duration-300">
                    Explore Space
                  </span>
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform duration-300" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{space.title}</DialogTitle>
          <DialogDescription>
            AI Space for advanced assistance
          </DialogDescription>
        </DialogHeader>
        <div className="py-6">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-16 h-16 rounded-xl bg-secondary/50 grid place-items-center flex-shrink-0">
              <Icon className="w-8 h-8" />
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-1">{space.title}</h4>
              <div className="flex items-center gap-4 mb-2">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-primary text-primary" />
                  <span className="text-sm">{space.rating}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Users className="w-4 h-4" />
                  <span className="text-sm">{space.users} users</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <h5 className="text-sm font-medium mb-2">Description</h5>
              <p className="text-sm text-muted-foreground">{space.description}</p>
            </div>
          </div>
        </div>
        <DialogFooter>
          <button 
            onClick={() => navigate(`/space/${space.id}`)}
            className="w-full inline-flex items-center justify-center px-4 py-2.5 rounded-lg font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
          >
            Continue to Space
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const ExploreCategory = () => {
  const { spacecategoryid } = useParams();
  const navigate = useNavigate();

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 overflow-auto">
          {Object.entries(categoryData).map(([id, category]) => (
            <section 
              key={id}
              className={`relative py-12 ${id === spacecategoryid ? 'min-h-screen' : 'min-h-[600px]'}`}
            >
              <div className="container">
                <div className="mb-12">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-xl grid place-items-center">
                      <category.icon className="w-8 h-8" />
                    </div>
                    <h2 className="text-3xl font-bold">{category.title}</h2>
                  </div>
                  <p className="text-lg text-white/80 max-w-2xl">{category.description}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {category.spaces.map((space) => (
                    <SpaceCard key={space.id} space={space} />
                  ))}
                </div>
              </div>
            </section>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ExploreCategory;
