
import { useParams } from "react-router-dom";
import { useState, useEffect } from "react";
import { spaceTemplates } from "@/config/spaceTemplates";
import SpaceLayout from "@/components/Space/SpaceLayout";
import SpaceContentGrid from "@/components/Space/SpaceContentGrid";
import BackToSpace from "@/components/Space/BackToSpace";
import ToolsSection from "@/components/Space/ToolsSection";
import WorldFeatures from "@/components/Space/WorldFeatures";
import TypewriterCard from "@/components/Space/TypewriterCard";
import { Search, Filter, Wand2, Palette, Image, Layers, Zap, FileText, Code, Globe, Database } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SpaceFeature } from "@/types/space";
import { getSpaceStats } from "@/data/spaceData";
import { toolsService } from "@/services/toolsService";
import { toast } from "sonner";

const ToolsPage = () => {
  const { spaceId = 'development' } = useParams();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  
  const spaceTemplate = spaceTemplates[spaceId] || spaceTemplates.development;
  const spaceStats = getSpaceStats();
  
  // Get tools for this specific space
  const allTools = toolsService.getToolsForSpace(spaceId);
  
  // Filter tools based on search query and category
  const filteredTools = allTools.filter(tool => {
    const matchesSearch = 
      searchQuery === "" || 
      tool.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = 
      selectedCategory === "all" || 
      tool.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });
  
  // Get all available categories for this space
  const toolCategories = ["all", ...toolsService.getCategories(spaceId)];
  
  // Space-specific typewriter examples
  const getTypewriterExamples = () => {
    if (spaceId === "leonardo") {
      return [
        "Generate a realistic portrait of a woman with blue eyes",
        "Create a sci-fi landscape with floating islands",
        "Design a logo for a tech startup with minimalist style"
      ];
    } else if (spaceId === "crypto" || spaceId === "crypto-analyst") {
      return [
        "Analyze the recent price movements of Bitcoin",
        "Create a report on emerging DeFi protocols",
        "Generate a prediction for next week's market trends"
      ];
    } else if (spaceId === "development") {
      return [
        "Generate a React component for a dashboard card",
        "Create a TypeScript interface for user data",
        "Write a CSS animation for a loading spinner"
      ];
    } else {
      return [
        "Create a workflow to process user data",
        "Build an automation for content approval",
        "Design a system architecture diagram"
      ];
    }
  };
  
  // Space-specific features
  const getWorldFeatures = (): SpaceFeature[] => {
    if (spaceId === "leonardo") {
      return [
        {
          id: "image-generation",
          title: "Image Generation",
          description: "Create photorealistic images or artistic content from text descriptions",
          icon: Image,
          isAvailable: true,
          category: "generation"
        },
        {
          id: "motion",
          title: "Motion Creation",
          description: "Transform static images into engaging short videos",
          icon: Zap,
          isAvailable: true,
          category: "animation"
        },
        {
          id: "custom-training",
          title: "Custom Model Training",
          description: "Create personalized AI models with your own datasets",
          icon: Database,
          isAvailable: true,
          category: "advanced"
        }
      ];
    } else if (spaceId === "crypto" || spaceId === "crypto-analyst") {
      return [
        {
          id: "market-analysis",
          title: "Market Analysis",
          description: "Advanced tools for analyzing cryptocurrency market trends",
          icon: Layers,
          isAvailable: true,
          category: "analysis"
        },
        {
          id: "ai-predictions",
          title: "AI Predictions",
          description: "Machine learning models for market trend forecasting",
          icon: Wand2,
          isAvailable: true,
          category: "prediction"
        },
        {
          id: "portfolio-optimization",
          title: "Portfolio Optimization",
          description: "AI-powered tools to optimize your crypto portfolio",
          icon: Globe,
          isAvailable: true,
          category: "portfolio"
        }
      ];
    } else if (spaceId === "development") {
      return [
        {
          id: "code-generation",
          title: "AI Code Generation",
          description: "Generate high-quality code in multiple languages",
          icon: Code,
          isAvailable: true,
          category: "development"
        },
        {
          id: "api-integration",
          title: "API Integration",
          description: "Connect to external services and APIs with ease",
          icon: Globe,
          isAvailable: true,
          category: "development"
        },
        {
          id: "database-designer",
          title: "Database Designer",
          description: "Visual database schema design and optimization",
          icon: Database,
          isAvailable: false,
          category: "data"
        }
      ];
    } else {
      return [
        {
          id: "workflow-automation",
          title: "Workflow Automation",
          description: "Automate complex workflows with visual editor",
          icon: Zap,
          isAvailable: true,
          category: "automation"
        },
        {
          id: "data-processing",
          title: "Data Processing",
          description: "Process and transform data with AI assistance",
          icon: Database,
          isAvailable: true,
          category: "data"
        },
        {
          id: "advanced-analytics",
          title: "Advanced Analytics",
          description: "Gain insights with powerful analytics tools",
          icon: Layers,
          isAvailable: false,
          category: "analysis"
        }
      ];
    }
  };
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success(`Searching for "${searchQuery}"`);
  };

  return (
    <SpaceLayout 
      template={spaceTemplate}
      stats={spaceStats}
    >
      <div className="container py-8">
        <BackToSpace spaceId={spaceId} />
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold">{spaceTemplate.title} Tools</h1>
            <p className="text-muted-foreground">Discover powerful tools for your projects</p>
          </div>
          
          <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search tools..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {toolCategories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category === "all" ? "All Categories" : 
                      category.charAt(0).toUpperCase() + category.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Button type="submit" variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </form>
        </div>
        
        <WorldFeatures
          features={getWorldFeatures()}
          title={`${spaceTemplate.title} Features`}
          description={`Specialized tools and capabilities for the ${spaceTemplate.title}`}
          primaryColor={spaceTemplate.primaryColor}
          gradient={`from-[${spaceTemplate.secondaryColor}]/20 to-[${spaceTemplate.accentColor}]/20`}
          className="mb-12"
        />
        
        <div className="mb-12">
          <h2 className="text-2xl font-semibold mb-6">AI-Powered Tools</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <TypewriterCard
              title="AI Assistant"
              description="Get help with your tasks using natural language"
              examples={getTypewriterExamples()}
              icon={<Wand2 className="w-5 h-5" style={{ color: spaceTemplate.primaryColor }} />}
              primaryColor={spaceTemplate.primaryColor}
            />
            <TypewriterCard
              title="Content Generator"
              description="Generate high-quality content for your projects"
              examples={[
                "Generate a product description for a smartphone",
                "Write a blog post about artificial intelligence",
                "Create marketing copy for a new service"
              ]}
              icon={<Palette className="w-5 h-5" style={{ color: spaceTemplate.accentColor }} />}
              primaryColor={spaceTemplate.accentColor}
            />
            <TypewriterCard
              title="Visual Creator"
              description="Create visual assets with AI assistance"
              examples={[
                "Design a logo for my project",
                "Create an icon set for my application",
                "Generate a banner image for social media"
              ]}
              icon={<Layers className="w-5 h-5" style={{ color: spaceTemplate.secondaryColor }} />}
              primaryColor={spaceTemplate.secondaryColor}
            />
          </div>
        </div>
        
        <ToolsSection
          tools={filteredTools}
          primaryColor={spaceTemplate.primaryColor}
          themeTitle="All Tools"
          themeDescription={`Browse all available tools for ${spaceTemplate.title}`}
          showCategories={true}
        />
      </div>
    </SpaceLayout>
  );
};

export default ToolsPage;
