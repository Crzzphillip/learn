
import Sidebar from "@/components/Layout/Sidebar";
import { Brain, Code, MessageSquare, Palette, Image, Zap, FileText } from "lucide-react";
import AutoScrollBanner from "@/components/Home/AutoScrollBanner";
import FeaturedAgent from "@/components/Home/FeaturedAgent";
import QuickStats from "@/components/Home/QuickStats";
import CategoryGrid from "@/components/Home/CategoryGrid";
import { ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";
import TypewriterCard from "@/components/Space/TypewriterCard";
import WorldFeatures from "@/components/Space/WorldFeatures";

const Index = () => {
  const navigate = useNavigate();
  const featuredAgents = [
    {
      id: "codecraft",
      title: "CodeCraft AI",
      description: "Expert coding assistant with deep understanding of multiple programming languages.",
      icon: Code,
      category: "Development",
      rating: "4.9",
    },
    {
      id: "creative",
      title: "Creative Muse",
      description: "Your AI partner for creative projects, from design to content creation.",
      icon: Palette,
      category: "Creative",
      rating: "4.8",
    },
    {
      id: "chat",
      title: "ChatMaster Pro",
      description: "Advanced conversational AI for natural and engaging interactions.",
      icon: MessageSquare,
      category: "Communication",
      rating: "4.9",
    },
    {
      id: "neural",
      title: "Neural Navigator",
      description: "Cutting-edge AI for complex problem-solving and analysis.",
      icon: Brain,
      category: "Analytics",
      rating: "4.7",
    },
  ];

  // Example image generation world features
  const imageWorldFeatures = [
    {
      id: "canvas-editor",
      title: "Canvas Editor",
      description: "Powerful canvas editing with AI-assisted tools and filters",
      icon: Image,
      isAvailable: true,
      category: "creation"
    },
    {
      id: "motion-graphics",
      title: "Motion Graphics",
      description: "Create dynamic motion effects and animations for your images",
      icon: Zap,
      isAvailable: true,
      category: "animation"
    },
    {
      id: "asset-library",
      title: "Asset Library",
      description: "Access thousands of pre-made elements, textures, and templates",
      icon: FileText,
      isAvailable: false,
      category: "resources"
    }
  ];

  // Example typewriter examples for image tools
  const imageGenExamples = [
    "Generate a cyberpunk cityscape with neon lights",
    "Create a watercolor portrait of a young woman",
    "Design a minimalist logo for a coffee shop"
  ];

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 overflow-auto">
          <AutoScrollBanner />

          <div className="container py-12">
            <QuickStats />
            
            {/* Featured Agents */}
            <div className="mb-16">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-2xl font-semibold mb-2">Featured AI Spaces</h2>
                  <p className="text-muted-foreground">Discover our most popular and powerful AI agents</p>
                </div>
                <button 
                  className="icon-button bg-secondary"
                  onClick={() => navigate("/explore/spaces")}
                >
                  View All <ArrowRight className="w-4 h-4" />
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {featuredAgents.map((agent, index) => (
                  <FeaturedAgent key={index} {...agent} />
                ))}
              </div>
            </div>

            {/* Example of a "World Space" Feature */}
            <div className="mb-16">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-semibold mb-2">Image Generation World</h2>
                  <p className="text-muted-foreground">Explore specialized tools in our Image Generation realm</p>
                </div>
                <button 
                  className="icon-button bg-secondary"
                  onClick={() => navigate("/explore/spaces")}
                >
                  Visit World <ArrowRight className="w-4 h-4" />
                </button>
              </div>
              
              <div className="mt-6 mb-8 grid grid-cols-1 md:grid-cols-3 gap-6">
                <TypewriterCard
                  title="Image Generator"
                  description="Create stunning images with AI from text descriptions"
                  examples={imageGenExamples}
                  icon={<Image className="text-purple-400" />}
                  primaryColor="#9333EA"
                />
                <TypewriterCard
                  title="Style Transfer"
                  description="Apply artistic styles to any image with one click"
                  examples={["Transform this photo into Van Gogh style", "Apply cyberpunk aesthetic to this portrait", "Convert this image to watercolor painting"]}
                  icon={<Palette className="text-blue-400" />}
                  primaryColor="#3B82F6"
                />
                <TypewriterCard
                  title="Image Enhancer"
                  description="Upscale, restore, and enhance images automatically"
                  examples={["Enhance the resolution of this photo", "Remove noise from this image", "Restore this old photograph"]}
                  icon={<Zap className="text-amber-400" />}
                  primaryColor="#F59E0B"
                />
              </div>
              
              {/* World Features Section */}
              <WorldFeatures 
                features={imageWorldFeatures}
                title="Image World Features"
                description="Specialized tools and capabilities for the Image Generation realm"
                primaryColor="#9333EA"
                gradient="from-purple-500/20 to-pink-500/20"
              />
            </div>

            <CategoryGrid />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
