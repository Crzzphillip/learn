
import { useParams, useNavigate } from "react-router-dom";
import Sidebar from "@/components/Layout/Sidebar";
import SpaceLeftSidebar from "@/components/Space/SpaceLeftSidebar";
import { spaceTemplates } from "@/config/spaceTemplates";
import { getSpaceStats, getTrendingWorkspaces, getSpaceCredits } from "@/data/spaceData";
import BackToSpace from "@/components/Space/BackToSpace";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { 
  GitBranch, Star, MessageSquare, TrendingUp, UserCheck, Zap as ZapIcon, 
  CreditCard, Clock, Users, ThumbsUp, ChevronLeft, ChevronRight, 
  BarChart3, LineChart, PieChart, Activity, Settings, ArrowRight, 
  Share2, Award, Bell, Bookmark, Target, Sparkles, Wallet, Lightbulb,
  BookMarked, PlusCircle
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import SpaceStatsPanel from "@/components/Space/SpaceStatsPanel";
import ForesightOrbs from "@/components/Space/ForesightOrbs";
import CollaborationZones from "@/components/Space/CollaborationZones";
import WorldConnections from "@/components/Space/WorldConnections";
import WorldTestingGrounds from "@/components/Space/WorldTestingGrounds";
import { useRef } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";

const ManageSpacePage = () => {
  const { spaceId } = useParams();
  const navigate = useNavigate();
  const spaceTemplate = spaceTemplates[spaceId as string] || spaceTemplates.development;
  const spaceStats = getSpaceStats();
  const trendingWorkspaces = getTrendingWorkspaces();
  const credits = getSpaceCredits();
  const analyticsScrollRef = useRef<HTMLDivElement>(null);

  const scrollAnalyticsLeft = () => {
    if (analyticsScrollRef.current) {
      analyticsScrollRef.current.scrollBy({
        left: -300,
        behavior: "smooth"
      });
    }
  };

  const scrollAnalyticsRight = () => {
    if (analyticsScrollRef.current) {
      analyticsScrollRef.current.scrollBy({
        left: 300,
        behavior: "smooth"
      });
    }
  };

  const recentActivity = [
    { 
      id: 1, 
      title: "Workflow execution completed", 
      type: "workflow", 
      status: "success", 
      time: "10 minutes ago", 
      credits: 3 
    },
    { 
      id: 2, 
      title: "Image generation failed", 
      type: "tool", 
      status: "error", 
      time: "1 hour ago", 
      credits: 0 
    },
    { 
      id: 3, 
      title: "App deployed successfully", 
      type: "app", 
      status: "success", 
      time: "3 hours ago", 
      credits: 5 
    },
    { 
      id: 4, 
      title: "Workflow shared with team", 
      type: "share", 
      status: "info", 
      time: "Yesterday", 
      credits: 0 
    }
  ];

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex">
        <SpaceLeftSidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <main className="flex-1 overflow-y-auto">
            <div className="container max-w-6xl py-6">
              <div className="flex items-center justify-between mb-4">
                <BackToSpace spaceId={spaceId || ""} />
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="gap-2">
                    <Bell className="w-4 h-4" />
                    <span className="hidden sm:inline">Notifications</span>
                  </Button>
                  <Button variant="outline" size="sm" className="gap-2">
                    <Settings className="w-4 h-4" />
                    <span className="hidden sm:inline">Settings</span>
                  </Button>
                </div>
              </div>
              
              <div className="mb-6">
                <h1 className="text-2xl sm:text-3xl font-bold mb-2">Space Dashboard</h1>
                <p className="text-sm text-muted-foreground">
                  Manage your space, track performance metrics, and optimize your workflows.
                </p>
              </div>

              {/* User Quick Stats */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
                <Card className="bg-gradient-to-br from-purple-500/20 to-blue-600/20 border border-primary/20">
                  <CardContent className="pt-6 pb-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-muted-foreground text-sm">Available Credits</p>
                        <h3 className="text-2xl sm:text-3xl font-bold mt-1">{credits.balance}</h3>
                      </div>
                      <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-purple-500/20 flex items-center justify-center">
                        <CreditCard className="w-5 h-5 sm:w-6 sm:h-6 text-purple-400" />
                      </div>
                    </div>
                    <div className="mt-3">
                      <Button variant="outline" size="sm" className="w-full gap-1 text-xs">
                        <PlusCircle className="w-3 h-3" />
                        Purchase Credits
                      </Button>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gradient-to-br from-blue-500/20 to-cyan-600/20 border border-primary/20">
                  <CardContent className="pt-6 pb-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-muted-foreground text-sm">Active Workflows</p>
                        <h3 className="text-2xl sm:text-3xl font-bold mt-1">12</h3>
                      </div>
                      <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-blue-500/20 flex items-center justify-center">
                        <GitBranch className="w-5 h-5 sm:w-6 sm:h-6 text-blue-400" />
                      </div>
                    </div>
                    <div className="flex justify-between items-center mt-3 text-xs text-muted-foreground">
                      <span>8 running</span>
                      <span>4 paused</span>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gradient-to-br from-green-500/20 to-emerald-600/20 border border-primary/20">
                  <CardContent className="pt-6 pb-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-muted-foreground text-sm">Saved Credits</p>
                        <h3 className="text-2xl sm:text-3xl font-bold mt-1">250</h3>
                      </div>
                      <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-green-500/20 flex items-center justify-center">
                        <Wallet className="w-5 h-5 sm:w-6 sm:h-6 text-green-400" />
                      </div>
                    </div>
                    <div className="mt-3">
                      <span className="text-xs text-green-400 flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" /> 
                        +24% from last month
                      </span>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-gradient-to-br from-amber-500/20 to-orange-600/20 border border-primary/20">
                  <CardContent className="pt-6 pb-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-muted-foreground text-sm">Efficiency Score</p>
                        <h3 className="text-2xl sm:text-3xl font-bold mt-1">92%</h3>
                      </div>
                      <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-amber-500/20 flex items-center justify-center">
                        <Target className="w-5 h-5 sm:w-6 sm:h-6 text-amber-400" />
                      </div>
                    </div>
                    <div className="mt-3">
                      <Progress value={92} className="h-1.5 bg-white/10" />
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Main Dashboard Content */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
                {/* Left column - 2/3 width */}
                <div className="lg:col-span-2 space-y-4">
                  {/* Analytics Tabs */}
                  <Card className="bg-card/50 border border-primary/10">
                    <CardHeader className="pb-2 pt-4 px-4 md:px-6">
                      <CardTitle className="text-xl">Performance Analytics</CardTitle>
                      <CardDescription>Track your space usage and trends</CardDescription>
                    </CardHeader>
                    <CardContent className="px-3 md:px-6 pb-4">
                      <Tabs defaultValue="usage">
                        <TabsList className="mb-3 w-full md:w-auto">
                          <TabsTrigger value="usage">Usage</TabsTrigger>
                          <TabsTrigger value="credits">Credits</TabsTrigger>
                          <TabsTrigger value="workflows">Workflows</TabsTrigger>
                          <TabsTrigger value="tools">Tools</TabsTrigger>
                        </TabsList>
                        <TabsContent value="usage" className="min-h-[200px] md:min-h-[250px]">
                          <div className="h-[200px] md:h-[250px] rounded-lg bg-black/20 border border-white/5 flex items-center justify-center">
                            <div className="text-center">
                              <Activity className="w-10 h-10 sm:w-12 sm:h-12 mb-2 mx-auto text-primary/60" />
                              <p className="text-xs sm:text-sm text-white/60">Usage data visualization to be implemented</p>
                            </div>
                          </div>
                        </TabsContent>
                        <TabsContent value="credits" className="min-h-[200px] md:min-h-[250px]">
                          <div className="h-[200px] md:h-[250px] rounded-lg bg-black/20 border border-white/5 flex items-center justify-center">
                            <div className="text-center">
                              <CreditCard className="w-10 h-10 sm:w-12 sm:h-12 mb-2 mx-auto text-primary/60" />
                              <p className="text-xs sm:text-sm text-white/60">Credits usage visualization to be implemented</p>
                            </div>
                          </div>
                        </TabsContent>
                        <TabsContent value="workflows" className="min-h-[200px] md:min-h-[250px]">
                          <div className="h-[200px] md:h-[250px] rounded-lg bg-black/20 border border-white/5 flex items-center justify-center">
                            <div className="text-center">
                              <GitBranch className="w-10 h-10 sm:w-12 sm:h-12 mb-2 mx-auto text-primary/60" />
                              <p className="text-xs sm:text-sm text-white/60">Workflow analytics to be implemented</p>
                            </div>
                          </div>
                        </TabsContent>
                        <TabsContent value="tools" className="min-h-[200px] md:min-h-[250px]">
                          <div className="h-[200px] md:h-[250px] rounded-lg bg-black/20 border border-white/5 flex items-center justify-center">
                            <div className="text-center">
                              <Settings className="w-10 h-10 sm:w-12 sm:h-12 mb-2 mx-auto text-primary/60" />
                              <p className="text-xs sm:text-sm text-white/60">Tools usage data to be implemented</p>
                            </div>
                          </div>
                        </TabsContent>
                      </Tabs>
                    </CardContent>
                  </Card>
                  
                  {/* Recent Activity */}
                  <Card className="bg-card/50 border border-primary/10">
                    <CardHeader className="pb-2 pt-4 px-4 md:px-6">
                      <CardTitle className="text-xl">Recent Activity</CardTitle>
                      <CardDescription>Your latest actions and events</CardDescription>
                    </CardHeader>
                    <CardContent className="px-3 md:px-6 pb-4">
                      <ScrollArea className="h-[240px] sm:h-[300px] pr-2">
                        <div className="space-y-3">
                          {recentActivity.map((activity) => (
                            <div 
                              key={activity.id} 
                              className="flex items-start p-2 sm:p-3 rounded-lg bg-black/20 border border-white/5"
                            >
                              <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-full mr-2 sm:mr-3 flex items-center justify-center
                                ${activity.status === 'success' ? 'bg-green-500/20' : 
                                  activity.status === 'error' ? 'bg-red-500/20' : 'bg-blue-500/20'}`}
                              >
                                {activity.type === 'workflow' && <GitBranch className="w-4 h-4 sm:w-5 sm:h-5" />}
                                {activity.type === 'tool' && <Settings className="w-4 h-4 sm:w-5 sm:h-5" />}
                                {activity.type === 'app' && <Sparkles className="w-4 h-4 sm:w-5 sm:h-5" />}
                                {activity.type === 'share' && <Share2 className="w-4 h-4 sm:w-5 sm:h-5" />}
                              </div>
                              
                              <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-start flex-wrap">
                                  <div className="mr-2">
                                    <h4 className="font-medium text-xs sm:text-sm truncate">{activity.title}</h4>
                                    <p className="text-xs text-white/60">{activity.time}</p>
                                  </div>
                                  {activity.credits > 0 && (
                                    <Badge variant="outline" className="bg-black/30 text-xs mt-1">
                                      {activity.credits} credits
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    </CardContent>
                    <CardFooter className="pt-0 px-4 md:px-6 pb-4">
                      <Button variant="ghost" size="sm" className="ml-auto gap-1 text-xs">
                        View all activity
                        <ArrowRight className="w-3 h-3" />
                      </Button>
                    </CardFooter>
                  </Card>
                </div>
                
                {/* Right column - 1/3 width */}
                <div className="space-y-4">
                  {/* Recommendations */}
                  <Card className="bg-gradient-to-br from-indigo-500/20 to-purple-600/20 border border-primary/20">
                    <CardHeader className="pb-2 pt-4 px-4">
                      <CardTitle className="text-lg">Recommendations</CardTitle>
                    </CardHeader>
                    <CardContent className="px-3 pb-4">
                      <div className="space-y-2">
                        <div className="p-2 sm:p-3 bg-black/30 rounded-lg border border-white/5">
                          <div className="flex items-center gap-2 mb-1">
                            <Lightbulb className="w-4 h-4 text-yellow-400" />
                            <h3 className="text-xs sm:text-sm font-medium">Optimize Workflow</h3>
                          </div>
                          <p className="text-xs text-white/70">Your "Content Generator" workflow could save 15% more credits with our suggested optimizations</p>
                          <Button variant="ghost" size="sm" className="mt-2 w-full text-xs">View Suggestion</Button>
                        </div>
                        
                        <div className="p-2 sm:p-3 bg-black/30 rounded-lg border border-white/5">
                          <div className="flex items-center gap-2 mb-1">
                            <Target className="w-4 h-4 text-green-400" />
                            <h3 className="text-xs sm:text-sm font-medium">Credit Usage Alert</h3>
                          </div>
                          <p className="text-xs text-white/70">Set up alerts to be notified when your credit usage exceeds normal patterns</p>
                          <Button variant="ghost" size="sm" className="mt-2 w-full text-xs">Setup Alerts</Button>
                        </div>
                        
                        <div className="p-2 sm:p-3 bg-black/30 rounded-lg border border-white/5">
                          <div className="flex items-center gap-2 mb-1">
                            <Award className="w-4 h-4 text-purple-400" />
                            <h3 className="text-xs sm:text-sm font-medium">Skill Advancement</h3>
                          </div>
                          <p className="text-xs text-white/70">Complete 2 more developer workflows to earn the "AI Developer" badge</p>
                          <Progress value={75} className="h-1 mt-2 bg-white/10" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Saved Items */}
                  <Card className="bg-card/50 border border-primary/10">
                    <CardHeader className="pb-2 pt-4 px-4">
                      <CardTitle className="text-lg">Saved Items</CardTitle>
                    </CardHeader>
                    <CardContent className="px-3 pb-4">
                      <div className="space-y-2">
                        {[1, 2, 3].map((i) => (
                          <div key={i} className="flex items-center gap-2 p-2 rounded-lg hover:bg-white/5 transition-colors">
                            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded bg-primary/20 flex items-center justify-center">
                              <BookMarked className="w-3 h-3 sm:w-4 sm:h-4" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <h4 className="text-xs sm:text-sm font-medium truncate">Saved Workflow {i}</h4>
                              <p className="text-xs text-white/60 truncate">Last edited 2 days ago</p>
                            </div>
                            <Button variant="ghost" size="icon" className="h-6 w-6">
                              <ArrowRight className="w-3 h-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                    <CardFooter className="pt-0 px-4 pb-4">
                      <Button variant="ghost" size="sm" className="w-full gap-1 text-xs">
                        <Bookmark className="w-3 h-3" />
                        View all saved items
                      </Button>
                    </CardFooter>
                  </Card>
                  
                  {/* Quick Actions */}
                  <Card className="bg-card/50 border border-primary/10">
                    <CardHeader className="pb-2 pt-4 px-4">
                      <CardTitle className="text-lg">Quick Actions</CardTitle>
                    </CardHeader>
                    <CardContent className="px-3 pb-4">
                      <div className="grid grid-cols-2 gap-2">
                        <Button variant="outline" size="sm" className="h-auto py-2 sm:py-3 flex flex-col items-center gap-1">
                          <GitBranch className="w-4 h-4 sm:w-5 sm:h-5" />
                          <span className="text-xs">New Workflow</span>
                        </Button>
                        
                        <Button variant="outline" size="sm" className="h-auto py-2 sm:py-3 flex flex-col items-center gap-1">
                          <Sparkles className="w-4 h-4 sm:w-5 sm:h-5" />
                          <span className="text-xs">Create App</span>
                        </Button>
                        
                        <Button variant="outline" size="sm" className="h-auto py-2 sm:py-3 flex flex-col items-center gap-1">
                          <Share2 className="w-4 h-4 sm:w-5 sm:h-5" />
                          <span className="text-xs">Share Space</span>
                        </Button>
                        
                        <Button variant="outline" size="sm" className="h-auto py-2 sm:py-3 flex flex-col items-center gap-1">
                          <Settings className="w-4 h-4 sm:w-5 sm:h-5" />
                          <span className="text-xs">Configure</span>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
              
              {/* Advanced Analytics Section - Horizontal Scrollable */}
              <div className="relative mb-6">
                <h3 className="text-lg sm:text-xl font-semibold mb-3">Advanced Analytics</h3>
                
                <div className="absolute left-0 top-1/2 -translate-y-1/2 z-10">
                  <Button
                    size="icon"
                    variant="secondary"
                    className="rounded-full w-8 h-8 sm:w-10 sm:h-10 bg-background/80 backdrop-blur-sm"
                    onClick={scrollAnalyticsLeft}
                  >
                    <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5" />
                  </Button>
                </div>
                
                <div 
                  ref={analyticsScrollRef}
                  className="flex overflow-x-auto space-x-3 pb-3 scrollbar-hide"
                  style={{ 
                    scrollBehavior: 'smooth',
                    msOverflowStyle: 'none',
                    scrollbarWidth: 'none'
                  }}
                >
                  <div className="min-w-[280px] sm:min-w-[320px] md:min-w-[380px] max-w-full flex-shrink-0">
                    <SpaceStatsPanel stats={spaceStats} className="h-full" primaryColor={spaceTemplate.primaryColor} />
                  </div>
                  <div className="min-w-[280px] sm:min-w-[320px] md:min-w-[380px] max-w-full flex-shrink-0">
                    <ForesightOrbs className="h-full" primaryColor={spaceTemplate.primaryColor} />
                  </div>
                  <div className="min-w-[280px] sm:min-w-[320px] md:min-w-[380px] max-w-full flex-shrink-0">
                    <CollaborationZones primaryColor={spaceTemplate.primaryColor} />
                  </div>
                  <div className="min-w-[280px] sm:min-w-[320px] md:min-w-[380px] max-w-full flex-shrink-0">
                    <WorldConnections primaryColor={spaceTemplate.primaryColor} />
                  </div>
                  <div className="min-w-[280px] sm:min-w-[320px] md:min-w-[380px] max-w-full flex-shrink-0">
                    <WorldTestingGrounds primaryColor={spaceTemplate.primaryColor} />
                  </div>
                </div>
                
                <div className="absolute right-0 top-1/2 -translate-y-1/2 z-10">
                  <Button
                    size="icon"
                    variant="secondary"
                    className="rounded-full w-8 h-8 sm:w-10 sm:h-10 bg-background/80 backdrop-blur-sm"
                    onClick={scrollAnalyticsRight}
                  >
                    <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
                  </Button>
                </div>
                
                <style>
                  {`
                  .scrollbar-hide::-webkit-scrollbar {
                    display: none;
                  }
                  .scrollbar-hide {
                    -ms-overflow-style: none;
                    scrollbar-width: none;
                  }
                  `}
                </style>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default ManageSpacePage;
