import { useParams, useNavigate } from "react-router-dom";
import Sidebar from "@/components/Layout/Sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, LayoutGrid, Users, Star, Calendar, Clock, CopyCheck, Zap, ArrowRight } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import BackToSpace from "@/components/Space/BackToSpace";
import SpaceLeftSidebar from "@/components/Space/SpaceLeftSidebar";
import PageSearchBar from "@/components/Space/PageSearchBar";
import { useEffect, useState } from "react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { AIForgeWorkspaceCard } from "@/components/Workspace/AIForgeWorkspaceCard";
import { getWorkspaces, Workspace } from "@/services/workspaceService";

const WorkspacesPage = () => {
  const { spaceId } = useParams();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [filteredWorkspaces, setFilteredWorkspaces] = useState<Workspace[]>([]);
  
  useEffect(() => {
    const fetchedWorkspaces = getWorkspaces(spaceId);
    setWorkspaces(fetchedWorkspaces);
    setFilteredWorkspaces(fetchedWorkspaces);
  }, [spaceId]);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric' 
    });
  };

  const handleSearch = (query: string) => {
    if (query.trim() === "") {
      setFilteredWorkspaces(workspaces);
      return;
    }
    
    const lowercaseQuery = query.toLowerCase();
    const filtered = workspaces.filter(workspace => 
      workspace.title.toLowerCase().includes(lowercaseQuery) || 
      workspace.description.toLowerCase().includes(lowercaseQuery)
    );
    
    setFilteredWorkspaces(filtered);
  };

  const showAIForgeCard = spaceId === 'aiforge';
  const showLeonardoCard = spaceId === 'leonardo';

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex">
        <SpaceLeftSidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <main className="flex-1 overflow-auto">
            <div className="container py-8">
              <div className="flex items-center justify-between mb-6">
                <BackToSpace spaceId={spaceId || ""} />
                <PageSearchBar 
                  placeholder="Search workspaces..." 
                  onSearch={handleSearch}
                />
              </div>
              
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h1 className="text-3xl font-bold mb-2">
                    {spaceId === 'leonardo' ? 'Canvas Workspaces' : 
                     spaceId === 'aiforge' ? 'AIForge Workspaces' : 
                     'Workspaces'}
                  </h1>
                  <p className="text-muted-foreground">
                    {spaceId === 'leonardo' 
                      ? 'Create and manage your Leonardo AI canvas workspaces'
                      : spaceId === 'aiforge'
                        ? 'Build AI-powered applications with AIForge workspaces'
                        : 'Your command centers for managing projects and combining agents, workflows, and apps'}
                  </p>
                </div>
                <Button onClick={() => navigate("/create")}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create {spaceId === 'leonardo' ? 'Canvas Workspace' : 'Workspace'}
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {showAIForgeCard && <AIForgeWorkspaceCard />}
                
                {filteredWorkspaces.map((workspace) => (
                  <Card key={workspace.id} className="hover:shadow-md transition-shadow overflow-hidden group">
                    {workspace.template && (
                      <div className="absolute top-0 right-0">
                        <Badge variant="outline" className="m-2 bg-primary/10 text-primary border-primary/30">
                          Template
                        </Badge>
                      </div>
                    )}
                    
                    {workspace.type === 'canvas' && (
                      <div className="absolute top-0 left-0">
                        <Badge className="m-2 bg-purple-500/80">
                          {workspace.canvasType?.charAt(0).toUpperCase() + workspace.canvasType?.slice(1)}
                        </Badge>
                      </div>
                    )}
                    
                    {workspace.type === 'aiforge' && (
                      <div className="absolute top-0 left-0">
                        <Badge className="m-2 bg-blue-500/80">
                          AIForge
                        </Badge>
                      </div>
                    )}
                    
                    <CardHeader className="pb-2 relative">
                      <CardTitle className="flex items-center gap-2">
                        {workspace.title}
                        
                        {workspace.activeCollaborators && workspace.activeCollaborators.length > 0 && (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <div className="flex -space-x-2 ml-2">
                                  {workspace.activeCollaborators.slice(0, 3).map((user, i) => (
                                    <Avatar key={i} className="border-2 border-background w-6 h-6">
                                      <AvatarImage src={user.avatar} alt={user.name} /><AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                  ))}
                                  {workspace.activeCollaborators.length > 3 && (
                                    <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center text-[10px] text-primary-foreground border-2 border-background">
                                      +{workspace.activeCollaborators.length - 3}
                                    </div>
                                  )}
                                </div>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p className="text-xs">
                                  {workspace.activeCollaborators.length} active collaborator(s)
                                </p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        )}
                      </CardTitle>
                      <CardDescription className="line-clamp-2">{workspace.description}</CardDescription>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={workspace.creator.avatar} />
                          <AvatarFallback>{workspace.creator.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="text-sm">
                          Created by <span className="font-medium">{workspace.creator.name}</span>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="flex items-center gap-1.5 text-muted-foreground">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>Updated {formatDate(workspace.lastUpdated)}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-muted-foreground">
                          <CopyCheck className="w-3.5 h-3.5" />
                          <span>{workspace.savePoints} save points</span>
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap gap-2">
                        {workspace.components.map((component, index) => (
                          <Badge key={index} variant="outline" className="bg-black/5">
                            {component.count} {component.type}{component.count > 1 ? 's' : ''}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                    
                    <CardFooter className="flex justify-between pt-2 border-t">
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          <span>{workspace.members.length}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4" />
                          <span>{workspace.favorites}</span>
                        </div>
                      </div>
                      <Button 
                        variant="outline" 
                        onClick={() => navigate(`/workspace/${workspace.id}`)}
                        className="group-hover:bg-primary/10 group-hover:text-primary group-hover:border-primary/30 transition-colors"
                      >
                        <LayoutGrid className="w-4 h-4 mr-2" />
                        Open
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
                
                <Card className="hover:shadow-md transition-shadow border-dashed border-2 border-muted">
                  <div className="flex flex-col items-center justify-center h-full py-12">
                    <div className="w-12 h-12 rounded-full bg-muted/50 flex items-center justify-center mb-4">
                      <Plus className="w-6 h-6 text-muted-foreground" />
                    </div>
                    <h3 className="text-xl font-medium mb-2">
                      Create New {spaceId === 'leonardo' ? 'Canvas' : 'Workspace'}
                    </h3>
                    <p className="text-muted-foreground text-center mb-6 max-w-xs">
                      {spaceId === 'leonardo' 
                        ? 'Design and create with Leonardo AI canvas tools'
                        : spaceId === 'aiforge' 
                          ? 'Build AI-powered applications with AIForge tools'
                          : 'Combine agents, workflows, and apps into a customized command center'}
                    </p>
                    <Button 
                      onClick={() => navigate("/create")}
                      className="gap-2"
                    >
                      <Plus className="w-4 h-4" />
                      New {spaceId === 'leonardo' ? 'Canvas' : 'Workspace'}
                    </Button>
                  </div>
                </Card>
              </div>
              
              <div className="mt-12">
                <h2 className="text-2xl font-bold mb-4">
                  About {spaceId === 'leonardo' ? 'Canvas Workspaces' : 
                          spaceId === 'aiforge' ? 'AIForge Workspaces' : 
                          'Workspaces'}
                </h2>
                
                {spaceId === 'leonardo' ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold flex items-center gap-2">
                        <Zap className="w-5 h-5 text-purple-400" />
                        What are Canvas Workspaces?
                      </h3>
                      <p className="text-muted-foreground">
                        Canvas workspaces are digital drawing boards powered by Leonardo AI. Create, edit, and collaborate on designs using advanced AI generation tools.
                      </p>
                      
                      <h3 className="text-lg font-semibold flex items-center gap-2 pt-4">
                        <Clock className="w-5 h-5 text-purple-400" />
                        Design History
                      </h3>
                      <p className="text-muted-foreground">
                        Every stroke and edit is saved in your design history. Revert to previous versions or branch off in new creative directions.
                      </p>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold flex items-center gap-2">
                        <Clock className="w-5 h-5 text-purple-400" />
                        Save & Export
                      </h3>
                      <p className="text-muted-foreground">
                        Save your canvas at any point and export your creations in various formats. Continue your work later exactly where you left off.
                      </p>
                      
                      <h3 className="text-lg font-semibold flex items-center gap-2 pt-4">
                        <CopyCheck className="w-5 h-5 text-purple-400" />
                        AI-Powered Tools
                      </h3>
                      <p className="text-muted-foreground">
                        Leverage Leonardo AI's powerful generation capabilities. Enhance your designs with AI-assisted drawing, inpainting, and refinement.
                      </p>
                    </div>
                  </div>
                ) : spaceId === 'aiforge' ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold flex items-center gap-2">
                        <Zap className="w-5 h-5 text-blue-400" />
                        What are AIForge Workspaces?
                      </h3>
                      <p className="text-muted-foreground">
                        AIForge workspaces are specialized environments for building AI-powered applications. They provide integrated tools for model training, prompt engineering, and deployment.
                      </p>
                      
                      <h3 className="text-lg font-semibold flex items-center gap-2 pt-4">
                        <Clock className="w-5 h-5 text-blue-400" />
                        AI Development Pipeline
                      </h3>
                      <p className="text-muted-foreground">
                        Each workspace tracks your AI development lifecycle from data preparation to model training and deployment, ensuring reproducible results.
                      </p>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold flex items-center gap-2">
                        <Clock className="w-5 h-5 text-blue-400" />
                        Model Integration
                      </h3>
                      <p className="text-muted-foreground">
                        Seamlessly integrate trained models into your workflows and applications. Test performance and iterate quickly with built-in evaluation metrics.
                      </p>
                      
                      <h3 className="text-lg font-semibold flex items-center gap-2 pt-4">
                        <CopyCheck className="w-5 h-5 text-blue-400" />
                        Visual Development
                      </h3>
                      <p className="text-muted-foreground">
                        AIForge provides visual tools for AI application development, allowing both technical and non-technical users to build sophisticated AI solutions without deep coding.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold flex items-center gap-2">
                        <Zap className="w-5 h-5 text-primary" />
                        What are Workspaces?
                      </h3>
                      <p className="text-muted-foreground">
                        Workspaces are your command centers—customizable hubs where you manage projects by combining agents, tools, and workflows into a unified environment.
                      </p>
                      
                      <h3 className="text-lg font-semibold flex items-center gap-2 pt-4">
                        <Clock className="w-5 h-5 text-primary" />
                        Timeline Tracking
                      </h3>
                      <p className="text-muted-foreground">
                        A visual timeline records every step—agent chats, tool outputs, manual tweaks. Click any step to revisit or adjust your work at that point in time.
                      </p>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold flex items-center gap-2">
                        <Clock className="w-5 h-5 text-primary" />
                        Save & Resume
                      </h3>
                      <p className="text-muted-foreground">
                        Pause your workspace, saving everything—open tools, chat histories, outputs. Pick up later exactly where you left off or start fresh from any saved point.
                      </p>
                      
                      <h3 className="text-lg font-semibold flex items-center gap-2 pt-4">
                        <CopyCheck className="w-5 h-5 text-primary" />
                        Templates
                      </h3>
                      <p className="text-muted-foreground">
                        Turn a successful workspace into a reusable blueprint for yourself or others. Create a "Landing Page Template" once, then deploy it repeatedly for different projects.
                      </p>
                    </div>
                  </div>
                )}
                
                <div className={`mt-8 p-6 rounded-xl border ${
                  spaceId === 'leonardo' ? 'bg-purple-500/5 border-purple-500/10' : 
                  spaceId === 'aiforge' ? 'bg-blue-500/5 border-blue-500/10' :
                  'bg-primary/5 border-primary/10'
                }`}>
                  <h3 className="text-lg font-semibold mb-2">Ready to get started?</h3>
                  <p className="text-muted-foreground mb-4">
                    {spaceId === 'leonardo' 
                      ? 'Create your first canvas workspace and unleash your creativity with Leonardo AI.'
                      : spaceId === 'aiforge'
                        ? 'Build your first AI-powered application with the AIForge workspace.'
                        : 'Create your first workspace and transform how you manage complex projects and workflows.'}
                  </p>
                  <Button 
                    className="gap-2" 
                    onClick={() => navigate("/create")}
                    style={{
                      background: spaceId === 'leonardo' ? 'linear-gradient(to right, #8b5cf6, #6366f1)' : 
                               spaceId === 'aiforge' ? 'linear-gradient(to right, #3b82f6, #2563eb)' :
                               undefined
                    }}
                  >
                    Create Your First {spaceId === 'leonardo' ? 'Canvas' : 
                                       spaceId === 'aiforge' ? 'AIForge Workspace' : 
                                       'Workspace'}
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default WorkspacesPage;
