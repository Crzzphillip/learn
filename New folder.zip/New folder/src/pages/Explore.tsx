
import { useEffect, useRef, useState } from "react";
import { useInfiniteQuery } from "@tanstack/react-query";
import * as LucideIcons from "lucide-react";
import Sidebar from "@/components/Layout/Sidebar";
import AutoScrollBanner from "@/components/Home/AutoScrollBanner";
import PopularAgents from "@/components/Explore/PopularAgents";
import FeaturedWorkspaces from "@/components/Explore/FeaturedWorkspaces";
import CategorySection from "@/components/Explore/CategorySection";
import ShowcasesCarousel from "@/components/Explore/ShowcasesCarousel";
import { categoriesService } from "@/services/categoriesService";
import { exploreService } from "@/services/exploreService";
import { popularAgents, featuredSpaces, categories } from "@/data/exploreData";
import { FeaturedSpace as TypedFeaturedSpace, PopularAgent, Category, CategorySpace } from "@/types/explore";

const Explore = () => {
  const lastItemRef = useRef<HTMLDivElement>(null);
  const [agents, setAgents] = useState<PopularAgent[]>(popularAgents);
  const [spaces, setSpaces] = useState<TypedFeaturedSpace[]>(
    // Convert the static data to have the right types
    featuredSpaces.map(space => ({
      ...space,
      // No need to convert here as the static data already has the correct type
    }))
  );
  
  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const fetchedAgents = await exploreService.getPopularAgents();
        const fetchedSpaces = await exploreService.getFeaturedSpaces();
        
        // Use fetched data if available, otherwise fallback to static data
        if (fetchedAgents && fetchedAgents.length > 0) {
          setAgents(fetchedAgents);
        }
        
        if (fetchedSpaces && fetchedSpaces.length > 0) {
          // Convert string icon names to Lucide components for compatibility
          const mappedSpaces = fetchedSpaces.map(space => ({
            ...space,
            // Convert string to LucideIcon component using the dynamic mapping
            icon: (LucideIcons as any)[space.icon] || LucideIcons.Code
          })) as TypedFeaturedSpace[];
          
          setSpaces(mappedSpaces);
        }
      } catch (error) {
        console.error("Error fetching explore data:", error);
        // If API fails, we'll use the static data that was already set
      }
    };
    
    fetchInitialData();
  }, []);

  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage
  } = useInfiniteQuery({
    queryKey: ['categories'],
    queryFn: async ({
      pageParam = 0
    }) => {
      try {
        const allCategories = await categoriesService.getAllCategories();
        
        // If no categories from service, use static data
        const categoriesToUse = allCategories.length > 0 ? allCategories : categories;
        
        const itemsPerPage = 2;
        const start = pageParam * itemsPerPage;
        const end = start + itemsPerPage;
        
        // For each category, fetch its spaces
        const categoriesWithSpaces = await Promise.all(
          categoriesToUse.slice(start, end).map(async (category) => {
            // Try to fetch from service first
            const spaces = await categoriesService.getSpacesByCategoryId(category.id);
            
            // Map category to include LucideIcon component instead of string
            const mappedCategory = {
              ...category,
              icon: (LucideIcons as any)[category.icon] || LucideIcons.Code
            };
            
            // If no spaces from service, use static data if available
            if (spaces.length === 0) {
              // Find matching category from static data to get spaces
              const matchingStaticCategory = categories.find(c => c.id === category.id);
              return {
                ...mappedCategory,
                spaces: matchingStaticCategory?.spaces || []
              };
            }
            
            // Map spaces to include LucideIcon component instead of string
            const mappedSpaces = spaces.map(space => ({
              ...space,
              icon: (LucideIcons as any)[space.icon] || LucideIcons.Code
            }));
            
            return {
              ...mappedCategory,
              spaces: mappedSpaces
            };
          })
        );
        
        return {
          categories: categoriesWithSpaces,
          nextPage: end < categoriesToUse.length ? pageParam + 1 : undefined
        };
      } catch (error) {
        console.error("Error fetching categories:", error);
        
        // Fallback to static data on error
        const itemsPerPage = 2;
        const start = pageParam * itemsPerPage;
        const end = start + itemsPerPage;
        
        // Make sure we convert the icon strings to components for the static data
        const mappedCategories = categories.slice(start, end).map(category => ({
          ...category,
          // Static data already has icon as a component so no need to convert
        }));
        
        return {
          categories: mappedCategories,
          nextPage: end < categories.length ? pageParam + 1 : undefined
        };
      }
    },
    getNextPageParam: lastPage => lastPage.nextPage,
    initialPageParam: 0
  });

  useEffect(() => {
    const observer = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasNextPage && !isFetchingNextPage) {
        fetchNextPage();
      }
    });
    if (lastItemRef.current) {
      observer.observe(lastItemRef.current);
    }
    return () => observer.disconnect();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  // Process the categories to ensure they have the right types
  const allCategories = data?.pages.flatMap(page => page.categories) ?? [];

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 overflow-auto">
          <AutoScrollBanner />

          <div className="container py-12">
            <div className="bg-card/50 border-none p-6 rounded-xl mb-12">
              <PopularAgents agents={agents} />
            </div>
            
            {/* Add the ShowcasesCarousel component here */}
            <ShowcasesCarousel />
            
            <div className="bg-card/50 border-none p-6 rounded-xl mb-12">
              <FeaturedWorkspaces workspaces={spaces as any} />
            </div>

            {allCategories.length > 0 ? (
              allCategories.map((category, index) => (
                <div key={category.id} className="bg-card/50 border-none p-6 rounded-xl mb-12">
                  <CategorySection 
                    category={category as any} 
                    lastItemRef={index === allCategories.length - 1 ? lastItemRef : undefined} 
                  />
                </div>
              ))
            ) : (
              // Fallback to static categories if no data from query
              categories.slice(0, 2).map((category, index) => (
                <div key={category.id} className="bg-card/50 border-none p-6 rounded-xl mb-12">
                  <CategorySection 
                    category={category as any} 
                    lastItemRef={index === categories.slice(0, 2).length - 1 ? lastItemRef : undefined} 
                  />
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Explore;
