
import { useState } from "react";
import { useParams } from "react-router-dom";
import Sidebar from "@/components/Layout/Sidebar";
import SpaceBanner from "@/components/Space/SpaceBanner";
import SpaceLeftSidebar from "@/components/Space/SpaceLeftSidebar";
import { Button } from "@/components/ui/button";
import { Menu, BookOpen, GraduationCap, Video, FileText } from "lucide-react";
import { getSpaceStats } from "@/data/spaceData";
import { spaceTemplates } from "@/config/spaceTemplates";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import EducationFeatures from "@/components/Education/EducationFeatures";
import EducationPaths from "@/components/Education/EducationPaths";
import EducationResources from "@/components/Education/EducationResources";

const EducationPage = () => {
  const { spaceId } = useParams();
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  
  // Get the education space template
  const stats = getSpaceStats();
  const spaceTemplate = spaceTemplates.education;

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-auto">
          <SpaceBanner stats={stats} template={spaceTemplate} />
          
          <div className="container py-6">
            {/* Mobile Sidebar Toggle */}
            <div className="md:hidden mb-4">
              <Button 
                variant="outline" 
                size="sm" 
                className="gap-2" 
                onClick={() => setShowMobileSidebar(!showMobileSidebar)}
              >
                <Menu className="h-4 w-4" />
                Menu
              </Button>
            </div>
          </div>
          
          <div className="container pb-12 grid grid-cols-12 gap-6 relative">
            {/* Space Left Sidebar - Hidden on mobile, visible on desktop */}
            <div className="hidden md:block col-span-3 sticky top-6 max-h-[calc(100vh-8rem)]">
              <SpaceLeftSidebar />
            </div>
            
            {/* Mobile Sidebar - Conditionally rendered */}
            {showMobileSidebar && (
              <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 md:hidden">
                <div className="h-full w-64 p-4">
                  <SpaceLeftSidebar onClose={() => setShowMobileSidebar(false)} />
                </div>
              </div>
            )}

            {/* Main content area */}
            <div className="col-span-12 md:col-span-9 space-y-8">
              <div>
                <h1 className="text-3xl font-bold mb-2">Education Space</h1>
                <p className="text-muted-foreground mb-8">
                  Interactive learning environment with courses, tutorials, and community-driven education.
                </p>

                <Tabs defaultValue="features">
                  <TabsList className="mb-8">
                    <TabsTrigger value="features" className="flex items-center gap-2">
                      <GraduationCap className="w-4 h-4" />
                      Features
                    </TabsTrigger>
                    <TabsTrigger value="paths" className="flex items-center gap-2">
                      <BookOpen className="w-4 h-4" />
                      Learning Paths
                    </TabsTrigger>
                    <TabsTrigger value="resources" className="flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      Resources
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="features">
                    {spaceTemplate.features && (
                      <EducationFeatures features={spaceTemplate.features} />
                    )}
                  </TabsContent>
                  
                  <TabsContent value="paths">
                    {spaceTemplate.learningPaths && (
                      <EducationPaths learningPaths={spaceTemplate.learningPaths} />
                    )}
                  </TabsContent>
                  
                  <TabsContent value="resources">
                    {spaceTemplate.resources && (
                      <EducationResources resources={spaceTemplate.resources} />
                    )}
                  </TabsContent>
                </Tabs>

                {/* Featured Course Section */}
                <div className="mt-12">
                  <h2 className="text-2xl font-bold mb-6">Featured Course</h2>
                  <Card className="bg-gradient-to-br from-blue-600/30 to-cyan-600/30 border-0">
                    <CardHeader>
                      <CardTitle className="text-2xl">Web Development Masterclass</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-col md:flex-row gap-8">
                        <div className="w-full md:w-2/3">
                          <p className="text-white/80 mb-4">
                            A comprehensive journey from HTML basics to advanced React applications.
                            Learn modern web development with hands-on projects and expert mentorship.
                          </p>
                          
                          <div className="grid grid-cols-2 gap-4 mb-6">
                            <div className="bg-white/10 p-3 rounded-lg">
                              <p className="text-xs text-white/60">Duration</p>
                              <p className="font-semibold">12 Weeks</p>
                            </div>
                            <div className="bg-white/10 p-3 rounded-lg">
                              <p className="text-xs text-white/60">Modules</p>
                              <p className="font-semibold">24 Modules</p>
                            </div>
                            <div className="bg-white/10 p-3 rounded-lg">
                              <p className="text-xs text-white/60">Projects</p>
                              <p className="font-semibold">6 Projects</p>
                            </div>
                            <div className="bg-white/10 p-3 rounded-lg">
                              <p className="text-xs text-white/60">Level</p>
                              <p className="font-semibold">Beginner to Advanced</p>
                            </div>
                          </div>
                          
                          <Button className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600">
                            Start Learning
                          </Button>
                        </div>
                        
                        <div className="w-full md:w-1/3 bg-white/5 rounded-lg p-4">
                          <h3 className="font-semibold mb-3">What you'll learn</h3>
                          <ul className="space-y-2 text-sm">
                            <li className="flex items-start gap-2">
                              <div className="mt-1 h-4 w-4 rounded-full bg-blue-500/20 flex items-center justify-center">
                                <div className="h-2 w-2 rounded-full bg-blue-500"></div>
                              </div>
                              <span>HTML, CSS and JavaScript fundamentals</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <div className="mt-1 h-4 w-4 rounded-full bg-blue-500/20 flex items-center justify-center">
                                <div className="h-2 w-2 rounded-full bg-blue-500"></div>
                              </div>
                              <span>React and modern state management</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <div className="mt-1 h-4 w-4 rounded-full bg-blue-500/20 flex items-center justify-center">
                                <div className="h-2 w-2 rounded-full bg-blue-500"></div>
                              </div>
                              <span>Backend integration with Node.js</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <div className="mt-1 h-4 w-4 rounded-full bg-blue-500/20 flex items-center justify-center">
                                <div className="h-2 w-2 rounded-full bg-blue-500"></div>
                              </div>
                              <span>Database design and implementation</span>
                            </li>
                            <li className="flex items-start gap-2">
                              <div className="mt-1 h-4 w-4 rounded-full bg-blue-500/20 flex items-center justify-center">
                                <div className="h-2 w-2 rounded-full bg-blue-500"></div>
                              </div>
                              <span>Deployment and DevOps basics</span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default EducationPage;
