
import React, { useState, useEffect } from "react";
import Sidebar from "@/components/Layout/Sidebar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Settings as SettingsIcon, 
  UserCircle, 
  CreditCard, 
  Bell, 
  Lock, 
  Palette, 
  Globe 
} from "lucide-react";
import { settingsService, UserProfile, UserPreferences, SubscriptionPlan } from "@/services/settingsService";
import { toast } from "sonner";

const Settings = () => {
  const [activeTab, setActiveTab] = useState("profile");
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [userPreferences, setUserPreferences] = useState<UserPreferences | null>(null);
  const [subscriptionPlan, setSubscriptionPlan] = useState<SubscriptionPlan | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        setIsLoading(true);
        // Load profile data
        const profileData = await settingsService.getUserProfile();
        setUserProfile(profileData);
        
        // Load preferences
        const preferencesData = await settingsService.getUserPreferences();
        setUserPreferences(preferencesData);
        
        // Load subscription
        const subscriptionData = await settingsService.getSubscriptionPlan();
        setSubscriptionPlan(subscriptionData);
      } catch (error) {
        console.error("Error loading settings:", error);
        toast.error("Failed to load settings data");
      } finally {
        setIsLoading(false);
      }
    };

    fetchSettings();
  }, []);

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 overflow-auto">
        <div className="container py-8">
          <div className="flex items-center mb-8">
            <SettingsIcon className="w-6 h-6 mr-3" />
            <h1 className="text-3xl font-bold">Settings</h1>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
            <TabsList className="grid grid-cols-2 md:grid-cols-6 gap-2">
              <TabsTrigger value="profile" className="flex items-center gap-2">
                <UserCircle className="w-4 h-4" />
                <span>Profile</span>
              </TabsTrigger>
              <TabsTrigger value="account" className="flex items-center gap-2">
                <CreditCard className="w-4 h-4" />
                <span>Account</span>
              </TabsTrigger>
              <TabsTrigger value="notifications" className="flex items-center gap-2">
                <Bell className="w-4 h-4" />
                <span>Notifications</span>
              </TabsTrigger>
              <TabsTrigger value="security" className="flex items-center gap-2">
                <Lock className="w-4 h-4" />
                <span>Security</span>
              </TabsTrigger>
              <TabsTrigger value="appearance" className="flex items-center gap-2">
                <Palette className="w-4 h-4" />
                <span>Appearance</span>
              </TabsTrigger>
              <TabsTrigger value="language" className="flex items-center gap-2">
                <Globe className="w-4 h-4" />
                <span>Language</span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="profile" className="space-y-4">
              <div className="p-6 bg-card rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-4">Profile Settings</h2>
                <p className="text-muted-foreground">Manage your profile information.</p>
                {userProfile && (
                  <div className="mt-4 grid gap-4">
                    <div>
                      <h3 className="font-medium mb-1">Name</h3>
                      <p>{userProfile.firstName} {userProfile.lastName}</p>
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">Email</h3>
                      <p>{userProfile.email}</p>
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">Bio</h3>
                      <p>{userProfile.bio}</p>
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="account" className="space-y-4">
              <div className="p-6 bg-card rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-4">Account Settings</h2>
                <p className="text-muted-foreground">Manage your account and subscription.</p>
                {subscriptionPlan && (
                  <div className="mt-4">
                    <h3 className="font-medium mb-2">Subscription Details</h3>
                    <div className="bg-accent/50 p-4 rounded-md">
                      <div className="flex justify-between mb-2">
                        <span>Plan</span>
                        <span className="font-semibold">{subscriptionPlan.planName}</span>
                      </div>
                      <div className="flex justify-between mb-2">
                        <span>Price</span>
                        <span className="font-semibold">${subscriptionPlan.planPrice}/{subscriptionPlan.billingCycle}</span>
                      </div>
                      <div className="flex justify-between mb-2">
                        <span>Next Renewal</span>
                        <span className="font-semibold">{subscriptionPlan.renewalDate}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="notifications" className="space-y-4">
              <div className="p-6 bg-card rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-4">Notification Preferences</h2>
                <p className="text-muted-foreground">Configure how and when you receive notifications.</p>
                {userPreferences && (
                  <div className="mt-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span>Email Notifications</span>
                      <span className={userPreferences.emailNotifications ? "text-green-500" : "text-red-500"}>
                        {userPreferences.emailNotifications ? "Enabled" : "Disabled"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Usage Alerts</span>
                      <span className={userPreferences.usageAlerts ? "text-green-500" : "text-red-500"}>
                        {userPreferences.usageAlerts ? "Enabled" : "Disabled"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Agent Updates</span>
                      <span className={userPreferences.agentUpdates ? "text-green-500" : "text-red-500"}>
                        {userPreferences.agentUpdates ? "Enabled" : "Disabled"}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="security" className="space-y-4">
              <div className="p-6 bg-card rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-4">Security Settings</h2>
                <p className="text-muted-foreground">Manage your security preferences and devices.</p>
              </div>
            </TabsContent>
            
            <TabsContent value="appearance" className="space-y-4">
              <div className="p-6 bg-card rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-4">Appearance Settings</h2>
                <p className="text-muted-foreground">Customize the look and feel of your interface.</p>
                {userPreferences && (
                  <div className="mt-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span>Theme</span>
                      <span className="capitalize">{userPreferences.theme}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Font Size</span>
                      <span className="capitalize">{userPreferences.fontSize}</span>
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="language" className="space-y-4">
              <div className="p-6 bg-card rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-4">Language Settings</h2>
                <p className="text-muted-foreground">Configure your preferred language and region.</p>
                {userProfile && (
                  <div className="mt-4 grid gap-4">
                    <div>
                      <h3 className="font-medium mb-1">Timezone</h3>
                      <p>{userProfile.timezone}</p>
                    </div>
                    <div>
                      <h3 className="font-medium mb-1">Location</h3>
                      <p>{userProfile.location}</p>
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Settings;
