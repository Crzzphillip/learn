
import { useEffect, useState } from "react";
import Sidebar from "@/components/Layout/Sidebar";
import { Brain, Code, Palette, MessageSquare, Star, Users, Zap, CreditCard, Clock, ArrowRight, Sparkles, Workflow, AppWindow } from "lucide-react";
import { useNavigate } from "react-router-dom";
import SpaceStats from "@/components/Library/SpaceStats";
import ForesightOrbs from "@/components/Library/ForesightOrbs";
import WorldConnections from "@/components/Library/WorldConnections";
import CollaborationZones from "@/components/Library/CollaborationZones";
import TestingGrounds from "@/components/Library/TestingGrounds";
import { UserSubscription, ActivityItem, libraryService } from "@/services/libraryService";
import { toast } from "sonner";

const SubscriptionCard = ({ subscription }: { subscription: UserSubscription }) => {
  const navigate = useNavigate();
  const percentage = (subscription.creditsLeft / subscription.totalCredits) * 100;
  
  // Map icon string to Lucide icon
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'palette': return <Palette className="w-7 h-7" />;
      case 'code': return <Code className="w-7 h-7" />;
      default: return <Star className="w-7 h-7" />;
    }
  };

  return (
    <div className="glass-panel rounded-2xl p-6 hover:scale-[1.02] transition-all duration-300">
      <div className="flex items-start justify-between mb-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-secondary/50 grid place-items-center">
            {getIcon(subscription.icon)}
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-1">{subscription.title}</h3>
            <div className="flex items-center gap-2">
              <span className="text-sm px-2.5 py-1 rounded-full bg-primary/20 text-primary">
                {subscription.plan}
              </span>
              <span className="text-sm text-muted-foreground">
                Renews {subscription.renewalDate}
              </span>
            </div>
          </div>
        </div>
        <button 
          onClick={() => navigate(`/space/${subscription.id}`)}
          className="text-sm text-primary hover:underline"
        >
          Manage Space →
        </button>
      </div>

      <div className="space-y-4">
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Credits Available</span>
            <span className="text-sm font-medium">{subscription.creditsLeft}/{subscription.totalCredits}</span>
          </div>
          <div className="h-2 rounded-full bg-secondary/50 overflow-hidden">
            <div 
              className="h-full bg-primary transition-all duration-300"
              style={{ width: `${percentage}%` }}
            />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="glass-panel rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <Brain className="w-4 h-4" />
              <span className="text-sm font-medium">{subscription.agents}</span>
            </div>
            <span className="text-xs text-muted-foreground">Agents</span>
          </div>
          <div className="glass-panel rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <Workflow className="w-4 h-4" />
              <span className="text-sm font-medium">{subscription.workflows}</span>
            </div>
            <span className="text-xs text-muted-foreground">Workflows</span>
          </div>
          <div className="glass-panel rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <AppWindow className="w-4 h-4" />
              <span className="text-sm font-medium">{subscription.apps}</span>
            </div>
            <span className="text-xs text-muted-foreground">Apps</span>
          </div>
        </div>
      </div>
    </div>
  );
};

const ActivityCard = ({ activity }: { activity: ActivityItem }) => {
  // Map icon string to Lucide icon
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'brain': return <Brain className="w-5 h-5" />;
      case 'workflow': return <Workflow className="w-5 h-5" />;
      case 'app-window': return <AppWindow className="w-5 h-5" />;
      default: return <Star className="w-5 h-5" />;
    }
  };

  // Format timestamp to relative time
  const formatTime = (timeString: string) => {
    const now = new Date();
    const time = new Date(timeString);
    const diffInSeconds = Math.floor((now.getTime() - time.getTime()) / 1000);
    
    if (diffInSeconds < 60) return `${diffInSeconds} seconds ago`;
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)} days ago`;
    
    return time.toLocaleDateString();
  };

  return (
    <div className="glass-panel rounded-xl p-4 hover:scale-[1.02] transition-all duration-300">
      <div className="flex items-start gap-4">
        <div className="w-10 h-10 rounded-lg bg-secondary/50 grid place-items-center flex-shrink-0">
          {getIcon(activity.icon)}
        </div>
        <div className="flex-1">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h4 className="font-medium mb-1">{activity.title}</h4>
              <p className="text-sm text-muted-foreground">{activity.space}</p>
            </div>
            <div className="text-right">
              <div className="flex items-center gap-1 text-primary mb-1">
                <Zap className="w-3.5 h-3.5" />
                <span className="text-sm font-medium">-{activity.creditsUsed}</span>
              </div>
              <p className="text-xs text-muted-foreground">{formatTime(activity.timestamp)}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Library = () => {
  const [subscriptions, setSubscriptions] = useState<UserSubscription[]>([]);
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [subscriptionsData, activitiesData] = await Promise.all([
          libraryService.getUserSubscriptions(),
          libraryService.getRecentActivity()
        ]);
        setSubscriptions(subscriptionsData);
        setActivities(activitiesData);
      } catch (error) {
        console.error("Error fetching library data:", error);
        toast.error("Failed to load library data");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="container py-8 overflow-y-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-semibold tracking-tight mb-2">Your Library</h1>
              <p className="text-muted-foreground">Manage your subscriptions and track activity</p>
            </div>
            <button className="button-hover bg-primary text-primary-foreground px-4 py-2 rounded-lg font-medium inline-flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              Add Credits
            </button>
          </div>

          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-semibold mb-6">Active Subscriptions</h2>
              {loading ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {[...Array(2)].map((_, index) => (
                    <div key={index} className="glass-panel rounded-2xl p-6 animate-pulse">
                      <div className="flex items-start mb-6">
                        <div className="w-14 h-14 rounded-xl bg-gray-300 dark:bg-gray-700 mr-4"></div>
                        <div className="flex-1">
                          <div className="h-6 bg-gray-300 dark:bg-gray-700 rounded w-1/3 mb-2"></div>
                          <div className="h-4 bg-gray-200 dark:bg-gray-800 rounded w-1/4"></div>
                        </div>
                      </div>
                      <div className="space-y-4">
                        <div>
                          <div className="h-4 bg-gray-200 dark:bg-gray-800 rounded w-full mb-2"></div>
                          <div className="h-2 rounded-full bg-gray-200 dark:bg-gray-800"></div>
                        </div>
                        <div className="grid grid-cols-3 gap-4">
                          {[...Array(3)].map((_, i) => (
                            <div key={i} className="glass-panel rounded-xl p-3">
                              <div className="h-4 bg-gray-200 dark:bg-gray-800 rounded mb-1"></div>
                              <div className="h-3 bg-gray-200 dark:bg-gray-800 rounded w-1/2"></div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {subscriptions.map((subscription) => (
                    <SubscriptionCard key={subscription.id} subscription={subscription} />
                  ))}
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <h2 className="text-2xl font-semibold mb-6">Recent Activity</h2>
                {loading ? (
                  <div className="grid gap-4">
                    {[...Array(3)].map((_, index) => (
                      <div key={index} className="glass-panel rounded-xl p-4 animate-pulse">
                        <div className="flex items-start gap-4">
                          <div className="w-10 h-10 rounded-lg bg-gray-300 dark:bg-gray-700"></div>
                          <div className="flex-1">
                            <div className="h-5 bg-gray-300 dark:bg-gray-700 rounded w-1/3 mb-2"></div>
                            <div className="h-4 bg-gray-200 dark:bg-gray-800 rounded w-1/2 mb-2"></div>
                            <div className="h-3 bg-gray-200 dark:bg-gray-800 rounded w-1/4"></div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="grid gap-4">
                    {activities.map((activity) => (
                      <ActivityCard key={activity.id} activity={activity} />
                    ))}
                  </div>
                )}
              </div>
              
              <div>
                <h2 className="text-2xl font-semibold mb-6">Stats & Insights</h2>
                <div className="space-y-6">
                  {subscriptions.length > 0 && <SpaceStats space={subscriptions[0]} />}
                  <ForesightOrbs />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1">
                <TestingGrounds />
              </div>
              <div className="lg:col-span-1">
                <CollaborationZones />
              </div>
              <div className="lg:col-span-1">
                <WorldConnections />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Library;
