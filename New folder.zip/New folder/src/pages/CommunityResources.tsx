import { useState } from "react";
import { useParams } from "react-router-dom";
import { FileText, Search, Plus, Download, Star, Share2, Bookmark, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const CommunityResources = () => {
  const { spaceId } = useParams();
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");

  // Mock data for resources
  const resources = [
    {
      id: 1,
      title: "AI Model Deployment Guide",
      description: "A comprehensive guide to deploying AI models in production environments",
      category: "Tutorials",
      author: {
        name: "Alex Chen",
        avatar: "/avatars/alex.jpg"
      },
      downloads: 245,
      rating: 4.8,
      tags: ["AI", "Deployment", "Guide"],
      fileType: "PDF",
      size: "2.4 MB",
      uploaded: "2 days ago"
    },
    {
      id: 2,
      title: "Data Analysis Template",
      description: "A reusable template for data analysis projects",
      category: "Templates",
      author: {
        name: "Sarah Johnson",
        avatar: "/avatars/sarah.jpg"
      },
      downloads: 189,
      rating: 4.5,
      tags: ["Data", "Analysis", "Template"],
      fileType: "XLSX",
      size: "1.2 MB",
      uploaded: "1 week ago"
    },
    // ... more resources
  ];

  const categories = [
    { value: "all", label: "All Categories" },
    { value: "tutorials", label: "Tutorials" },
    { value: "templates", label: "Templates" },
    { value: "documentation", label: "Documentation" },
    { value: "code", label: "Code Samples" }
  ];

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Community Resources</h1>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search resources..."
              className="pl-8 w-64"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((category) => (
                <SelectItem key={category.value} value={category.value}>
                  {category.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button size="sm" className="gap-2">
            <Plus className="w-4 h-4" />
            Upload Resource
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-8">
          {/* Resources List */}
          <Card className="bg-card/50 border-primary/10">
            <CardContent className="p-4">
              <div className="space-y-4">
                {resources.map((resource) => (
                  <div key={resource.id} className="flex items-start gap-4 p-4 rounded-lg hover:bg-black/20">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <FileText className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{resource.title}</h3>
                        <Badge variant="secondary">{resource.category}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{resource.description}</p>
                      <div className="flex items-center gap-2 mt-2">
                        {resource.tags.map((tag) => (
                          <Badge key={tag} variant="outline">{tag}</Badge>
                        ))}
                      </div>
                      <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                        <span>{resource.fileType} • {resource.size}</span>
                        <span>Uploaded {resource.uploaded}</span>
                        <span>{resource.downloads} downloads</span>
                        <span className="flex items-center gap-1">
                          <Star className="w-4 h-4 text-yellow-500" />
                          {resource.rating}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="icon">
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Share2 className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Bookmark className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="col-span-4">
          {/* Popular Resources */}
          <Card className="bg-card/50 border-primary/10 mb-6">
            <CardHeader>
              <CardTitle className="text-lg">Popular Resources</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {resources.slice(0, 3).map((resource) => (
                  <div key={resource.id} className="flex items-center gap-3">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <FileText className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{resource.title}</p>
                      <p className="text-sm text-muted-foreground">{resource.downloads} downloads</p>
                    </div>
                    <Star className="w-4 h-4 text-yellow-500" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Resource Categories */}
          <Card className="bg-card/50 border-primary/10">
            <CardHeader>
              <CardTitle className="text-lg">Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {categories.map((category) => (
                  <div key={category.value} className="flex items-center justify-between p-2 rounded-lg hover:bg-black/20">
                    <span>{category.label}</span>
                    <Badge variant="secondary">24</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CommunityResources; 