
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import Sidebar from '@/components/Layout/Sidebar';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import SpaceLeftSidebar from '@/components/Space/SpaceLeftSidebar';
import BackToSpace from '@/components/Space/BackToSpace';
import { Search, Plus, Filter } from 'lucide-react';
import { IntegrationItem } from '@/data/integrationHubData';
import { integrationHubService } from '@/services/integrationHubService';
import IntegrationCard from '@/components/IntegrationHub/IntegrationCard';
import { toast } from 'sonner';

const IntegrationHub = () => {
  const { spaceId } = useParams();
  const [integrations, setIntegrations] = useState<IntegrationItem[]>([]);
  const [filteredIntegrations, setFilteredIntegrations] = useState<IntegrationItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    const fetchIntegrations = async () => {
      try {
        const data = await integrationHubService.getIntegrations();
        setIntegrations(data);
        setFilteredIntegrations(data);
        setIsLoading(false);
      } catch (error) {
        console.error("Failed to fetch integrations:", error);
        toast.error("Failed to load integrations. Please try again.");
        setIsLoading(false);
      }
    };
    
    fetchIntegrations();
  }, []);
  
  useEffect(() => {
    let result = integrations;
    
    // Apply search filter
    if (searchQuery) {
      result = result.filter(integration => 
        integration.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        integration.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    // Apply tab filter
    if (activeTab !== 'all') {
      result = result.filter(integration => integration.category === activeTab);
    }
    
    setFilteredIntegrations(result);
  }, [searchQuery, activeTab, integrations]);
  
  const handleConnect = async (id: string) => {
    const success = await integrationHubService.connectIntegration(id);
    if (success) {
      const updatedIntegrations = integrations.map(item => {
        if (item.id === id) {
          return { 
            ...item, 
            status: 'active' as const, 
            connectionCount: item.connectionCount + 1 
          };
        }
        return item;
      });
      setIntegrations(updatedIntegrations);
    }
  };
  
  const handleDisconnect = async (id: string) => {
    const success = await integrationHubService.disconnectIntegration(id);
    if (success) {
      const updatedIntegrations = integrations.map(item => {
        if (item.id === id) {
          return { 
            ...item, 
            status: 'inactive' as const, 
            connectionCount: Math.max(0, item.connectionCount - 1) 
          };
        }
        return item;
      });
      setIntegrations(updatedIntegrations);
    }
  };
  
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex">
        <SpaceLeftSidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <main className="flex-1 overflow-auto">
            <div className="container py-6">
              <BackToSpace spaceId={spaceId || ""} />
              
              <div className="flex items-center justify-between mb-6">
                <h1 className="text-2xl font-bold">Integration Hub</h1>
                <Button className="gap-2">
                  <Plus className="w-4 h-4" />
                  Add Integration
                </Button>
              </div>
              
              <div className="mb-6">
                <div className="relative">
                  <Search className="absolute top-3 left-3 h-4 w-4 text-muted-foreground" />
                  <Input 
                    className="pl-10" 
                    placeholder="Search integrations..." 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <div className="flex items-center justify-between mb-4">
                  <TabsList>
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="api">API</TabsTrigger>
                    <TabsTrigger value="data">Data</TabsTrigger>
                    <TabsTrigger value="communication">Communication</TabsTrigger>
                    <TabsTrigger value="cloud">Cloud</TabsTrigger>
                    <TabsTrigger value="tools">Tools</TabsTrigger>
                  </TabsList>
                  
                  <Button variant="outline" size="sm" className="gap-2">
                    <Filter className="w-4 h-4" />
                    Filter
                  </Button>
                </div>
                
                <TabsContent value="all" className="space-y-0 mt-0">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {filteredIntegrations.map(integration => (
                      <IntegrationCard 
                        key={integration.id} 
                        integration={integration} 
                        onConnect={handleConnect}
                        onDisconnect={handleDisconnect}
                      />
                    ))}
                  </div>
                </TabsContent>
                
                {['api', 'data', 'communication', 'cloud', 'tools'].map(category => (
                  <TabsContent key={category} value={category} className="space-y-0 mt-0">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {filteredIntegrations.map(integration => (
                        <IntegrationCard 
                          key={integration.id} 
                          integration={integration} 
                          onConnect={handleConnect}
                          onDisconnect={handleDisconnect}
                        />
                      ))}
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default IntegrationHub;
