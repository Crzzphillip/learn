import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { 
  ArrowLeft, 
  Code, 
  Copy, 
  Eye, 
  Layers, 
  Save, 
  Settings, 
  Share, 
  Undo,
  Redo,
  List,
  Plus
} from 'lucide-react';

import { 
  getComponentLibrary,
  LibraryComponent 
} from '@/services/componentLibraryService';
import ComponentLibrary from '@/components/WorkspaceCreator/ComponentLibrary';
import EnhancedCanvasView from '@/components/WorkspaceCreator/EnhancedCanvasView';
import EnhancedPropertyPanel from '@/components/WorkspaceCreator/EnhancedPropertyPanel';
import WebsitePreview from '@/components/WorkspaceCreator/WebsitePreview';
import CanvasView from '@/components/WorkspaceCreator/CanvasView';
import ComponentTree from '@/components/WorkspaceCreator/ComponentTree';

import {
  CanvasState,
  CanvasComponent,
  initialCanvasState,
  addComponentToCanvas,
  removeComponentFromCanvas,
  updateComponentPosition,
  updateComponentProperty,
  selectComponent,
  saveCanvasState,
  toggleGrid,
  toggleSnapToGrid,
  undo,
  redo
} from '@/services/canvasService';

import { 
  WebsiteComponent, 
  findComponentById, 
  updateComponentInTree, 
  deleteComponentFromTree, 
  addComponentToParent,
  createComponentInstance,
  createInitialComponents
} from '@/services/websiteComponentsService';
import { Box, Layout, Heading, Text, AlignLeft, Code as CodeIcon, Image, Link } from 'lucide-react';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import CanvasEditor from '@/components/WorkspaceCreator/CanvasEditor';

const WebsiteWorkspaceCreator = () => {
  const { templateId } = useParams<{ templateId: string }>();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('canvas');
  const [sidebarTab, setSidebarTab] = useState('library');
  const [showPropertyPanel, setShowPropertyPanel] = useState(true);
  const [canvasState, setCanvasState] = useState<CanvasState>(initialCanvasState);
  const [viewportZoom, setViewportZoom] = useState(1);
  const [parentIdForNewComponent, setParentIdForNewComponent] = useState<string | null>(null);
  const [showAddComponentDialog, setShowAddComponentDialog] = useState(false);
  const [gridEnabled, setGridEnabled] = useState(false);
  const [snapToGrid, setSnapToGrid] = useState(true);
  const [gridSize] = useState(8);
  
  // Website components state
  const [websiteComponents, setWebsiteComponents] = useState<WebsiteComponent[]>(createInitialComponents());
  const [selectedComponentId, setSelectedComponentId] = useState<string | null>(null);
  const [selectedComponent, setSelectedComponent] = useState<WebsiteComponent | null>(null);
  const [history, setHistory] = useState<WebsiteComponent[][]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  
  // Update selected component when ID changes
  useEffect(() => {
    if (selectedComponentId) {
      const component = findComponentById(websiteComponents, selectedComponentId);
      setSelectedComponent(component);
    } else {
      setSelectedComponent(null);
    }
  }, [selectedComponentId, websiteComponents]);
  
  // Add components to history when they change
  useEffect(() => {
    if (websiteComponents.length > 0) {
      const newHistory = [...history.slice(0, historyIndex + 1), [...websiteComponents]];
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
    }
  }, [websiteComponents]);
  
  const handleAddComponent = (component: LibraryComponent) => {
    if (parentIdForNewComponent) {
      const newComponent = createComponentInstance(component);
      
      const parent = findComponentById(websiteComponents, parentIdForNewComponent);
      
      if (parent && parent.isDroppable) {
        const updatedComponents = addComponentToParent(
          websiteComponents, 
          parentIdForNewComponent, 
          newComponent
        );
        
        setWebsiteComponents(updatedComponents);
        setSelectedComponentId(newComponent.id);
        setShowAddComponentDialog(false);
        setParentIdForNewComponent(null);
        
        toast.success(`${component.name} added to ${parent.name}`);
      }
    } else {
      const newComponent = createComponentInstance(component);
      setWebsiteComponents([...websiteComponents, newComponent]);
      setSelectedComponentId(newComponent.id);
      
      toast.success(`${component.name} added to canvas`);
    }
  };
  
  const handleSelectComponent = (component: WebsiteComponent) => {
    setSelectedComponentId(component.id);
  };
  
  const handleDropComponent = (component: any, position: { x: number; y: number }) => {
    const newComponent = {
      ...component,
      id: `${component.id}-${Date.now()}`,
      position,
      style: {
        ...component.style,
        position: 'absolute',
        left: `${position.x}px`,
        top: `${position.y}px`,
        width: component.style?.width || 'auto',
        height: component.style?.height || 'auto',
        minWidth: component.style?.minWidth || '100px',
        minHeight: component.style?.minHeight || '50px',
        backgroundColor: component.style?.backgroundColor || 'transparent',
        border: component.style?.border || '1px dashed #666',
        borderRadius: component.style?.borderRadius || '4px',
        padding: component.style?.padding || '8px',
        cursor: 'move',
        userSelect: 'none',
        transition: 'all 0.2s ease',
      },
      content: component.content || '',
      props: {
        ...component.props,
        draggable: true,
        onDragStart: (e: React.DragEvent) => {
          e.stopPropagation();
          e.dataTransfer.setData('application/json', JSON.stringify(component));
        },
        onDragOver: (e: React.DragEvent) => {
          e.preventDefault();
          e.stopPropagation();
        },
        onDrop: (e: React.DragEvent) => {
          e.preventDefault();
          e.stopPropagation();
          const droppedComponent = JSON.parse(e.dataTransfer.getData('application/json'));
          const rect = e.currentTarget.getBoundingClientRect();
          const x = e.clientX - rect.left;
          const y = e.clientY - rect.top;
          handleDropComponent(droppedComponent, { x, y });
        },
      },
    };

    setWebsiteComponents([...websiteComponents, newComponent]);
    setSelectedComponentId(newComponent.id);
    toast.success(`Added ${component.name} to canvas`);
  };
  
  const handleUpdateComponent = (componentId: string, property: string, value: any) => {
    const component = findComponentById(websiteComponents, componentId);
    if (!component) return;
    
    const updatedComponent = { ...component };
    
    // Handle nested properties (e.g., style.color or props.className)
    if (property.includes('.')) {
      const [section, key] = property.split('.');
      
      if (section === 'style') {
        updatedComponent.style = { ...updatedComponent.style, [key]: value };
      } else if (section === 'props') {
        updatedComponent.props = { ...updatedComponent.props, [key]: value };
      }
    } else {
      // Direct property update
      updatedComponent[property] = value;
    }
    
    const updatedComponents = updateComponentInTree(websiteComponents, updatedComponent);
    setWebsiteComponents(updatedComponents);
    
    toast.success(`Updated ${property}`, {
      duration: 2000
    });
  };
  
  const handleDuplicateComponent = (id: string) => {
    const component = findComponentById(websiteComponents, id);
    if (!component) return;
    
    const duplicate = {
      ...component,
      id: `${component.id}-${Date.now()}`,
      position: {
        x: (component.position?.x || 0) + 20,
        y: (component.position?.y || 0) + 20
      }
    };
    
    setWebsiteComponents([...websiteComponents, duplicate]);
    setSelectedComponentId(duplicate.id);
    
    toast.success("Component duplicated", {
      duration: 2000
    });
  };
  
  const handleDeleteComponent = (id: string) => {
    const newComponents = deleteComponentFromTree(websiteComponents, id);
    setWebsiteComponents(newComponents);
    setSelectedComponentId(null);
    
    toast.success("Component deleted", {
      duration: 2000
    });
  };
  
  const handleAddChildComponent = (parentId: string) => {
    setParentIdForNewComponent(parentId);
    setShowAddComponentDialog(true);
  };
  
  const handleSave = () => {
    // Here you would save the website structure to a backend service
    toast.success("Website saved", {
      description: "Your website layout has been saved successfully."
    });
  };
  
  const handleZoomIn = () => {
    setViewportZoom(prev => Math.min(prev + 0.1, 2));
  };
  
  const handleZoomOut = () => {
    setViewportZoom(prev => Math.max(prev - 0.1, 0.5));
  };
  
  const handleUndo = useCallback(() => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setWebsiteComponents([...history[historyIndex - 1]]);
      toast.info("Undo successful");
    }
  }, [historyIndex, history]);
  
  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setWebsiteComponents([...history[historyIndex + 1]]);
      toast.info("Redo successful");
    }
  }, [historyIndex, history]);
  
  return (
    <div className="h-screen flex flex-col bg-[#121212] text-gray-200">
      {/* Top Navigation */}
      <div className="border-b border-[#333] py-2 px-4 flex items-center justify-between bg-[#1a1a1a]">
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => navigate(-1)}
            className="text-gray-400 hover:text-gray-200"
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back
          </Button>
          <div className="h-6 border-r border-[#333] mx-1" />
          <h1 className="text-lg font-semibold text-gray-200">
            {templateId ? `Website Builder: ${templateId}` : 'New Website'}
          </h1>
        </div>
        
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setShowPropertyPanel(!showPropertyPanel)}
            className="text-gray-400 hover:text-gray-200"
          >
            <Settings className="h-4 w-4 mr-1" />
            {showPropertyPanel ? 'Hide' : 'Show'} Properties
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={handleSave}
            className="text-gray-400 hover:text-gray-200"
          >
            <Save className="h-4 w-4 mr-1" />
            Save
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            className="text-gray-400 hover:text-gray-200"
          >
            <Share className="h-4 w-4 mr-1" />
            Share
          </Button>
          <Button variant="secondary">
            <Eye className="h-4 w-4 mr-1" />
            Preview
          </Button>
        </div>
      </div>
      
      <div className="flex-1 flex">
        {/* Left Sidebar */}
        <div className="w-64 border-r border-[#333] flex flex-col bg-[#1a1a1a]">
          <Tabs 
            defaultValue="library" 
            value={sidebarTab}
            onValueChange={setSidebarTab}
            className="w-full border-b border-[#333]"
          >
            <TabsList className="w-full grid grid-cols-2 bg-[#252525]">
              <TabsTrigger 
                value="library" 
                className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400"
              >
                <Layers className="h-4 w-4 mr-1" /> Components
              </TabsTrigger>
              <TabsTrigger 
                value="tree" 
                className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400"
              >
                <List className="h-4 w-4 mr-1" /> Structure
              </TabsTrigger>
            </TabsList>
            
            <div className="flex-1 overflow-hidden">
              <TabsContent value="library" className="m-0 h-full">
                <ComponentLibrary onAddComponent={handleAddComponent} />
              </TabsContent>
              <TabsContent value="tree" className="m-0 h-full p-3 bg-[#1a1a1a]">
                <ComponentTree 
                  components={websiteComponents}
                  selectedComponentId={selectedComponentId}
                  onSelectComponent={handleSelectComponent}
                  onDeleteComponent={handleDeleteComponent}
                  onDuplicateComponent={handleDuplicateComponent}
                  onAddChildComponent={handleAddChildComponent}
                />
              </TabsContent>
            </div>
          </Tabs>
        </div>
        
        {/* Main Content */}
        <div className="flex-1 flex flex-col bg-[#121212]">
          <Tabs 
            defaultValue="canvas" 
            value={activeTab} 
            onValueChange={setActiveTab}
            className="flex-1 flex flex-col"
          >
            <TabsList className="mx-4 mt-2 justify-start bg-[#252525]">
              <TabsTrigger 
                value="canvas" 
                className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400"
              >
                <Layers className="h-4 w-4 mr-1" /> Canvas
              </TabsTrigger>
              <TabsTrigger 
                value="preview" 
                className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400"
              >
                <Eye className="h-4 w-4 mr-1" /> Preview
              </TabsTrigger>
              <TabsTrigger 
                value="code" 
                className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400"
              >
                <Code className="h-4 w-4 mr-1" /> Code
              </TabsTrigger>
            </TabsList>
            
            <div className="flex-1 p-4 flex overflow-hidden">
              <TabsContent value="canvas" className="flex-1 m-0 border border-[#333] rounded-md overflow-hidden flex">
                <div className="flex-1 bg-[#1a1a1a]">
                  <EnhancedCanvasView
                    components={websiteComponents}
                    selectedComponentId={selectedComponentId}
                    gridEnabled={gridEnabled}
                    snapToGrid={snapToGrid}
                    gridSize={gridSize}
                    viewportZoom={viewportZoom}
                    onSelectComponent={(id) => setSelectedComponentId(id)}
                    onUpdateComponent={(id, position) => {
                      const component = findComponentById(websiteComponents, id);
                      if (!component) return;
                      
                      const updatedComponent = {
                        ...component,
                        position,
                        style: {
                          ...component.style,
                          left: `${position.x}px`,
                          top: `${position.y}px`
                        }
                      };
                      
                      const updatedComponents = updateComponentInTree(websiteComponents, updatedComponent);
                      setWebsiteComponents(updatedComponents);
                    }}
                    onDuplicateComponent={handleDuplicateComponent}
                    onDeleteComponent={handleDeleteComponent}
                    onDropComponent={handleDropComponent}
                    onToggleGrid={() => setGridEnabled(!gridEnabled)}
                    onToggleSnapToGrid={() => setSnapToGrid(!snapToGrid)}
                    onUndo={handleUndo}
                    onRedo={handleRedo}
                    onZoomIn={handleZoomIn}
                    onZoomOut={handleZoomOut}
                  />
                </div>
                
                {showPropertyPanel && (
                  <div className="w-80 border-l border-[#333]">
                    <EnhancedPropertyPanel
                      selectedComponentId={selectedComponentId}
                      onUpdateComponent={handleUpdateComponent}
                    />
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="preview" className="flex-1 m-0 border border-[#333] rounded-md overflow-hidden">
                <div className="h-full bg-white">
                  <WebsitePreview
                    components={websiteComponents}
                    selectedComponentId={selectedComponentId}
                    onSelectComponent={handleSelectComponent}
                  />
                </div>
              </TabsContent>
              
              <TabsContent value="code" className="flex-1 m-0 border border-[#333] rounded-md overflow-hidden">
                <div className="h-full p-4 bg-[#1a1a1a]">
                  <h2 className="text-xl font-bold mb-4 text-gray-200">Generated Code</h2>
                  <div className="bg-[#252525] text-gray-200 p-4 rounded-md overflow-auto h-[calc(100%-3rem)]">
                    <pre className="text-sm"><code>{`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Generated Website</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
  <!-- Generated components -->
  ${websiteComponents.map(component => {
    return `<${component.type} class="${component.props?.className || ''}" style="${Object.entries(component.style || {}).map(([key, value]) => `${key.replace(/([A-Z])/g, '-$1').toLowerCase()}: ${value}`).join('; ')}">${component.content || ''}</${component.type}>`
  }).join('\n  ')}
</body>
</html>
                    `}</code></pre>
                  </div>
                </div>
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>

      {/* Add Component Dialog */}
      <Dialog open={showAddComponentDialog} onOpenChange={setShowAddComponentDialog}>
        <DialogContent className="sm:max-w-md bg-[#1a1a1a] border-[#333] text-gray-200">
          <DialogHeader>
            <DialogTitle>Add Component</DialogTitle>
            <DialogDescription className="text-gray-400">
              {parentIdForNewComponent ? (
                <span>
                  Select a component to add as a child to{' '}
                  <strong className="text-purple-400">
                    {findComponentById(websiteComponents, parentIdForNewComponent)?.name || 'component'}
                  </strong>
                </span>
              ) : (
                <span>Select a component to add to the canvas</span>
              )}
            </DialogDescription>
          </DialogHeader>
          <div className="max-h-[70vh] overflow-y-auto p-4">
            <ComponentLibrary onAddComponent={handleAddComponent} />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default WebsiteWorkspaceCreator;
