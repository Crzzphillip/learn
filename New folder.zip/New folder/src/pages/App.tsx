
import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Layers, Download, Share, ArrowLeft, Settings, MessageSquare, Play, ArrowRight } from 'lucide-react';
import Sidebar from '@/components/Layout/Sidebar';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import CreditBadge from '@/components/Space/CreditBadge';
import { toast } from 'sonner';
import BackToSpace from '@/components/Space/BackToSpace';

const App = () => {
  const { appId, spaceId } = useParams();
  const [activeTab, setActiveTab] = useState('interact');
  const [isRunning, setIsRunning] = useState(false);
  const [userInput, setUserInput] = useState('');
  
  const appData = {
    id: appId,
    name: 'Component Crafter',
    description: 'Generate UI components from text descriptions with a simple chat interface.',
    credits: '15',
    author: {
      name: 'Design AI Space',
      avatar: '/lovable-uploads/091fc3d6-b8de-40a6-9ec4-e494fb240295.png'
    },
    source: {
      type: 'agent',
      id: 'agent-123',
      name: 'UI Builder Agent'
    },
    createdAt: '2023-09-15T12:00:00Z',
    updatedAt: '2023-10-01T09:30:00Z',
    usageCount: 2567,
    rating: 4.8,
    reviews: 127
  };
  
  const handleRun = () => {
    if (!userInput) {
      toast.error('Please enter an input prompt');
      return;
    }
    
    setIsRunning(true);
    
    setTimeout(() => {
      setIsRunning(false);
      toast.success('App executed successfully');
    }, 3000);
  };
  
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <div className="border-b bg-background/95 backdrop-blur-sm">
          <div className="container py-4">
            <BackToSpace spaceId={spaceId || ""} />
            <div className="flex items-center justify-between py-2">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/10 rounded-xl grid place-items-center">
                  <Layers className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h1 className="text-2xl font-semibold">{appData.name}</h1>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">{appData.source.name}</span>
                    <CreditBadge credits={appData.credits} />
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon">
                  <Download className="w-5 h-5" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Share className="w-5 h-5" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Settings className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-hidden">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
            <div className="border-b">
              <div className="container">
                <TabsList>
                  <TabsTrigger value="interact" className="flex items-center gap-1">
                    <MessageSquare className="w-4 h-4" />
                    Interact
                  </TabsTrigger>
                  <TabsTrigger value="examples" className="flex items-center gap-1">
                    <ArrowRight className="w-4 h-4" />
                    Examples
                  </TabsTrigger>
                  <TabsTrigger value="about" className="flex items-center gap-1">
                    <Layers className="w-4 h-4" />
                    About
                  </TabsTrigger>
                </TabsList>
              </div>
            </div>

            <div className="flex-1 overflow-auto">
              <TabsContent value="interact" className="h-full p-0 m-0">
                <div className="container h-full py-6">
                  <div className="h-full flex flex-col">
                    <div className="flex-1 bg-muted/30 rounded-lg p-6 mb-6 overflow-auto">
                      <div className="flex items-start gap-4 mb-6">
                        <Avatar className="w-10 h-10">
                          <AvatarImage src={appData.author.avatar} alt={appData.author.name} />
                          <AvatarFallback>{appData.author.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="bg-card p-4 rounded-lg shadow-sm">
                          <p>Hello! I'm the Component Crafter. I can generate UI components based on your descriptions. Try giving me a description of a component you'd like to create.</p>
                        </div>
                      </div>
                    </div>

                    <div className="border rounded-lg p-4 bg-card flex flex-col">
                      <Textarea
                        placeholder="Describe the UI component you want to create..."
                        className="min-h-[100px] mb-4 resize-none"
                        value={userInput}
                        onChange={(e) => setUserInput(e.target.value)}
                      />
                      <div className="flex justify-end gap-2">
                        <Button variant="outline">
                          Clear
                        </Button>
                        <Button onClick={handleRun} className="gap-2">
                          {isRunning ? (
                            <>
                              <div className="w-4 h-4 border-2 border-white border-t-transparent animate-spin rounded-full"></div>
                              Processing...
                            </>
                          ) : (
                            <>
                              <Play className="w-4 h-4" />
                              Generate Component
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="examples" className="h-full p-0 m-0">
                <div className="container py-6">
                  <h2 className="text-xl font-semibold mb-4">Example Prompts</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[
                      "A simple card component with a title, description, and action button",
                      "A navigation bar with logo, links, and a profile dropdown",
                      "A pricing table with three tiers: Free, Pro, and Enterprise",
                      "A contact form with name, email, subject, and message fields"
                    ].map((example, index) => (
                      <div 
                        key={index}
                        className="p-4 border rounded-lg hover:bg-muted/20 cursor-pointer transition-colors"
                        onClick={() => setUserInput(example)}
                      >
                        <p className="font-medium text-primary">{example}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="about" className="h-full p-0 m-0">
                <div className="container py-6">
                  <h2 className="text-xl font-semibold mb-4">About {appData.name}</h2>
                  <div className="space-y-4">
                    <p>{appData.description}</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="p-4 border rounded-lg bg-card">
                        <div className="text-sm text-muted-foreground">Created by</div>
                        <div className="font-medium">{appData.author.name}</div>
                      </div>
                      <div className="p-4 border rounded-lg bg-card">
                        <div className="text-sm text-muted-foreground">Created on</div>
                        <div className="font-medium">{new Date(appData.createdAt).toLocaleDateString()}</div>
                      </div>
                      <div className="p-4 border rounded-lg bg-card">
                        <div className="text-sm text-muted-foreground">Total usages</div>
                        <div className="font-medium">{appData.usageCount.toLocaleString()}</div>
                      </div>
                      <div className="p-4 border rounded-lg bg-card">
                        <div className="text-sm text-muted-foreground">Rating</div>
                        <div className="font-medium">{appData.rating} ({appData.reviews} reviews)</div>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default App;
