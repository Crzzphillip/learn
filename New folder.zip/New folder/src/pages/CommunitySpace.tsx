import { useState } from "react";
import { useParams } from "react-router-dom";
import { 
  Users, MessageSquare, FileText, Code, Brain, Palette, 
  Image, Music, Settings, Share2, Plus, Search, Grid3X3, 
  List, ChevronDown, ArrowRight, Star, Bookmark, 
  GitBranch, Zap, Workflow, AppWindow, Layout, 
  Sparkles, Lightbulb, Award, Trophy, BookOpen
} from "lucide-react";
import Sidebar from "@/components/Layout/Sidebar";
import SpaceBanner from "@/components/Space/SpaceBanner";
import CommunityLeftSidebar from "@/components/Community/CommunityLeftSidebar";
import CommunityTabs from "@/components/Community/CommunityTabs";
import getDefaultCommunityStats from "@/components/Community/CommunityStats";
import getDefaultCommunityTemplate from "@/components/Community/CommunityTemplate";
import BackToSpace from "@/components/Space/BackToSpace";
import { SpaceCredits } from "@/types/space";
import SpaceLeftSidebar from "@/components/Space/SpaceLeftSidebar";
import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";

const CommunitySpace = () => {
  const { spaceId } = useParams();
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  
  // Mock space hierarchy data
  const spaceHierarchy = [{
    id: 'space-1',
    title: 'Development Space',
    children: [{
      id: 'space-1-1',
      title: 'Frontend Development',
      children: []
    }, {
      id: 'space-1-2',
      title: 'Backend Development',
      children: []
    }]
  }];

  // Mock credits data
  const credits: SpaceCredits = {
    balance: 1200,
    usage: {
      agents: 250,
      workflows: 150,
      tools: 100,
      apps: 50
    },
    earnings: 420,
    subscriptionTier: 'pro'
  };

  // Get stats and template data
  const stats = getDefaultCommunityStats();
  const spaceTemplate = getDefaultCommunityTemplate();

  // Mock data for community resources
  const communityResources = {
    workspaces: [
      { id: 1, title: "AI Art Generator", description: "Create stunning AI-generated artwork", author: "Alex Chen", likes: 245, type: "workspace" },
      { id: 2, title: "ML Model Trainer", description: "Train and deploy machine learning models", author: "Sarah Johnson", likes: 189, type: "workspace" },
    ],
    templates: [
      { id: 1, title: "E-commerce Template", description: "Complete e-commerce solution", author: "Mike Wilson", downloads: 1200, type: "template" },
      { id: 2, title: "Portfolio Template", description: "Professional portfolio website", author: "Emma Davis", downloads: 980, type: "template" },
    ],
    agents: [
      { id: 1, title: "Content Writer", description: "AI-powered content creation", author: "David Lee", usage: 1500, type: "agent" },
      { id: 2, title: "Code Assistant", description: "Smart coding companion", author: "Lisa Brown", usage: 2100, type: "agent" },
    ],
    workflows: [
      { id: 1, title: "Image Processing", description: "Automated image enhancement", author: "Tom Wilson", runs: 850, type: "workflow" },
      { id: 2, title: "Data Analysis", description: "Advanced data processing", author: "Anna Smith", runs: 1200, type: "workflow" },
    ],
    apps: [
      { id: 1, title: "Task Manager", description: "Project management tool", author: "Chris Taylor", users: 500, type: "app" },
      { id: 2, title: "Analytics Dashboard", description: "Data visualization platform", author: "Rachel Green", users: 750, type: "app" },
    ]
  };

  // Mock data for community members
  const communityMembers = [
    { id: 1, name: "Alex Chen", role: "Community Lead", avatar: "/avatars/alex.jpg", contributions: 120 },
    { id: 2, name: "Sarah Johnson", role: "AI Expert", avatar: "/avatars/sarah.jpg", contributions: 95 },
    { id: 3, name: "Mike Wilson", role: "Template Creator", avatar: "/avatars/mike.jpg", contributions: 78 },
    { id: 4, name: "Emma Davis", role: "Developer", avatar: "/avatars/emma.jpg", contributions: 65 },
  ];

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-auto">
          <SpaceBanner stats={stats} template={spaceTemplate} />
          
          <div className="container py-6">
            <BackToSpace spaceId={spaceId || ""} />
            
            {/* Community Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <h1 className="text-2xl font-bold">AI Development Hub</h1>
                <Badge variant="secondary" className="text-sm">Active Community</Badge>
              </div>
              <div className="flex items-center gap-4">
                <Button variant="outline" size="sm" className="gap-2">
                  <Share2 className="w-4 h-4" />
                  Share
                </Button>
                <Button size="sm" className="gap-2">
                  <Plus className="w-4 h-4" />
                  Join Community
              </Button>
            </div>
          </div>
          
            {/* Search and View Controls */}
            <div className="flex items-center gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  placeholder="Search community resources..."
                  className="pl-9"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  className={viewMode === 'grid' ? 'bg-primary/20' : ''}
                  onClick={() => setViewMode('grid')}
                >
                  <Grid3X3 className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className={viewMode === 'list' ? 'bg-primary/20' : ''}
                  onClick={() => setViewMode('list')}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>
            
            {/* Main Content */}
            <div className="grid grid-cols-12 gap-6">
              {/* Left Sidebar */}
              <div className="col-span-3 space-y-6">
                {/* Community Stats */}
                <Card className="bg-card/50 border-primary/10">
                  <CardHeader>
                    <CardTitle className="text-lg">Community Stats</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-primary" />
                        <span className="text-sm">Members</span>
                      </div>
                      <span className="font-medium">1.2K</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="w-4 h-4 text-primary" />
                        <span className="text-sm">Discussions</span>
                      </div>
                      <span className="font-medium">450</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-primary" />
                        <span className="text-sm">Resources</span>
                      </div>
                      <span className="font-medium">320</span>
                    </div>
                  </CardContent>
                </Card>

                {/* Top Contributors */}
                <Card className="bg-card/50 border-primary/10">
                  <CardHeader>
                    <CardTitle className="text-lg">Top Contributors</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[200px]">
                      <div className="space-y-4">
                        {communityMembers.map((member) => (
                          <div key={member.id} className="flex items-center gap-3">
                            <Avatar>
                              <AvatarImage src={member.avatar} />
                              <AvatarFallback>{member.name[0]}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="font-medium">{member.name}</div>
                              <div className="text-sm text-muted-foreground">{member.role}</div>
                            </div>
                            <Badge variant="secondary">{member.contributions}</Badge>
                          </div>
                        ))}
                </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>

              {/* Main Content Area */}
              <div className="col-span-9">
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid grid-cols-6">
                    <TabsTrigger value="overview">
                      <Layout className="w-4 h-4 mr-2" />
                      Overview
                    </TabsTrigger>
                    <TabsTrigger value="workspaces">
                      <GitBranch className="w-4 h-4 mr-2" />
                      Workspaces
                    </TabsTrigger>
                    <TabsTrigger value="templates">
                      <FileText className="w-4 h-4 mr-2" />
                      Templates
                    </TabsTrigger>
                    <TabsTrigger value="agents">
                      <Brain className="w-4 h-4 mr-2" />
                      Agents
                    </TabsTrigger>
                    <TabsTrigger value="workflows">
                      <Workflow className="w-4 h-4 mr-2" />
                      Workflows
                    </TabsTrigger>
                    <TabsTrigger value="apps">
                      <AppWindow className="w-4 h-4 mr-2" />
                      Apps
                    </TabsTrigger>
                  </TabsList>

                  {/* Overview Tab */}
                  <TabsContent value="overview" className="mt-6">
                    <div className="grid grid-cols-2 gap-6">
                      {/* Featured Resources */}
                      <Card className="col-span-2 bg-card/50 border-primary/10">
                        <CardHeader>
                          <CardTitle className="text-lg">Featured Resources</CardTitle>
                          <CardDescription>Most popular and recently added resources</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="grid grid-cols-2 gap-4">
                            {Object.values(communityResources).flat().slice(0, 4).map((resource) => (
                              <Card key={resource.id} className="bg-card/30 border-primary/5">
                                <CardContent className="p-4">
                                  <div className="flex items-start gap-3">
                                    <div className="w-10 h-10 rounded-lg bg-primary/20 grid place-items-center">
                                      {resource.type === 'workspace' && <GitBranch className="w-5 h-5 text-primary" />}
                                      {resource.type === 'template' && <FileText className="w-5 h-5 text-primary" />}
                                      {resource.type === 'agent' && <Brain className="w-5 h-5 text-primary" />}
                                      {resource.type === 'workflow' && <Workflow className="w-5 h-5 text-primary" />}
                                      {resource.type === 'app' && <AppWindow className="w-5 h-5 text-primary" />}
                                    </div>
                                    <div className="flex-1">
                                      <h3 className="font-medium">{resource.title}</h3>
                                      <p className="text-sm text-muted-foreground">{resource.description}</p>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            ))}
                          </div>
                        </CardContent>
                      </Card>

                      {/* Community Activity */}
                      <Card className="bg-card/50 border-primary/10">
                        <CardHeader>
                          <CardTitle className="text-lg">Recent Activity</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ScrollArea className="h-[300px]">
                            <div className="space-y-4">
                              {[...Array(5)].map((_, i) => (
                                <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-black/20">
                                  <Avatar>
                                    <AvatarImage src={`/avatars/user${i + 1}.jpg`} />
                                    <AvatarFallback>U{i + 1}</AvatarFallback>
                                  </Avatar>
                                  <div>
                                    <p className="text-sm">
                                      <span className="font-medium">User {i + 1}</span> created a new workspace
                                    </p>
                                    <p className="text-xs text-muted-foreground">2 hours ago</p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </ScrollArea>
                        </CardContent>
                      </Card>

                      {/* Community Guidelines */}
                      <Card className="bg-card/50 border-primary/10">
                        <CardHeader>
                          <CardTitle className="text-lg">Community Guidelines</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div className="flex items-start gap-3">
                              <div className="w-8 h-8 rounded-full bg-primary/20 grid place-items-center">
                                <Star className="w-4 h-4 text-primary" />
                              </div>
                              <div>
                                <h4 className="font-medium">Be Respectful</h4>
                                <p className="text-sm text-muted-foreground">Treat all members with respect and kindness</p>
                              </div>
                            </div>
                            <div className="flex items-start gap-3">
                              <div className="w-8 h-8 rounded-full bg-primary/20 grid place-items-center">
                                <Share2 className="w-4 h-4 text-primary" />
                              </div>
                              <div>
                                <h4 className="font-medium">Share Knowledge</h4>
                                <p className="text-sm text-muted-foreground">Contribute and help others learn</p>
                              </div>
                            </div>
                            <div className="flex items-start gap-3">
                              <div className="w-8 h-8 rounded-full bg-primary/20 grid place-items-center">
                                <Sparkles className="w-4 h-4 text-primary" />
                              </div>
                              <div>
                                <h4 className="font-medium">Be Creative</h4>
                                <p className="text-sm text-muted-foreground">Share innovative ideas and solutions</p>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>

                  {/* Resource Tabs */}
                  {Object.entries(communityResources).map(([key, resources]) => (
                    <TabsContent key={key} value={key} className="mt-6">
                      <div className={viewMode === 'grid' ? 
                        "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : 
                        "space-y-4"
                      }>
                        {resources.map((resource) => (
                          <Card key={resource.id} className="bg-card/50 border-primary/10">
                            <CardContent className="p-4">
                              <div className="flex items-start gap-3">
                                <div className="w-10 h-10 rounded-lg bg-primary/20 grid place-items-center">
                                  {resource.type === 'workspace' && <GitBranch className="w-5 h-5 text-primary" />}
                                  {resource.type === 'template' && <FileText className="w-5 h-5 text-primary" />}
                                  {resource.type === 'agent' && <Brain className="w-5 h-5 text-primary" />}
                                  {resource.type === 'workflow' && <Workflow className="w-5 h-5 text-primary" />}
                                  {resource.type === 'app' && <AppWindow className="w-5 h-5 text-primary" />}
                                </div>
                                <div className="flex-1">
                                  <h3 className="font-medium">{resource.title}</h3>
                                  <p className="text-sm text-muted-foreground">{resource.description}</p>
                                  <div className="mt-2 flex items-center gap-4">
                                    <div className="flex items-center gap-1">
                                      <Star className="w-4 h-4 text-primary" />
                                      <span className="text-sm">{resource.likes || resource.downloads || resource.usage || resource.runs || resource.users}</span>
                                    </div>
                                    <div className="text-sm text-muted-foreground">by {resource.author}</div>
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                            <CardFooter className="flex justify-between p-4 pt-0">
                              <Button variant="outline" size="sm">View Details</Button>
                              <Button size="sm" className="gap-2">
                                <Plus className="w-4 h-4" />
                                Add to Space
                              </Button>
                            </CardFooter>
                          </Card>
                        ))}
                      </div>
                    </TabsContent>
                  ))}
                </Tabs>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default CommunitySpace;
