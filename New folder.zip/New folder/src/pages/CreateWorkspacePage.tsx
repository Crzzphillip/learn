import { useState } from "react";
import { motion } from "framer-motion";
import { Link, useNavigate } from "react-router-dom";
import Sidebar from "@/components/Layout/Sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BrainCircuit, 
  Layers, 
  PenLine, 
  Rocket, 
  Code, 
  Users, 
  Workflow, 
  Bot, 
  BarChart3, 
  PlusCircle,
  Globe,
  Sparkles,
  Puzzle,
  Zap,
  Settings,
  LucideIcon
} from "lucide-react";
import { workspaceBuilderService } from "@/services/workspaceTemplateService";
import { WorkspaceTemplateWithComponent } from "@/services/workspaceTemplateTypes";
import TemplateSelector from "@/components/WorkspaceCreator/TemplateSelector";

const CreateWorkspacePage = () => {
  const [activeTab, setActiveTab] = useState("templates");
  const navigate = useNavigate();
  
  // Get templates from our service
  const templates = workspaceBuilderService.getPopularTemplates();
  const coreFeatures = [
    {
      id: "drag-drop",
      name: "AI-Powered Drag-and-Drop Builder",
      description: "Simplified visual editor for creating web, mobile, and desktop apps with AI-assisted suggestions.",
      icon: PenLine
    },
    {
      id: "generative",
      name: "Generative Design Tools",
      description: "Use natural language prompts to generate app designs, backend schemas, and workflows.",
      icon: Sparkles
    },
    {
      id: "deployment",
      name: "Cross-Platform Deployment",
      description: "One-click deployment across web, iOS, Android, and desktop with platform-specific optimizations.",
      icon: Rocket
    },
    {
      id: "templates",
      name: "Pre-Built AI Templates",
      description: "Ready-to-use templates for chatbots, recommendation engines, voice assistants, and more.",
      icon: Layers
    },
    {
      id: "ai-models",
      name: "Integrated AI Models",
      description: "Built-in support for GPT models, computer vision APIs, and easy integration with third-party AI services.",
      icon: BrainCircuit
    },
    {
      id: "plugins",
      name: "Marketplace for Plugins",
      description: "Access a library of pre-trained models and third-party plugins to extend your workspace.",
      icon: Puzzle
    }
  ];

  // Data for advanced features
  const advancedFeatures = [
    {
      id: "collaboration",
      name: "Real-Time Collaboration",
      description: "Multi-user editing for teams with AI-powered version control to track changes and suggest improvements.",
      icon: Users
    },
    {
      id: "custom-code",
      name: "Custom Code Integration",
      description: "Inject custom code (Python or JavaScript) alongside no-code tools for maximum flexibility.",
      icon: Code
    },
    {
      id: "automation",
      name: "AI Workflow Automation",
      description: "Automate repetitive tasks like data cleaning or API integration using intelligent bots.",
      icon: Workflow
    },
    {
      id: "data-viz",
      name: "Data Visualization Tools",
      description: "Drag-and-drop dashboards with real-time analytics powered by machine learning.",
      icon: BarChart3
    },
    {
      id: "chatbot",
      name: "Voice & Chatbot Builders",
      description: "Create conversational interfaces with natural language processing capabilities.",
      icon: Bot
    },
    {
      id: "testing",
      name: "Automated Testing & Debugging",
      description: "AI identifies bugs and optimizes performance in real-time, ensuring error-free apps.",
      icon: Settings
    }
  ];

  // Data for unique differentiators
  const differentiators = [
    {
      id: "copilot",
      name: "AI Copilot for Developers",
      description: "A coding assistant that generates code snippets or fixes errors in real-time as you build.",
      icon: BrainCircuit
    },
    {
      id: "personalization",
      name: "Dynamic Personalization Engine",
      description: "Enable apps to adapt dynamically to user behavior using embedded AI models.",
      icon: Zap
    },
    {
      id: "ux-design",
      name: "Smart UI/UX Design",
      description: "AI suggests layouts, color schemes, and fonts based on user behavior analysis.",
      icon: PenLine
    }
  ];

  // Data for AI models
  const aiModels = [
    {
      id: "gpt",
      name: "GPT Models",
      type: "Natural Language",
      icon: BrainCircuit
    },
    {
      id: "vision",
      name: "Computer Vision",
      type: "Image Recognition",
      icon: PenLine
    },
    {
      id: "automl",
      name: "AutoML",
      type: "Custom Training",
      icon: Settings
    },
    {
      id: "huggingface",
      name: "Hugging Face",
      type: "3rd Party Integration",
      icon: Bot
    }
  ];

  const handleSelectTemplate = (template) => {
    navigate(`/create/workspace/${template.id}`);
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-auto">
        {/* Hero Section */}
        <div className="relative p-8 pb-20 bg-gradient-to-br from-purple-500/10 via-indigo-500/10 to-blue-500/10">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl font-bold mb-3">Create Your AI Workspace</h1>
            <p className="text-xl text-muted-foreground mb-8">
              Build powerful AI-driven workspaces with our intuitive platform
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-background/60 backdrop-blur-sm border-purple-500/20">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-full bg-purple-500/10 flex items-center justify-center mb-4">
                    <BrainCircuit className="w-6 h-6 text-purple-500" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">AI-Powered Builder</h3>
                  <p className="text-muted-foreground text-sm">
                    Create apps with AI-assisted design and workflow suggestions
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-background/60 backdrop-blur-sm border-blue-500/20">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center mb-4">
                    <Rocket className="w-6 h-6 text-blue-500" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">Cross-Platform</h3>
                  <p className="text-muted-foreground text-sm">
                    One-click deployment across web, mobile, and desktop platforms
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-background/60 backdrop-blur-sm border-green-500/20">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center mb-4">
                    <Layers className="w-6 h-6 text-green-500" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">Pre-Built Templates</h3>
                  <p className="text-muted-foreground text-sm">
                    Ready-to-use templates for chatbots, recommendations, and more
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
        
        {/* Main Content with Tabs */}
        <div className="flex-1 p-8 max-w-7xl mx-auto w-full">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <div className="flex justify-between items-center mb-8">
              <TabsList className="grid grid-cols-3 w-[400px]">
                <TabsTrigger value="templates">Templates</TabsTrigger>
                <TabsTrigger value="features">Features</TabsTrigger>
                <TabsTrigger value="advanced">Advanced</TabsTrigger>
              </TabsList>
              
              <Button onClick={() => navigate('/create/workspace/fullstack')}>
                <PlusCircle className="w-4 h-4 mr-2" />
                New Workspace
              </Button>
            </div>
            
            {/* Templates Tab */}
            <TabsContent value="templates" className="space-y-8">
              <TemplateSelector onSelectTemplate={handleSelectTemplate} />
            </TabsContent>
            
            {/* Features Tab */}
            <TabsContent value="features" className="space-y-8">
              <h2 className="text-2xl font-bold">Core Features</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {coreFeatures.map((feature) => (
                  <FeatureCard key={feature.id} feature={feature} />
                ))}
              </div>
              
              <h2 className="text-2xl font-bold mt-12">Integrated AI Models</h2>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {aiModels.map((model) => (
                  <ModelCard key={model.id} model={model} />
                ))}
              </div>
            </TabsContent>
            
            {/* Advanced Tab */}
            <TabsContent value="advanced" className="space-y-8">
              <h2 className="text-2xl font-bold">Advanced Features</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {advancedFeatures.map((feature) => (
                  <FeatureCard key={feature.id} feature={feature} />
                ))}
              </div>
              
              <h2 className="text-2xl font-bold mt-12">Unique Differentiators</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {differentiators.map((feature) => (
                  <FeatureCard key={feature.id} feature={feature} highlight />
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

// Component for feature cards
const FeatureCard = ({ feature, highlight = false }: { feature: any, highlight?: boolean }) => {
  const IconComponent = feature.icon as LucideIcon;
  
  return (
    <Card className={`hover:shadow-md transition-all duration-300 ${highlight ? 'border-primary/30 bg-primary/5' : ''}`}>
      <CardContent className="p-5">
        <div className={`w-10 h-10 rounded-full ${highlight ? 'bg-primary/10' : 'bg-gray-100'} flex items-center justify-center mb-4`}>
          <IconComponent className={`w-5 h-5 ${highlight ? 'text-primary' : 'text-gray-600'}`} />
        </div>
        <h3 className="text-lg font-semibold mb-2">{feature.name}</h3>
        <p className="text-muted-foreground text-sm">{feature.description}</p>
      </CardContent>
    </Card>
  );
};

// Component for AI model cards
const ModelCard = ({ model }: { model: any }) => {
  const IconComponent = model.icon as LucideIcon;
  
  return (
    <Card className="border hover:shadow-md transition-all hover:-translate-y-1 duration-300">
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center">
            <IconComponent className="w-4 h-4 text-purple-600" />
          </div>
          <div>
            <h3 className="font-semibold">{model.name}</h3>
            <p className="text-xs text-muted-foreground">{model.type}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CreateWorkspacePage;
