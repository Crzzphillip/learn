
import { useParams } from "react-router-dom";
import Sidebar from "@/components/Layout/Sidebar";
import BackToSpace from "@/components/Space/BackToSpace";
import SpaceLeftSidebar from "@/components/Space/SpaceLeftSidebar";

const SpaceSettings = () => {
  const { spaceId } = useParams();

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex">
        <SpaceLeftSidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <main className="flex-1 overflow-auto">
            <div className="container py-8">
              <BackToSpace spaceId={spaceId || ""} />
              
              <div className="mb-8">
                <h1 className="text-3xl font-bold mb-2">Space Settings</h1>
                <p className="text-muted-foreground">
                  Manage your space settings and configurations
                </p>
              </div>
              
              <div className="grid gap-6">
                <section className="space-y-4">
                  <h2 className="text-xl font-semibold">General Settings</h2>
                  <div className="grid gap-4 p-6 rounded-lg border border-white/10 bg-white/5">
                    <div>
                      <label className="block text-sm font-medium mb-2">Space Name</label>
                      <input
                        type="text"
                        className="w-full px-3 py-2 rounded-md bg-white/10 border border-white/20"
                        placeholder="Enter space name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Description</label>
                      <textarea
                        className="w-full px-3 py-2 rounded-md bg-white/10 border border-white/20"
                        rows={3}
                        placeholder="Enter space description"
                      />
                    </div>
                  </div>
                </section>

                <section className="space-y-4">
                  <h2 className="text-xl font-semibold">Privacy & Security</h2>
                  <div className="grid gap-4 p-6 rounded-lg border border-white/10 bg-white/5">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Space Visibility</h3>
                        <p className="text-sm text-white/60">Control who can see your space</p>
                      </div>
                      <select className="px-3 py-2 rounded-md bg-white/10 border border-white/20">
                        <option value="public">Public</option>
                        <option value="private">Private</option>
                        <option value="unlisted">Unlisted</option>
                      </select>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Access Control</h3>
                        <p className="text-sm text-white/60">Manage who can access your space</p>
                      </div>
                      <select className="px-3 py-2 rounded-md bg-white/10 border border-white/20">
                        <option value="everyone">Everyone</option>
                        <option value="members">Members Only</option>
                        <option value="admins">Admins Only</option>
                      </select>
                    </div>
                  </div>
                </section>

                <section className="space-y-4">
                  <h2 className="text-xl font-semibold">Advanced Settings</h2>
                  <div className="grid gap-4 p-6 rounded-lg border border-white/10 bg-white/5">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">API Access</h3>
                        <p className="text-sm text-white/60">Enable or disable API access</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" className="sr-only peer" />
                        <div className="w-11 h-6 bg-white/10 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                      </label>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Webhooks</h3>
                        <p className="text-sm text-white/60">Configure webhook notifications</p>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" className="sr-only peer" />
                        <div className="w-11 h-6 bg-white/10 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                      </label>
                    </div>
                  </div>
                </section>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default SpaceSettings;
