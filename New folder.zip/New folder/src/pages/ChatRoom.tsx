
import { useParams, useNavigate } from "react-router-dom";
import { useState } from "react";
import Sidebar from "@/components/Layout/Sidebar";
import SpaceLeftSidebar from "@/components/Space/SpaceLeftSidebar";
import ChatPanel from "@/components/Agent/ChatPanel";
import { Menu, Settings, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import ChatSettingsDialog from "@/components/Agent/ChatSettingsDialog";
import AgentSessions from "@/components/Agent/AgentSessions";
import ViewTabs, { ViewType } from "@/components/Agent/ViewTabs";
import CodeView from "@/components/Agent/Views/CodeView";
import ImageView from "@/components/Agent/Views/ImageView";
import CanvasView from "@/components/Agent/Views/CanvasView";
import FileView from "@/components/Agent/Views/FileView";

interface DualViewState {
  id: string;
  views: [ViewType, ViewType];
}

const ChatRoom = () => {
  const { agentId } = useParams();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [selectedPersona, setSelectedPersona] = useState<string | null>(null);
  const [activeView, setActiveView] = useState<ViewType>("chat");
  const [activeDualView, setActiveDualView] = useState<DualViewState | null>(null);
  
  // This is placeholder data that would normally come from the AI's responses
  const [codeData, setCodeData] = useState({ 
    code: "function hello() {\n  console.log('Hello, world!');\n}", 
    language: "javascript" 
  });
  const [imageData, setImageData] = useState({ 
    images: ["https://placehold.co/600x400/png"] 
  });
  const [canvasData, setCanvasData] = useState({ 
    canvasData: "<svg width='100%' height='100%' viewBox='0 0 800 600'><circle cx='400' cy='300' r='150' fill='#6246ea' /></svg>" 
  });
  const [fileData, setFileData] = useState({ 
    files: [
      { name: "example.pdf", url: "#", size: "1.2 MB" },
      { name: "document.docx", url: "#", size: "842 KB" }
    ] 
  });
  
  const handlePersonaSelect = (personaId: string) => {
    setSelectedPersona(personaId);
    setIsSettingsOpen(false);
  };
  
  const handleDualViewSelect = (views: [ViewType, ViewType], id: string) => {
    setActiveDualView({ id, views });
  };
  
  // Render a single view based on the view type
  const renderView = (viewType: ViewType) => {
    switch (viewType) {
      case "chat":
        return <ChatPanel agentTitle="Creative Writer" onClose={() => window.history.back()} />;
      case "code":
        return <CodeView code={codeData.code} language={codeData.language} />;
      case "image":
        return <ImageView images={imageData.images} />;
      case "canvas":
        return <CanvasView canvasData={canvasData.canvasData} />;
      case "file":
        return <FileView files={fileData.files} />;
      default:
        return <ChatPanel agentTitle="Creative Writer" onClose={() => window.history.back()} />;
    }
  };
  
  // Render the active view content
  const renderActiveView = () => {
    if (activeView === "dual" && activeDualView) {
      return (
        <div className="grid grid-cols-2 gap-4 h-full">
          <div className="h-full">{renderView(activeDualView.views[0])}</div>
          <div className="h-full">{renderView(activeDualView.views[1])}</div>
        </div>
      );
    } else {
      return renderView(activeView);
    }
  };
  
  return (
    <div className="flex h-screen bg-background">
      {/* Collapsible Sidebar with Overlay */}
      <div className="relative z-30">
        {/* Backdrop */}
        {isSidebarOpen && <div className="fixed inset-0 bg-black/50 backdrop-blur-sm transition-opacity" onClick={() => setIsSidebarOpen(false)} />}
        
        {/* Sidebar, SpaceLeftSidebar, and AgentSessions Container */}
        <div className={`fixed inset-y-0 left-0 flex transform transition-transform duration-300 ease-in-out 
            ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="relative h-full">
            <Button variant="ghost" size="icon" className="absolute top-4 right-4 z-50" onClick={() => setIsSidebarOpen(false)}>
              <X className="w-5 h-5" />
            </Button>
            <Sidebar />
          </div>
          
          {/* Space Left Sidebar - conditionally shown if spaceId is available */}
          <div className="h-full ml-5">
            <SpaceLeftSidebar className="h-full" />
          </div>
          
          {/* Agent Sessions */}
          <div className="h-full ml-5">
            <AgentSessions agentId={agentId} className="h-full" />
          </div>
        </div>
      </div>
      
      <div className="flex-1 flex flex-col w-full">
        <div className="absolute top-4 left-4 z-20 flex flex-col gap-2">
          <Button variant="ghost" size="icon" onClick={() => setIsSidebarOpen(!isSidebarOpen)}>
            <Menu className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setIsSettingsOpen(true)}>
            <Settings className="w-5 h-5" />
          </Button>
        </div>
        
        <main className="flex-1 overflow-hidden relative">
          {/* Circular gradient background */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-[800px] h-[800px] rounded-full bg-gradient-to-r from-primary/10 via-primary/5 to-transparent opacity-50 blur-3xl" />
          </div>

          <div className="h-full p-4 flex items-center">
            {/* Main content area - displays the active view */}
            <div className="flex-1 flex flex-col max-w-3xl mx-auto">
              {renderActiveView()}
            </div>
            
            {/* View tabs fixed at the center right */}
            <div className="fixed right-6 top-1/2 transform -translate-y-1/2 z-10">
              <ViewTabs 
                activeView={activeView} 
                onChange={setActiveView}
                onDualSelect={handleDualViewSelect}
              />
            </div>
          </div>
        </main>
      </div>

      <ChatSettingsDialog 
        open={isSettingsOpen} 
        onOpenChange={setIsSettingsOpen}
        onPersonaSelect={handlePersonaSelect}
        selectedPersona={selectedPersona}
      />
    </div>
  );
};

export default ChatRoom;
