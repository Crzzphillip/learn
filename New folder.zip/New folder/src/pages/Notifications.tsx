
import { useEffect, useState } from "react";
import Sidebar from "@/components/Layout/Sidebar";
import { Bell, MessageSquare, Star, AlertCircle, Zap, CreditCard, Settings, Workflow, AppWindow } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Notification, notificationsService } from "@/services/notificationsService";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

const NotificationCard = ({ notification, onRead }: { notification: Notification; onRead: (id: string) => void }) => {
  const navigate = useNavigate();
  
  const icons = {
    message: <MessageSquare className="w-5 h-5 text-blue-400" />,
    alert: <AlertCircle className="w-5 h-5 text-red-400" />,
    credit: <Zap className="w-5 h-5 text-yellow-400" />,
    space: <Star className="w-5 h-5 text-purple-400" />,
    workflow: <Workflow className="w-5 h-5 text-green-400" />,
    app: <AppWindow className="w-5 h-5 text-orange-400" />
  };

  const handleClick = () => {
    // Mark as read when clicked
    if (!notification.read) {
      onRead(notification.id);
    }
    
    // Navigate based on notification type
    switch (notification.type) {
      case "space":
        if (notification.spaceId) {
          navigate(`/space/${notification.spaceId}`);
        }
        break;
      case "credit":
        navigate("/settings");
        break;
      // Add more navigation cases as needed
    }
  };

  const formatTime = (timeString: string) => {
    const now = new Date();
    const time = new Date(timeString);
    const diffInSeconds = Math.floor((now.getTime() - time.getTime()) / 1000);
    
    if (diffInSeconds < 60) return `${diffInSeconds} seconds ago`;
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)} days ago`;
    
    return time.toLocaleDateString();
  };

  return (
    <div 
      className={`glass-panel rounded-xl p-4 flex items-start gap-4 cursor-pointer hover:bg-secondary/5 transition-colors ${!notification.read ? 'border-l-4 border-primary' : ''}`}
      onClick={handleClick}
    >
      <div className="w-10 h-10 rounded-lg bg-secondary/50 grid place-items-center">
        {icons[notification.type]}
      </div>
      <div className="flex-1">
        <h3 className="font-medium mb-1">{notification.title}</h3>
        <p className="text-sm text-muted-foreground">{notification.message}</p>
        {notification.spaceName && (
          <span className="inline-block px-2 py-0.5 bg-secondary/30 rounded text-xs mt-2">
            {notification.spaceName}
          </span>
        )}
        {notification.creditAmount && (
          <div className="flex items-center gap-1 mt-2 text-primary">
            <Zap className="w-3.5 h-3.5" />
            <span className="text-sm font-medium">{notification.creditAmount} credits</span>
          </div>
        )}
        <span className="text-xs text-muted-foreground mt-2 block">{formatTime(notification.time)}</span>
      </div>
      {!notification.read && (
        <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0 mt-2"></div>
      )}
    </div>
  );
};

const Notifications = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        setLoading(true);
        const data = await notificationsService.getAllNotifications();
        setNotifications(data);
      } catch (error) {
        console.error("Error fetching notifications:", error);
        toast.error("Failed to load notifications");
      } finally {
        setLoading(false);
      }
    };

    fetchNotifications();
  }, []);

  const handleMarkAsRead = async (id: string) => {
    try {
      const updated = await notificationsService.markAsRead(id);
      if (updated) {
        setNotifications(prevNotifications => 
          prevNotifications.map(notification => 
            notification.id === id ? { ...notification, read: true } : notification
          )
        );
      }
    } catch (error) {
      console.error("Error marking notification as read:", error);
    }
  };

  const handleMarkAllAsRead = async () => {
    try {
      const success = await notificationsService.markAllAsRead();
      if (success) {
        setNotifications(prevNotifications => 
          prevNotifications.map(notification => ({ ...notification, read: true }))
        );
        toast.success("All notifications marked as read");
      }
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
      toast.error("Failed to mark all as read");
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-auto">
          <div className="container py-8">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-secondary/50 grid place-items-center">
                  <Bell className="w-6 h-6" />
                </div>
                <div>
                  <h1 className="text-2xl font-semibold">Notifications</h1>
                  <p className="text-muted-foreground">Stay updated with your AI workspace</p>
                </div>
              </div>
              
              {unreadCount > 0 && (
                <Button variant="outline" onClick={handleMarkAllAsRead}>
                  Mark all as read
                </Button>
              )}
            </div>

            {loading ? (
              <div className="space-y-4">
                {[...Array(4)].map((_, index) => (
                  <div key={index} className="glass-panel rounded-xl p-4 animate-pulse">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-gray-300 dark:bg-gray-700"></div>
                      <div className="flex-1">
                        <div className="h-5 bg-gray-300 dark:bg-gray-700 rounded w-1/3 mb-2"></div>
                        <div className="h-4 bg-gray-200 dark:bg-gray-800 rounded w-full mb-2"></div>
                        <div className="h-3 bg-gray-200 dark:bg-gray-800 rounded w-1/4 mt-2"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : notifications.length > 0 ? (
              <div className="space-y-4">
                {notifications.map((notification) => (
                  <NotificationCard 
                    key={notification.id} 
                    notification={notification} 
                    onRead={handleMarkAsRead}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Bell className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">No notifications</h3>
                <p className="text-muted-foreground">
                  You're all caught up! We'll notify you when there's something new.
                </p>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Notifications;
