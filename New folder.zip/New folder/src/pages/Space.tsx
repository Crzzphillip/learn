
import { useParams, useNavigate, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import SpaceLayout from "@/components/Space/SpaceLayout";
import SpaceContentGrid from "@/components/Space/SpaceContentGrid";
import SpaceContent from "@/components/Space/SpaceContent";
import AnalyticsScrollable from "@/components/Space/AnalyticsScrollable";
import TrendingWorkspacesSection from "@/components/Space/TrendingWorkspacesSection";
import LoadingState from "@/components/Space/LoadingState";
import BenchmarkSection from "@/components/Space/BenchmarkSection";
import useSpaceData from "@/hooks/useSpaceData";
import { leonardoWorkflowService } from "@/services/leonardoWorkflowService";
import { Workflow } from "@/types/explore";

const Space = () => {
  const { spaceId } = useParams();
  const navigate = useNavigate();
  const [leonardoWorkflows, setLeonardoWorkflows] = useState<Workflow[]>([]);
  const [leonardoFeaturedWorkflows, setLeonardoFeaturedWorkflows] = useState<Workflow[]>([]);
  
  // Handle undefined spaceId by redirecting to default space
  useEffect(() => {
    if (spaceId === 'undefined' || !spaceId) {
      console.warn("Redirecting from invalid spaceId:", spaceId);
      navigate('/space/development', { replace: true });
    }
  }, [spaceId, navigate]);
  
  // If spaceId is undefined or "undefined", redirect to the default space
  if (spaceId === 'undefined' || !spaceId) {
    return <Navigate to="/space/development" replace />;
  }
  
  // Load Leonardo.ai workflows if we're in the leonardo space
  useEffect(() => {
    const loadLeonardoData = async () => {
      if (spaceId === 'leonardo') {
        try {
          const workflows = await leonardoWorkflowService.getLeonardoWorkflows();
          setLeonardoWorkflows(workflows);
          
          const featuredWorkflows = await leonardoWorkflowService.getFeaturedLeonardoWorkflows();
          setLeonardoFeaturedWorkflows(featuredWorkflows);
        } catch (error) {
          console.error("Error loading Leonardo.ai data:", error);
          toast.error("Failed to load Leonardo.ai content");
        }
      }
    };
    
    loadLeonardoData();
  }, [spaceId]);
  
  const {
    isLoading,
    selectedSpaceId,
    setSelectedSpaceId,
    reviewItems,
    spaceTemplate,
    stats,
    trendData,
    selectedSpace,
    filteredAgents,
    filteredWorkflows,
    filteredApps,
    filteredTools,
    filteredResources,
    filteredEnhancedWorkflows,
    filteredFeaturedWorkflows,
    trendingWorkspaces,
    handleApproveContent,
    handleRejectContent
  } = useSpaceData(spaceId);

  const handleSpaceSelect = (selectedId: string) => {
    setSelectedSpaceId(selectedId);
    toast.success(`Navigating to space: ${selectedId}`);
    
    if (selectedId !== spaceId) {
      navigate(`/space/${selectedId}`, { replace: true });
    }
  };

  // Determine which workflows to use based on the space
  const workflowsToUse = spaceId === 'leonardo' ? leonardoWorkflows : filteredWorkflows;
  const featuredWorkflowsToUse = spaceId === 'leonardo' ? leonardoFeaturedWorkflows : filteredFeaturedWorkflows;

  return (
    <SpaceLayout 
      stats={stats} 
      template={spaceTemplate} 
      trendData={trendData}
    >
      <div className="container">
        <SpaceContentGrid
          spaceId={selectedSpaceId}
          spaceTitle={selectedSpace?.title || "Space"}
          spaceType={spaceTemplate.type}
          spaceGradient={spaceTemplate.gradient}
          primaryColor={spaceTemplate.primaryColor}
          accentColor={spaceTemplate.accentColor}
        >
          {isLoading ? (
            <LoadingState />
          ) : (
            <>
              {/* Space Analytics Section - Horizontal Scrollable */}
              <AnalyticsScrollable 
                stats={stats}
                primaryColor={spaceTemplate.primaryColor}
              />

              {/* Benchmarks Section */}
              <BenchmarkSection 
                spaceId={selectedSpaceId} 
                primaryColor={spaceTemplate.primaryColor}
              />

              {/* Trending Workspaces Section */}
              <TrendingWorkspacesSection
                workspaces={trendingWorkspaces}
                spaceId={selectedSpaceId}
              />

              {/* Original Space Content */}
              <SpaceContent
                spaceTemplate={spaceTemplate}
                featuredWorkflows={featuredWorkflowsToUse || []}
                reviewItems={reviewItems || []}
                tools={filteredTools || []}
                agents={filteredAgents || []}
                workflows={workflowsToUse || []}
                enhancedWorkflows={filteredEnhancedWorkflows || []}
                apps={filteredApps || []}
                resources={filteredResources || []}
                onApproveContent={handleApproveContent}
                onRejectContent={handleRejectContent}
              />
            </>
          )}
        </SpaceContentGrid>
      </div>
    </SpaceLayout>
  );
};

export default Space;
