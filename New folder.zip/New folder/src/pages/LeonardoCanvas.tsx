
import { useParams, useNavigate } from "react-router-dom";
import { useState, useEffect, useRef } from "react";
import { ArrowLeft, Menu, Settings, X, Minus, Square, Maximize2, ChevronDown, Search, 
  Image, Layers, ArrowUpDown, Save, Download, History, Undo, Redo, 
  Palette, Sparkles, Upload, FileImage, PaintBucket } from "lucide-react";
import Sidebar from "@/components/Layout/Sidebar";
import SpaceLeftSidebar from "@/components/Space/SpaceLeftSidebar";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import SpaceLayout from "@/components/Space/SpaceLayout";
import { getLeonardoAiTemplate } from "@/components/Leonardo/LeonardoTemplate";
import { toast } from "sonner";
import { leonardoCanvasService } from "@/services/leonardoCanvasService";

// Sample data for the Leonardo canvas with proper SpaceStat format
const dummyStats = [
  { icon: FileImage, label: "Canvas Sessions", value: "142" },
  { icon: Image, label: "Generated Images", value: "3,654" },
  { icon: PaintBucket, label: "Edits Made", value: "8,921" }
];

const LeonardoCanvas = () => {
  const { canvasId } = useParams();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [windowWidth, setWindowWidth] = useState("900px");
  const [activeTool, setActiveTool] = useState<string>("draw");
  const resizeRef = useRef<HTMLDivElement>(null);
  const initialX = useRef<number>(0);
  const initialWidth = useRef<number>(0);
  const [brushSize, setBrushSize] = useState<number>(30);
  const [creativity, setCreativity] = useState<number>(0.75);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [canvasContext, setCanvasContext] = useState<CanvasRenderingContext2D | null>(null);
  const [canvasMode, setCanvasMode] = useState<"draw" | "inpaint">("draw");
  const [images, setImages] = useState({
    input: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Input+Image",
    output: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Output+Image"
  });

  // Initialize canvas
  useEffect(() => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');
    
    if (context) {
      context.strokeStyle = '#0099ff';
      context.lineJoin = 'round';
      context.lineCap = 'round';
      context.lineWidth = brushSize;
      setCanvasContext(context);
    }
  }, [canvasRef, brushSize]);

  // Handle resize functionality
  const handleResize = (e: MouseEvent) => {
    if (!resizeRef.current) return;
    
    const newWidth = initialWidth.current + (e.clientX - initialX.current);
    
    const minWidth = 300;
    const maxWidth = Math.min(window.innerWidth * 0.8, 1200);

    if (newWidth >= minWidth && newWidth <= maxWidth) {
      setWindowWidth(`${newWidth}px`);
    }
  };

  const startResize = (e: React.MouseEvent) => {
    initialX.current = e.clientX;
    if (resizeRef.current) {
      initialWidth.current = resizeRef.current.getBoundingClientRect().width;
    }
    
    document.addEventListener('mousemove', handleResize);
    document.addEventListener('mouseup', stopResize);
  };

  const stopResize = () => {
    document.removeEventListener('mousemove', handleResize);
    document.removeEventListener('mouseup', stopResize);
  };

  // Canvas drawing methods
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasContext || !canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    canvasContext.beginPath();
    canvasContext.moveTo(x, y);
    setIsDrawing(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !canvasContext || !canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    canvasContext.lineTo(x, y);
    canvasContext.stroke();
  };

  const endDrawing = () => {
    if (canvasContext) {
      canvasContext.closePath();
    }
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    if (canvasContext && canvasRef.current) {
      canvasContext.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
      toast.success("Canvas cleared");
    }
  };

  const generateImage = () => {
    toast.success("Processing image...", {
      description: "Your image is being generated with Leonardo AI"
    });
    
    // Simulate image generation process
    setTimeout(() => {
      toast.success("Image generated successfully!");
    }, 2000);
  };

  return (
    <SpaceLayout 
      stats={dummyStats} 
      template={getLeonardoAiTemplate()} 
      fullWidth={true}
    >
      <div className="flex h-full bg-background">
        <div className="relative z-30">
          {/* Backdrop */}
          {isSidebarOpen && (
            <div 
              className="fixed inset-0 bg-black/50 backdrop-blur-sm transition-opacity" 
              onClick={() => setIsSidebarOpen(false)} 
            />
          )}
          
          {/* Sidebar Container */}
          <div className={`fixed inset-y-0 left-0 flex transform transition-transform duration-300 ease-in-out 
              ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
            <div className="relative h-full">
              <Button variant="ghost" size="icon" className="absolute top-4 right-4 z-50" onClick={() => setIsSidebarOpen(false)}>
                <X className="w-5 h-5" />
              </Button>
              <Sidebar />
            </div>
            
            <div className="h-full ml-5">
              <SpaceLeftSidebar className="h-full" />
            </div>
          </div>
        </div>
        
        {/* Main Content */}
        <div className="flex-1 flex flex-col">
          {/* Top Header */}
          <div className="bg-black h-12 border-b border-white/10 flex items-center justify-between px-4">
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-white gap-1" 
                onClick={() => navigate('/space/leonardo')}
              >
                <ArrowLeft className="w-4 h-4" />
                Exit the editor
              </Button>
            </div>
            <div className="text-purple-400 text-lg font-medium">Leonardo.AI Realtime Canvas</div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="bg-purple-600/20 border-purple-500/30 text-purple-300">
                <Sparkles className="w-4 h-4 mr-1" />
                Instant Refine
              </Button>
              <Button variant="outline" size="sm" className="bg-purple-600/20 border-purple-500/30 text-purple-300">
                <ArrowUpDown className="w-4 h-4 mr-1" />
                Upscale Image
              </Button>
              <Button variant="ghost" size="icon" className="text-white">
                <Settings className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-white">
                <Download className="w-5 h-5" />
              </Button>
            </div>
          </div>
          
          {/* Toggle buttons for Draw/Inpaint */}
          <div className="bg-black p-4 flex justify-center">
            <div className="inline-flex bg-gray-900/50 rounded-lg border border-white/10 p-1">
              <Button 
                variant={canvasMode === "draw" ? "default" : "ghost"}
                size="sm"
                className={cn(
                  "rounded-md",
                  canvasMode === "draw" 
                    ? "bg-gradient-to-r from-purple-600 to-blue-500 text-white" 
                    : "text-white hover:text-white hover:bg-white/10"
                )}
                onClick={() => setCanvasMode("draw")}
              >
                <Palette className="w-4 h-4 mr-2" />
                Draw
              </Button>
              <Button 
                variant={canvasMode === "inpaint" ? "default" : "ghost"}
                size="sm"
                className={cn(
                  "rounded-md",
                  canvasMode === "inpaint" 
                    ? "bg-gradient-to-r from-purple-600 to-blue-500 text-white" 
                    : "text-white hover:text-white hover:bg-white/10"
                )}
                onClick={() => setCanvasMode("inpaint")}
              >
                <Image className="w-4 h-4 mr-2" />
                Inpaint
              </Button>
            </div>
          </div>
          
          <div className="flex-1 flex bg-black">
            {/* Left Toolbar */}
            <div className="w-12 bg-gray-900/50 border-r border-white/10 flex flex-col items-center py-2 gap-2">
              <Button 
                variant="ghost" 
                size="icon" 
                className={cn("text-white hover:bg-white/10", 
                  activeTool === "image" && "bg-white/20")}
                onClick={() => setActiveTool("image")}
              >
                <Image className="w-5 h-5" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className={cn("text-white hover:bg-white/10", 
                  activeTool === "layers" && "bg-white/20")}
                onClick={() => setActiveTool("layers")}
              >
                <Layers className="w-5 h-5" />
              </Button>
              <div className="mt-4 border-t border-white/10 pt-4 flex flex-col gap-2">
                <div className="w-8 h-8 rounded-full bg-blue-500 cursor-pointer" 
                  onClick={() => {
                    if (canvasContext) {
                      canvasContext.strokeStyle = '#0099ff';
                    }
                  }}
                />
                <div className="w-8 h-8 rounded-full bg-green-500 cursor-pointer"
                  onClick={() => {
                    if (canvasContext) {
                      canvasContext.strokeStyle = '#00cc44';
                    }
                  }}
                />
                <div className="w-8 h-8 rounded-full bg-red-500 cursor-pointer"
                  onClick={() => {
                    if (canvasContext) {
                      canvasContext.strokeStyle = '#ff3333';
                    }
                  }}
                />
                <div className="w-8 h-8 rounded-full bg-yellow-500 cursor-pointer"
                  onClick={() => {
                    if (canvasContext) {
                      canvasContext.strokeStyle = '#ffcc00';
                    }
                  }}
                />
                <div className="w-8 h-8 rounded-full bg-purple-500 cursor-pointer"
                  onClick={() => {
                    if (canvasContext) {
                      canvasContext.strokeStyle = '#9933ff';
                    }
                  }}
                />
                <div className="w-8 h-8 rounded-full bg-white cursor-pointer"
                  onClick={() => {
                    if (canvasContext) {
                      canvasContext.strokeStyle = '#ffffff';
                    }
                  }}
                />
              </div>
              
              {/* Slider for brush size */}
              <div className="mt-4 h-40 flex flex-col items-center">
                <div className="text-white text-xs mb-2">{brushSize}</div>
                <Slider 
                  orientation="vertical"
                  value={[brushSize]}
                  min={1}
                  max={100}
                  step={1}
                  className="h-32"
                  onValueChange={(value) => {
                    setBrushSize(value[0]);
                    if (canvasContext) {
                      canvasContext.lineWidth = value[0];
                    }
                  }}
                />
              </div>
              
              <div className="mt-auto">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-red-500 hover:bg-red-500/10 hover:text-red-400"
                  onClick={clearCanvas}
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>
            </div>
            
            {/* Main Canvas Area */}
            <div className="flex-1 flex">
              <div className="flex-1 flex flex-col bg-black p-4">
                <div className="flex-1 flex justify-center items-center">
                  <div className="border border-red-500/50 relative">
                    <canvas 
                      ref={canvasRef}
                      width={600}
                      height={400}
                      className="bg-black border border-white/20"
                      onMouseDown={startDrawing}
                      onMouseMove={draw}
                      onMouseUp={endDrawing}
                      onMouseLeave={endDrawing}
                    />
                  </div>
                </div>
                
                {/* Prompt input area */}
                <div className="flex items-center gap-2 mt-4">
                  <div className="w-8 h-8 grid place-items-center bg-gray-800 rounded-md">
                    <Layers className="w-4 h-4 text-gray-400" />
                  </div>
                  <div className="flex-1 relative">
                    <Input 
                      className="w-full bg-gray-900/50 border-white/10 rounded-md text-white placeholder:text-gray-500 py-6"
                      placeholder="Type a prompt..."
                    />
                  </div>
                  <Button 
                    className="bg-gradient-to-r from-pink-500 to-purple-600 text-white flex items-center gap-1"
                    onClick={generateImage}
                  >
                    Interactive
                    <ChevronDown className="w-4 h-4" />
                  </Button>
                </div>
                
                {/* Creativity Strength */}
                <div className="flex items-center gap-4 mt-4">
                  <div className="text-white text-sm min-w-24">Creativity Strength</div>
                  <Slider 
                    value={[creativity]}
                    min={0}
                    max={1}
                    step={0.01}
                    className="flex-1"
                    onValueChange={(value) => setCreativity(value[0])}
                  />
                  <div className="text-white text-sm min-w-12">{creativity.toFixed(2)}</div>
                </div>
              </div>
              
              {/* Right Panel - Output Image */}
              <div className="w-80 bg-gray-900/30 border-l border-white/10 p-4 flex flex-col">
                <div className="text-white/70 text-sm font-medium mb-2">Output to Input</div>
                <div className="flex-1 flex items-center justify-center">
                  <img 
                    src={images.output} 
                    alt="Output Preview" 
                    className="max-w-full max-h-full border border-white/10 object-contain"
                  />
                </div>
                <div className="mt-4 flex gap-2">
                  <Button variant="outline" size="sm" className="text-white border-white/20 bg-white/5 flex-1">
                    <Undo className="w-4 h-4 mr-1" />
                    Revert
                  </Button>
                  <Button variant="outline" size="sm" className="text-white border-white/20 bg-white/5 flex-1">
                    <Redo className="w-4 h-4 mr-1" />
                    Apply
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </SpaceLayout>
  );
};

export default LeonardoCanvas;
