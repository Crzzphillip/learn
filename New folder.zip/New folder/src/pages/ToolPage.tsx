
import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { spaceTemplates } from "@/config/spaceTemplates";
import SpaceLayout from "@/components/Space/SpaceLayout";
import BackToSpace from "@/components/Space/BackToSpace";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { getSpaceStats } from "@/data/spaceData";
import { Button } from "@/components/ui/button";
import { 
  Maximize2,
  Save,
  Share,
  Download,
  ChevronLeft
} from "lucide-react";
import { toast } from "sonner";
import { toolsService } from "@/services/toolsService";

const ToolPage = () => {
  const { spaceId = 'development', toolId } = useParams();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  
  const spaceTemplate = spaceTemplates[spaceId] || spaceTemplates.development;
  const stats = getSpaceStats();
  
  // Get the tool based on spaceId and toolId
  const tool = toolId ? toolsService.getToolById(spaceId, toolId) : null;
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    
    return () => clearTimeout(timer);
  }, []);
  
  if (!tool) {
    return (
      <SpaceLayout 
        stats={stats} 
        template={spaceTemplate}
      >
        <div className="container py-8">
          <BackToSpace spaceId={spaceId} />
          <Card className="mt-8 p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Tool Not Found</h2>
            <p className="mb-6">The tool you're looking for doesn't exist or is not available in this space.</p>
            <Button onClick={() => navigate(`/space/${spaceId}/tools`)}>
              Browse Available Tools
            </Button>
          </Card>
        </div>
      </SpaceLayout>
    );
  }
  
  const renderToolContent = () => {
    if (isLoading) {
      return (
        <div className="flex items-center justify-center h-[400px]">
          <div className="relative w-20 h-20">
            <div className="absolute top-0 left-0 w-full h-full border-4 border-t-primary border-r-transparent border-b-transparent border-l-transparent rounded-full animate-spin"></div>
            <div className="absolute top-2 left-2 w-16 h-16 border-4 border-t-transparent border-r-primary border-b-transparent border-l-transparent rounded-full animate-spin animation-delay-150"></div>
            <div className="absolute top-4 left-4 w-12 h-12 border-4 border-t-transparent border-r-transparent border-b-primary border-l-transparent rounded-full animate-spin animation-delay-300"></div>
          </div>
        </div>
      );
    }
    
    // Render different tool interfaces based on tool title
    if (tool.title === "Image Creation" || tool.title === "Realtime Generation") {
      return (
        <div className="rounded-lg overflow-hidden border border-white/10 bg-black/40 h-[500px] flex flex-col">
          <div className="bg-black/70 p-3 flex justify-between items-center border-b border-white/10">
            <div className="flex items-center space-x-2">
              <Button size="sm" variant="ghost" className="flex items-center gap-1">
                <tool.icon className="h-4 w-4" />
                <span className="text-xs">{tool.title}</span>
              </Button>
            </div>
            <div className="text-sm opacity-70">New Generation</div>
            <div>
              <Button size="sm" variant="ghost">
                <Maximize2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          <div className="flex-1 flex flex-col p-6 bg-gradient-to-br from-black/50 to-black/30">
            <div className="mb-6">
              <label className="block text-sm font-medium mb-2">Prompt</label>
              <textarea 
                className="w-full p-3 rounded-lg bg-black/40 border border-white/10 text-sm h-20"
                placeholder="Describe the image you want to create..."
              ></textarea>
            </div>
            
            <div className="mb-6">
              <label className="block text-sm font-medium mb-2">Negative Prompt (Optional)</label>
              <textarea 
                className="w-full p-3 rounded-lg bg-black/40 border border-white/10 text-sm h-12"
                placeholder="Elements to avoid in the generation..."
              ></textarea>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium mb-2">Model</label>
                <select className="w-full p-2 rounded-lg bg-black/40 border border-white/10 text-sm">
                  <option>Leonardo Diffusion XL</option>
                  <option>Leonardo Vision XL</option>
                  <option>Leonardo Kino XL</option>
                  <option>PhotoReal</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Resolution</label>
                <select className="w-full p-2 rounded-lg bg-black/40 border border-white/10 text-sm">
                  <option>1024 x 1024</option>
                  <option>768 x 1024</option>
                  <option>1024 x 768</option>
                  <option>512 x 512</option>
                </select>
              </div>
            </div>
            
            <div className="mt-auto">
              <Button 
                className="w-full bg-purple-600 hover:bg-purple-700"
                onClick={() => toast.success("Image generation started")}
              >
                Generate
              </Button>
            </div>
          </div>
        </div>
      );
    }
    
    if (tool.title === "Canvas Editor" || tool.title === "Realtime Canvas") {
      return (
        <div className="rounded-lg overflow-hidden border border-white/10 bg-black/40 h-[500px] flex flex-col">
          <div className="bg-black/70 p-3 flex justify-between items-center border-b border-white/10">
            <div className="flex items-center space-x-2">
              <Button size="sm" variant="ghost" className="flex items-center gap-1">
                <tool.icon className="h-4 w-4" />
                <span className="text-xs">{tool.title}</span>
              </Button>
              <Button size="sm" variant="ghost" className="flex items-center gap-1">
                <Download className="h-4 w-4" />
                <span className="text-xs">Import</span>
              </Button>
            </div>
            <div className="text-sm opacity-70">Canvas Project</div>
            <div>
              <Button size="sm" variant="ghost">
                <Maximize2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          <div className="flex-1 flex items-center justify-center bg-gradient-to-br from-black/50 to-black/30 p-8">
            <div className="text-center">
              <tool.icon className="h-16 w-16 mx-auto mb-4 opacity-40" />
              <h3 className="text-lg font-medium mb-2">Create a New Canvas</h3>
              <p className="text-sm opacity-70 mb-4">Start with a blank canvas or import an image</p>
              <div className="flex justify-center gap-2">
                <Button
                  onClick={() => toast.success("New canvas created")}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  New Canvas
                </Button>
                <Button variant="outline">
                  Import Image
                </Button>
              </div>
            </div>
          </div>
        </div>
      );
    }
    
    if (tool.title === "Training & Datasets" || tool.title === "Finetuned Models") {
      return (
        <div className="rounded-lg overflow-hidden border border-white/10 bg-black/40 h-[500px] flex flex-col">
          <div className="bg-black/70 p-3 flex justify-between items-center border-b border-white/10">
            <div className="flex items-center space-x-2">
              <Button size="sm" variant="ghost" className="flex items-center gap-1">
                <tool.icon className="h-4 w-4" />
                <span className="text-xs">{tool.title}</span>
              </Button>
            </div>
            <div className="text-sm opacity-70">Advanced Training</div>
            <div>
              <Button size="sm" variant="ghost">
                <Maximize2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          <div className="flex-1 flex items-center justify-center bg-gradient-to-br from-black/50 to-black/30 p-8">
            <div className="w-full max-w-md text-center">
              <tool.icon className="h-16 w-16 mx-auto mb-4 opacity-40" />
              <h3 className="text-lg font-medium mb-2">Create Custom AI Model</h3>
              <p className="text-sm opacity-70 mb-4">Upload your images to train a personalized AI model</p>
              
              <div className="mb-6 p-8 border border-dashed border-white/20 rounded-lg bg-black/20">
                <p className="text-sm mb-2">Drag and drop images here</p>
                <p className="text-xs opacity-70">Minimum 10-15 images recommended for best results</p>
              </div>
              
              <Button
                className="w-full bg-purple-600 hover:bg-purple-700"
                onClick={() => toast.success("Model training started")}
              >
                Start Training
              </Button>
            </div>
          </div>
        </div>
      );
    }
    
    // Default view for other tools
    return (
      <div className="rounded-lg overflow-hidden border border-white/10 bg-black/40 h-[400px] flex items-center justify-center">
        <div className="text-center p-8">
          <tool.icon className="h-16 w-16 mx-auto mb-4 opacity-40" />
          <h3 className="text-xl font-medium mb-2">{tool.title}</h3>
          <p className="text-sm opacity-70 mb-6">{tool.description}</p>
          <Button 
            onClick={() => toast.success(`${tool.title} launching...`)}
            className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
          >
            Launch Tool
          </Button>
        </div>
      </div>
    );
  };
  
  return (
    <SpaceLayout 
      stats={stats} 
      template={spaceTemplate}
    >
      <div className="container py-8">
        <BackToSpace spaceId={spaceId} />
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-lg flex items-center justify-center"
              style={{ backgroundColor: `${tool.themeColor || spaceTemplate.primaryColor}20` }}
            >
              <tool.icon className="h-6 w-6" style={{ color: tool.themeColor || spaceTemplate.primaryColor }} />
            </div>
            <div>
              <h1 className="text-2xl font-bold">{tool.title}</h1>
              <p className="text-sm text-muted-foreground">{tool.description}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button 
              size="sm" 
              variant="outline"
              className="flex items-center gap-1"
              onClick={() => toast.success("Settings opened")}
            >
              <Download className="h-4 w-4" />
              <span>Export</span>
            </Button>
            <Button 
              size="sm" 
              variant="outline"
              className="flex items-center gap-1"
              onClick={() => toast.success("Sharing options opened")}
            >
              <Share className="h-4 w-4" />
              <span>Share</span>
            </Button>
            <Button 
              size="sm"
              className="flex items-center gap-1 bg-primary/80"
              onClick={() => toast.success("Progress saved")}
            >
              <Save className="h-4 w-4" />
              <span>Save</span>
            </Button>
          </div>
        </div>
        
        {renderToolContent()}
      </div>
    </SpaceLayout>
  );
};

export default ToolPage;
