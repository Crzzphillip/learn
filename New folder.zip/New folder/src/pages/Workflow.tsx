import { useParams, useNavigate } from "react-router-dom";
import Sidebar from "@/components/Layout/Sidebar";
import { Button } from "@/components/ui/button";
import { PlayCircle, Workflow as WorkflowIcon, Zap } from "lucide-react";
import BackToSpace from "@/components/Space/BackToSpace";

const Workflow = () => {
  const { spaceId, workflowId } = useParams();
  const navigate = useNavigate();

  // Dummy data for demonstration
  const workflow = {
    title: "Content Creation Suite",
    description: "End-to-end workflow for creating engaging content.",
    credits: "25",
    agents: [
      { name: "Creative Writer", persona: "Storyteller" },
      { name: "Image Generator", persona: "Artist" },
    ],
    steps: [
      "Generate content ideas with Creative Writer",
      "Create first draft of the content",
      "Generate supporting images with Image Generator",
      "Review and finalize content",
    ],
  };

  const handleStartWorkflow = () => {
    navigate(`/workflow/${workflowId}/run`);
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-auto">
          <div className="container py-8">
            <BackToSpace spaceId={spaceId || ""} />

            <div className="glass-panel rounded-xl p-8 mb-8">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h1 className="text-3xl font-semibold tracking-tight mb-2">{workflow.title}</h1>
                  <p className="text-muted-foreground">{workflow.description}</p>
                </div>
                <Button variant="default" className="gap-2" onClick={handleStartWorkflow}>
                  <PlayCircle className="w-4 h-4" />
                  Start Workflow
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-6 mb-8">
                <div className="glass-panel rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <WorkflowIcon className="w-4 h-4" />
                    <span className="font-semibold">{workflow.agents.length}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">Agents Involved</p>
                </div>
                <div className="glass-panel rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Zap className="w-4 h-4" />
                    <span className="font-semibold">{workflow.credits}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">Credits per run</p>
                </div>
              </div>

              <div className="mb-8">
                <h2 className="text-xl font-semibold mb-4">Agents & Personas</h2>
                <div className="grid grid-cols-2 gap-4">
                  {workflow.agents.map((agent, index) => (
                    <div key={index} className="glass-panel rounded-xl p-4">
                      <h3 className="font-medium mb-2">{agent.name}</h3>
                      <span className="text-sm px-2.5 py-1 rounded-full bg-primary/10">
                        {agent.persona}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h2 className="text-xl font-semibold mb-4">Workflow Steps</h2>
                <div className="space-y-4">
                  {workflow.steps.map((step, index) => (
                    <div key={index} className="glass-panel rounded-xl p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-6 h-6 rounded-full bg-primary/10 grid place-items-center text-sm font-medium">
                          {index + 1}
                        </div>
                        <p>{step}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Workflow;
