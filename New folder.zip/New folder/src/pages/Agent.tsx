
import { useParams } from "react-router-dom";
import Sidebar from "@/components/Layout/Sidebar";
import { PenTool, BookOpen, Globe, FileSearch } from "lucide-react";
import type { AgentDetails as AgentDetailsType, UseCase } from "@/types/agent";
import AgentHero from "@/components/Agent/AgentHero";
import AgentStats from "@/components/Agent/AgentStats";
import AgentTasks from "@/components/Agent/AgentTasks";
import AgentPersonas from "@/components/Agent/AgentPersonas";
import AgentReviews from "@/components/Agent/AgentReviews";
import AgentUseCases from "@/components/Agent/AgentUseCases";
import AgentBenchmarks from "@/components/Agent/AgentBenchmarks";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";

const Agent = () => {
  const { spaceId, agentId } = useParams();
  const [activeTab, setActiveTab] = useState<string>("overview");

  // Sample use cases data
  const useCases: UseCase[] = [
    {
      id: "usecase-1",
      user: "Sarah Johnson",
      userAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah",
      title: "Streamlined our content creation process",
      description: "We used this agent to help write and edit all our marketing materials. It saved us countless hours of work.",
      industry: "Marketing",
      results: "Reduced content creation time by 40% and improved consistency across all materials.",
      date: "June 12, 2024"
    },
    {
      id: "usecase-2",
      user: "Michael Chen",
      userAvatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Michael",
      title: "Automated our technical documentation",
      description: "This agent helped us document our API and create user guides for our software. The results were impressive.",
      industry: "Software Development",
      results: "Generated comprehensive documentation in half the time it would take manually.",
      date: "May 3, 2024"
    }
  ];

  const agent: AgentDetailsType = {
    title: "Creative Writer",
    description: "AI writing assistant for creative content and storytelling.",
    category: "Writing",
    rating: "4.9",
    credits: "10",
    personas: ["Storyteller", "Poet", "Journalist"],
    reviews: [
      { user: "John Doe", rating: 5, comment: "Amazing writing assistant!" },
      { user: "Jane Smith", rating: 4, comment: "Very helpful for content creation." },
    ],
    useCases: useCases
  };

  const tasks = [
    {
      icon: PenTool,
      title: "Blog Post Creation",
      description: "Generate engaging blog posts with SEO optimization",
      examples: ["How-to guides", "Industry insights", "Product reviews"]
    },
    {
      icon: BookOpen,
      title: "Story Writing",
      description: "Create compelling stories and narratives",
      examples: ["Short stories", "Character development", "Plot outlines"]
    },
    {
      icon: Globe,
      title: "Social Media Content",
      description: "Craft engaging social media posts",
      examples: ["Twitter threads", "LinkedIn articles", "Instagram captions"]
    },
    {
      icon: FileSearch,
      title: "Content Editing",
      description: "Polish and refine your existing content",
      examples: ["Grammar check", "Style improvement", "Tone adjustment"]
    }
  ];

  const handleAddReview = (review: { user: string; rating: number; comment: string }) => {
    agent.reviews.unshift(review);
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-auto">
          <AgentHero agent={agent} spaceId={spaceId || ""} agentId={agentId!} />

          <div className="container py-12">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="mb-8">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="benchmarks">Benchmarks</TabsTrigger>
                <TabsTrigger value="usecases">Use Cases</TabsTrigger>
                <TabsTrigger value="personas">Personas</TabsTrigger>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="space-y-12">
                <AgentStats agent={agent} />
                <AgentTasks tasks={tasks} />
              </TabsContent>
              
              <TabsContent value="benchmarks">
                <AgentBenchmarks agentId={agentId || "agent-1"} />
              </TabsContent>
              
              <TabsContent value="usecases">
                <AgentUseCases useCases={agent.useCases} />
              </TabsContent>
              
              <TabsContent value="personas">
                <AgentPersonas agent={agent} />
              </TabsContent>
              
              <TabsContent value="reviews">
                <AgentReviews agent={agent} onAddReview={handleAddReview} />
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Agent;
