import { useParams, useNavigate } from "react-router-dom";
import { useState, useEffect, useRef } from "react";
import Sidebar from "@/components/Layout/Sidebar";
import SpaceLeftSidebar from "@/components/Space/SpaceLeftSidebar";
import { Menu, Settings, X, Minus, Square, Maximize2, ChevronDown, Menu as MenuIcon, Search, Clock, Server, Shield, Folder, Files, FileText, Image, Code, FileCode, PuzzleIcon, Network } from "lucide-react";
import { Button } from "@/components/ui/button";
import ChatSettingsDialog from "@/components/Agent/ChatSettingsDialog";
import AgentSessions from "@/components/Agent/AgentSessions";
import CodeView from "@/components/Agent/Views/CodeView";
import ImageView from "@/components/Agent/Views/ImageView";
import CanvasView from "@/components/Agent/Views/CanvasView";
import FileView from "@/components/Agent/Views/FileView";
import LangGraphView from "@/components/Agent/Views/LangGraphView";
import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { getWorkspaceById, getWorkspaceType } from "@/services/workspaceService";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { leonardoCanvasService } from "@/services/leonardoCanvasService";
import { SidebarIcons } from '@/components/Workspace/SidebarIcons';
import { WorkspaceDialog } from '@/components/Workspace/WorkspaceDialog';
import { Briefcase } from 'lucide-react';

type SessionType = "code" | "image" | "canvas" | "file" | "langgraph";

interface WorkspaceSession {
  id: string;
  name: string;
  type: SessionType;
  icon: React.ReactNode;
  lastAccessed: Date;
}

const WorkspaceRun = () => {
  const { workspaceId } = useParams();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [selectedPersona, setSelectedPersona] = useState<string | null>(null);
  const [activeSession, setActiveSession] = useState<string | null>(null);
  const [isSessionsOpen, setIsSessionsOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [windowWidth, setWindowWidth] = useState("800px");
  const resizeRef = useRef<HTMLDivElement>(null);
  const initialX = useRef<number>(0);
  const initialWidth = useRef<number>(0);
  const [workspaceType, setWorkspaceType] = useState<'standard' | 'aiforge' | 'canvas'>('standard');
  const [isWorkspaceDialogOpen, setIsWorkspaceDialogOpen] = useState(false);
  
  const [brushSize, setBrushSize] = useState<number>(30);
  const [creativity, setCreativity] = useState<number>(0.75);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [canvasContext, setCanvasContext] = useState<CanvasRenderingContext2D | null>(null);
  const [canvasMode, setCanvasMode] = useState<"draw" | "inpaint">("draw");
  const [activeTool, setActiveTool] = useState<string>("draw");
  const [images, setImages] = useState({
    input: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Input+Image",
    output: "https://placehold.co/600x400/8B5CF6/FFFFFF/png?text=Output+Image"
  });

  const sessions: WorkspaceSession[] = [
    {
      id: "code-session",
      name: "Component Code",
      type: "code",
      icon: <Code className="h-4 w-4" />,
      lastAccessed: new Date(),
    },
    {
      id: "image-session",
      name: "Design Assets",
      type: "image",
      icon: <Image className="h-4 w-4" />,
      lastAccessed: new Date(Date.now() - 3600000), // 1 hour ago
    },
    {
      id: "canvas-session",
      name: "Canvas Diagram",
      type: "canvas",
      icon: <FileCode className="h-4 w-4" />,
      lastAccessed: new Date(Date.now() - 7200000), // 2 hours ago
    },
    {
      id: "file-session",
      name: "Configuration Files",
      type: "file",
      icon: <Files className="h-4 w-4" />,
      lastAccessed: new Date(Date.now() - 86400000), // 1 day ago
    },
    {
      id: "langgraph-session",
      name: "LangGraph Workflow",
      type: "langgraph",
      icon: <Network className="h-4 w-4" />,
      lastAccessed: new Date(),
    },
  ];

  const [codeData, setCodeData] = useState({ 
    code: `import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from './ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './ui/tabs';
import { Badge } from './ui/badge';

const WorkspaceOverview = ({ workspace }) => {
  const [components, setComponents] = useState([]);
  const [activeTab, setActiveTab] = useState('all');
  
  useEffect(() => {
    if (workspace && workspace.components) {
      setComponents(workspace.components);
    }
  }, [workspace]);
  
  const filteredComponents = components.filter(component => {
    if (activeTab === 'all') return true;
    return component.type === activeTab.slice(0, -1);
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Workspace Components</CardTitle>
        <CardDescription>All agents, workflows, apps, and tools in this workspace</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="all">
          <TabsList className="mb-4">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="agents">Agents</TabsTrigger>
            <TabsTrigger value="workflows">Workflows</TabsTrigger>
            <TabsTrigger value="apps">Apps</TabsTrigger>
            <TabsTrigger value="tools">Tools</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="m-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {workspace.components.map((component) => (
                <Card key={component.id} className={\`overflow-hidden bg-muted \${
                  component.type === 'agent'
                    ? 'bg-primary/10'
                    : component.type === 'workflow'
                    ? 'bg-blue-500/10'
                    : component.type === 'app'
                    ? 'bg-green-500/10'
                    : 'bg-amber-500/10'
                }\`}>
                  <div className="p-4">
                    <div className="flex items-start gap-3 mb-2">
                      {getComponentIcon(component.type)}
                      <div>
                        <h3 className="font-medium">{component.name}</h3>
                        <p className="text-sm text-muted-foreground">
                          {component.description}
                        </p>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default WorkspaceOverview;`, 
    language: "tsx" 
  });
  const [imageData, setImageData] = useState({ 
    images: ["https://placehold.co/600x400/png"] 
  });
  const [canvasData, setCanvasData] = useState({ 
    canvasData: "<svg width='100%' height='100%' viewBox='0 0 800 600'><circle cx='400' cy='300' r='150' fill='#6246ea' /></svg>" 
  });
  const [fileData, setFileData] = useState({ 
    files: [
      { name: "workspace.config.json", url: "#", size: "1.2 MB" },
      { name: "aiforge.settings.json", url: "#", size: "842 KB" }
    ] 
  });

  useEffect(() => {
    if (workspaceId) {
      const type = getWorkspaceType(workspaceId);
      setWorkspaceType(type);
      
      if (type === 'canvas' && workspaceId.startsWith('canvas')) {
        const canvasImages = leonardoCanvasService.getCanvasImages(workspaceId);
        setImages(canvasImages);
      }
    }
    
    if (sessions.length > 0 && !activeSession) {
      setActiveSession(sessions[0].id);
    }

    if (workspaceType === 'canvas' && canvasRef.current) {
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      
      if (context) {
        context.strokeStyle = '#0099ff';
        context.lineJoin = 'round';
        context.lineCap = 'round';
        context.lineWidth = brushSize;
        setCanvasContext(context);
      }
    }
  }, [workspaceId, activeSession, sessions, brushSize, workspaceType]);

  const handleResize = (e: MouseEvent) => {
    if (!resizeRef.current) return;
    
    const newWidth = initialWidth.current + (e.clientX - initialX.current);
    
    const minWidth = 300;
    const maxWidth = Math.min(window.innerWidth * 0.8, 1200);

    if (newWidth >= minWidth && newWidth <= maxWidth) {
      setWindowWidth(`${newWidth}px`);
    }
  };

  const startResize = (e: React.MouseEvent) => {
    initialX.current = e.clientX;
    if (resizeRef.current) {
      initialWidth.current = resizeRef.current.getBoundingClientRect().width;
    }
    
    document.addEventListener('mousemove', handleResize);
    document.addEventListener('mouseup', stopResize);
  };

  const stopResize = () => {
    document.removeEventListener('mousemove', handleResize);
    document.removeEventListener('mouseup', stopResize);
  };

  const handlePersonaSelect = (personaId: string) => {
    setSelectedPersona(personaId);
    setIsSettingsOpen(false);
  };

  const getActiveSessionData = () => {
    if (!activeSession) return null;
    return sessions.find(session => session.id === activeSession);
  };
  
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasContext || !canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    canvasContext.beginPath();
    canvasContext.moveTo(x, y);
    setIsDrawing(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !canvasContext || !canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    canvasContext.lineTo(x, y);
    canvasContext.stroke();
  };

  const endDrawing = () => {
    if (canvasContext) {
      canvasContext.closePath();
    }
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    if (canvasContext && canvasRef.current) {
      canvasContext.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
      toast.success("Canvas cleared");
    }
  };

  const generateImage = () => {
    toast.success("Processing image...", {
      description: "Your image is being generated with Leonardo AI"
    });
    
    setTimeout(() => {
      toast.success("Image generated successfully!");
    }, 2000);
  };

  const renderStandardWorkspaceContent = () => {
    const workspace = getWorkspaceById(workspaceId || '');
    
    let title = "Standard Workspace";
    if (workspace) {
      title = workspace.title;
    }
    
    return (
      <div className="flex h-[calc(100%-2.5rem)]">
        <div className="w-52 bg-[#252526]/80 backdrop-blur-md border-r border-[#7e57c2]/20">
          <div className="flex items-center justify-between px-3 py-2 border-b border-[#7e57c2]/20">
            <span className="text-xs font-medium text-gray-400">EXPLORER</span>
            <MenuIcon className="h-3.5 w-3.5 text-gray-500" />
          </div>
          
          <ScrollArea className="h-full">
            <div className="p-2">
              <div className="text-xs text-gray-500 px-2 py-1">{title.toUpperCase()}</div>
              
              <div className="space-y-1 mt-1">
                <div className="flex items-center text-sm text-white px-2 py-1 rounded bg-[#6246ea]/20 cursor-pointer">
                  <Folder className="h-4 w-4 mr-2 text-blue-400" />
                  <span>src</span>
                </div>
                
                <div className="flex items-center text-sm text-gray-300 px-2 py-1 rounded hover:bg-[#37373d]/70 cursor-pointer">
                  <Folder className="h-4 w-4 mr-2 text-yellow-400" />
                  <span>components</span>
                </div>
                
                <div className="flex items-center text-sm text-gray-300 px-2 py-1 rounded hover:bg-[#37373d]/70 cursor-pointer">
                  <Folder className="h-4 w-4 mr-2 text-green-400" />
                  <span>utils</span>
                </div>
                
                <div className="flex items-center text-sm text-gray-300 px-2 py-1 rounded hover:bg-[#37373d]/70 cursor-pointer">
                  <Files className="h-4 w-4 mr-2 text-purple-400" />
                  <span>package.json</span>
                </div>
                
                <div className="flex items-center text-sm text-gray-300 px-2 py-1 rounded hover:bg-[#37373d]/70 cursor-pointer">
                  <FileText className="h-4 w-4 mr-2 text-gray-400" />
                  <span>README.md</span>
                </div>
              </div>
            </div>
          </ScrollArea>
        </div>
        
        <div className="flex-1 flex flex-col bg-[#1e1e1e]/70 backdrop-blur-md overflow-hidden">
          <div className="flex justify-center items-center p-2 bg-[#252526]/70 backdrop-blur-sm border-b border-[#7e57c2]/20">
            <div className="flex items-center gap-1 bg-[#333333]/70 backdrop-blur-sm rounded-full p-1">
              {sessions.map((session) => (
                <Button
                  key={session.id}
                  variant="ghost"
                  size="icon"
                  onClick={() => setActiveSession(session.id)}
                  className={cn(
                    "rounded-full h-8 w-8",
                    activeSession === session.id 
                      ? "bg-[#6246ea]/30 text-white" 
                      : "text-gray-400 hover:text-gray-300 hover:bg-[#3a3a3a]/70"
                  )}
                >
                  {session.icon}
                </Button>
              ))}
            </div>
          </div>
          
          <div className="flex-1 overflow-hidden">
            {renderSessionContent()}
          </div>
          
          <div className="h-6 bg-[#6246ea]/80 backdrop-blur-md flex items-center justify-between px-3 text-xs text-white/80">
            <div className="flex items-center space-x-4">
              <span>{title}</span>
              <span>v1.0.0</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="flex items-center">
                <Clock className="h-3 w-3 mr-1" />
                Sessions: {sessions.length}
              </span>
              <span className="flex items-center">
                <Server className="h-3 w-3 mr-1" />
                Connected
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderAIForgeWorkspaceContent = () => {
    const workspace = getWorkspaceById(workspaceId || '');
    let title = "AIForge Workspace";
    
    if (workspace && workspace.title) {
      title = workspace.title;
    }
    
    return (
      <div className="flex h-[calc(100%-2.5rem)]">
        <div className="w-52 bg-[#1a2030]/80 backdrop-blur-md border-r border-blue-600/20">
          <div className="flex items-center justify-between px-3 py-2 border-b border-blue-600/20">
            <span className="text-xs font-medium text-gray-400">AI FORGE</span>
            <MenuIcon className="h-3.5 w-3.5 text-gray-500" />
          </div>
          
          <ScrollArea className="h-full">
            <div className="p-2">
              <div className="text-xs text-gray-500 px-2 py-1">PROJECT</div>
              
              <div className="space-y-1 mt-1">
                <div className="flex items-center text-sm text-white px-2 py-1 rounded bg-blue-600/20 cursor-pointer">
                  <Folder className="h-4 w-4 mr-2 text-blue-400" />
                  <span>models</span>
                </div>
                
                <div className="flex items-center text-sm text-gray-300 px-2 py-1 rounded hover:bg-[#37373d]/70 cursor-pointer">
                  <Folder className="h-4 w-4 mr-2 text-green-400" />
                  <span>prompts</span>
                </div>
                
                <div className="flex items-center text-sm text-gray-300 px-2 py-1 rounded hover:bg-[#37373d]/70 cursor-pointer">
                  <Folder className="h-4 w-4 mr-2 text-purple-400" />
                  <span>datasets</span>
                </div>
                
                <div className="flex items-center text-sm text-gray-300 px-2 py-1 rounded hover:bg-[#37373d]/70 cursor-pointer">
                  <Folder className="h-4 w-4 mr-2 text-yellow-400" />
                  <span>integrations</span>
                </div>
                
                <div className="flex items-center text-sm text-gray-300 px-2 py-1 rounded hover:bg-[#37373d]/70 cursor-pointer">
                  <Files className="h-4 w-4 mr-2 text-blue-300" />
                  <span>config.json</span>
                </div>
              </div>
              
              <div className="text-xs text-gray-500 px-2 py-1 mt-4">TOOLS</div>
              <div className="space-y-1 mt-1">
                <div className="flex items-center text-sm text-gray-300 px-2 py-1 rounded hover:bg-[#37373d]/70 cursor-pointer">
                  <PuzzleIcon className="h-4 w-4 mr-2 text-blue-400" />
                  <span>Model Training</span>
                </div>
                <div className="flex items-center text-sm text-gray-300 px-2 py-1 rounded hover:bg-[#37373d]/70 cursor-pointer">
                  <Code className="h-4 w-4 mr-2 text-green-400" />
                  <span>Code Generator</span>
                </div>
                <div className="flex items-center text-sm text-gray-300 px-2 py-1 rounded hover:bg-[#37373d]/70 cursor-pointer">
                  <Network className="h-4 w-4 mr-2 text-purple-400" />
                  <span>API Builder</span>
                </div>
              </div>
            </div>
          </ScrollArea>
        </div>
        
        <div className="flex-1 flex flex-col bg-[#131620]/70 backdrop-blur-md overflow-hidden">
          <div className="flex justify-center items-center p-2 bg-[#1a2030]/70 backdrop-blur-sm border-b border-blue-600/20">
            <div className="flex items-center gap-1 bg-[#242b3d]/70 backdrop-blur-sm rounded-full p-1">
              {sessions.map((session) => (
                <Button
                  key={session.id}
                  variant="ghost"
                  size="icon"
                  onClick={() => setActiveSession(session.id)}
                  className={cn(
                    "rounded-full h-8 w-8",
                    activeSession === session.id 
                      ? "bg-blue-600/30 text-white" 
                      : "text-gray-400 hover:text-gray-300 hover:bg-[#303a52]/70"
                  )}
                >
                  {session.icon}
                </Button>
              ))}
            </div>
          </div>
          
          <div className="flex-1 overflow-hidden">
            {renderSessionContent()}
          </div>
          
          <div className="h-6 bg-blue-600/80 backdrop-blur-md flex items-center justify-between px-3 text-xs text-white/80">
            <div className="flex items-center space-x-4">
              <span>AIForge Workspace</span>
              <span>v1.0.0</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="flex items-center">
                <Clock className="h-3 w-3 mr-1" />
                Sessions: {sessions.length}
              </span>
              <span className="flex items-center">
                <Shield className="h-3 w-3 mr-1" />
                AI Secure
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderCanvasWorkspaceContent = () => {
    const workspace = getWorkspaceById(workspaceId || '');
    let title = "Canvas Workspace";
    
    if (workspace && workspace.title) {
      title = workspace.title;
    }
    
    return (
      <div className="flex flex-col h-[calc(100%-2.5rem)]">
        <div className="bg-black p-4 flex justify-center border-b border-white/10">
          <div className="inline-flex bg-gray-900/50 rounded-lg border border-white/10 p-1">
            <Button 
              variant={canvasMode === "draw" ? "default" : "ghost"}
              size="sm"
              className={cn(
                "rounded-md",
                canvasMode === "draw" 
                  ? "bg-gradient-to-r from-purple-600 to-blue-500 text-white" 
                  : "text-white hover:text-white hover:bg-white/10"
              )}
              onClick={() => setCanvasMode("draw")}
            >
              <div className="w-4 h-4 mr-2" />
              Draw
            </Button>
            <Button 
              variant={canvasMode === "inpaint" ? "default" : "ghost"}
              size="sm"
              className={cn(
                "rounded-md",
                canvasMode === "inpaint" 
                  ? "bg-gradient-to-r from-purple-600 to-blue-500 text-white" 
                  : "text-white hover:text-white hover:bg-white/10"
              )}
              onClick={() => setCanvasMode("inpaint")}
            >
              <Image className="w-4 h-4 mr-2" />
              Inpaint
            </Button>
          </div>
        </div>
        
        <div className="flex-1 flex bg-black">
          <div className="w-12 bg-gray-900/50 border-r border-white/10 flex flex-col items-center py-2 gap-2">
            <Button 
              variant="ghost" 
              size="icon" 
              className={cn("text-white hover:bg-white/10", 
                activeTool === "image" && "bg-white/20")}
              onClick={() => setActiveTool("image")}
            >
              <Image className="w-5 h-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className={cn("text-white hover:bg-white/10", 
                activeTool === "layers" && "bg-white/20")}
              onClick={() => setActiveTool("layers")}
            >
              <Files className="w-5 h-5" />
            </Button>
            <div className="mt-4 border-t border-white/10 pt-4 flex flex-col gap-2">
              <div className="w-8 h-8 rounded-full bg-blue-500 cursor-pointer" 
                onClick={() => {
                  if (canvasContext) {
                    canvasContext.strokeStyle = '#0099ff';
                  }
                }}
              />
              <div className="w-8 h-8 rounded-full bg-green-500 cursor-pointer"
                onClick={() => {
                  if (canvasContext) {
                    canvasContext.strokeStyle = '#00cc44';
                  }
                }}
              />
              <div className="w-8 h-8 rounded-full bg-red-500 cursor-pointer"
                onClick={() => {
                  if (canvasContext) {
                    canvasContext.strokeStyle = '#ff3333';
                  }
                }}
              />
              <div className="w-8 h-8 rounded-full bg-yellow-500 cursor-pointer"
                onClick={() => {
                  if (canvasContext) {
                    canvasContext.strokeStyle = '#ffcc00';
                  }
                }}
              />
              <div className="w-8 h-8 rounded-full bg-purple-500 cursor-pointer"
                onClick={() => {
                  if (canvasContext) {
                    canvasContext.strokeStyle = '#9933ff';
                  }
                }}
              />
              <div className="w-8 h-8 rounded-full bg-white cursor-pointer"
                onClick={() => {
                  if (canvasContext) {
                    canvasContext.strokeStyle = '#ffffff';
                  }
                }}
              />
            </div>
            
            <div className="mt-4 h-40 flex flex-col items-center">
              <div className="text-white text-xs mb-2">{brushSize}</div>
              <Slider 
                orientation="vertical"
                value={[brushSize]}
                min={1}
                max={100}
                step={1}
                className="h-32"
                onValueChange={(value) => {
                  setBrushSize(value[0]);
                  if (canvasContext) {
                    canvasContext.lineWidth = value[0];
                  }
                }}
              />
            </div>
            
            <div className="mt-auto">
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-red-500 hover:bg-red-500/10 hover:text-red-400"
                onClick={clearCanvas}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          </div>
          
          <div className="flex-1 flex">
            <div className="flex-1 flex flex-col bg-black p-4">
              <div className="flex-1 flex justify-center items-center">
                <div className="border border-purple-500/50 relative">
                  <canvas 
                    ref={canvasRef}
                    width={600}
                    height={400}
                    className="bg-black border border-white/20"
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={endDrawing}
                    onMouseLeave={endDrawing}
                  />
                </div>
              </div>
              
              <div className="flex items-center gap-2 mt-4">
                <div className="w-8 h-8 grid place-items-center bg-gray-800 rounded-md">
                  <Files className="w-4 h-4 text-gray-400" />
                </div>
                <div className="flex-1 relative">
                  <Input 
                    className="w-full bg-gray-900/50 border-white/10 rounded-md text-white placeholder:text-gray-500 py-6"
                    placeholder="Type a prompt..."
                  />
                </div>
                <Button 
                  className="bg-gradient-to-r from-pink-500 to-purple-600 text-white flex items-center gap-1"
                  onClick={generateImage}
                >
                  {workspace?.canvasType === 'inpainting' ? 'Inpaint' : 
                   workspace?.canvasType === 'generation' ? 'Generate' : 'Draw'}
                  <ChevronDown className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="flex items-center gap-4 mt-4">
                <div className="text-white text-sm min-w-24">Creativity Strength</div>
                <Slider 
                  value={[creativity]}
                  min={0}
                  max={1}
                  step={0.01}
                  className="flex-1"
                  onValueChange={(value) => setCreativity(value[0])}
                />
                <div className="text-white text-sm min-w-12">{creativity.toFixed(2)}</div>
              </div>
            </div>
            
            <div className="w-80 bg-gray-900/30 border-l border-white/10 p-4 flex flex-col">
              <div className="text-white/70 text-sm font-medium mb-2">Output to Input</div>
              <div className="flex-1 flex items-center justify-center">
                <img 
                  src={images.output} 
                  alt="Output Preview" 
                  className="max-w-full max-h-full border border-white/10 object-contain"
                />
              </div>
              <div className="mt-4 flex gap-2">
                <Button variant="outline" size="sm" className="text-white border-white/20 bg-white/5 flex-1">
                  <X className="w-4 h-4 mr-1" />
                  Revert
                </Button>
                <Button variant="outline" size="sm" className="text-white border-white/20 bg-white/5 flex-1">
                  <Files className="w-4 h-4 mr-1" />
                  Apply
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderSessionContent = () => {
    const currentSession = getActiveSessionData();
    if (!currentSession) return null;

    switch (currentSession.type) {
      case "code":
        return <CodeView code={codeData.code} language={codeData.language} />;
      case "image":
        return <ImageView images={imageData.images} />;
      case "canvas":
        return <CanvasView canvasData={canvasData.canvasData} />;
      case "file":
        return <FileView files={fileData.files} />;
      case "langgraph":
        return <LangGraphView workspaceId={workspaceId} />;
      default:
        return (
          <div className="flex-1 flex flex-col justify-center items-center p-6 text-center">
            <h2 className="text-2xl font-semibold mb-4">Workspace Environment</h2>
            <p className="text-muted-foreground">View your workspace content using the icons above</p>
          </div>
        );
    }
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <div className="relative z-30">
        {isSidebarOpen && <div className="fixed inset-0 bg-black/50 backdrop-blur-sm transition-opacity" onClick={() => setIsSidebarOpen(false)} />}
        
        <div className={`fixed inset-y-0 left-0 flex transform transition-transform duration-300 ease-in-out 
            ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="relative h-full">
            <Button variant="ghost" size="icon" className="absolute top-4 right-4 z-50" onClick={() => setIsSidebarOpen(false)}>
              <X className="w-5 h-5" />
            </Button>
            <Sidebar />
          </div>
          
          <div className="h-full ml-5">
            <SpaceLeftSidebar className="h-full" />
          </div>
          
          <div className="h-full ml-5">
            <AgentSessions agentId={workspaceId} className="h-full" />
          </div>
        </div>
      </div>
      
      <div className="flex-1 flex flex-col w-full">
        <div className="absolute top-4 left-4 z-20 flex flex-col gap-2">
          <Button variant="ghost" size="icon" onClick={() => setIsSidebarOpen(!isSidebarOpen)}>
            <Menu className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setIsSettingsOpen(true)}>
            <Settings className="w-5 h-5" />
          </Button>
        </div>
        
        <div className="absolute top-24 left-4 z-20 flex flex-col gap-2">
          <SidebarIcons />
        </div>
        
        <div className="absolute top-4 right-4 z-20">
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full h-10 w-10 text-white/60 hover:text-white hover:bg-white/10"
            onClick={() => setIsWorkspaceDialogOpen(true)}
          >
            <Briefcase className="h-5 w-5" />
          </Button>
        </div>
        
        <main className="flex-1 overflow-auto relative p-4 sm:p-6 lg:p-8 flex items-center justify-center dark-gradient-bg">
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-[900px] h-[900px] rounded-full bg-gradient-to-br from-[#4a1e8a]/30 via-[#6933b5]/20 to-[#36207b]/10 opacity-70 blur-3xl" />
          </div>
          
          <div className="absolute inset-0 pointer-events-none">
            <div className="bg-texture w-[300px] h-[300px] top-[10%] right-[15%] bg-[#8046ea]/20"></div>
            <div className="bg-texture w-[250px] h-[250px] bottom-[15%] left-[10%] bg-[#a346ea]/20"></div>
            <div className="bg-texture w-[200px] h-[200px] top-[30%] left-[25%] bg-[#6246ea]/20"></div>
          </div>

          <div 
            ref={resizeRef}
            className={cn(
              "relative glass-panel rounded-lg overflow-hidden z-10",
              isFullscreen ? "fixed inset-4 z-50" : "max-h-[85vh] max-w-full"
            )}
            style={{ 
              width: isFullscreen ? "auto" : windowWidth,
              height: isFullscreen ? "auto" : "85vh"
            }}
          >
            <div className="h-10 bg-[#2d2d2d]/80 border-b border-[#7e57c2]/20 flex items-center justify-between px-3 backdrop-blur-md">
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5">
                  <div onClick={() => navigate(-1)} className="w-3 h-3 rounded-full bg-red-500 hover:bg-red-600 cursor-pointer" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500 hover:bg-yellow-600 cursor-pointer" onClick={() => setWindowWidth("800px")} />
                  <div onClick={() => setIsFullscreen(!isFullscreen)} className="w-3 h-3 rounded-full bg-green-500 hover:bg-green-600 cursor-pointer" />
                </div>
                <div className="ml-4 text-xs text-gray-300 select-none">
                  {workspaceType === 'canvas' ? 'Leonardo Canvas' : workspaceType === 'aiforge' ? 'AIForge Workspace' : 'Workspace'}
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="h-6 w-6 text-gray-400 hover:text-gray-300">
                  <Search className="h-3.5 w-3.5" />
                </Button>
                
                {workspaceType !== 'canvas' && (
                  <Popover open={isSessionsOpen} onOpenChange={setIsSessionsOpen}>
                    <PopoverTrigger asChild>
                      <Button variant="ghost" size="sm" className="text-sm text-gray-400 hover:text-gray-300 gap-1">
                        Sessions
                        <ChevronDown className="h-3.5 w-3.5" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-60 bg-[#2d2d2d]/90 backdrop-blur-md border-[#7e57c2]/30 text-gray-300 p-2" align="end">
                      <div className="text-xs font-medium mb-2 text-gray-400">Recent Sessions</div>
                      <ScrollArea className="h-[200px]">
                        {sessions.map((session) => (
                          <div 
                            key={session.id}
                            onClick={() => {
                              setActiveSession(session.id);
                              setIsSessionsOpen(false);
                            }}
                            className={cn(
                              "flex items-center gap-2 px-2 py-1.5 rounded cursor-pointer text-sm",
                              activeSession === session.id 
                                ? "bg-[#6246ea]/20 text-white" 
                                : "hover:bg-[#3a3a3a]/70 text-gray-300"
                            )}
                          >
                            {session.icon}
                            <div className="flex-1">
                              <div className="font-medium">{session.name}</div>
                              <div className="text-xs text-gray-400">
                                Last opened: {session.lastAccessed.toLocaleString()}
                              </div>
                            </div>
                          </div>
                        ))}
                      </ScrollArea>
                    </PopoverContent>
                  </Popover>
                )}
              </div>
            </div>
            
            {workspaceType === 'canvas' ? 
              renderCanvasWorkspaceContent() : 
             workspaceType === 'aiforge' ? 
              renderAIForgeWorkspaceContent() : 
              renderStandardWorkspaceContent()}
            
            <div 
              className="absolute top-0 right-0 w-1 h-full cursor-ew-resize opacity-0 hover:opacity-100"
              onMouseDown={startResize}
            >
              <div className="w-1 h-full bg-[#6246ea]"></div>
            </div>
          </div>
        </main>
      </div>

      <ChatSettingsDialog 
        open={isSettingsOpen} 
        onOpenChange={setIsSettingsOpen}
        onPersonaSelect={handlePersonaSelect}
        selectedPersona={selectedPersona}
      />
      
      <WorkspaceDialog 
        open={isWorkspaceDialogOpen}
        onOpenChange={setIsWorkspaceDialogOpen}
      />
    </div>
  );
};

export default WorkspaceRun;
