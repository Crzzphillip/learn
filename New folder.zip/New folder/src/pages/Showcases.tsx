
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Star, Users, Zap, ArrowRight, LayoutGrid, LayoutList } from "lucide-react";
import Sidebar from "@/components/Layout/Sidebar";
import { showcasesService } from "@/services/showcasesService";
import { Showcase } from "@/types/explore";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { useNavigate } from "react-router-dom";

const ShowcasesPage = () => {
  const navigate = useNavigate();
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const { data: allShowcases = [], isLoading: isLoadingShowcases } = useQuery({
    queryKey: ["showcases"],
    queryFn: showcasesService.getAllShowcases,
  });

  const { data: categories = [], isLoading: isLoadingCategories } = useQuery({
    queryKey: ["showcaseCategories"],
    queryFn: showcasesService.getAllCategories,
  });

  // Filter showcases based on selected category
  const filteredShowcases = selectedCategory === "all"
    ? allShowcases
    : allShowcases.filter(showcase => showcase.category === selectedCategory);

  // Group showcases by type for the tabs
  const showcasesByType = {
    all: filteredShowcases,
    agent: filteredShowcases.filter(showcase => showcase.type === 'agent'),
    workflow: filteredShowcases.filter(showcase => showcase.type === 'workflow'),
    workspace: filteredShowcases.filter(showcase => showcase.type === 'workspace'),
    app: filteredShowcases.filter(showcase => showcase.type === 'app'),
  };

  const navigateToShowcase = (id: string) => {
    navigate(`/showcase/${id}`);
  };

  const renderShowcaseCard = (showcase: Showcase) => (
    <Card 
      key={showcase.id} 
      className="overflow-hidden border-primary/10 hover:border-primary/30 transition-all duration-300 h-full cursor-pointer"
      onClick={() => navigateToShowcase(showcase.id)}
    >
      <div className="relative h-48 overflow-hidden bg-black/20">
        <img
          src={showcase.image}
          alt={showcase.title}
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
        />
        <div className="absolute top-4 left-4 px-2.5 py-1 bg-black/60 text-xs font-medium rounded-full backdrop-blur-sm">
          {showcase.category}
        </div>
        <div className="absolute top-4 right-4 px-2.5 py-1 bg-primary/20 text-primary text-xs font-medium rounded-full backdrop-blur-sm">
          {showcase.type.toUpperCase()}
        </div>
      </div>
      
      <CardContent className="p-5">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-xl font-semibold mb-2">{showcase.title}</h3>
            <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
              {showcase.description}
            </p>
          </div>
        </div>
        
        {showcase.stats && (
          <div className="flex items-center gap-4 mb-4">
            {showcase.stats.users && (
              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                <Users className="h-4 w-4" />
                <span>{showcase.stats.users.toLocaleString()}</span>
              </div>
            )}
            {showcase.stats.rating && (
              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                <Star className="h-4 w-4 text-yellow-400" />
                <span>{showcase.stats.rating}</span>
              </div>
            )}
            {showcase.stats.efficiency && (
              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                <Zap className="h-4 w-4 text-green-400" />
                <span>{showcase.stats.efficiency}%</span>
              </div>
            )}
          </div>
        )}
        
        <div className="space-y-2 mb-4">
          {showcase.features.map((feature, idx) => (
            <div key={idx} className="bg-black/20 px-3 py-2 rounded-lg text-sm">
              {feature}
            </div>
          ))}
        </div>
        
        {showcase.author && (
          <div className="flex items-center gap-2 mt-auto pt-2 border-t border-border/50">
            <Avatar className="h-6 w-6">
              <AvatarImage src={showcase.author.avatar} alt={showcase.author.name} />
              <AvatarFallback>{showcase.author.name[0]}</AvatarFallback>
            </Avatar>
            <span className="text-sm">{showcase.author.name}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );

  const renderShowcaseList = (showcase: Showcase) => (
    <Card 
      key={showcase.id} 
      className="overflow-hidden border-primary/10 hover:border-primary/30 transition-all duration-300 cursor-pointer flex"
      onClick={() => navigateToShowcase(showcase.id)}
    >
      <div className="w-64 h-full bg-black/20 flex-shrink-0">
        <img
          src={showcase.image}
          alt={showcase.title}
          className="w-full h-full object-cover"
        />
      </div>
      
      <CardContent className="p-5 flex flex-col justify-between flex-1">
        <div>
          <div className="flex justify-between mb-2">
            <div>
              <h3 className="text-xl font-semibold">{showcase.title}</h3>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary">
                  {showcase.type.toUpperCase()}
                </span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-black/60 text-foreground backdrop-blur-sm">
                  {showcase.category}
                </span>
              </div>
            </div>
            
            {showcase.stats && (
              <div className="flex items-center gap-3">
                {showcase.stats.users && (
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Users className="h-4 w-4" />
                    <span>{showcase.stats.users.toLocaleString()}</span>
                  </div>
                )}
                {showcase.stats.rating && (
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Star className="h-4 w-4 text-yellow-400" />
                    <span>{showcase.stats.rating}</span>
                  </div>
                )}
                {showcase.stats.efficiency && (
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Zap className="h-4 w-4 text-green-400" />
                    <span>{showcase.stats.efficiency}%</span>
                  </div>
                )}
              </div>
            )}
          </div>
          
          <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
            {showcase.description}
          </p>
        </div>
        
        <div className="flex justify-between items-center">
          <div className="flex gap-2">
            {showcase.features.slice(0, 2).map((feature, idx) => (
              <div key={idx} className="bg-black/20 px-3 py-1 rounded-lg text-xs">
                {feature}
              </div>
            ))}
            {showcase.features.length > 2 && (
              <div className="bg-black/20 px-3 py-1 rounded-lg text-xs">
                +{showcase.features.length - 2} more
              </div>
            )}
          </div>
          
          {showcase.author && (
            <div className="flex items-center gap-2">
              <Avatar className="h-6 w-6">
                <AvatarImage src={showcase.author.avatar} alt={showcase.author.name} />
                <AvatarFallback>{showcase.author.name[0]}</AvatarFallback>
              </Avatar>
              <span className="text-sm">{showcase.author.name}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 overflow-auto">
          <div className="container py-12">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h1 className="text-4xl font-bold mb-2">AI Showcases</h1>
                <p className="text-muted-foreground">
                  Explore real-world applications of AI agents, workflows, workspaces, and apps
                </p>
              </div>
              
              <div className="flex items-center gap-4">
                <Button 
                  variant="outline" 
                  size="icon" 
                  className={viewMode === "grid" ? "bg-primary/10 text-primary" : ""}
                  onClick={() => setViewMode("grid")}
                  aria-label="Grid View"
                >
                  <LayoutGrid className="h-5 w-5" />
                </Button>
                <Button 
                  variant="outline" 
                  size="icon" 
                  className={viewMode === "list" ? "bg-primary/10 text-primary" : ""}
                  onClick={() => setViewMode("list")}
                  aria-label="List View"
                >
                  <LayoutList className="h-5 w-5" />
                </Button>
              </div>
            </div>
            
            {/* Category filters */}
            <div className="flex flex-wrap gap-2 mb-8">
              <Button
                variant={selectedCategory === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory("all")}
              >
                All Categories
              </Button>
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Button>
              ))}
            </div>
            
            {/* Type tabs */}
            <Tabs defaultValue="all" className="mb-8">
              <TabsList className="mb-4">
                <TabsTrigger value="all">All Showcases</TabsTrigger>
                <TabsTrigger value="agent">Agents</TabsTrigger>
                <TabsTrigger value="workflow">Workflows</TabsTrigger>
                <TabsTrigger value="workspace">Workspaces</TabsTrigger>
                <TabsTrigger value="app">Apps</TabsTrigger>
              </TabsList>
              
              {Object.entries(showcasesByType).map(([type, showcases]) => (
                <TabsContent key={type} value={type}>
                  {isLoadingShowcases || isLoadingCategories ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {[1, 2, 3, 4, 5, 6].map((i) => (
                        <div key={i} className="h-[450px] rounded-lg bg-card/40 animate-pulse"></div>
                      ))}
                    </div>
                  ) : showcases.length === 0 ? (
                    <div className="text-center py-12">
                      <h3 className="text-lg font-medium">No showcases found</h3>
                      <p className="text-muted-foreground">Try selecting a different category or type</p>
                    </div>
                  ) : (
                    <div className={
                      viewMode === "grid" 
                        ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" 
                        : "flex flex-col gap-4"
                    }>
                      {showcases.map((showcase) => 
                        viewMode === "grid" 
                          ? renderShowcaseCard(showcase) 
                          : renderShowcaseList(showcase)
                      )}
                    </div>
                  )}
                </TabsContent>
              ))}
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShowcasesPage;
